/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1999 by M. Wangen.
**
**   Info: A library for spline tables
**   Date: Version 1.2, October 1992
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <lib_input.h>

#ifndef _LIB_TABLE_H_
#define _LIB_TABLE_H_

#define ABC_MAX_TABLE_SIZE 250

typedef struct table_def
{
     int size;            /* The size of the table. */
     char *name;          /* The table name. */
     double *x;           /* The table x-values. */
     double *y;           /* The table y-values. */
     double *y2;          /* Coefficients in cubic spline. */
     int is_equidist;     /* Equal distance between the x-coords. */
} AbcTable;

int abc_test_table_lib(int argc, char **argv);
AbcTable *abc_create_table(char const *name, int size, double *xcoord, double *ycoord);
AbcTable *abc_read_and_create_table(AbcInput *in);
int abc_read_two_table_coords(AbcInput *in, double *x, double *y);
void abc_delete_table(AbcTable **pp);
double abc_get_table_linear_interpolate(AbcTable *table, double x);
double abc_get_table_func(AbcTable *table, double x);
double abc_get_d_table_func(AbcTable *table, double x);
double abc_get_dd_table_func(AbcTable *table, double x);
int abc_binary_search(double x, double *xcoord, int n);
double abc_get_table_xmin(AbcTable *table);
double abc_get_table_xmax(AbcTable *table);
double abc_get_table_ymin(AbcTable *table);
double abc_get_table_ymax(AbcTable *table);
double abc_get_table_boundary(AbcTable *table, double x);
void abc_write_only_table_values(FILE *out, AbcTable *table);
void abc_write_table(FILE *out, char const *margin1, char const *margin2, AbcTable *table);
void abc_dump_table_values_to_file(AbcTable *table, const char *filename, int size);
void abc_dump_table_values(AbcTable *table, FILE *out, int out_size);

#endif

