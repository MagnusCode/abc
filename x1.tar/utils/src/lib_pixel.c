/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2000-2002 by M. Wangen.
**
**   Info: Functions for pixel processing
**   Date: Version 1.0, September 2000
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_pixel.h>

static void swap_ints(int *a, int *b);
static double get_interval_transform(AbcPixelBuffer *pixbuf, double hue);
static double get_value(double x0, double x1, double x2, double xu, double yu);
/***
static double get_discret_hue_value(double value, double max_steps);
***/

static int 
     debug_line_mapping = FALSE; 

int abc_test_pixel_buffer(
     int argc,
     char **argv)
{
     int nx = 32;
     int ny = 32;
     AbcPixelBuffer *pixbuf = abc_create_pixel_buffer(nx, ny);

     abc_read_pixel_options(argc, argv);
     abc_set_pixel_buffer_user_space(pixbuf, 50.0, 50.0, 150.0, 150.0);
     abc_draw_pixel_line_hls(pixbuf,  75.0,  75.0, 125.0, 125.0, 6.0, 0.5, 1.0);
     abc_draw_pixel_line_hls(pixbuf,  75.0, 125.0, 125.0,  75.0, 8.0, 0.5, 1.0);
     abc_draw_pixel_line_hls(pixbuf,  0.0, 75.0,  200.0,  75.0, 7.0, 0.5, 1.0);
     abc_insert_triangle_in_pixel_buffer_const_hue(pixbuf, 75.0, 75.0, 100.0, 100.0, 125.0, 75.0, 0.5);
     abc_insert_triangle_in_pixel_buffer_hue(pixbuf, 75.0, 75.0, 100.0, 50.0, 125.0, 75.0, 0.9, 0.0, 0.9);
     abc_show_pixel_buffer_09(pixbuf, stdout);
     abc_delete_pixel_buffer(&pixbuf);

     return 0;
}


void abc_read_pixel_options(
     int argc,
     char **argv)
{
     int i;

     for (i = 1; i < argc; i++)
          if (ABC_MATCH(argv[i], "-debug")) debug_line_mapping = TRUE;
          else
               fprintf(stderr, "[pix_read_options] %s is an unknown option!", argv[i]);
}


AbcPixelBuffer *abc_create_pixel_buffer(
     int nx,
     int ny)
{
     int size = nx * ny;
     AbcPixelBuffer *pixbuf;
     int i;

     if (size < 4)
     {
          fprintf(stderr, "[pix_create_pixel_buffer] Too few pixels!");
          return NULL;
     }

     ABC_NEW_OBJECT(pixbuf, AbcPixelBuffer);
     ABC_NEW_ARRAY(pixbuf->buffer1, double, size);
     ABC_NEW_ARRAY(pixbuf->buffer2, double, size);
     ABC_NEW_ARRAY(pixbuf->buffer3, double, size);
     pixbuf->nx = nx;
     pixbuf->ny = ny;

     abc_set_pixel_buffer_user_space(pixbuf, 0.0, 0.0, 1.0, 1.0);
     abc_set_pixel_color_intervals(pixbuf, 0.0, 240.0, 0);

     for (i = 0; i < size; i++)
     {
          pixbuf->buffer1[i] = 0.0;
          pixbuf->buffer2[i] = 0.0;
          pixbuf->buffer3[i] = 0.0;
     }

     return pixbuf;
}


void abc_delete_pixel_buffer(
     AbcPixelBuffer **pixbuf)
{
     AbcPixelBuffer *pb = *pixbuf;

     if (pb == NULL) return;
     ABC_FREE_ARRAY(pb->buffer1);
     ABC_FREE_ARRAY(pb->buffer2);
     ABC_FREE_ARRAY(pb->buffer3);
     ABC_FREE(pb);
     *pixbuf = NULL; 
}


void abc_set_pixel_buffer_user_space(
     AbcPixelBuffer *pixbuf,
     double x0,
     double y0,
     double x1,
     double y1)
{
     if ((x0 > x1) or (y0 > y1))
          ABC_ERROR_RETURN("[abc_set_pixel_buffer_user_space] Error in user space coordinates!\n");

     pixbuf->x0_user_space = x0;
     pixbuf->y0_user_space = y0;
     pixbuf->x1_user_space = x1;
     pixbuf->y1_user_space = y1;
}


void abc_set_pixel_color_intervals(
     AbcPixelBuffer *pixbuf,
     double hue_min,
     double hue_max,
     int steps)
{
     pixbuf->hue_min = hue_min;
     pixbuf->hue_max = hue_max;
     pixbuf->hue_steps = steps;
}


void abc_show_pixel_buffer_09(
     AbcPixelBuffer *pixbuf,
     FILE *out)
{
     double min_value = 1.e+26;
     double max_value = -1.e+26;
     double dv = 0.0;
     double *buffer1 = pixbuf->buffer1;
     int nx = pixbuf->nx;
     int ny = pixbuf->ny;
     int size = nx * ny;
     int is_zero = FALSE;
     int i, j, k, v;

     for (i = 0; i < size; i++)
     {
          if (buffer1[i] > max_value) max_value = buffer1[i];
          if (buffer1[i] < min_value) min_value = buffer1[i];
     }

     dv = max_value - min_value;

     if (dv < 1.0e-12)
          is_zero = TRUE; 

     for (j = 0; j < ny; j++)
     {
          fprintf(out, "%3d:", j);

          for (i = 0; i < nx; i++)
          {
               if (is_zero)
                    v = 0;
               else
               {
                    k = j * nx + i;
                    v = (int) (9.0 * (buffer1[k] - min_value) / dv);
               }

               fprintf(out, "%d", v);
          }

          fprintf(out, "\n");
     }
}


void abc_set_pixel_hls(
     AbcPixelBuffer *pixbuf,
     double x,
     double y,
     double hue,
     double lightness,
     double saturation)
{
     int nx, ny, i, j, k;
     double dx, dy;

     if (pixbuf == NULL) 
          ABC_ERROR_RETURN("[abc_set_pixel_hls] NULL-pointer!");

     dx = abc_get_pixel_dx(pixbuf);
     dy = abc_get_pixel_dy(pixbuf);

     i = (int) ((x - pixbuf->x0_user_space) / dx);
     j = (int) ((y - pixbuf->y0_user_space) / dy);

     nx = pixbuf->nx;
     ny = pixbuf->ny;

     if (i < 0 or j < 0) return;
     if (i >= nx or j >= ny) return;

     k = j * nx + i;

     pixbuf->buffer1[k] = hue; 
     pixbuf->buffer2[k] = lightness; 
     pixbuf->buffer3[k] = saturation; 
}


void abc_draw_pixel_line_hls(
     AbcPixelBuffer *pixbuf,
     double x1,
     double y1,
     double x2,
     double y2,
     double hue,
     double lightness,
     double saturation)
{
     double dx = abc_get_pixel_dx(pixbuf);
     double dy = abc_get_pixel_dy(pixbuf);
     double x0_user = pixbuf->x0_user_space;
     double y0_user = pixbuf->y0_user_space;
     double ax, ay, x, y;
     int i, i1, i2, j, j1, j2;

     if (ABC_ABS(x2 - x1) > ABC_ABS(y2 - y1))
     {
          ax = (y2 - y1) / (x2 - x1);

          i1 = (int) ((x1 - x0_user) / dx);
          i2 = (int) ((x2 - x0_user) / dx);

          if (i1 > i2) swap_ints(&i1, &i2);

          for (i = i1; i <= i2; i++)
          {
               x = (i + 0.5) * dx + x0_user;
               y = ax * (x - x1) + y1;
               abc_set_pixel_hls(pixbuf, x, y, hue, lightness, saturation);
          }
     }
     else
     {
          ay = (x2 - x1) / (y2 - y1);

          j1 = (int) ((y1 - y0_user) / dy);
          j2 = (int) ((y2 - y0_user) / dy);

          if (j1 > j2) swap_ints(&j1, &j2);

          for (j = j1; j <= j2; j++)
          {
               y = (j + 0.5) * dy + y0_user;
               x = ay * (y - y1) + x1;
               abc_set_pixel_hls(pixbuf, x, y, hue, lightness, saturation);
          }
     }
}


double abc_get_pixel_dx(
     AbcPixelBuffer *pixbuf)
{
     double dx;

     if (pixbuf == NULL)
          ABC_ERROR_EXIT("[abc_get_pixel_dx] NULL-pointer!");

     dx = (pixbuf->x1_user_space - pixbuf->x0_user_space) / pixbuf->nx;
     return dx;
}


double abc_get_pixel_dy(
     AbcPixelBuffer *pixbuf)
{
     double dy;

     if (pixbuf == NULL)
          ABC_ERROR_EXIT("[abc_get_pixel_dy] NULL-pointer!");

     dy = (pixbuf->y1_user_space - pixbuf->y0_user_space) / pixbuf->ny;
     return dy;
}


static void swap_ints(
     int *ai,
     int *bi)
{
     int ci = *ai;
     *ai = *bi;
     *bi = ci;
}


void abc_fill_pixel_buffer_black(
     AbcPixelBuffer *pixbuf)
{
     int i, size;
     double *buffer1;

     if (pixbuf == NULL)
          ABC_ERROR_EXIT("[abc_fill_pixel_buffer_black] NULL-pointer!");

     size = pixbuf->nx * pixbuf->ny;
     buffer1 = pixbuf->buffer1;

     for (i = 0; i < size; i++)
          buffer1[i] = -1.0;
}


void abc_fill_pixel_buffer_white(
     AbcPixelBuffer *pixbuf)
{
     int i, size;
     double *buffer1;

     if (pixbuf == NULL)
          ABC_ERROR_EXIT("[abc_fill_pixel_buffer_white] NULL-pointer!");

     size = pixbuf->nx * pixbuf->ny;
     buffer1 = pixbuf->buffer1;

     for (i = 0; i < size; i++)
          buffer1[i] = 361.0;
}


void abc_insert_triangle_in_pixel_buffer_const_hue(
     AbcPixelBuffer *pixbuf,
     double x0,
     double y0,
     double x1,
     double y1,
     double x2,
     double y2,
     double hue)
{
     abc_insert_triangle_in_pixel_buffer_hue(pixbuf, x0, y0, x1, y1, x2, y2, hue, hue, hue);
}


void abc_insert_triangle_in_pixel_buffer_hue(
     AbcPixelBuffer *pixbuf,
     double x0,
     double y0,
     double x1,
     double y1,
     double x2,
     double y2,
     double h0,
     double h1,
     double h2)
{
     double lightness = 0.5;
     double saturation = 1.0;
     double dx = abc_get_pixel_dx(pixbuf);
     double dy = abc_get_pixel_dy(pixbuf);
     double xmax = ABC_MAX(x0, ABC_MAX(x1, x2));
     double xmin = ABC_MIN(x0, ABC_MIN(x1, x2));
     double ymax = ABC_MAX(y0, ABC_MAX(y1, y2));
     double ymin = ABC_MIN(y0, ABC_MIN(y1, y2));
     double hue0, hue1, x, y, du, xu, yu;
     double size, xsize, ysize, i, j;

     xsize = (xmax - xmin) / dx;
     ysize = (ymax - ymin) / dy;

     size = 1.5 * ABC_MAX(xsize, ysize);
     du = 1.0 / (size - 1);

     for (j = 0; j < size; j++)
          for (i = 0; i < size - j; i++)
          {
               xu = i * du;
               yu = j * du;
               x = get_value(x0, x1, x2, xu, yu);
               y = get_value(y0, y1, y2, xu, yu);
               hue0 = get_value(h0, h1, h2, xu, yu);
               hue1 = get_interval_transform(pixbuf, hue0);
               /***
               hue2 = get_discret_hue_value(hue1, 256.0);
               ***/
               abc_set_pixel_hls(pixbuf, x, y, hue1, lightness, saturation);
          }
}


static double get_interval_transform(
     AbcPixelBuffer *pixbuf,
     double hue)
{
     double hmin = pixbuf->hue_min;
     double hmax = pixbuf->hue_max;
     int steps = pixbuf->hue_steps;
     double dh, h2;
     int ii;

     if (steps < 2) return hue;
     if (ABC_ABS(hmax - hmin) < 0.001) return hue;

     dh = (hmax - hmin) / (steps - 1);
     ii = (int) ((hue - hmin) / dh);
     h2 = ii * dh + hmin;

     return h2;
}


static double get_value(
     double x0,
     double x1,
     double x2,
     double xu,
     double yu)
{
     double v = x0 * (1.0 - xu - yu) + x1 * xu + x2 * yu;
     return v;
}


/***
static double get_discret_hue_value(
     double value,
     double max_steps)
{
     double dv = 360.0 / (max_steps - 1.0);
     int index = (int) (value / dv);
     double new_value = index * dv;
     return new_value;
}
***/
