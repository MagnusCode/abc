/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1987-2002 by M. Wangen.
**
**   Info: A small input library
**   Date: Version 6.0, November 1993
**
**  $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_INPUT_H_
#define _LIB_INPUT_H_

#define ABC_CONST_VAR 1
#define ABC_NON_CONST_VAR 0

#define ABC_CONST_MACRO 1
#define ABC_NON_CONST_MACRO 0

#define ABC_INPUT_WORD 1024
#define ABC_INPUT_BUFFER 8192

typedef struct _AbcInput_ AbcInput;

struct _AbcInput_ {             /* Input session definition. */
     FILE *file;                 /* File descriptor. */
     char file_name[ABC_INPUT_WORD]; /* File name. */
     char buffer[ABC_INPUT_BUFFER];  /* Buffer for put-back-chars. */
     int bp;                     /* Buffer pointer. */
     int char_no;                /* Character number. */
     int line_no;                /* Line number. */
     int is_open;                /* True if stream is open. */
     AbcInput *prev_in;         /* Previous input-def for nested input. */
     void (*read_input)(AbcInput *in); /* Read input inside if-branch. */
};

int abc_interpreter_main(int argc, char **argv);
void abc_init_input_main(void);
int abc_interpret_input_file(const char *file_name);
void abc_run_command_loop(AbcInput *in);
void abc_run_command_string(AbcInput *in, const char *string);
void abc_test_input_lib(void);
int abc_begin_input(AbcInput *in, const char *filename);
void abc_init_input_def(AbcInput *in, FILE *newfile, const char *filename);
void abc_copy_input_def(AbcInput *in1, AbcInput *in2);
void abc_read_default(AbcInput *in);
void abc_init_input_vars(void);
void abc_delete_input_lib(void);
void abc_end_input(AbcInput *in);
void abc_get_input_lib_options(int *argc, char **argv);
void abc_show_input_lib_options(FILE *out);
const char *get_promt(void);
void abc_set_read_function(AbcInput *in, void (*read)(AbcInput *in));
void abc_set_comment_delimiters(int c1, int c2);
void abc_set_comment_skip(int on_off);
void abc_set_macro_expansion(int on_off);
int abc_getch(AbcInput *in);
void abc_ungetch(AbcInput *in, int c);
int abc_is_next_word(AbcInput *in, const char *wanted);
void abc_skip_rest_of_line(AbcInput *in);
int abc_skip_line(AbcInput *in);
int abc_skip_until_char(AbcInput *in, int ch);
int abc_skip_until_word(AbcInput *in, const char *word);
void abc_skip_comment_lines(AbcInput *in, int comment_char);
int abc_get_input_line_number(AbcInput *in);
int abc_get_input_char_number(AbcInput *in);
FILE *abc_get_input_file_descriptor(AbcInput *in);
char *abc_get_input_file_name(AbcInput *in);
int abc_get_field(AbcInput *in, char *field, int lim);
int abc_get_word(AbcInput *in, char *word, int lim);
int abc_get_string(AbcInput *in, char *string, int lim);
int abc_get_int(AbcInput *in, int *value);
int abc_get_float(AbcInput *in, float *value);
int abc_get_double(AbcInput *in, double *value);
int abc_get_expression(AbcInput *in, double *numb);
int abc_get_simple_expr(AbcInput *in, double *numb);
int abc_get_term(AbcInput *in, double *term);
int abc_get_factor(AbcInput *in, double *factor);
int abc_get_var_or_func(AbcInput *in, double *numb);
int abc_get_var_def(AbcInput *in, int constant);
int abc_get_macro_def(AbcInput *in, int constant);
int abc_get_condition(AbcInput *in, int *cond);
int abc_get_logical_op(AbcInput *in, int *op);
void abc_look_ahead(AbcInput *in);
void abc_skip_until_key_word(AbcInput *in, const char *key_word);
void abc_skip_until_end_of_string(AbcInput *in);
int abc_end_of_if_branch(AbcInput *in);
int abc_search_for_next_branch(AbcInput *in);
int abc_skip_blanks_and_comments(AbcInput *in);
int abc_read_key_word_and_number(AbcInput *in, const char *keyword, double *numb);
int abc_read_key_word_and_yes_no(AbcInput *in, const char *keyword, int *yes_no);
void abc_read_error(AbcInput *in, const char *text);
void abc_read_error2(AbcInput *in, const char *text1, const char *text2);
int abc_run_built_in(AbcInput *in, const char *name);
void abc_show_variables(FILE *out);
void abc_show_macro_defs(FILE *out);
void abc_show_math_funcs(FILE *out);
void abc_show_built_ins(FILE *out);
void abc_show_strings(FILE *out);
void abc_what_is_next_word(AbcInput *in, FILE *out);
void abc_try_to_expand_text(AbcInput *in);
int abc_next_int(AbcInput *in, int *value);
int abc_next_alphanum_word(AbcInput *in, char *field, int lim);
int abc_expand_macro(AbcInput *in, char *word);
int abc_expand_var(AbcInput *in, char *name);
int abc_get_macro_args(AbcInput *in, const char *name, int n);
int abc_get_old_macro_args(AbcInput *in, int n);
int abc_get_new_macro_args(AbcInput *in, const char *name, int n);
void abc_put_back_word(AbcInput *in, const char *word);
void abc_put_back_int(AbcInput *in, int numb, const char *format);
void abc_put_back_double(AbcInput *in, double numb, const char *format);
void abc_report_abc_input_error(AbcInput *in, FILE *out, const char *text);
void abc_input_error(AbcInput *in, const char *text);
void abc_install_macro(const char *name, int argc, const char *def, int constant);
void abc_install_var(const char *name, double value, int constant);
void abc_install_all_math_funcs(void);
void abc_install_math_func(const char *name, double (*func)(double x));
void abc_install_string(const char *name, const char *def);
void abc_install_file_desc(const char *desc_name, const char *file_name, FILE *out, int mode);
FILE *abc_get_output_file_stream(AbcInput *in);
void abc_install_all_built_ins(void);
void abc_install_built_in(const char *name, void (*command)(AbcInput *in), const char *comment);

#endif
