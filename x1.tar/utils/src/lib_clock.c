/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1999 by M. Wangen.
**
**   Info: A library for measuring CPU-time
**   Date: Version 2.0, February 1990
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifndef WIN32
#include <sys/types.h>
#include <sys/param.h>
#endif

#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_clock.h>


void abc_test_clock(
     void)
{
     int i, j;
     double a = 0.5, b = 2.0, c = 0.0;
     AbcClock *my_clock = abc_create_clock("Test clock");

     for (i = 0; i < 9; i++)
     {
          abc_start_clock(my_clock);

          for (j = 0; j < 5000000; j++)
               c = a * b;

          abc_stop_clock(my_clock);
          abc_show_clock(my_clock, stdout);
     }

     abc_delete_clock(&my_clock);
     ABC_UNUSED_PARAMETER(c);
}


int abc_is_clock_running(
     AbcClock *clock_def)
{
     return clock_def->is_running;
}


AbcClock *abc_create_clock(
     char const *name) 
{
     AbcClock *clock_def;

     ABC_NEW_OBJECT(clock_def, AbcClock);
     ABC_NEW_ARRAY(clock_def->name, char, strlen(name)+1);
     strcpy(clock_def->name, name);
     abc_reset_clock(clock_def);
     return clock_def;
}


void abc_delete_clock(
     AbcClock **clock_def) 
{
     if (clock_def == NULL) return;
     if ((*clock_def) == NULL) return;
     ABC_FREE((*clock_def)->name);
     ABC_FREE((*clock_def));
     *clock_def = NULL;
}


void abc_reset_clock(
     AbcClock *clock_def) 
{
     clock_def->is_running = FALSE;
     clock_def->start_time = 0;
     clock_def->stop_time = 0;
     clock_def->total_time = 0;
}


void abc_start_clock(
     AbcClock *clock_def) 
{
     if (clock_def->is_running)
     {
          fprintf(stderr, "[abc_start_clock] Clock \"%s\" is running!\n", clock_def->name);
          return;
     }

     clock_def->start_time = abc_get_time_in_sec();
     clock_def->is_running = TRUE;
}


void abc_stop_clock(
     AbcClock *clock_def) 
{
     if (not clock_def->is_running)
     {
          fprintf(stderr, "[abc_stop_clock] Clock \"%s\" is not running!\n", clock_def->name);
          return;
     }

     clock_def->stop_time = abc_get_time_in_sec();
     clock_def->used_time = clock_def->stop_time - clock_def->start_time;
     clock_def->total_time += clock_def->used_time;
     clock_def->is_running = FALSE;
}


void abc_read_clock(
     AbcClock *clock_def, /* The clock. */
     int *time_used,      /* Time used since clock was started last time (sec). */
     int *time_total)     /* Total time measured with this clock (sec). */
{
     int is_running = clock_def->is_running;

     if (is_running) abc_stop_clock(clock_def);
     *time_used = clock_def->used_time;
     *time_total = clock_def->total_time;
     if (is_running) abc_start_clock(clock_def);
}


void abc_show_clock(
     AbcClock *clock_def,
     FILE *fp) 
{
     int i, time_used, time_total;

     if (fp == NULL) return;

     abc_read_clock(clock_def, &time_used, &time_total);

     fprintf(fp, "%s ", clock_def->name);

     for (i = 0; i < 30 - (int) strlen(clock_def->name); i++)
          fprintf(fp, ".");
     fprintf(fp, " ");

     abc_print_clock_time(fp, time_used);

     fprintf(fp, " (total ");
     abc_print_clock_time(fp, time_total);
     fprintf(fp, ") ");
     fprintf(fp, "\n");
}


void abc_print_clock_used_time(
     AbcClock *clock_def,
     FILE *fp)
{
     int time_used, time_total;

     abc_read_clock(clock_def, &time_used, &time_total);
     abc_print_clock_time(fp, time_used);
}


void abc_print_clock_total_time(
     AbcClock *clock_def,
     FILE *fp)
{
     int time_used, time_total;

     abc_read_clock(clock_def, &time_used, &time_total);
     abc_print_clock_time(fp, time_total);
}


void abc_print_clock_time(
     FILE *fp,
     int sec) 
{
     int hours, min;

     if (fp == NULL) return;

     hours = sec / 3600;
     sec = sec - 3600 * hours;
     min = sec / 60;
     sec = sec - 60 * min;

     fprintf(fp, "%d", hours);
     fprintf(fp, (min < 10) ? ":0%1d" : ":%2d", min);
     fprintf(fp, (sec < 10) ? ":0%1d" : ":%2d", sec);
}


int abc_get_time_in_sec(
     void)
{
     double t1 = ((double) clock()) / ((double) CLOCKS_PER_SEC);
     return (int) t1;
}

