/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2012 by M. Wangen.
**
**   Info: Functions for computing principal components
**   Date: Version 1.1, October 2012
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_utils.h>
#include <lib_math.h>
#include <lib_mech.h>
#include <lib_params.h>

static void print_separator(FILE *out);
static double get_rest_for_root(AbcTensor3x3 *T, double x1);
static const char *get_solver_name(int version);


static AbcTensor3x3 current_stress;

/*
**  ===============================
**  PART 1: Demo and test functions
**  ===============================
*/

int abc_main_test_mech_functions(
     int argc, 
     char **argv)
{
     int P1 = 1;
     AbcStressTest data;
     AbcParams *params = NULL;

     params = abc_new_params(16);
     abc_def_param_group(params, "Params:", P1);

     abc_def_boolean_param(params, &data.is_debugging, "deb", "Debug test", 0, P1);
     abc_def_int_param(params, &data.solver_version,  "solver", "-", "Solver version", 1, 1, 2, P1);

     abc_def_double_param(params, &data.x1,  "x1", "-", "Coordinate x1", 1.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &data.x2,  "x2", "-", "Coordinate x2", 1.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &data.x3,  "x3", "-", "Coordinate x3", 1.0, -1.0e+32, 1.0e+32, P1);                                                      
     abc_def_double_param(params, &data.S1,  "S1", "-", "Sigma S1", 1.0e+8, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &data.S2,  "S2", "-", "Sigma S2", 2.0e+8, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &data.S3,  "S3", "-", "Sigma S3", 3.0e+8, -1.0e+32, 1.0e+32, P1);                                                      
     abc_def_double_param(params, &data.c0,  "c0", "-", "Cohesion", 3.0e+5, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &data.phi, "phi", "-", "Angle of internal friction", 30.0, 1.0, 89.0, P1);                                                      
     abc_read_all_params_by_args(params, argc, argv);
     abc_test_principal_directions(&data);
     abc_delete_params(&params);

     return 1;
}


void abc_test_principal_directions(
     AbcStressTest *input)
{
     AbcTensor3x3 sigma;
     AbcFractureCond frac;
     double S_vec[3], R[3][3], S_diag[3][3], S_full[3][3];
     double I1, I2, I3;
     int mode;

     abc_init_tensor3x3(&sigma);
     sigma.is_debugging = input->is_debugging;

     /* Sort S1, S2 and S3. */

     S_vec[0] = input->S1;
     S_vec[1] = input->S2;
     S_vec[2] = input->S3;

     abc_vec3_sort(S_vec);

     /* Make a diagonal stress tensor (principal system) . */

     abc_mat3x3_set_zero(S_diag);
     S_diag[0][0] = S_vec[2];
     S_diag[1][1] = S_vec[1];
     S_diag[2][2] = S_vec[0];

     /* Make a rotation matrix. */

     abc_make_test_rotation_matrix(input->x1, input->x2, input->x3, R, input->is_debugging);
     abc_mat3x3_rotate(S_diag, R, S_full);

     print_separator(stdout);
     abc_mat3x3_show(stdout, "S_diag", S_diag);

     /* Make the rotated stress state. */
     
     abc_set_tensor3x3(&sigma,
          S_full[0][0], S_full[1][1], S_full[2][2],
          S_full[0][1], S_full[1][2], S_full[0][2]);

     print_separator(stdout);
     abc_show_tensor3x3(stdout, "S_full", &sigma);

     /* Find the principal stress components. */

     if (input->solver_version == 2)
          abc_make_principal_components_II(&sigma);
     else
          abc_make_principal_components_I(&sigma);

     print_separator(stdout);
     printf("Solver: %d (%s)\n", input->solver_version, 
          get_solver_name(input->solver_version));
     print_separator(stdout);
     printf("Principal stress: (in=out)\n");
     printf("S1: %g=%g\n", S_vec[2], sigma.S1);
     printf("S2: %g=%g\n", S_vec[1], sigma.S2);
     printf("S3: %g=%g\n", S_vec[0], sigma.S3);

     /* Check invariants are the same for the two stress states. */

     I1 =  input->S1 + input->S2 + input->S3;
     I2 = (input->S1 * input->S2) + (input->S2 * input->S3) + (input->S3 * input->S1);
     I3 =  input->S1 * input->S2 * input->S3;

     print_separator(stdout);
     printf("Checking the invariants of the principal tensor: (in=out)\n");
     printf("I1: %12.6e=%12.6e\n", I1, sigma.I1);
     printf("I2: %12.6e=%12.6e\n", I2, sigma.I2);
     printf("I3: %12.6e=%12.6e\n", I3, sigma.I3);

     /* Check if the stress state implies fracturing. */

     frac.cohesion = input->c0;
     frac.angle_oif = input->phi;
     frac.tension_cutoff = 0.0;

     print_separator(stdout);
     mode = abc_is_fracture_state(&frac, &sigma);
     printf("Fracture=%d, mode=\"%s\"\n", mode, abc_get_name_of_fracture_mode(mode));
     abc_plot_fracture_envelope_and_stress(&frac, &sigma, "xstress");
}


void abc_make_test_rotation_matrix(
     double x1,
     double x2,
     double x3,
     double R[3][3],
     int is_debugging)
{
     double n1[3], n2[3], n3[3], l2, Rt[3][3], I[3][3];

     n1[0] = x1;
     n1[1] = x2;
     n1[2] = x3;

     n2[0] = x2;
     n2[1] = -x1;
     n2[2] = 0.0;


     l2 = abc_vec3_dot_vec3(n2, n2);

     if (l2 < 0.001)
          ABC_ERROR_RETURN("[abc_make_test_rotation_matrix] Point is too close to (0,0)!");

     abc_vec3_normalize(n1);
     abc_vec3_normalize(n2);
     abc_vec3_cross_vec3(n1, n2, n3);

     if (is_debugging)
     {
          print_separator(stdout);
          abc_vec3_show(stdout, "n1", n1);
          abc_vec3_show(stdout, "n2", n2);
          abc_vec3_show(stdout, "n3", n3);

          print_separator(stdout);
          printf("|n1| = %g\n", abc_vec3_dot_vec3(n1, n1));
          printf("|n2| = %g\n", abc_vec3_dot_vec3(n2, n2));
          printf("|n3| = %g\n", abc_vec3_dot_vec3(n3, n3));

          print_separator(stdout);
          printf("n1 dot n2 = %g\n", abc_vec3_dot_vec3(n1, n2));
          printf("n2 dot n3 = %g\n", abc_vec3_dot_vec3(n2, n3));
          printf("n3 dot n1 = %g\n", abc_vec3_dot_vec3(n3, n1));
     }

     R[0][0] = n1[0];   R[0][1] = n1[1];   R[0][2] = n1[2];
     R[1][0] = n2[0];   R[1][1] = n2[1];   R[1][2] = n2[2];
     R[2][0] = n3[0];   R[2][1] = n3[1];   R[2][2] = n3[2];

     if (is_debugging)
     {
          print_separator(stdout);
          abc_mat3x3_show(stdout, "R", R);

          abc_mat3x3_transpose(R, Rt);
          abc_mat3x3_mul_mat3x3(R, Rt, I);

          print_separator(stdout);
          abc_mat3x3_show(stdout, "RRt", I);
     }

     if (not abc_mat3x3_is_rotation_matrix(R, 3))
          ABC_ERROR_RETURN("[abc_make_test_rotation_matrix] R isn't a rotation matrix!");
}


static void print_separator(
     FILE *out)
{
     fprintf(out, "------------------\n");
}

/*
**  ===============================
**  PART 2: 3x3 Tensor functions
**  ===============================
*/

int abc_is_equal_tensor3x(
     AbcTensor3x3 *A,
     AbcTensor3x3 *B)
{
     if (A->dim != B->dim) return FALSE;
     if (ABC_ABS(A->s11 - B->s11) > 1.0e-12) return FALSE;
     if (ABC_ABS(A->s22 - B->s22) > 1.0e-12) return FALSE;
     if (ABC_ABS(A->s33 - B->s33) > 1.0e-12) return FALSE;
     if (ABC_ABS(A->s12 - B->s12) > 1.0e-12) return FALSE;
     if (ABC_ABS(A->s23 - B->s23) > 1.0e-12) return FALSE;
     if (ABC_ABS(A->s13 - B->s13) > 1.0e-12) return FALSE;

     return TRUE;
}


void abc_init_tensor3x3(
     AbcTensor3x3 *T)
{
     T->is_debugging = FALSE;
     T->dim = 3;
     
     T->s11 = 0.0;
     T->s22 = 0.0;
     T->s33 = 0.0;
     T->s12 = 0.0;
     T->s23 = 0.0;
     T->s13 = 0.0;

     T->S1 = 0.0;
     T->S2 = 0.0;
     T->S3 = 0.0;

     T->I1 = 0.0;
     T->I2 = 0.0;
     T->I3 = 0.0;
}


void abc_set_tensor3x3_by_vec(
     AbcTensor3x3 *T,
     int dim,
     double *vec)
{
     switch (dim)
     {
          case 1:
          T->dim = 1;
          T->s11 = vec[0];
          return;

          case 2:
          T->dim = 2;
          T->s11 = vec[0];
          T->s22 = vec[1];
          T->s12 = vec[2];
          break;

          case 3:
          T->dim = 3;
          T->s11 = vec[0];
          T->s22 = vec[1];
          T->s33 = vec[2];
          T->s12 = vec[3];
          T->s23 = vec[4];
          T->s13 = vec[5];
          break;

          default: ABC_ERROR_EXIT("[abc_set_tensor3x3_by_vec] Illegal dim!");
     }
}


void abc_set_tensor3x3_by_negative_vec(
     AbcTensor3x3 *T,
     int dim,
     double *vec)
{
     switch (dim)
     {
          case 1:
          T->dim = 1;
          T->s11 = - vec[0];
          return;

          case 2:
          T->dim = 2;
          T->s11 = - vec[0];
          T->s22 = - vec[1];
          T->s12 = - vec[2];
          break;

          case 3:
          T->dim = 3;
          T->s11 = - vec[0];
          T->s22 = - vec[1];
          T->s33 = - vec[2];
          T->s12 = - vec[3];
          T->s23 = - vec[4];
          T->s13 = - vec[5];
          break;

          default: ABC_ERROR_EXIT("[abc_set_tensor3x3_by_negative_vec] Illegal dim!");
     }
}


void abc_set_tensor3x3(
     AbcTensor3x3 *T,
     double s11,
     double s22,
     double s33,
     double s12,
     double s23,
     double s13)
{
     T->dim = 3;
     T->s11 = s11;
     T->s22 = s22;
     T->s33 = s33;
     T->s12 = s12;
     T->s23 = s23;
     T->s13 = s13;
}


void abc_set_sub2x2_tensor3x3(
     AbcTensor3x3 *T,
     double s11,
     double s22,
     double s12)
{
     T->dim = 2;
     T->s11 = s11;
     T->s22 = s22;
     T->s33 = 0.0;
     T->s12 = s12;
     T->s23 = 0.0;
     T->s13 = 0.0;
}


void abc_show_tensor3x3(
     FILE *out,
     const char *name,
     AbcTensor3x3 *T)
{
     fprintf(out, "%s=[\n", name);
     fprintf(out, "%g, %g, %g;\n", T->s11, T->s12, T->s13);
     fprintf(out, "%g, %g, %g;\n", T->s12, T->s22, T->s23);
     fprintf(out, "%g, %g, %g]\n", T->s13, T->s23, T->s33);
}


double abc_get_invariant_I1(
     AbcTensor3x3 *T)
{
     double I1 = T->s11 + T->s22 + T->s33;
     return I1;
}


double abc_get_invariant_I2(
     AbcTensor3x3 *T)
{
     double I2 = 0.0;
     I2 += (T->s11 * T->s22) - (T->s12 * T->s12);
     I2 += (T->s22 * T->s33) - (T->s23 * T->s23);
     I2 += (T->s33 * T->s11) - (T->s13 * T->s13);
     return I2;
}


double abc_get_invariant_I3(
     AbcTensor3x3 *T)
{
     double I3 = 0.0;
     I3 += T->s11 * T->s22 * T->s33;
     I3 -= T->s11 * T->s23 * T->s23;
     I3 += T->s12 * T->s23 * T->s13;
     I3 -= T->s12 * T->s12 * T->s33;
     I3 += T->s13 * T->s12 * T->s23;
     I3 -= T->s13 * T->s22 * T->s13;
     return I3;
}


static double get_rest_for_root(
     AbcTensor3x3 *T,
     double x1)
{
     double x2 = x1 * x1;
     double x3 = x2 * x1;
     double rest = x3 - (T->I1 * x2) + (T->I2 * x1) - T->I3;
     return rest;
}


static const char *get_solver_name(
     int version)
{
     if (version == 1) return "eigenvalue solver";
     if (version == 2) return "solution by formula";
     return "unknown solver";
}


void abc_make_principal_components_I(
     AbcTensor3x3 *T)
{
     double aa, bb, cc, dd, vec3[3];
     double epsilon = 1.0;  /* Pa */
     AbcComplex x1, x2, x3;

     abc_complex_zero(&x1);
     abc_complex_zero(&x2);
     abc_complex_zero(&x3);

     T->I1 = abc_get_invariant_I1(T);
     T->I2 = abc_get_invariant_I2(T);
     T->I3 = abc_get_invariant_I3(T);

     aa =  1.0;
     bb = -T->I1;
     cc =  T->I2;
     dd = -T->I3;

     if (T->dim == 2)
          abc_solve_quadratic(aa, bb, cc, &x1, &x2);
     else
          abc_solve_cubic(aa, bb, cc, dd, &x1, &x2, &x3);
     
     if (T->is_debugging)
     {
          print_separator(stdout);
          printf("a=%g, b=%g, c=%g, d=%g\n", aa, bb, cc, dd);

          print_separator(stdout);
          abc_check_cubic_root(aa, bb, cc, dd, "sum1 = ", &x1);
          abc_check_cubic_root(aa, bb, cc, dd, "sum2 = ", &x2);
          abc_check_cubic_root(aa, bb, cc, dd, "sum3 = ", &x3);
     
          print_separator(stdout);
          abc_complex_print(stdout, "x1 = ", &x1);
          abc_complex_print(stdout, "x2 = ", &x2);
          abc_complex_print(stdout, "x3 = ", &x3);

          print_separator(stdout);
          printf("rest1=%g\n", get_rest_for_root(T, x1.re));
          printf("rest2=%g\n", get_rest_for_root(T, x2.re));
          printf("rest3=%g\n", get_rest_for_root(T, x3.re));
     }

     /* Only real roots? */

     if (ABC_ABS(x1.im) > epsilon) 
          printf("[abc_make_principal_components_I] s1.im=%g\n", x1.im);

     if (ABC_ABS(x2.im) > epsilon) 
          printf("[abc_make_principal_components_I] s2.im=%g\n", x2.im);

     if (ABC_ABS(x3.im) > epsilon) 
          printf("[abc_make_principal_components_I] s3.im=%g\n", x3.im);

     /* Sorting the principal stress. */

     vec3[0] = x1.re;
     vec3[1] = x2.re;
     vec3[2] = x3.re;

     /* S1 and S3 are always the larges and the smallest principal comp. */

     if (T->dim == 2) 
          vec3[2] = x2.re;

     abc_vec3_sort(vec3);

     T->S1 = vec3[2];
     T->S2 = vec3[1];
     T->S3 = vec3[0];
}


void abc_make_principal_components_II(
     AbcTensor3x3 *T)
{
     /*
     ** Version II is based on: 
     ** http://www.continuummechanics.org/cm/principalstress.html
     ** https://en.wikiversity.org/wiki/Principal_stresses
     **
     ** which are also store here:
     ** $HOME/ps/doc-solution-for-principal-stresses.pdf
     ** $HOME/ps/doc-computation-principal-stresses.pdf
     */
     double term1, term2, term3, Q, R, X, F, phi;

     T->I1 = abc_get_invariant_I1(T);
     T->I2 = abc_get_invariant_I2(T);
     T->I3 = abc_get_invariant_I3(T);

     if (T->dim == 1)
     {
          T->S1 = T->s11;
          T->S2 = T->s11;
          T->S3 = T->s11;
          return;
     }

     if (T->dim == 2)
     { 
          term1 = (T->s11 + T->s22) / 2.0;
          term2 = (T->s11 - T->s22) / 2.0;
          term3  = sqrt((term2 * term2) + (T->s12 * T->s12));

          T->S1 = term1 + term3;
          T->S2 = term1 - term3;
          T->S3 = T->S2;

          return;
     }

     if (T->dim == 3)
     {
          Q = ((3.0 * T->I2) - (T->I1 * T->I1)) / 9.0;
          if (Q > -1.0e-32) Q = -1.0e-32;
          R = ((2.0 * T->I1 * T->I1 * T->I1) - (9.0 * T->I1 * T->I2) + (27.0 * T->I3)) / 54.0;
          X = R / sqrt( - Q * Q * Q);
          if (X >  1.0) X =  1.0;
          if (X < -1.0) X = -1.0;
          F = 2.0 * sqrt(- Q);
          phi = acos(X);

          T->S1 = (T->I1 / 3.0) + F * cos((phi / 3.0));
          T->S2 = (T->I1 / 3.0) + F * cos((phi + 2.0 * ABC_PI) / 3.0);
          T->S3 = (T->I1 / 3.0) + F * cos((phi + 4.0 * ABC_PI) / 3.0);

          /* Increasing order: S3 <= S2 <= S1 */
          abc_sort_three_doubles(&T->S3, &T->S2, &T->S1);

          return;
     }

     printf("[abc_make_principal_components_II] Illegal dim! (dim=%d)\n", T->dim);
}

/*
**  ================================
**  PART 3: Fracture state functions
**  ================================
*/

int abc_is_fracture_state2x2(
     AbcFractureCond *FC,
     double s11,
     double s22,
     double s12)
{
     abc_init_tensor3x3(&current_stress);
     abc_set_sub2x2_tensor3x3(&current_stress, s11, s22, s12);
     abc_make_principal_components_I(&current_stress);

     return abc_is_fracture_state(FC, &current_stress);
}


int abc_is_fracture_state3x3(
     AbcFractureCond *FC,
     double s11,
     double s22,
     double s33,
     double s12,
     double s23,
     double s13)
{
     abc_init_tensor3x3(&current_stress);
     abc_set_tensor3x3(&current_stress, s11, s22, s33, s12, s23, s13);
     abc_make_principal_components_I(&current_stress);

     return abc_is_fracture_state(FC, &current_stress);
}


int abc_is_fracture_state_S1_S3(
     AbcFractureCond *FC,
     double S1,
     double S3)
{
     abc_init_tensor3x3(&current_stress);

     current_stress.S1 = S1;
     current_stress.S3 = S3;

     return abc_is_fracture_state(FC, &current_stress);
}


int abc_is_fracture_state(
     AbcFractureCond *FC,
     AbcTensor3x3 *T)
{
     double angle, radius, length, offset, max_radius, S1, S3;
     int is_fracture = ABC_FRACTURE_NONE;

     if (T->S1 < T->S3)
     {
          S1 = T->S3;
          S3 = T->S1;
     }
     else
     {
          S1 = T->S1;
          S3 = T->S3;
     }

     angle = (ABC_PI / 180.0) * FC->angle_oif;
     radius = 0.5 * (S1 - S3);
     length = 0.5 * (S1 + S3);
     offset = FC->cohesion / tan(angle);
     max_radius = (length + offset) * sin(angle);

     if (radius > max_radius)
          is_fracture = ABC_FRACTURE_SHEAR;
     else if (S3 < FC->tension_cutoff)
          is_fracture = ABC_FRACTURE_TENSION;
     else
          is_fracture = ABC_FRACTURE_NONE;
      
     if (T->is_debugging)
     {
          printf("angle_oif=%g, cohesion=%g, tension_offset=%g\n", 
               FC->angle_oif, FC->cohesion, FC->tension_cutoff); 
          printf("max_radius=%g, radius=%g, fracture=%d\n", 
               max_radius, radius, is_fracture);
     }

     return is_fracture;
}


const char *abc_get_name_of_fracture_mode(
     int type)
{
     if (type == ABC_FRACTURE_NONE) return "-";
     if (type == ABC_FRACTURE_SHEAR) return "shear fracture";
     if (type == ABC_FRACTURE_TENSION) return "tension fracture";
     return "unknown fracture type";
}


AbcTensor3x3 *abc_get_current_fracture_stress(
     void)
{
     return &current_stress;
}


void abc_print_fracture_stress(
     AbcTensor3x3 *sigma,
     FILE *out)
{
     if (sigma->dim == 2)
     {
          fprintf(out, "s11=%g, s22=%g, s12=%g\n", sigma->s11, sigma->s22, sigma->s12);
     }
     else
     {
          fprintf(out, "s11=%g, s22=%g, s33=%g\n", sigma->s11, sigma->s22, sigma->s33);
          fprintf(out, "s12=%g, s23=%g, s13=%g\n", sigma->s12, sigma->s23, sigma->s13);
     }

     fprintf(out, "S1=%g, S2=%g, S3=%g\n", sigma->S1, sigma->S2, sigma->S3);
     fprintf(out, "I1=%g, I2=%g, I3=%g\n", sigma->I1, sigma->I2, sigma->I3);
}


void abc_plot_fracture_envelope_and_stress(
     AbcFractureCond *FC,
     AbcTensor3x3 *T,
     const char *filename)
{
     double angle = (ABC_PI / 180.0) * FC->angle_oif;
     double mu = tan(angle);
     double radius = 0.5 * (T->S1 - T->S3);
     double center = 0.5 * (T->S1 + T->S3);
     double min_alpha = ABC_PI;
     double max_alpha = 2.0 * ABC_PI;
     double step = (max_alpha - min_alpha) / 64.0;
     double alpha, x, y;
     
     double x1 = -FC->cohesion / mu;
     double y1 = 0.0;
     double x2 = T->S1 * 1.1;
     double y2 = mu * x2 + FC->cohesion;

     FILE *out = abc_new_file(filename, ".xy");

     fprintf(out, "#( x:[Pa]  y:[Pa] )#\n");
     fprintf(out, "#( the fracture envelope )#\n");
     fprintf(out, "%g %g\n", x1, y1);
     fprintf(out, "%g %g\n", x2, y2);
     
     fprintf(out, "#( the Mohr-circle )#\n");

     for (alpha = min_alpha; alpha <= max_alpha; alpha += step)
     {
          x = radius * cos(alpha) + center;
          y = - radius * sin(alpha);
          fprintf(out, "%g %g\n", x, y);
     }

     fclose(out);
     printf("(Fracture envelope and Mohr-circle is written to: %s.xy)\n", filename);

     out = abc_new_file(filename, ".post");
     fprintf(out, "define PlotFractureState 0\n");
     fprintf(out, "{\n");
     fprintf(out, "    initpictures\n");
     fprintf(out, "    rd xstress.xy\n");
     fprintf(out, "    setxaxis{autoscale=No, min=0, max=%g}\n", x2);
     fprintf(out, "    setyaxis{autoscale=No, min=0, max=%g}\n", x2);
     fprintf(out, "    setplotcurve{xmonoton=Yes}\n");
     fprintf(out, "    ng tl pl\n");
     fprintf(out, "}\n");
     fprintf(out, "\n");
     fprintf(out, "win PlotFractureState\n");
     fprintf(out, "\n");

     fclose(out);
     printf("(Post definitions are written to: %s.post)\n", filename);
}

/*
**  ========================
**  PART 4: Useful functions
**  ========================
*/

double abc_get_G_parameter(
     double E,
     double nu)
{
     double G = E / (2.0 * (1.0 + nu));
     return G;
}


double abc_get_lambda_parameter(
     double E,
     double nu)
{
     double lambda = nu * E / ((1.0 + nu) * (1.0 - 2.0 * nu));
     return lambda;
}

