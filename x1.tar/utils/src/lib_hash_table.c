/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1993-2002 by M. Wangen.
**
**   Info: A general hash table
**   Date: Version 1.0, November 1993
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_alloc.h>
#include <lib_utils.h>
#include <lib_hash_table.h>

static void delete_string_item(void **buffer);
static void print_string_item(FILE *out, AbcHashTableItem *item);
static int compare(const void *a0, const void *b0);
static char *save_string(char const *string);
static void print_any_type(FILE *out, void const *buffer);
static void delete_any_type(void **buffer);

/*
**   \chapter{An example}
**
**   The following type and variables are for the
**   demo example shown in "main/abc_test_hash_table"
*/

typedef struct AnyType {
     char *name;
     char *data;
} AnyType;

int abc_test_hash_table(
     void)
{
     int i;
     int table_size = 100;
     AnyType *item = NULL;
     AbcHashTable *table = abc_create_hash_table(table_size, "Test hash table", delete_any_type);
     char const *item_name[] = {"Blue", "Green", "Red", "Yellow", "Pink", ""};
     char const *some_name[] = {"Black", "Yellow", "Grey", "Green", "White", ""};

     /* Insert some objects of "AnyType" into the table. */

     for (i = 0; strcmp(item_name[i], ""); i++)
     {
          ABC_NEW_OBJECT(item, AnyType);
          item->name = save_string(item_name[i]);
          item->data = save_string(" anything ... ");
          abc_hash_table_insert(table, item_name[i], (void *) item);
     }

     /* Look up objects of "AnyType". */

     for (i = 0; strcmp(some_name[i], ""); i++)
     {
          item = (AnyType *) abc_hash_table_lookup(table, some_name[i]);
          printf("Key: %-7s Item: %s\n", some_name[i],
               (item == NULL) ? "(nothing)" : item->data);
     }

     abc_print_hash_table(stdout, table, print_any_type);
     abc_delete_hash_table(&table);

     return 0;
}


static void print_any_type(
     FILE *out,
     void const *buffer)
{
     AnyType const *item = (AnyType const *) buffer;
     fprintf(out, " is %s\n", item->data);
}


static void delete_any_type(
     void **buffer)
{
     AnyType *item = (AnyType *) *buffer;
     printf("Deallocates storage for %s\n", item->name);
     ABC_FREE(item->name);
     ABC_FREE(item->data);
     ABC_FREE(item);
     *buffer = NULL;
}

/*
**   \chapter{Hash table functions}
*/


AbcHashTable *abc_create_hash_table(
     int size,
     char const *table_name,
     ABC_HASH_DELETE_FUNC delete_buffer_func)
{
     int i;
     AbcHashTable *table;

     ABC_NEW_OBJECT(table, AbcHashTable);
     ABC_NEW_ARRAY(table->table, AbcHashTableItem *, size);
     table->delete_buffer_func = delete_buffer_func;
     table->name = save_string(table_name);
     table->size = size;

     for (i = 0; i < size; i++)
          table->table[i] = NULL;

     return table;
}


void abc_delete_hash_table(
     AbcHashTable **pp)
{
     int i;
     AbcHashTable *table;
     AbcHashTableItem *item, *junk;

     if (pp == NULL) return;
     table = *pp;
     if (table == NULL) return;

     for (i = 0; i < table->size; i++)
          for (item = table->table[i]; item != NULL; )
          {
               junk = item;
               item = item->next;

               ABC_FREE(junk->name);

               if (table->delete_buffer_func)
                    table->delete_buffer_func(&(junk->buffer));
               else
                    ABC_FREE(junk->buffer);

               ABC_FREE(junk->name);
               ABC_FREE(junk);
          }

     ABC_FREE(table->table);
     ABC_FREE(table->name);
     ABC_FREE(table);
     table = NULL;
}


int abc_get_hash_table_index(
     int size,
     char const *string)
{
     int i, value;

     for (i = 0, value = 0; string[i] != '\0'; i++)
          value += string[i];

     return value % size;
}


void abc_hash_table_insert(
     AbcHashTable *table,
     char const *name,
     void *anything)
{
     int index;
     AbcHashTableItem *item;

     if (table == NULL)
     {
          fprintf(stderr, "[abc_hash_table_insert] NULL-table!\n");
          return;
     }

     if ((item = abc_get_hash_table_item(table, name)) == NULL)
     {
          ABC_NEW_OBJECT(item, AbcHashTableItem);
          item->name = save_string(name);
          index = abc_get_hash_table_index(table->size, name);
          item->next = table->table[index];
          table->table[index] = item;
     }
     else if (table->delete_buffer_func)
          table->delete_buffer_func(&(item->buffer));
     else
          ABC_FREE(item->buffer);

     item->buffer = anything;
}


AbcHashTableItem *abc_get_hash_table_item(
     AbcHashTable *table,
     char const *name)
{
     int index = 0;
     AbcHashTableItem *item = NULL;

     if (table == NULL)
          return NULL;

     index = abc_get_hash_table_index(table->size, name);

     for (item = table->table[index]; item != NULL; item = item->next)
          if (strcmp(name, item->name) == 0)
               return item;

     return NULL;
}


void *abc_hash_table_lookup(
     AbcHashTable *table,
     char const *name)
{
     AbcHashTableItem *item = NULL;

     if (table == NULL) return NULL;
     item = abc_get_hash_table_item(table, name);
     if (item != NULL) return item->buffer;
     return NULL;
}


void abc_print_hash_table(
     FILE *out,
     AbcHashTable *table,
     ABC_HASH_PRINT_FUNC print_buffer)
{
     int i;
     AbcHashTableItem **sorted_table = abc_create_sorted_hash_table(table);

     if (print_buffer != NULL)
     {
          for (i = 0; sorted_table[i] != NULL; i++)
          {
               fprintf(stdout, "Name: %s", sorted_table[i]->name);
               (*print_buffer)(out, sorted_table[i]->buffer);
          }
     }
     else
     {
          for (i = 0; sorted_table[i] != NULL; i++)
               fprintf(out, "name: %s\n", sorted_table[i]->name);
     }

     ABC_FREE(sorted_table);
}


void abc_print_hash_table_items(
     FILE *out, 
     AbcHashTable *table, 
     ABC_HASH_PRINT_FUNC_ITEM print_func)
{
     int i;
     AbcHashTableItem **sorted_table;

     if (print_func == NULL)
          return;

     sorted_table = abc_create_sorted_hash_table(table);

     for (i = 0; sorted_table[i] != NULL; i++)
          print_func(out, sorted_table[i]);

     ABC_FREE(sorted_table);
}


int abc_get_number_of_items_in_hash_table(
    AbcHashTable *table)
{
     int i;
     int counter = 0;
     AbcHashTableItem *item = NULL;

     if (table == NULL) 
          return 0;

     for (i = 0; i < table->size; i++)
          for (item = table->table[i]; item != NULL; item = item->next)
               counter++;

     return counter;
}


AbcHashTableItem **abc_create_sorted_hash_table(
     AbcHashTable *table)
{
     AbcHashTableItem *item = NULL;
     AbcHashTableItem **sorted_table = NULL;
     size_t size_of_item = sizeof(AbcHashTableItem *);
     size_t counter = (size_t) abc_get_number_of_items_in_hash_table(table);
     int i;
    
     ABC_NEW_ARRAY(sorted_table, AbcHashTableItem *, (counter + 1));
     sorted_table[counter] = NULL;

     for (i = counter = 0; i < table->size; i++)
          for (item = table->table[i]; item != NULL; item = item->next)
               sorted_table[counter++] = item;

     qsort((void *) sorted_table, counter, size_of_item, compare);

     return sorted_table;
}

/*
**   ======================
**   Hash table for strings
**   ======================
*/

AbcHashTable *abc_create_string_hash_table(
     int size,
     const char *name)
{
     return abc_create_hash_table(size, name, delete_string_item);
}


static void delete_string_item(
     void **buffer)
{
     const char *item = (const char *) *buffer;
     ABC_FREE(item);
     *buffer = NULL;
}


void abc_set_hash_table_string_item(
     AbcHashTable *table,
     const char *key,
     const char *value)
{
     const char *item = (const char *) abc_hash_table_lookup(table, key);

     if (item != NULL)
     {
          ABC_FREE(item);
          item = abc_save_string(value);
     }
     else
     {
          item = abc_save_string(value);
          abc_hash_table_insert(table, key, (void *) item);
     }
}


void abc_print_string_hash_table(
     FILE *out, 
     AbcHashTable *table)
{
     int size = 2 * abc_get_number_of_items_in_hash_table(table);

     fprintf(out, "strings %s %d\n", table->name, size);
     abc_print_hash_table_items(out, table, print_string_item);
}


static void print_string_item(
     FILE *out,
     AbcHashTableItem *item)
{
     const char *string = (const char *) item->buffer;
     fprintf(out, "\"%s\" \"%s\"\n", item->name, string);
}

/*
**   =================
**   Private functions
**   =================
*/

static int compare(
     const void *a0,
     const void *b0)
{
     AbcHashTableItem *a = *(AbcHashTableItem **) a0;
     AbcHashTableItem *b = *(AbcHashTableItem **) b0;
     return strcmp(a->name, b->name);
}


static char *save_string(
     char const *string)
{
     char *p = NULL;
     ABC_NEW_ARRAY(p, char, strlen(string)+1);
     strcpy(p, string);
     return p;
}

