/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998-2011 by M. Wangen.
**
**   Info: Library for allocation of memory, which will not be reallocated
**   Date: Version 1.1, December 2011
**
**   $Id$
*/   

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <lib_macros.h>
#include <lib_alloc_once.h>

static void print_sum(int sum);
static void free_pointer_index(int i);

static AbcMemory
     private_memory = {TRUE, 0, {0}, {NULL}, {NULL}};

static AbcMemory
     *current = &private_memory;

/*
**   Functions with names in singular --
**   needed for compatibility with old programs.
*/

void abc_test_allocated_once1(
     void)
{
     int size = 1024;

     int *i1 = abc_alloc_ints_once(size);
     int *i2 = abc_alloc_ints_once(size);
     int *i3 = abc_alloc_ints_once(size);

     char *c1 = abc_alloc_chars_once(size);
     char *c2 = abc_alloc_chars_once(size);
     char *c3 = abc_alloc_chars_once(size);

     double *d1 = abc_alloc_doubles_once(size);
     double *d2 = abc_alloc_doubles_once(size);
     double *d3 = abc_alloc_doubles_once(size);

     printf("\nTHIS WHAT WE HAVE!\n");
     abc_list_allocated_once(stdout);

     printf("\nDELETE 3 ARRAYS!\n");
     abc_free_allocated_pointer((void *) i2);
     abc_free_allocated_pointer((void *) c2);
     abc_free_allocated_pointer((void *) d2);
     abc_list_allocated_once(stdout);

     printf("\nREALLOCATE 3 ARRAYS!\n");
     i2 = abc_alloc_ints_once(size);
     c2 = abc_alloc_chars_once(size);
     d2 = abc_alloc_doubles_once(size);
     abc_list_allocated_once(stdout);

     printf("\nALLOCATE 3 MORE INT-ARRAYS!\n");
     i1 = abc_alloc_ints_once(size);
     i2 = abc_alloc_ints_once(size);
     i3 = abc_alloc_ints_once(size);
     abc_list_allocated_once(stdout);

     printf("\nDELETE ALL!\n");
     abc_delete_all_allocated_once();
     abc_list_allocated_once(stdout);

     ABC_UNUSED_PARAMETER(i1);
     ABC_UNUSED_PARAMETER(i3);
     ABC_UNUSED_PARAMETER(c1);
     ABC_UNUSED_PARAMETER(c3);
     ABC_UNUSED_PARAMETER(d1);
     ABC_UNUSED_PARAMETER(d3);
}


void abc_test_allocated_once2(
     void)
{
     static int n1 = 1, n2 = 2, n3 = 3;
     /* Make two group id's. */
     void *gr1 = (void *) &n1;
     void *gr2 = (void *) &n2;
     void *gr3 = (void *) &n3;

     int size = 1024;

     int *i1 = abc_alloc_ints_once2(gr1, size, 1);
     int *i2 = abc_alloc_ints_once2(gr2, size, 2);
     int *i3 = abc_alloc_ints_once2(gr3, size, 3);

     char *c1 = abc_alloc_chars_once2(gr1, size, 'a');
     char *c2 = abc_alloc_chars_once2(gr2, size, 'b');
     char *c3 = abc_alloc_chars_once2(gr3, size, 'c');

     double *d1 = abc_alloc_doubles_once2(gr1, size, 1.1);
     double *d2 = abc_alloc_doubles_once2(gr2, size, 2.2);
     double *d3 = abc_alloc_doubles_once2(gr3, size, 3.3);

     printf("\nTHIS WHAT WE HAVE!\n");
     abc_list_allocated_once(stdout);

     printf("\nDELETE GROUP II\n");
     abc_delete_all_allocated_once2(gr2);
     abc_list_allocated_once(stdout);
     
     printf("\nDELETE GROUP I\n");
     abc_delete_all_allocated_once2(gr1);
     abc_list_allocated_once(stdout);

     printf("\nALLOCATE MORE VARS TO GROUP III\n");
     i2 = abc_alloc_ints_once2(gr3, size, 9);
     c2 = abc_alloc_chars_once2(gr3, size, '9');
     d2 = abc_alloc_doubles_once2(gr3, size, 9.9);
     abc_list_allocated_once(stdout);

     printf("\nDELETE GROUP III\n");
     abc_delete_all_allocated_once2(gr3);

     printf("\nDELETE ALL\n");
     abc_delete_all_allocated_once();
     abc_list_allocated_once(stdout);

     ABC_UNUSED_PARAMETER(i1);
     ABC_UNUSED_PARAMETER(i2);
     ABC_UNUSED_PARAMETER(i3);
     ABC_UNUSED_PARAMETER(c1);
     ABC_UNUSED_PARAMETER(c2);
     ABC_UNUSED_PARAMETER(c3);
     ABC_UNUSED_PARAMETER(d1);
     ABC_UNUSED_PARAMETER(d2);
     ABC_UNUSED_PARAMETER(d3);
}


void abc_alloc_once_init(
     AbcMemory *memory)
{
     int i;

     memory->is_verbose = TRUE;
     memory->n_array = 0;

     for (i = 0; i < ABC_MAX_POINTERS; i++)
     {
          memory->array_of_pointers[i] = NULL;
          memory->array_of_group_id[i] = NULL;
          memory->array_of_sizes[i] = 0;
     }
}


AbcMemory *abc_get_current_alloc_once(
     void)
{
     return current;
}


void abc_set_current_alloc_once(
     AbcMemory *memory)
{
     current = memory;
}


void abc_set_default_alloc_once(
     void)
{
     current = &private_memory;
}


int *abc_alloc_int_once(
     int number)
{
     return abc_alloc_ints_once(number);
}


char *abc_alloc_char_once(
     int number)
{
     return abc_alloc_chars_once(number);
}

/*
**   The standard alloc-functions.
**
**   void *calloc(size_t nmemb, size_t size);
**   void *malloc(size_t size);
*/

char *abc_alloc_chars_once(
     int number)
{
     return abc_alloc_chars_once2(NULL, number, '\0');
}


char *abc_alloc_chars_once2(
     void *id,
     int number,
     char value)
{    
     int i;
     char *array = (char *) abc_calloc_once((size_t) number, sizeof(char), id);
     
     for (i = 0;i < number; i++)
          array[i] = value;
     
     return array;
}


int *abc_alloc_ints_once(
     int number)
{
     return abc_alloc_ints_once2(NULL, number, 0);
}


int *abc_alloc_ints_once2(
     void *id,
     int number,
     int value)
{    
     int i;
     int *array = (int *) abc_calloc_once((size_t) number, sizeof(int), id);
     
     for (i = 0;i < number; i++)
          array[i] = value;
     
     return array;
}


float *abc_alloc_floats_once(
     int number)
{    
     return abc_alloc_floats_once2(NULL, number, 0.0);
}


float *abc_alloc_floats_once2(
     void *id,
     int number,
     float value)
{
     int i;
     float *array = (float *) abc_calloc_once((size_t) number, sizeof(float), id);

     for (i = 0;i < number; i++)
          array[i] = value;

     return array;
}


double *abc_alloc_doubles_once(
     int number)
{
     return abc_alloc_doubles_once2(NULL, number, 0.0);
}


double *abc_alloc_doubles_once2(
     void *id,
     int number,
     double value)
{    
     int i; 
     double *array = (double *) abc_calloc_once((size_t) number, sizeof(double), id);
     
     for (i = 0;i < number; i++)
          array[i] = value;
     
     return array;
}


void *abc_calloc_once(
     size_t n_nmemb,
     size_t size,
     void *id)
{
     return abc_malloc_once(n_nmemb * size, id);
}


void *abc_malloc_once(
     size_t n_bytes,
     void *id)
{
     void *pointer;

     pointer = malloc(n_bytes);
     abc_store_allocated_pointer(pointer, (int) n_bytes, id);

     return pointer;
}


void abc_store_allocated_pointer(
     void *pointer,
     int n_bytes,
     void *id)
{
     int i = abc_get_unused_index_alloc_once();
     current->array_of_group_id[i] = id;
     current->array_of_pointers[i] = pointer;
     current->array_of_sizes[i] = n_bytes;
}


void abc_free_allocated_pointer(
     void *pointer)
{
     int i = abc_get_pointer_index_alloc_once(pointer);

     if (i >= 0)
          free_pointer_index(i);
     else
          printf("[abc_free_allocated_once] Not allocated once!");
}


void abc_delete_memory_allocated_once(
     AbcMemory *memory)
{
     AbcMemory *saved = abc_get_current_alloc_once();
     abc_set_current_alloc_once(memory);
     abc_delete_all_allocated_once();
     abc_set_current_alloc_once(saved);
}


void abc_delete_all_allocated_once2(
     void *id)
{
     int i;
     int sum = 0;

     if (current->n_array < 1)
          return;

     for (i = 0; i < current->n_array; i++)
     {
          if (current->array_of_pointers[i] == NULL) continue;
          if (current->array_of_group_id[i] != id) continue;
          sum += current->array_of_sizes[i];
          free_pointer_index(i);
     }

     if (current->is_verbose)
          print_sum(sum);
}


void abc_delete_all_allocated_once(
     void)
{
     int i;
     int sum = 0;

     if (current->n_array < 1)
          return;

     for (i = 0; i < current->n_array; i++)
     {
          if (current->array_of_pointers[i] == NULL) continue;
          sum += current->array_of_sizes[i];
          free_pointer_index(i);
     }

     current->n_array = 0;

     if (current->is_verbose)
          print_sum(sum);
}


static void print_sum(
     int sum)
{
     if (sum > 1024 * 1024)
     {
          double MB = ((double) sum) / (1024.0 * 1024.0);
          printf("(has freed %d bytes or %.1f MB of memory)\n", sum, MB);
     }
     else if (sum > 1024)
     {
          double kB = ((double) sum) / (1024.0);
          printf("(has freed %d bytes or %.1f kB of memory)\n", sum, kB);
     }
     else
     {
          printf("(has freed %d bytes of memory)\n", sum);
     }
}


void abc_list_allocated_once(
     FILE *out)
{
     int i;
     int sum = 0;

     for (i = 0; i < current->n_array; i++)
     {
          fprintf(out, "%3d) ptr=%9p, size=%9d, group=%9p\n", i, 
               current->array_of_pointers[i], 
               current->array_of_sizes[i],
               current->array_of_group_id[i]);

          sum += current->array_of_sizes[i];
     }

     fprintf(out, "total allocated = %d bytes\n", sum);
}


int abc_get_bytes_allocated_once(
     void)
{
     int i;
     int sum = 0;

     for (i = 0; i < current->n_array; i++)
          sum += current->array_of_sizes[i];

     return sum;
}


int abc_get_unused_index_alloc_once(
     void)
{
     int i, k;

     for (i = 0; i < current->n_array; i++)
          if (current->array_of_pointers[i] == NULL)
               return i;

     k = current->n_array;

     if (k >= ABC_MAX_POINTERS)
     {
          fprintf(stderr, "[abc_allocated_once ...] Is full!");
          return -1;
     }

     current->n_array++;
     return k;
}


int abc_get_pointer_index_alloc_once(
     void *pointer)
{
     int i;

     for (i = 0; i < current->n_array; i++)
          if (current->array_of_pointers[i] == pointer)
               return i;

     return -1;
}


static void free_pointer_index(
     int i)
{
     if (i < 0) return;
     free(current->array_of_pointers[i]);
     current->array_of_group_id[i] = NULL;
     current->array_of_pointers[i] = NULL;
     current->array_of_sizes[i] = 0;
}


