/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1999-2002 by M. Wangen.
**
**   Info: Functions for socket connections
**   Date: Version 1.0, October 2002
**
**   $Id$
*/

/*
**   Testing with the demo client and demo server:
**
**   1)  cc -g -I$HOME/abc/utils/src -D_DEMO_SERVER lib_socket.c -o xserver
**   2)  cc -g -I$HOME/abc/utils/src -D_DEMO_CLIENT lib_socket.c -o xclient
**   3) Run server in the background:  xserver &   # Start server
**      or: xserver -port <number> &               # Using a specific port number
**   4) Start the client: xclient                  # The client reads stdin ...
**      or: xclient -port <number> -host <name>    # The server runs on specific host.
**
*/

#ifdef WIN32
#include <windows.h>
#include <winsock.h>
typedef int socklen_t;
#define CLOSE closesocket
#else
#include <netdb.h>           /* struct hostent; ... */
#include <sys/types.h>       /* socket(); ... */
#include <sys/socket.h>      /* socket(); ... */
#include <netinet/in.h>      /* struct sockaddr_in; .. */
#include <arpa/inet.h>
#include <sys/time.h>        /* select(); ... */
#include <unistd.h>          /* select(); ... */
#define CLOSE close
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_socket.h>

static void my_bzero(void *target, int n);
static void convert_to_upper(char *string);
static const char *get_socket_arg( int argc, char **argv, 
     const char *option, const char *value);

static int 
     is_initialized = FALSE;


#ifdef _ABC_MAIN_SERVER
int main(int argc, char **argv)
#else
int run_demo_server(
     int argc,
     char **argv)
#endif
{
     int fd1, fd2;
     int counter = 0;
     const char *port_no = NULL;
     char string[ABC_MAX_WORD] = "";

     port_no = get_socket_arg(argc, argv, "-port", "2441");

     if (not (fd1 = socket_begin_server(port_no)))
          ABC_ERROR_EXIT("Can't open socket!\n");

     while (1)
     {
          fd2 = socket_accept(fd1);
          printf("Server accepts connection to client! (socket=%d)\n", fd2);
          string[0] = '\0';

          while (not ABC_MATCH(string, "exit") and not ABC_MATCH(string, "EXIT"))
          {
               if (socket_has_data(fd2) and socket_read_string(fd2, string, ABC_MAX_WORD))
               {
                    socket_chop_string(string);
                    printf("server received: \"%s\"\n", string);
                    convert_to_upper(string);
                    socket_write_string(fd2, string);
               }
               else
               {
                    printf("zzzz ... (counter=%d)\n", counter++);
                    /***
                    sleep(1);
                    ***/
               }
          }

          printf("Server closes the connection to client! (socket=%d)\n", fd2);
          socket_close(fd2);
     }

     printf("Server has terminated!\n");
     /***
     socket_close(fd1);
     ***/
     return 0;
}


#ifdef _ABC_MAIN_CLIENT
int main(int argc, char **argv)
#else
int run_demo_client(
     int argc,
     char **argv)
#endif
{
     int fd;
     char string[ABC_MAX_WORD];
     const char *port_no = "2441";
     const char *host_name = NULL;

     port_no = get_socket_arg(argc, argv, "-port", "2441");
     host_name = get_socket_arg(argc, argv, "-host", NULL);

     if (not (fd = socket_begin_client(host_name, port_no)))
          ABC_ERROR_EXIT("Can't open socket!\n");

     while (scanf("%s", string) > 0)
     {
          printf("To server: %s (%d characters)\n", string, (int) strlen(string));
          socket_write_string(fd, string);
          socket_read_string(fd, string, ABC_MAX_WORD);
          printf("From server: %s (%d characters)\n\n", string, (int) strlen(string));
     }

     socket_close(fd);
     return 0;
}


void socket_init_lib(
     void)
{
     if (is_initialized) return;

#ifdef WIN32
     WSADATA wsaData;
     WSAStartup(0x0101, &wsaData);
#endif

     is_initialized = TRUE;
}


int socket_begin_client(
     const char *host_name,
     const char *port_number)
{
     int client = 0;
     struct hostent *ptrh;
     struct sockaddr_in server_addr;

     if (not is_initialized)
          socket_init_lib();

     /* Set the specified IP and port numbers of the server. */

     if (host_name == NULL) 
          host_name = "localhost";

     ptrh = gethostbyname(host_name);

     if (ptrh == NULL)
     {
          fprintf(stderr, "[socket_begin_client] Call to gethostbyname() failed!\n");
          fprintf(stderr, "(host: %s and port number: %s)\n", host_name, port_number);
          return FALSE;
     }

     my_bzero((void *) &server_addr, sizeof(server_addr));

     server_addr.sin_family = AF_INET;
     server_addr.sin_port = htons(atoi(port_number));
     memcpy(&server_addr.sin_addr, ptrh->h_addr, ptrh->h_length);

     /* Create a file handle for the socket */

     if ((client = socket(AF_INET, SOCK_STREAM, 0)) < 0)
     {
          fprintf(stderr, "[socket_begin_client] Call to socket() failed!\n");
          fprintf(stderr, "(host: %s and port number: %s)\n", host_name, port_number);
          return FALSE;
     }

     /* Try to connect to the server */

     if (connect(client, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0 )
     {
          fprintf(stderr, "[socket_begin_client] Call to connect() failed\n");
          fprintf(stderr, "(host: %s and port number: %s)\n", host_name, port_number);
          return FALSE;
     }

     return client;
}


int socket_begin_server(
     const char *port_number)
{
     struct sockaddr_in server_addr;
     int socket_listen = 0;
     int max_queue = 2;

     if (not is_initialized)
          socket_init_lib();

     my_bzero((void *) &server_addr, sizeof(server_addr));

     /* Use the specified port; accept a connectin from any IF */

     server_addr.sin_family = AF_INET;
     server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
     server_addr.sin_port = htons(atoi(port_number));
     
     /* Create a file handle for the initial connection socket */
     
     if ((socket_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
     {
          fprintf(stderr, "[socket_begin_server] Call to socket() failed!\n");
          fprintf(stderr, "(port number: %s)\n", port_number);
          return FALSE;
     }

     /* Associate the file descriptor with the socket data struct */

     if ((bind(socket_listen, (struct sockaddr *) &server_addr, sizeof(server_addr))) < 0) 
     {
          fprintf(stderr, "[socket_begin_server] Call to bind() failed!\n");
          fprintf(stderr, "(port number: %s)\n", port_number);
          return FALSE;
     }

     listen(socket_listen, max_queue);

     return socket_listen;
}


int socket_accept(
     int socket_listen)
{
     struct sockaddr_in client_addr;
     socklen_t client_len = sizeof(client_addr);
     int socket_client = accept(socket_listen, (struct sockaddr *) &client_addr, &client_len);

     if (socket_client < 0)
     {
          fprintf(stderr, "[socket_accept] Call to accept() failed!\n");
          return FALSE;
     }

     return socket_client;
}


int socket_close(
     int s1)
{
     CLOSE(s1);
     return TRUE;
}


int socket_has_data(
     int fd)
{
     fd_set fd_read_set;
     struct timeval tv;
     int s; 

     tv.tv_sec = 1;
     tv.tv_usec = 0;
     FD_ZERO(&fd_read_set);
     FD_SET(fd, &fd_read_set);

     s = select(fd + 1, &fd_read_set, NULL, NULL, &tv);     

     return (s > 0);
}


int socket_write_string(
     int fd,
     const char *string)
{
     int max_size = strlen(string) + 1;
#ifdef WIN32
     int flags = 0;
     int size = send(fd, (char *) string, max_size, flags);
#else
     int size = write(fd, (void *) string, (size_t) (max_size));
#endif

     return (size > 0);
}


int socket_read_string(
     int fd,
     char *string,
     int max_size)
{
#ifdef WIN32
     int flags = 0;
     int size = recv(fd, (char *) string, (int) max_size, flags);
#else
     int size = read(fd, (void *) string, (size_t) max_size);
#endif
     string[size+1] = '\0';

     return (size > 0);
}


void socket_chop_string(
     char *string)
{
     int i;

     for (i = strlen(string) - 1; 
          i >= 0 and (string[i] == 10 or string[i] == 13);
          i--); 

     string[i+1] = '\0';
}


static void my_bzero(void *target, int n)
{
     (void) memset(target, '\0', (size_t) n);
}


static void convert_to_upper(char *string)
{
     while (*string)
     {
          if ('a' <= *string and *string <= 'z') 
               *string += 'A' - 'a';

          string++;
     }
}


static const char *get_socket_arg(
     int argc,
     char **argv,
     const char *option,
     const char *default_value)
{
     int i;
     const char *value = default_value;

     for (i = 1; i < argc; i++)
          if (ABC_MATCH(argv[i], option))
          {
               if (i < argc - 1)
                    value = argv[++i];
               else
               {
                    fprintf(stderr, "Missing argument after option %s!\n", option);
                    fprintf(stderr, "Using default value.");
                    value = default_value;
               }
          }

     return value;
}


