/*   
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1998 by M. Wangen.
**        
**   Info: Some functions for doning 2-D geometry.
**   Date: Version 1.0, November 1997
**   
**   $Id$
*/   

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_XY_GEOM_H_
#define _LIB_XY_GEOM_H_

#define ABC_MAX_XY_POLYGONS 1024

typedef struct LineXY {
     double x1;
     double y1;
     double x2;
     double y2;
} LineXY;

typedef struct AbcXYPolygon {
     int is_convex;
     int n_coords;
     double *xcoord;
     double *ycoord;
     double *scoord;
     char *name;
} AbcXYPolygon;

typedef struct AbcXYPolygonLib {
     int size;
     AbcXYPolygon *polygon[ABC_MAX_XY_POLYGONS];
} AbcXYPolygonLib;

void abc_test_xy_polygon(void);
void abc_init_xy_polygon_lib(AbcXYPolygonLib *lib);
int abc_read_xy_polygon_lib(AbcInput *in, AbcXYPolygonLib *lib);
void abc_print_xy_polygon_lib(FILE *out, AbcXYPolygonLib *lib);
void abc_free_xy_polygon_lib(AbcXYPolygonLib *lib);
AbcXYPolygon *abc_get_xy_polygon_from_lib(AbcXYPolygonLib *lib, const char *name);
AbcXYPolygon *abc_get_xy_polygon_from_lib_by_index(AbcXYPolygonLib *lib, int index);
int abc_get_xy_polygon_index_in_lib(AbcXYPolygonLib *lib, const char *name);
int abc_read_xy_polygon(AbcInput *in, AbcXYPolygon **ppolygon);
void abc_print_xy_polygon(FILE *out, AbcXYPolygon *polygon);
AbcXYPolygon *abc_create_xy_polygon_from_file(const char *filename);
AbcXYPolygon *abc_create_xy_polygon(const char *name, int size, double *xcoords, double *ycoords);
AbcXYPolygon *abc_new_xy_polygon(int n_coords);
void abc_free_xy_polygon(AbcXYPolygon **polygon_in);
const char *abc_get_xy_polygon_name(AbcXYPolygon *polygon);
double abc_get_length_of_polygon(AbcXYPolygon *polygon);
int abc_is_line_overlapping_xy_polygon(AbcXYPolygon *polygon, LineXY *line, double *ds);
void abc_get_line_normal_to_xy_line(double x0, double y0, LineXY *line1, LineXY *line2);
void abc_get_left_side_normal_to_xy_line(LineXY *line, double *nx, double *ny);
void abc_get_right_side_normal_to_xy_line(LineXY *line, double *nx, double *ny);
int abc_is_point_left_of_xy_line(LineXY *line, double x0, double y0);
int abc_are_xy_lines_intersecting(LineXY *line0, LineXY *line1, double *xc, double *yc);
int abc_solve_2x2_xy_system(double A[2][2], double b[2], double x[2]);
int abc_is_point_strictly_inside_xy_polygon(AbcXYPolygon *polygon, double x0, double y0);
int abc_find_point_along_xy_polygon(AbcXYPolygon *polygon, double spos, double *xx, double *yy);

#endif
