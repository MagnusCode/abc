/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1996-2010 by M. Wangen.
**
**   Info: Functions for reading parameters
**   Date: Version 1.0, March 2000
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_PARAMS_H_
#define _LIB_PARAMS_H_

#include <lib_args.h>

#define MAX_ABC_PARAM_LABELS 32
#define MAX_ABC_PARAM_GROUPS 32

#define AbcParamInt        1
#define AbcParamDouble     2
#define AbcParamBoolean    3
#define AbcParamString     4
#define AbcParamBit        5
#define AbcParamLabel      6
#define AbcParamFunction   7

typedef struct _AbcParams_ AbcParams;
typedef struct _AbcParamDef_ AbcParamDef;

typedef int (*ABC_PARAM_ACTION)(AbcParams *params, int k, void *data);

struct _AbcParamDef_ {
     /* The parameter action. */
     ABC_PARAM_ACTION take_action;     

     /* Common member data. */
     int type;
     int group_code;
     void *pointer;
     char *name;
     char *units;
     char *comment;
     double default_value;
     double min_value;
     double max_value;

     /* Bit-pattern value. */
     int bit_value;

     /* Label-name mapped to ID-number. */
     int n_labels;
     char *label_name[MAX_ABC_PARAM_LABELS];
     int label_ID[MAX_ABC_PARAM_LABELS];

     /* String default value. */
     int max_string_size;
     char *default_string;

     /* Member functions. */
     int (*set_param_by_string)(AbcParamDef *param, const char *string);
     double (*get_param_as_number)(AbcParamDef *param);
     void (*get_param_as_string)(AbcParamDef *param, char *string);
     const char *(*get_param_type_name)(void);
     void (*print_param_info_line)(AbcParamDef *param, FILE *out);
     void (*print_param_line)(AbcParamDef *param, FILE *out);
     void (*print_param_line_tex)(AbcParamDef *param, FILE *out);
     void (*print_param_defaults_line1_tex)(AbcParamDef *param, FILE *out);
     void (*print_param_defaults_line2_tex)(AbcParamDef *param, FILE *out);
};

typedef int (*ABC_READ_SPECIAL_PARAMS)(AbcArgs *args, const char *option);

struct _AbcParams_ {
     int max_params;
     int n_params;
     AbcParamDef *param;

     /* Parameter groups. */
     int n_groups;
     char *group_name[MAX_ABC_PARAM_GROUPS];
     int group_code[MAX_ABC_PARAM_GROUPS];

     /* Last input file. */
     char *input_file;

     /* Function for reading special parameters. */
     ABC_READ_SPECIAL_PARAMS read_special_params;

     /* Control parameters */
     int show_comment;
     int do_range_checking;
     int is_delimited_block;
     int is_sloppy;  /* Unused params are OK. */
};

int abc_test_params_main1(int argc, char **argv);
int abc_test_params_main2(int argc, char **argv);
int abc_test_params_main3(int argc, char **argv);
void abc_add_some_test_params(AbcParams *params);
AbcParams *abc_new_params(int max_params);
void abc_set_params_sloppy_mode(AbcParams *params, int on_off);
void abc_set_params_comments(AbcParams *params, int on_off);
void abc_set_params_range_checking(AbcParams *params, int on_off);
void abc_use_params_input_block(AbcParams *params, int on_off);
void abc_set_special_param_input(AbcParams *params, 
     ABC_READ_SPECIAL_PARAMS read_special_params);
void abc_delete_params(AbcParams **pparams);
void abc_delete_one_param(AbcParamDef *param);
void abc_def_param_group(AbcParams *params, const char *group_name, int group_code);
void abc_def_func_param(AbcParams *params, ABC_PARAM_ACTION take_action,
     const char *name, const char *comment, int code);
void abc_def_string_param(AbcParams *params, char *pointer,
     const char *name, const char *comment,
     const char *default_string, int max_size, int code);
void abc_def_bit_param(AbcParams *params, int *pointer, 
     const char *name, const char *comment, 
     int default_value, int bit_value, int code);
void abc_def_boolean_param(AbcParams *params, int *pointer,
     const char *name, const char *comment,
     int default_value, int code);
void abc_def_yes_no_param(AbcParams *params, int *pointer, 
     const char *name, const char *comment, 
     int default_value, int code);
void abc_def_true_false_param(AbcParams *params, int *pointer, 
     const char *name, const char *comment, 
     int default_value, int code);
void abc_def_label_param2(AbcParams *params, int *pointer,
     const char *comment, const char *name, const char *label_name,
     int label_value, int code);
void abc_def_label_param(AbcParams *params, int *pointer, 
     const char *name, const char *comment, const char *label_name,
     int label_value, int code);
void abc_def_int_param(AbcParams *params, int *pointer, 
     const char *name, const char *units, const char *comment, 
     int default_value, int min_value, int max_value, int code);
void abc_def_double_param(AbcParams *params, double *pointer, 
     const char *name, const char *units, const char *comment, 
     double default_value, double min_value, double max_value, int code);
AbcParamDef *abc_def_param(AbcParams *params, void *pointer, 
     const char *name, const char *units, const char *comment, 
     double default_value, double min_value, double max_value, int code, int type);
void abc_add_label(AbcParams *params, const char *name,
     const char *label_name, int label_value);
void abc_debug_params(AbcParams *params);
int abc_is_unused_param_name(AbcParams *params, const char *name);
int abc_get_param_index(AbcParams *params, const char *name);
const char *abc_get_params_input_file_name(AbcParams *params);
void abc_rename_param(AbcParams *params, const char *name, const char *new_name);
int abc_read_params(AbcParams *params, int *argc, char **argv);
void abc_read_all_params_by_args(AbcParams *params, int argc, char **argv);
void abc_read_params_by_args(AbcParams *params, AbcArgs *args);
int abc_read_one_param_option(AbcParams *params, const char *string);
int abc_param_std_action(AbcParams *params, int k, void *data);
int abc_param_inputfile_action(AbcParams *params, int k, void *data);
int abc_param_help_action(AbcParams *params, int k, void *data);
int abc_read_params_from_file(AbcParams *params, const char *filename);
int abc_assign_param_value(AbcParamDef *param, const char *string);
int abc_assign_param_number(AbcParamDef *param, double value);
double abc_get_param_value(AbcParamDef *param);
void abc_print_param_info(AbcParams *params, FILE *out);
void abc_print_param_info_for_one_group(AbcParams *params, 
     int group_code, const char *margin, FILE *out);
void abc_print_input_info_to_tex_file(AbcParams *params, 
     const char *case_name, const char *file_name, const char *prog_name);
void abc_print_param_info_tex(AbcParams *params, FILE *out);
void abc_print_param_info_for_one_group_tex(AbcParams *params, 
     int group_code, FILE *out);
void abc_print_all_params_to_a2_file(AbcParams *params, 
     const char *case_name, const char *file_name);
void abc_print_all_params_with_prename_to_a2_file(AbcParams *params,
     const char *case_name, const char *file_name, const char *prename);
void abc_print_all_params_as_a2(AbcParams *params, FILE *out);
void abc_print_all_params_with_prename_as_a2(AbcParams *params, 
     FILE *out, const char *prename);
void abc_print_all_params_to_file(AbcParams *params,
     const char *case_name, const char *file_name);
void abc_print_all_params(AbcParams *params, FILE *out);
void abc_print_params_for_one_group(AbcParams *params, 
     int group_code, FILE *out);
void abc_print_params_as_tex_file(AbcParams *params, const char *filename);
void abc_print_all_params_to_tex_file(AbcParams *params,
     const char *case_name, const char *file_name);
void abc_print_case_input_as_tex_file(AbcParams *params, 
     const char *case_name, const char *file_name);
void abc_print_all_params_as_tex(AbcParams *params, FILE *out);
void abc_print_params_as_tex(AbcParams *params, FILE *out);
void abc_print_params_as_tex_for_one_group(AbcParams *params, 
     int group_code, FILE *out);
void abc_print_default_params_as_tex(AbcParams *params, FILE *out);
void abc_print_default_params_as_tex_for_one_group(AbcParams *params, 
     int group_code, FILE *out);

#endif

