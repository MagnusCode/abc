/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-2002 by M. Wangen.
**
**   Info: A simple PostScript driver
**   Date: Version 2.0, June 2002
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_PLOTPS_H_
#define _LIB_PLOTPS_H_

typedef struct AbcPSState {
     FILE *out;
     double font_size;
     double bullet_size;
     double line_width;
     double grayness;
     double x1_ps_space;
     double y1_ps_space;
     double x2_ps_space;
     double y2_ps_space;
     double x1_user_space;
     double y1_user_space;
     double x2_user_space;
     double y2_user_space;
     double x1_viewport_unit;
     double y1_viewport_unit;
     double x2_viewport_unit;
     double y2_viewport_unit;
     char font_name[256];
     int page_number;
     int is_using_device_coords;
} AbcPSState;

typedef struct AbcPSPixelBuffer {
     int nx;               /* Number of pixels in x-direction. */
     int ny;               /* Number of pixels in y-direction. */
     int nbits;            /* Number of bits per component. */
     int ncomps;           /* Number of components: bw=1 and rgb=3 */
     int bufsize;          /* Number of enteries in buffer. */
     char *buffer;         /* The char-code-buffer: 0-9, a-f */
     char *bufname;        /* The pixel buffer name. */
} AbcPSPixelBuffer;

void abc_ps_meta_text_example(void);
int abc_ps_begin(char const *filename, char const *extension);
void abc_ps_end(void);
void abc_ps_comment(char const *text);
void abc_ps_use_device_coords(int yes_or_no);
int abc_ps_is_using_device_coords(void);
void abc_ps_draw_line(double x1, double y1, double x2, double y2);
void abc_ps_draw_vector(double x1, double y1, double x2, double y2);
void abc_ps_draw_vector_old(double x1, double y1, double x2, double y2);
void abc_ps_init(FILE *out);
void abc_ps_init_scan_fonts(FILE *out);
void abc_ps_begin_panel(double x, double y);
void abc_ps_draw_panel(double x, double y);
void abc_ps_end_panel(double gray, int show_boundary);
void abc_ps_end_color_panel(double hue, double saturation, double brightness, int show_boundary);
void abc_ps_draw_polygon(double *xcoord, double *ycoord, int steps, double gray, int show_bounary);
void abc_ps_draw_color_polygon(double *xcoord, double *ycoord, int steps, double hue, double saturation, double brightness, int show_boundary);
void abc_ps_draw_legend_by_hue(double hue1, double hue2, double value1, double value2, int steps);
void abc_ps_draw_basic_legend_by_hue(double xpos, double ypos, double xlength, double ylength, double hue1, double hue2, double value1, double value2, int steps, const char *format);
FILE *abc_ps_get_output_stream(void);
void abc_ps_set_output_stream(FILE *out);
void abc_ps_new_page(void);
void abc_ps_put_text(double x, double y, char const *text);
void abc_ps_put_rotated_text(double x, double y, double angle, double factor, const char *text);
void abc_ps_put_meta_text(double x, double y, double angle, double factor, const char *text);
int abc_ps_parse_meta_text(const char *text);
void abc_ps_fix_and_print_text(FILE *out, const char *text);
void abc_ps_fix_and_print_char(FILE *out, char ch);
void abc_ps_put_bullet(double x, double y);
void abc_ps_set_bullet_size(double size);
double abc_ps_get_bullet_size(void);
void abc_ps_set_font(char const *name);
void abc_ps_get_font(char *name);
void abc_ps_set_font_size(double size);
double abc_ps_get_font_size(void);
void abc_ps_set_grayness(double gray);
double abc_ps_get_grayness(void);
void abc_ps_set_line_stype(int style);
int abc_ps_get_line_stype(void);
void abc_ps_set_line_width(double width);
double abc_ps_get_line_width(void);
void abc_ps_set_page_number(int page);
int abc_ps_get_page_number(void);
void abc_ps_set_ps_space(double x1, double y1, double x2, double y2);
void abc_ps_get_ps_space(double *x1, double *y1, double *x2, double *y2);
void abc_ps_set_user_space(double x1, double y1, double x2, double y2);
void abc_ps_get_user_space(double *x1, double *y1, double *x2, double *y2);
void abc_ps_set_viewport(double x1, double y1, double x2, double y2);
void abc_ps_get_viewport(double *x1, double *y1, double *x2, double *y2);
void abc_ps_set_state(AbcPSState *state);
void abc_ps_get_state(AbcPSState *state);
int abc_ps_is_in_use(void);
AbcPSPixelBuffer *abc_ps_create_pixel_buffer(int nx, int ny, int nbits, int colors, const char *name);
void abc_ps_delete_pixel_buffer(AbcPSPixelBuffer **pixbuf2);
void abc_ps_clear_pixel_buffer(AbcPSPixelBuffer *pixbuf);
void abc_ps_draw_pixel_image(AbcPSPixelBuffer *pixbuf);
void abc_ps_write_pixel_buffer(AbcPSPixelBuffer *pixbuf);
void abc_ps_store_pixel_buffer(AbcPSPixelBuffer *pixbuf);
void abc_ps_draw_stored_pixel_buffer(AbcPSPixelBuffer *pixbuf);
void abc_ps_fill_pixel_buffer_hue_values(AbcPSPixelBuffer *pixbuf, double *hue_values);
void abc_ps_set_pixel_hue(AbcPSPixelBuffer *pixbuf, int i, int j, double hue);
void abc_ps_set_pixel_hls(AbcPSPixelBuffer *pixbuf, int i, int j, double hue, double lightness, double saturation);
void abc_ps_set_pixel_rgb(AbcPSPixelBuffer *pixbuf, int i, int j, double red, double green, double blue);
int abc_ps_pixel_buffer_index(AbcPSPixelBuffer *pixbuf, int i, int j);
void abc_ps_convert_hls_to_rgb(double hue, double lightness, double sat, double *red, double *green, double *blue);

#endif

