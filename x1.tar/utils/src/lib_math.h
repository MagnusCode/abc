#ifndef _LIB_MATH_H_
#define _LIB_MATH_H_

/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998 by M. Wangen.
**
**   $Id$/
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/* Prototypes for: lib_math.c */

typedef struct AbcComplex {
     double re;
     double im;
} AbcComplex;

void abc_vec3_copy(double a[3], double b[3]);
void abc_vec3_add_vec3(double a[3], double b[3], double c[3]);
void abc_vec3_mul_scalar(double a[3], double scalar);
void abc_vec3_normalize(double a[3]);
void abc_vec3_cross_vec3(double a[3], double b[3], double c[3]);
double abc_vec3_dot_vec3(double a[3], double b[3]);
void abc_vec3_sort(double a[3]);
void abc_mat3x3_set_zero(double mat[3][3]);
void abc_mat3x3_copy(double A[3][3], double B[3][3]);
void abc_mat3x3_transpose(double A[3][3], double B[3][3]);
void abc_mat3x3_mul_vec3(double mat[3][3], double vec1[3], double vec2[3]);
void abc_mat3x3_mul_mat3x3(double mat1[3][3], double mat2[3][3], double mat3[3][3]);
void abc_vec3_show(FILE *fp, char const *name, double a[3]);
void abc_mat3x3_show(FILE *fp, char const *name, double mat[3][3]);
int abc_mat3x3_is_rotation_matrix(double R[3][3], int size);
void abc_mat3x3_rotate(double M1[3][3], double R[3][3], double M2[3][3]);
double abc_rint(double numb);
double abc_erfc(double x);
double abc_erf(double x);
double abc_E1(double x);
double abc_Ei(double x);
void nr_error(const char *text);
double nr_erf(double x);
double nr_erfc(double x);
double nr_gammp(double a, double x);
double nr_gammq(double a, double x);
void nr_gser(double *gamser, double a, double x, double *gln);
void nr_gcf(double *gammcf, double a, double x, double *gln);
double nr_gammln(double xx);
double nr_gauss(int *idum);
double nr_ran1(int *idum);
double matpack_ExpIntegralEi(double x);
double matpack_ExpIntegralExpEi(double x);
double matpack_ExpIntegralE1(double x);
double abc_complex_abs(AbcComplex *x1);
void abc_complex_add(AbcComplex *x1, AbcComplex *x2, AbcComplex *x3);
void abc_complex_sub(AbcComplex *x1, AbcComplex *x2, AbcComplex *x3);
void abc_complex_mul(AbcComplex *x1, AbcComplex *x2, AbcComplex *x3);
void abc_complex_div(AbcComplex *x1, AbcComplex *x2, AbcComplex *x3);
void abc_complex_set(AbcComplex *x, double re, double im);
void abc_complex_zero(AbcComplex *x);
void abc_complex_print(FILE *out, const char *name, AbcComplex *x);
int abc_complex_is_real(AbcComplex *x);
void abc_complex_to_polar(AbcComplex *u, double *r, double *w);
int abc_main_solve_quad_or_cub(int argc, char **argv);
void abc_test_solve_quadratic(double a, double b, double c);
void abc_test_solve_cubic(double a, double b, double c, double d);
void abc_solve_quadratic(double a, double b, double c, AbcComplex *x1, AbcComplex *x2);
void abc_solve_cubic(double a, double b, double c, double d, AbcComplex *x1, AbcComplex *x2, AbcComplex *x3);
double abc_cubic_root(double x);
void abc_check_cubic_root(double a, double b, double c, double d, const char *text, AbcComplex *x);
void abc_newton_step_on_cubic_root(double a, double b, double c, double d, AbcComplex *x);

#endif
