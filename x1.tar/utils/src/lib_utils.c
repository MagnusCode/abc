/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1998 by M. Wangen.
**
**   Info: Utility functions
**   Date: Version 1.0, January 1998
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_utils.h>
#include <lib_input.h>

#define MAX_RECURSION_DEPTH 8
#define MAX_MARGIN_LEVEL 8
#define MAX_MARGIN_SIZE 8
#define MAX_MARGIN_WORD ((MAX_MARGIN_LEVEL * MAX_MARGIN_SIZE) + 16)

static int 
     has_init_my_margins = FALSE;

static char
     output_separator = '\n',
     my_margin[MAX_MARGIN_LEVEL][MAX_MARGIN_WORD];


void abc_do_nothing(
     void)
{
}


void abc_swap_ints(
     int *n1,
     int *n2)
{
     int tmp = *n1;
     *n1 = *n2;
     *n2 = tmp;
}


void abc_swap_floats(
     float *n1,
     float *n2)
{
     float tmp = *n1;
     *n1 = *n2;
     *n2 = tmp;
}


void abc_swap_doubles(
     double *n1,
     double *n2)
{
     double tmp = *n1;
     *n1 = *n2;
     *n2 = tmp;
}


void abc_sort_three_doubles(
     double *aa,
     double *bb,
     double *cc)
{
     if (*aa > *bb) abc_swap_doubles(aa, bb);
     if (*aa > *cc) abc_swap_doubles(aa, cc);
     if (*bb > *cc) abc_swap_doubles(bb, cc);
}


void abc_copy_ints(
     int *a,
     int *b,
     int size)
{
     int i; 
     if ((a == NULL) or (b == NULL)) return;
     for (i = 0; i < size; i++) b[i] = a[i];
}


void abc_copy_doubles(
     double *a,
     double *b,
     int size)
{
     int i; 
     if ((a == NULL) or (b == NULL)) return;
     for (i = 0; i < size; i++) b[i] = a[i];
}


void abc_init_ints(
     int *a,
     int size,
     int value)
{    
     int i; 
     if (a == NULL) return;
     for (i = 0; i < size; i++) a[i] = value;
}


void abc_init_doubles(
     double *a,
     int size,
     double value)
{
     int i; 
     if (a == NULL) return;
     for (i = 0; i < size; i++) a[i] = value;
}


void abc_interpret_option(
     const char *string,
     char *option,
     char *value_part,
     double *value)
{
     int i;
     int no = 0;
     int nv = 0;
     int has_equal_sign = FALSE;

     for (i = 0; i < (int) strlen(string); i++)
     {
          if (string[i] == '=')
          {
               has_equal_sign = TRUE;
               continue;
          }

          if (has_equal_sign)
          {
               value_part[nv] = string[i];
               nv++;
          }
          else
          {
               option[no] = string[i];
               no++;
          }
     }

     option[no] = '\0';
     value_part[nv] = '\0';

     if (sscanf(value_part, "%lf", value) != 1)
          *value = 0.0;
}


void abc_read_options_from_file(
     ABC_READ_ONE_OPTION read_one_option,
     const char *filename)
{
     static int level_of_recursion = 0;
     static char *fnames[MAX_RECURSION_DEPTH];
     AbcInput in;
     char field[ABC_MAX_WORD];
     int n_errors = 0;
     int i;

     if (ABC_MATCH(filename, ""))
          return;

     fnames[level_of_recursion] = abc_save_string(filename);
     level_of_recursion++;

     if (level_of_recursion >= MAX_RECURSION_DEPTH)
     {
          fprintf(stderr, "Level of recursion has reached %d!\n", MAX_RECURSION_DEPTH);
          fprintf(stderr, "Is there direct or indirect reading of the same input files?\n");
          fprintf(stderr, "These files have been opened so far:\n");

          for (i = 0; i < level_of_recursion; i++)
               fprintf(stderr, "file%d: %s\n", i + 1, fnames[i]);

          exit(1);
     }

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Can't open input-file: %s\n", filename);
          exit(1);
     }

     while(abc_get_field(&in, field, ABC_MAX_WORD))
          if (not read_one_option(field))
          {
               fprintf(stderr, "Unknown parameter: %s\n", field);
               n_errors++;
          }

     abc_end_input(&in);
     level_of_recursion--;

     if (n_errors > 0)
          ABC_ERROR_EXIT("Parameter errors! Can't continue!");

     printf("(parameters are read from: %s)\n", filename);
}


int abc_get_one_int_arg(
     int *argc,
     char **argv,
     const char *wanted_option,
     int min_value,
     int max_value,
     int default_value)
{
     int value = (int) abc_get_one_double_arg(argc, argv, 
          wanted_option, (double) min_value, (double) max_value, (double) default_value);
     return value;
}


double abc_get_one_double_arg(
     int *argc,
     char **argv,
     const char *wanted_option,
     double min_value,
     double max_value,
     double default_value)
{
     int i;
     int new_argc = 0;
     char option[ABC_MAX_WORD];
     char value_part[ABC_MAX_WORD];
     double input_value = default_value;
     double value;
     char *new_argv[ABC_MAX_ARGS];

     if (*argc > ABC_MAX_ARGS - 2)
          ABC_ERROR_EXIT("Too many options!");

     for (i = 0; i < *argc; i++)
     {
          abc_interpret_option(argv[i], option, value_part, &value);

          if (ABC_MATCH(option, wanted_option))
               input_value = value;
          else 
               new_argv[new_argc++] = argv[i];
     }

     abc_copy_args(argc, argv, new_argc, new_argv);

     if (input_value < min_value)
     {
          fprintf(stderr, "option \"%s\" is less than min %g! ", wanted_option, min_value);
          fprintf(stderr, "(min is used)\n");
          return min_value;
     }

     if (input_value > max_value)
     {
          fprintf(stderr, "option \"%s\" is larger than max %g! ", wanted_option, max_value);
          fprintf(stderr, "(max is used)\n");
          return max_value;
     }

     return input_value;
}


FILE *abc_open_file(
     char const *basename,
     char const *extension)
{
     FILE *in = NULL;
     char filename[ABC_MAX_WORD];

     sprintf(filename, "%s%s", basename, extension);

     if (ABC_MATCH(filename, "-"))
          return stdin;

     if ((in = fopen(filename, "r")) == NULL)
     {
          fprintf(stderr, "[abc_open_file] Can't open \"%s\" for reading!\n", filename);
          exit(1);
     }

     return in;
}


FILE *abc_new_file(
     char const *basename,
     char const *extension) 
{
     FILE *out = NULL;
     char filename[ABC_MAX_WORD];

     sprintf(filename, "%s%s", basename, extension);

     if (ABC_MATCH(filename, "-"))
          return stdout;

     if ((out = fopen(filename, "w")) == NULL)
     {
          fprintf(stderr, "[abc_new_file] Can't open \"%s\" for writing!\n", filename);
          exit(1);
     }

     return out;
}


FILE *abc_new_TeX_file2(
     const char *part1,
     const char *part2)
{
     char filename[ABC_MAX_WORD];
     sprintf(filename, "%s%s", part1, part2);
     return abc_new_TeX_file(filename);
}


FILE *abc_new_TeX_file(
     const char *filename) 
{
     FILE *out = NULL;
     char extension[ABC_MAX_WORD];

     abc_get_extension(filename, extension);

     if (ABC_MATCH(extension, ".tex"))
          out = abc_new_file(filename, "");
     else
          out = abc_new_file(filename, ".tex");

     if (out == NULL) return NULL;

     fprintf(out, "\\documentclass[12pt]{article}");
     fprintf(out, "%%\\usepackage{palatino}\n");
     fprintf(out, "\\usepackage{rotating}\n");
     fprintf(out, "\\begin{document}\n");
     fprintf(out, "\\setlength{\\parindent}{0cm}\\setlength{\\parskip}{3mm}\n\n");

     return out;
}


void abc_end_TeX_file(
     FILE *out) 
{
     if (out == NULL) return;
     fprintf(out, "\n\\end{document}\n");
     fclose(out);
}


FILE *abc_begin_reading(
     char const *filename) 
{
     FILE *out = NULL;

     if ((out = fopen(filename, "r")) == NULL)
          fprintf(stderr, "Can't open \"%s\" for reading!\n", filename);

     return out;
}


void abc_escape_TeX_underscore(
     char const *string1,
     char *string2)
{
     int i;
     int pos = 0;
     int length1 = (int) strlen(string1);

     for (i = 0; i < length1; i++)
     {
          if (string1[i] == '_') string2[pos++] = '\\';
          string2[pos++] = string1[i];
     }

     string2[pos] = '\0';
}


void abc_replace_TeX_underscore(
     char const *string1,
     int chr,
     char *string2)
{
     int i;

     strcpy(string2, string1);

     for (i = 0; i < (int) strlen(string2); i++)
          if (string2[i] == '_') string2[i] = chr;
}


void abc_print_TeX_number(
     FILE *out,
     double numb)
{
     fprintf(out, "%s", tex_numb(numb));
}


const char *tex_numb(
     double numb)
{
     int i;
     double numb1, numb2;
     char string[MAX_ABC_WORD];
     static char result[MAX_ABC_WORD] = "";

     if (numb == 0.0)
     {
          sprintf(result, "$0$");
          return result;
     }

     if ((0.001 < ABC_ABS(numb)) and (ABC_ABS(numb) < 1000.0))
     {
          sprintf(result, "$%g$", numb);
          return result;
     }

     /* ex: 5.12893e+05 */

     sprintf(string, "%10.4e", numb);

     for (i = 0; i < (int) strlen(string); i++)
          if (string[i] == 'e') string[i] = ' ';

     if (sscanf(string, "%lf %lf", &numb1, &numb2) == 2)
          sprintf(result, "$%g\\cdot 10^{%g}$", numb1, numb2);
     else
          sprintf(result, "$%g$", numb);

     return result;
}


char *abc_save_string(
     char const *string) 
{
     char *p = NULL;
     if (string == NULL) return NULL;
     ABC_NEW_ARRAY(p, char, strlen(string) + 1);
     strcpy(p, string);
     return p;
}


int *abc_save_int_array(
     int *array1,
     int size)
{
     int i;
     int *array2;
     ABC_NEW_ARRAY(array2, int, size);
     for (i = 0; i < size; i++) array2[i] = array1[i];
     return array2;
} 


double *abc_save_double_array(
     double *array1,
     int size)
{
     int i;
     double *array2;
     ABC_NEW_ARRAY(array2, double, size);
     for (i = 0; i < size; i++) array2[i] = array1[i];
     return array2;
}    
 

void abc_split_string_to_args(
     char *string,
     int *argc,
     char **argv) 
{
     int k = 0;
     int n = 0;
     static char const *dummy = "arg[0] (dummy)";

     argv[k++] = (char *) dummy; /* The first arg is empty (prog name). */
     *argc = k;

     if (string == NULL) return;

     while (string[n])
     {
          while (string[n] == ' ') n++;
          argv[k++] = &string[n];
          while (string[n] and string[n] != ' ') n++;

          if (string[n])
          {
               string[n] = '\0';
               n++;
          }
     }

     *argc = k;
}


void abc_copy_args(
     int *argc,       /* Number of arguments. */
     char **argv,     /* The array of arguments. */
     int new_argc,    /* Number of arguments. */
     char **new_argv) /* The array of arguments. */
{
     int i;

     for (i = 0; i < new_argc; i++)
          argv[i] = new_argv[i];

     *argc = new_argc;
}


void abc_remove_one_arg(
     int n,          /* The argument to be removed. */
     int *argc,      /* Number of arguments. */
     char **argv)    /* The array of arguments. */
{
     int i;
     int new_argc = 0;
     char *new_argv[256];

     for (i = 0; i < *argc; i++)
          if (i != n) new_argv[new_argc++] = argv[i];

     abc_copy_args(argc, argv, new_argc, new_argv);
}


void abc_skip_blanks(
     FILE *in) 
{
     int c;
     while ((c = getc(in)) == ' ' || c == '\t' || c == '\n' || c == ',')
          ;
     ungetc(c, in);
}


int abc_read_int(
     FILE *in,
     int *numb) 
{
     return (fscanf(in, "%d", numb) == 1);
}


int abc_read_real(
     FILE *in,
     double *numb) 
{
     return (fscanf(in, "%lf", numb) == 1);
}


int abc_read_comma(
     FILE *in) 
{
     char word[ABC_MAX_WORD];
     return (abc_read_word(in, word) && ABC_MATCH(word, ","));
}


int abc_read_word(
     FILE *in,
     char *word)
{
     return (fscanf(in, "%s", word) == 1);
}


int abc_read_string(
     FILE *in,
     char *string) 
{
     int c = ' ';
     int i = 0;

     abc_skip_blanks(in);

     if ((c = getc(in)) == EOF)
          return 0;
     else if (c != '"')
          ABC_RETURN_FALSE("Expected the beginning of a string!");

     for (c = getc(in); c != '"' && !ABC_IS_EOF(c); c = getc(in))
           if (i < ABC_MAX_WORD - 1)
                string[i++] = (char) c;

     string[i] = '\0';

      if (c != '"')
          ABC_RETURN_FALSE("Expected the end of a string!");

     return 1;
}


int abc_read_named_ints(
     FILE *in,
     char const *name,
     int max_size,
     int *array) 
{
     int size = 0;
     if (not abc_read_and_match_name(in, "int")) return FALSE;
     if (not abc_read_and_match_name(in, name)) return FALSE;
     if (not abc_read_size_of_vector(in, &size)) return FALSE;
     if (not abc_read_ints(in, array, ABC_MIN(size, max_size))) return FALSE;
     return TRUE;
}


int abc_read_named_reals(
     FILE *in,
     char const *name,
     int max_size,
     double *array) 
{
     int size = 0;
     if (not abc_read_and_match_name(in, "double")) return FALSE;
     if (not abc_read_and_match_name(in, name)) return FALSE;
     if (not abc_read_size_of_vector(in, &size)) return FALSE;
     if (not abc_read_reals(in, array, ABC_MIN(size, max_size))) return FALSE;
     return TRUE;
}


int abc_read_named_strings(
     FILE *in,
     char const *name,
     int max_size,
     char **array) 
{
     int size = 0;
     if (not abc_read_and_match_name(in, "char")) return FALSE;
     if (not abc_read_and_match_name(in, name)) return FALSE;
     if (not abc_read_size_of_vector(in, &size)) return FALSE;
     if (not abc_read_strings(in, array, ABC_MIN(size, max_size))) return FALSE;
     return TRUE;
}


int abc_read_and_match_name(
     FILE *in,         /* In file. */
     char const *name) /* The file name. */
{
     char word[ABC_MAX_WORD];

     if (not abc_read_word(in, word))
          ABC_RETURN_FALSE("[abc_read_and_match_name] Can't read name!");

     return (ABC_MATCH(word, name));
}


int abc_read_size_of_vector(
     FILE *in,  /* In file. */
     int *rows) /* Vector size. */
{
     if (not abc_read_int(in, rows))
          ABC_RETURN_FALSE("[abc_read_size_of_vector] Can't read number of rows!");

     return TRUE;
}


int abc_read_size_of_matrix(
     FILE *in,  /* In file. */
     int *rows, /* Matrix rows. */
     int *cols) /* Matrix cols. */
{
     if (not abc_read_int(in, rows))
          ABC_RETURN_FALSE("[abc_read_size_of_matrix] Can't read number of rows!");

     if (not abc_read_int(in, cols))
          ABC_RETURN_FALSE("[abc_read_size_of_matrix] Can't read number of cols!");

     return TRUE;
}


int abc_read_ints(
     FILE *in,    /* In file. */
     int *vector, /* Vector to be read. */
     int size)    /* The expected size of the vector. */
{
     int i;

     for (i = 0; i < size; i++)
          if (not abc_read_int(in, &vector[i]))
               ABC_RETURN_FALSE("[abc_read_ints] Missing numbers!");

     return TRUE;
}


int abc_read_reals(
     FILE *in,       /* In file. */
     double *vector, /* Vector to be read. */
     int size)       /* The expected size of the vector. */
{
     int i;
     double number;

     for (i = 0; i < size; i++)
     {
          if (not abc_read_real(in, &number))
               ABC_RETURN_FALSE("[abc_read_reals] Missing numbers!");

          vector[i] = (double) number;
     }

     return TRUE;
}


int abc_read_matrix_reals(
     FILE *in,        /* In file. */
     double **matrix, /* The matrix to be read. */
     int rows,        /* The expected number of rows. */
     int cols)        /* The expected number of cols. */
{
     int i, j;
     double number;

     for (i = 0; i < rows; i++)
          for (j = 0; j < cols; j++)
          {
               if (not abc_read_real(in, &number))
                    ABC_RETURN_FALSE("[abc_read_matrix_reals] Missing numbers!");

               matrix[i][j] = (double) number;
          }

     return TRUE;
}


int abc_read_strings(
     FILE *in,
     char **array,
     int size) 
{
     int i;
     char string[ABC_MAX_WORD];

     for (i = 0; i < size; i++)
     {
          if (not abc_read_string(in, string))
               ABC_RETURN_FALSE("[abc_read_strings] Missing string!");

          if (array[i] != NULL) ABC_FREE(array[i]);
          array[i] = abc_save_string(string);
     }

     return TRUE;
}


int abc_read_mm_banner(
     FILE *in,
     char *vec)
{
     char mm[ABC_MAX_WORD], coord[ABC_MAX_WORD];
     char real[ABC_MAX_WORD], gen[ABC_MAX_WORD];

     if (fscanf(in, "%s %s %s %s %s", mm, vec, coord, real, gen) != 5)
          ABC_RETURN_FALSE("[abc_read_mm_banner] Can't read banner!");

     if (not ABC_MATCH(mm, "%%MatrixMarket"))
          ABC_RETURN_FALSE("[abc_read_mm_banner] Expected %%MatrixMarket!");

     if (not ABC_MATCH(vec, "vector") and not ABC_MATCH(vec, "matrix"))
          ABC_RETURN_FALSE("[abc_read_mm_banner] Expected vector or matrix!");

     if (not ABC_MATCH(coord, "coordinate"))
          ABC_RETURN_FALSE("[abc_read_mm_banner] Expected coordinate!");

     if (not ABC_MATCH(real, "real"))
          ABC_RETURN_FALSE("[abc_read_mm_banner] Expected real!");

     return TRUE;
}


void abc_write_ints(
     FILE *out,
     char const *name,
     int size,
     int *array) 
{
     int i;

     fprintf(out, "int %s %d", name, size);
     for (i = 0; i < size; i++)
          fprintf(out, "%s%d", ((i % 5) == 0) ? "\n" : " ", array[i]);
     fprintf(out, "\n");
}


void abc_write_reals(
     FILE *out,
     char const *name,
     int size,
     double *array) 
{
     int i;

     fprintf(out, "double %s %d", name, size);
     for (i = 0; i < size; i++)
          fprintf(out, "%s%g", ((i % 5) == 0) ? "\n" : " ", array[i]);
     fprintf(out, "\n");
}


void abc_write_strings(
     FILE *out,
     char const *name,
     int size,
     char **array) 
{
     int i;

     fprintf(out, "char %s %d\n", name, size);
     for (i = 0; i < size; i++)
          fprintf(out, "\"%s\"\n", array[i]);
     fprintf(out, "\n");
}


void abc_show_vector(
     FILE *out,            /* Write the the vector here. */
     char const *name,     /* The vector name. */
     const double *vector, /* The vector. */
     int rows)             /* Size of vector. */
{
     int i;

     fprintf(out, "\n");
     fprintf(out, "#( Vector: %s )#\n", name);
     fprintf(out, "#( ====== )#\n");
     fprintf(out, " %5d \n", rows);

     for (i = 0; i < rows; i++)
          fprintf(out, "#( %6d )#  %28.16e\n", i, vector[i]);
}


void abc_show_matrix(
     FILE *out,          /* Write the the vector here. */
     char const *name,   /* The name of the matrix. */
     double **matrix,    /* The matrix. */
     int rows,           /* The number of rows in the matrix. */
     int cols)           /* The number of cols in the matrix. */
{
     int i, j, k, l;

     fprintf(out, "\n");
     fprintf(out, "# Matrix: %s #\n", name);
     fprintf(out, "# ====== #\n");
     fprintf(out, " %5d   %5d \n", rows, cols);

     for (i = 0; i < rows; i++)
     {
          fprintf(out, "# %6d # ", i);

          for (j = 0, k = 0, l = 0; j < cols; j++)
          {
               if (k++ > 9)
               {
                    k = 1;
                    fprintf(out, "\n");
                    fprintf(out, "#%3d     # ", ++l);
               }

               fprintf(out, " %10.3e", matrix[i][j]);
          }

          fprintf(out, "\n");
     }
}


void abc_get_basename(
     char const *filename,
     char *basename) 
{
     int i = 0;
     int pos = -1;

     strcpy(basename, filename);

     for (i = strlen(basename) - 1; i >= 0 && pos < 0; i--)
          if (basename[i] == '.')
               pos = i;

     if (pos >= 0) basename[pos] = '\0';
}


void abc_get_extension(
     char const *filename,
     char *extension)
{
     int i = 0;
     int pos = -1;

     for (i = strlen(filename) - 1; i >= 0 && pos < 0; i--)
          if (filename[i] == '.')
               pos = i;

     if (pos >= 0)
          strcpy(extension, &filename[pos]);
     else
          strcpy(extension, "");
}


void abc_get_dirname(
     char const *filename,
     char *dirname)
{
     int i = 0;
     int pos = -1;

     strcpy(dirname, filename);

     for (i = strlen(dirname) - 1; i >= 0 && pos < 0; i--)
          if (dirname[i] == '/')
               pos = i;

     if (pos >= 0) 
          dirname[pos] = '\0';
     else
          dirname[0] = '\0';
}


int abc_is_number(
     char const *string) 
{
     int i;

     for (i = 0; i < (int) strlen(string); i++)
          if (!ABC_IS_NUMERIC(string[i]))
               return 0;

     return 1;
}


double abc_max_velocity(
     double *vx,
     double *vy,
     double *vz,
     int size) 
{
     int i;
     double sum = 0.0;
     double vel = 0.0;
     double max_vel = 0.0;

     for (i = 0; i < size; i++)
     {
          sum = 0.0;
          if (vx != NULL) sum += vx[i] * vx[i];
          if (vy != NULL) sum += vy[i] * vy[i];
          if (vz != NULL) sum += vz[i] * vz[i];
          vel = sqrt(sum);
          if (vel > max_vel) max_vel = vel;
     }

     return max_vel;
}


double abc_mean_value(
     double *array,
     int size) 
{
     int i;
     double sum = 0.0;

     for (i = 0; i < size; i++)
          sum += array[i];

     return (sum / size);
}


int abc_is_equally_spaced_array(
     double *vec,
     int size)
{
     double ds = (vec[size-1] - vec[0]) / (size - 1);
     double de = 1.0e-6 * ds;
     int i;
 
     for (i = 1; i < size; i++)
          if (ABC_ABS(vec[i] - vec[0] - i * ds) > de)
               return FALSE;

     return TRUE;
}    


const char *abc_get_name_yes_or_no(
     int is_yes_or_no)
{
     if (is_yes_or_no)
          return "yes";

     return "no";
}


const char *abc_get_name_YES_or_NO( 
     int is_yes_or_no)
{
     if (is_yes_or_no)
          return "YES";

     return "NO";
}


const char *abc_get_name_true_or_false( 
     int is_yes_or_no)
{
     if (is_yes_or_no)
          return "true";

     return "false";
}


const char *abc_get_name_TRUE_or_FALSE( 
     int is_yes_or_no)
{
     if (is_yes_or_no)
          return "TRUE";

     return "FALSE";
}


void abc_set_output_separator(
     char ch)
{
     output_separator = ch;
}


char abc_get_output_separator(
     void)
{
     return output_separator;
}


void abc_set_margin_size(
     int size)
{
     int i, level;

     if (size < 0)
          ABC_ERROR_EXIT("[abc_set_margin_size] Margin size is less than zero!");

     if (size >= MAX_MARGIN_SIZE)
          ABC_ERROR_EXIT("[abc_set_margin_size] Too large margin size!");

     for (level = 0; level < MAX_MARGIN_LEVEL; level++)
     {
          for (i = 0; i < size * level; i++)
               my_margin[level][i] = ' ';

          my_margin[level][i] = '\0';
     }

     has_init_my_margins = TRUE;
}


const char *abc_get_margin(
     int level)
{
     if (level < 0)
          ABC_ERROR_EXIT("[abc_get_margin] Margin level is less than zero!");

     if (level >= MAX_MARGIN_LEVEL)
          ABC_ERROR_EXIT("[abc_get_margin] Too large margin level!");

     if (not has_init_my_margins)
          abc_set_margin_size(5);

     return my_margin[level];
}


int abc_get_number_of_columns(
     const char *filename)
{
     int c;
     int cols = 0;
     FILE *in = abc_begin_reading(filename);

     if (in == NULL)
          return -1;
 
     for (c = getc(in); (c != '\n' and c != EOF); )
     {
          if (ABC_IS_BLANK(c) and (c != '\n'))
               c = getc(in);
          else if (ABC_IS_NUMERIC(c))
          {
               cols++;

               while (ABC_IS_NUMERIC(c))
                    c = getc(in);
          }
          else
          {
               fprintf(stderr, "Something is wrong with the file: %s\n", filename);
               return -1;
          }
     }

     fclose(in);
    
     if (c == '\n')
          return cols;

     fprintf(stderr, "Expected end-of-line character! (file: %s)\n", filename);
     return -1;
}


int abc_get_number_of_lines(
     const char *filename)
{
     int c;
     int lines = 0;
     FILE *in = abc_begin_reading(filename);

     if (in == NULL)
          return -1;

     for (c = getc(in); (c != EOF); c = getc(in))
          if (c == '\n') 
               lines++;

     fclose(in);
     return lines;
}


void abc_print_time(
     FILE *out,
     double t_sec)
{
     double t_min = t_sec / 60.0;
     double t_hours = t_min / 60.0;
     double t_days = t_hours / 24.0;
     double t_years = t_days / 365.0;
     double t_mill_years = t_years / 1.0e+6;

     if (t_sec < 1.0e-12)
          fprintf(out, "%.1f [sec]", t_sec);
     else if (t_sec < 1.0e-6)
          fprintf(out, "%.1f [mu-sec]", 1.0e+6 * t_sec);
     else if (t_sec < 1.0e-3)
          fprintf(out, "%.1f [msec]", 1000.0 * t_sec);
     else if (t_sec < 0.1)
          fprintf(out, "%.3f [sec]", t_sec);
     else if (t_sec < 120.0)
          fprintf(out, "%.1f [sec]", t_sec);
     else if (t_min < 120.0)
          fprintf(out, "%.1f [min]", t_min);
     else if (t_hours < 24.0)
          fprintf(out, "%.1f [hours]", t_hours);
     else if (t_days < 365.0)
          fprintf(out, "%.1f [days]", t_days);
     else if (t_years < 1.0e+5)
          fprintf(out, "%.1f [years]", t_years);
     else
          fprintf(out, "%.1f [My]", t_mill_years);
}


double abc_get_sec_in_time_unit(
     AbcTimeUnit time_unit)
{
     switch (time_unit)
     {
          case AbcTimeUnitMillionYears:    return 3.1536e+13;
          case AbcTimeUnitYears:           return 3.1536e+07;
          case AbcTimeUnitDays:            return 86400.0;
          case AbcTimeUnitHours:           return 3600.0;
          case AbcTimeUnitMinutes:         return 60.0;
          case AbcTimeUnitSeconds:         return 1.0;
          default: 
               fprintf(stderr, "[abc_get_sec_in_time_unit] Illegal time unit!\n");
               fprintf(stderr, "(time unit = %d)\n", time_unit);
     }

     return 1.0;
}


const char *abc_get_time_unit_name(
     AbcTimeUnit time_unit)
{
     switch (time_unit)
     {    
          case AbcTimeUnitMillionYears:    return "Ma";
          case AbcTimeUnitYears:           return "years";
          case AbcTimeUnitDays:            return "days";
          case AbcTimeUnitHours:           return "hours";
          case AbcTimeUnitMinutes:         return "min";
          case AbcTimeUnitSeconds:         return "sec";
          default: 
               fprintf(stderr, "[get_time_unit_name] Illegal time unit!\n");
               fprintf(stderr, "(time unit = %d)\n", time_unit);
     }

     return "(unknown time unit)";
}


const char *abc_get_time_unit_full_name(
     AbcTimeUnit time_unit)
{
     switch (time_unit)
     {    
          case AbcTimeUnitMillionYears:    return "million_years";
          case AbcTimeUnitYears:           return "years";
          case AbcTimeUnitDays:            return "days"; 
          case AbcTimeUnitHours:           return "hours";
          case AbcTimeUnitMinutes:         return "minutes";
          case AbcTimeUnitSeconds:         return "seconds";
          default:
               fprintf(stderr, "[get_time_unit_name] Illegal time unit!\n");  
               fprintf(stderr, "(time unit = %d)\n", time_unit);
     }
     
     return "(unknown time unit)";
}


AbcTimeUnit abc_get_time_unit_from_full_name(
     const char *name)
{
     if      (ABC_MATCH(name, "million_years"))   return AbcTimeUnitMillionYears;
     else if (ABC_MATCH(name, "years"))           return AbcTimeUnitYears;
     else if (ABC_MATCH(name, "days"))            return AbcTimeUnitDays;
     else if (ABC_MATCH(name, "hours"))           return AbcTimeUnitHours;
     else if (ABC_MATCH(name, "minutes"))         return AbcTimeUnitMinutes;
     else if (ABC_MATCH(name, "seconds"))         return AbcTimeUnitSeconds;
     else                                         return AbcTimeUnitUndefined;
}


double abc_get_time_in_new_unit(
     double t,
     AbcTimeUnit old_unit,
     AbcTimeUnit new_unit)
{
     /* 
     ** new = old * (sec / old) / (sec / new)
     */

     double sec_in_old_unit = abc_get_sec_in_time_unit(old_unit); 
     double sec_in_new_unit = abc_get_sec_in_time_unit(new_unit); 
     return t * sec_in_old_unit / sec_in_new_unit;
}


int abc_get_int_option_in_string(
     const char *text,
     const char *name,
     int *numb)
{
     char field[ABC_MAX_WORD];

     if (not abc_get_option_field_in_string(text, name, ABC_MAX_WORD, field))
          return 0;
  
     if (sscanf(field, "%d", numb) != 1)
          return 0;

     return 1;
}


int abc_get_double_option_in_string(
     const char *text,
     const char *name,
     double *numb)
{
     char field[ABC_MAX_WORD];

     if (not abc_get_option_field_in_string(text, name, ABC_MAX_WORD, field))
          return 0;
 
     if (sscanf(field, "%lf", numb) != 1)
          return 0;

     return 1;
}


int abc_get_pos_after_substring(
     const char *text,
     const char *name)
/*
**   Note: This function returns the position of the first char after the string "name".
*/
{
     int i, j;
     int pos = -1;
     int imax = strlen(text);
     int jmax = strlen(name);

     for (i = j = 0; i < imax; i++)
     {
          if (j == jmax)
          {
               pos = i;
               j = 0;
          }
          else if (text[i] == name[j])
               j++;
          else
               j = 0;
     }

     return pos;
}


int abc_get_option_field_in_string(
     const char *text,
     const char *name,
     int max_field,  
     char *field)
{
     int i, k;   
     int imax = strlen(text);
     int pos = abc_get_pos_after_substring(text, name);

     if (pos < 0)
          return 0;

     while (text[pos] == ' ' or text[pos] =='\t')
          if (pos < imax - 1) pos++;

     if (text[pos] != '=')
     {
          fprintf(stderr, "Expected a equal sign (=) after option \"%s\"!\n", name);
          return 0;
     }

     pos++;

     while (text[pos] == ' ' or text[pos] =='\t')
          if (pos < imax - 1)
               pos++;
          else
               return FALSE;

     for (i = pos, k = 0; (i < imax) and (text[i] != ' ') and (text[i] != '\t'); i++, k++)
          if (k < max_field)
               field[k] = text[i];

     field[k] = '\0';

     if (k == 0)
         return FALSE;

     return TRUE;
}


void abc_nice_interval(
     double *min,   /* Lower interval limit (both in and out). */
     double *max,   /* Upper interval limit (both in and out). */
     int *steps,    /* Number of steps in the intervall. */
     int steplimit) /* A limit on the number of steps in the interval. */
{
     double dx;
     int ex, index, minsteps, maxsteps, totalsteps;
     static int exp_table[3] = {1, 0, 0};
     static double coef_table[3] = {1, 2, 5};

     /* "min" must be less than "max". */

     if ((dx = *max - *min) < 1.0e-12)
          return;

     /* "ex" is the integer part of exponent for the interval "dx". */

     ex = (int) log10(dx);                             

     /* 
     ** "ex" is equal to 0 for "dx" in the interval <0.1, 10.0>,
     ** but one has do distinguish beteen the intervals <0.1, 1.0]
     ** and <1.0, 10.0>.  
     */

     if ((ex == 0 and dx < 1.0) or ex < 0)
          ex--;

     /* 
     ** We will start with a small step size, and increase it
     ** until the total number of steps in the interval is less than
     ** the step limit given by the user. 
     */

     ex -= 2;
     index = -1;
 
     do {
          index = (index + 1) % 3;

          ex += exp_table[index];
          dx = coef_table[index] * pow(10.0, (double) ex);

          minsteps = (int) (*min / dx);
          maxsteps = (int) (*max / dx);

          if (*min < 0.0)
               if (minsteps * dx > *min)
                    minsteps--;

          if (*max > 0.0)
               if (maxsteps * dx < *max)
                    maxsteps++;

          totalsteps = maxsteps - minsteps;

     } while (totalsteps > steplimit);

     /* The results are ready. */

     *min = minsteps * dx;
     *max = maxsteps * dx;
     *steps = totalsteps;
}

 
void abc_nice_log_interval(
     double *min, /* Interval boundaries. */
     double *max, /* Interval boundaries. */
     int *steps)  /* Number of steps in the interval. */
{
     double x0, x1, i0, i1;

     if (*min > *max or *min < 0.0)
          return;
 
     x0 = log10(*min);
     x1 = log10(*max);
 
     i0 = (int) x0;
     i1 = (int) x1;
 
     if (x0 < 0.0 and ABC_ABS(x0 - i0) > 0.01)
          i0 -= 1;
 
     if (x1 > 0.0 and ABC_ABS(x1 - i1) > 0.01)
          i1 += 1;

     *steps = (int) (i1 - i0);
     *min = pow(10.0, i0);
     *max = pow(10.0, i1);
}


void abc_init_geom_coord_series(
     double *rcoord,
     int nr,
     double r1,
     double r2,
     double k0)
{
     int n;
     double dr0, dr, rr;

     if (nr < 2)
          ABC_ERROR_EXIT("[abc_init_geom_coord_series] n < 2!");

     if (k0 < 1.0001)
          dr0 = (r2 - r1) / (nr - 1.0);
     else
          dr0 = (k0 - 1.0) * (r2 - r1) / (pow(k0, (double) (nr - 1.0)) - 1.0);

     dr = dr0;
     rr = r1;

     for (n = 0; n < nr; n++)
     {
          rcoord[n] = rr;
          rr += dr;
          dr *= k0;
     }
}

#define MAX_BIT_INTS 128

int abc_get_max_bit_ints(
     void)
{
     int max_bit_ints = 8 * sizeof(int) - 1;
     return max_bit_ints;
}


int abc_get_bit_as_int(
     int bit)
{
     static int max_bit_ints = -1;
     static int bit_int[MAX_BIT_INTS];

     /* Initialize the the bit-array. */

     if (max_bit_ints < 0)
     {
          int i;
          int numb = 1;
          max_bit_ints = abc_get_max_bit_ints();
  
          if (max_bit_ints > MAX_BIT_INTS)
               ABC_ERROR_EXIT("[abc_get_bit_as_int] Too many bits!");

          for (i = 0; i < max_bit_ints; i++)
          {
               bit_int[i] = numb;
               numb *= 2;
          }
     }

     /* Check that "bit" is with in the legal range. */

     if (bit < 0)
     {
          fprintf(stderr, "[abc_get_bit_as_int] bit=%d is negative!\n", bit);
          fprintf(stderr, "[abc_get_bit_as_int] Returning 0.\n");
          return 0;
     }

     if (bit >= max_bit_ints)
     {
          fprintf(stderr, "[abc_get_bit_as_int] bit=%d is too large!\n", bit);
          fprintf(stderr, "[abc_get_bit_as_int] Max bit is %d!\n", max_bit_ints - 1);
          fprintf(stderr, "[abc_get_bit_as_int] Returning 0.\n");
          return 0;
     }

     /* Return the integer that corresponds to the "bit". */

     return bit_int[bit];
}

