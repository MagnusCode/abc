/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1998 by M. Wangen.
**
**   Info: Some functions for doing 2-D geometry.
**   Date: Version 1.0, November 1997
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <lib_alloc.h>
#include <lib_macros.h>
#include <lib_utils.h>
#include <lib_input.h>
#include <lib_xy_geom.h>

#define ABC_MAX_COORD_XY 1024

#ifdef ABC_RETURN_FALSE
#undef ABC_RETURN_FALSE
#endif
#define ABC_RETURN_FALSE(in, text) {abc_input_error(in, text); return FALSE;}


void abc_test_xy_polygon(
     void)
{
     int size = 5;
     double xcoord[5] = {-3.0,  1.0,  2.0,  1.0, -3.0};
     double ycoord[5] = {-3.0, -2.0,  0.0,  1.0,  2.0};
     const char *name = "test polygon";
     AbcXYPolygon *polygon = abc_create_xy_polygon(name, size, xcoord, ycoord);

     int npos = 9;
     double xpos[9]   = {-2.0, -1.0,  1.0,  1.0, -1.0,    -3.0,  0.0,  2.0,  1.0};
     double ypos[9]   = {-1.0, -2.0, -1.0,  0.0,  1.0,     3.0, -3.0,  2.0, -3.0};
     int is_inside[9] = { 1,    1,    1,    1,    1,       0,    0,    0,    0};

     int i;

     abc_print_xy_polygon(stdout, polygon);

     for (i = 0; i < npos; i++)
          printf("x=%2g, y=%2g is%s inside polygon, (should be %s)\n",
               xpos[i], ypos[i],
               (abc_is_point_strictly_inside_xy_polygon(polygon, xpos[i], ypos[i]) ? "" : " not"),
               (is_inside[i] ? "inside" : "outside"));
}


void abc_init_xy_polygon_lib(
     AbcXYPolygonLib *lib)
{
     int i;

     lib->size = 0;

     for (i = 0; i < ABC_MAX_XY_POLYGONS; i++)
          lib->polygon[i] = NULL;
}


int abc_read_xy_polygon_lib(
     AbcInput *in,
     AbcXYPolygonLib *lib)
{
     char word[ABC_MAX_WORD];
     AbcXYPolygon *polygon;

     while (abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, "begin_polygon_library"))
          ;

     while (abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, "end_polygon_library"))
     {
          abc_put_back_word(in, word);

          if (lib->size >= ABC_MAX_XY_POLYGONS)
               ABC_ERROR_EXIT("[abc_read_xy_polygon_lib] Too many polygons!");

          if (not abc_read_xy_polygon(in, &polygon))
               ABC_RETURN_FALSE(in, "Can't read polygon!");

          lib->polygon[lib->size] = polygon;
          lib->size++;
     }

     return TRUE;
}


void abc_print_xy_polygon_lib(
     FILE *out,
     AbcXYPolygonLib *lib)
{
     int i;

     fprintf(out, "%sbegin_polygon_library\n", abc_get_margin(1));

     for (i = 0; i < lib->size; i++)
     {
          abc_print_xy_polygon(out, lib->polygon[i]);
          if (i != lib->size - 1) fprintf(out, "\n");
     }

     fprintf(out, "%send_polygon_library\n", abc_get_margin(1));
}


void abc_free_xy_polygon_lib(
     AbcXYPolygonLib *lib)
{
     int i;

     for (i = 0; i < lib->size; i++)
          abc_free_xy_polygon(&(lib->polygon[i]));

     lib->size = 0;
}


AbcXYPolygon *abc_get_xy_polygon_from_lib(
     AbcXYPolygonLib *lib,
     const char *name)
{
      int index = abc_get_xy_polygon_index_in_lib(lib, name);
      return abc_get_xy_polygon_from_lib_by_index(lib, index);
}


AbcXYPolygon *abc_get_xy_polygon_from_lib_by_index(
     AbcXYPolygonLib *lib,
     int index)
{
      if (0 <= index and index < lib->size)
           return lib->polygon[index];

      return NULL;
}


int abc_get_xy_polygon_index_in_lib(
     AbcXYPolygonLib *lib,
     const char *name)
{
     int i;

     for (i = 0; i < lib->size; i++)
          if (ABC_MATCH(lib->polygon[i]->name, name))
               return i;

     return -1;
}


int abc_read_xy_polygon(
     AbcInput *in,
     AbcXYPolygon **ppolygon)
{
     static double xcoord[ABC_MAX_COORD_XY];
     static double ycoord[ABC_MAX_COORD_XY];
     char word[ABC_MAX_WORD], name[ABC_MAX_WORD];
     int n = 0;

     if (not abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, "begin_polygon"))
          ABC_RETURN_FALSE(in, "Expected keyword \"begin_polygon\"!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, "name"))
          ABC_RETURN_FALSE(in, "Expected keyword \"name\"!");

     if (not abc_get_string(in, name, ABC_MAX_WORD))
          ABC_RETURN_FALSE(in, "Expected a string after \"name\"!");

     while (abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, "end_polygon"))
     {
          abc_put_back_word(in, word);

          if (n >= ABC_MAX_COORD_XY)
               ABC_ERROR_EXIT("[abc_read_polygon] Too many coordinates in polygon!");

          if (not abc_get_double(in, &xcoord[n]))
               ABC_RETURN_FALSE(in, "Expected a polygon x-coordinate!");

          if (not abc_get_double(in, &ycoord[n]))
               ABC_RETURN_FALSE(in, "Expected a polygon y-coordinate!");

          n++;
     }

     *ppolygon = abc_create_xy_polygon(name, n, xcoord, ycoord);

     return TRUE;
}


void abc_print_xy_polygon(
     FILE *out,
     AbcXYPolygon *polygon)
{
     int i;

     fprintf(out, "%sbegin_polygon\n", abc_get_margin(2));
     fprintf(out, "%sname \"%s\"\n", abc_get_margin(3), polygon->name);

     for (i = 0; i < polygon->n_coords; i++)
          fprintf(out, "%s%10g %10g\n", 
               abc_get_margin(3), polygon->xcoord[i], polygon->ycoord[i]);

     fprintf(out, "%send_polygon\n", abc_get_margin(2));
}


AbcXYPolygon *abc_create_xy_polygon_from_file(
     const char *filename)
{
     AbcInput in;
     AbcXYPolygon *polygon = NULL;

     if (not abc_begin_input(&in, filename))
          ABC_RETURN_NULL("Can't open xy-polygon file!");

     if (not abc_read_xy_polygon(&in, &polygon))
          ABC_RETURN_NULL("Can't read xy-polygon file!");

     abc_end_input(&in);
     return polygon;
}


AbcXYPolygon *abc_create_xy_polygon(
     const char *name,
     int size,
     double *xcoord,
     double *ycoord)
{
     int i;
     double dx, dy, ds;
     AbcXYPolygon *polygon;

     polygon = abc_new_xy_polygon(size);
     polygon->name = abc_save_string(name);
     polygon->n_coords = size;

     for (i = 0; i < size; i++)
     {
          polygon->xcoord[i] = xcoord[i];
          polygon->ycoord[i] = ycoord[i];

          if (i == 0) continue;

          dx = xcoord[i] - xcoord[i - 1];
          dy = ycoord[i] - ycoord[i - 1];
          ds = sqrt((dx * dx) + (dy * dy));
          polygon->scoord[i] = polygon->scoord[i - 1] + ds;
     }

     return polygon;
}


AbcXYPolygon *abc_new_xy_polygon(
     int n_coords)
{
     AbcXYPolygon *polygon;

     if (n_coords < 3)
          ABC_ERROR_EXIT("[abc_new_xy_polygon] Less than 3 points!");

     ABC_NEW_OBJECT(polygon, AbcXYPolygon);
     ABC_NEW_ARRAY(polygon->xcoord, double, n_coords);
     ABC_NEW_ARRAY(polygon->ycoord, double, n_coords);
     ABC_NEW_ARRAY(polygon->scoord, double, n_coords);
     polygon->n_coords = n_coords;
     polygon->name = NULL;
     return polygon;
}


void abc_free_xy_polygon(
     AbcXYPolygon **pp)
{
     AbcXYPolygon *polygon = NULL;

     if (pp == NULL) return;
     if ((polygon = *pp) == NULL) return;

     ABC_FREE_ARRAY(polygon->xcoord);
     ABC_FREE_ARRAY(polygon->ycoord);
     ABC_FREE_ARRAY(polygon->scoord);
     ABC_FREE_ARRAY(polygon->name);
     ABC_FREE(polygon);
     *pp = NULL;
}


const char *abc_get_xy_polygon_name(
     AbcXYPolygon *polygon)
{
     if (polygon != NULL) 
          return polygon->name;

     return "(polygon NULL-pointer)";
}


double abc_get_length_of_polygon(
     AbcXYPolygon *polygon)
{
     int i = polygon->n_coords - 1;
     return polygon->scoord[i];
}


int abc_is_line_overlapping_xy_polygon(
     AbcXYPolygon *polygon,
     LineXY *line,
     double *ds)
{
     LineXY side;
     double *xcoord = polygon->xcoord;
     double *ycoord = polygon->ycoord;
     double xc[5] = {0.0}, yc[5] = {0.0};
     int n_coords = polygon->n_coords;
     int nc = 0;
     int i;

     *ds = 0.0;

     for (i = 0; i < n_coords; i++)
     {
          side.x1 = xcoord[i];
          side.y1 = ycoord[i];
          side.x2 = xcoord[(i + 1) % n_coords];
          side.y2 = ycoord[(i + 1) % n_coords];

          if (abc_are_xy_lines_intersecting(line, &side, &xc[nc], &yc[nc]))
               nc++;
     }

     if (nc == 0)
     {
          *ds = 0.0;
          return FALSE;
     }
     else if (nc == 1)
     {
          if (abc_is_point_strictly_inside_xy_polygon(polygon, line->x1, line->y1))
               *ds = sqrt(ABC_SQR(line->x1 - xc[0]) + ABC_SQR(line->y1 - yc[0]));
          else if (abc_is_point_strictly_inside_xy_polygon(polygon, line->x2, line->y2))
               *ds = sqrt(ABC_SQR(line->x2 - xc[0]) + ABC_SQR(line->y2 - yc[0]));
          else 
               *ds = 0.0;

          return TRUE;     
     }
     else if (nc == 2)
     {
          *ds = sqrt(ABC_SQR(xc[1] - xc[0]) + ABC_SQR(yc[1] - yc[0]));
          return TRUE;
     }
     else
     {
          *ds = 0.0;
          fprintf(stderr, "[abc_is_line_overlapping_xy_polygon] Error! (nc=%d)\n", nc);
          return FALSE;
     }
}


void abc_get_line_normal_to_xy_line(
     double x0,
     double y0,
     LineXY *line1,
     LineXY *line2)
{
     double x1 = line1->x1;
     double y1 = line1->y1;
     double x2 = line1->x2;
     double y2 = line1->y2;
     double nom = (x2 - x1) * (x0 - x1) + (y2 - y1) * (y0 - y1);
     double denom = ABC_SQR(x2 - x1) + ABC_SQR(y2 - y1);
     double t = (ABC_ABS(denom) < 1.0e-12) ? 0.0 : (nom / denom);

     line2->x1 = x0;
     line2->y1 = y0;
     line2->x2 = (x2 - x1) * t + x1;
     line2->y2 = (y2 - y1) * t + y1;
}


void abc_get_left_side_normal_to_xy_line(
     LineXY *line,
     double *nx,
     double *ny)
{
     double dx = line->x2 - line->x1;
     double dy = line->y2 - line->y1;
     double ds = sqrt(ABC_SQR(dx) + ABC_SQR(dy));

     if (ABC_ABS(ds) < 1.0e-12)
     {
          *nx = 0.0;
          *ny = 0.0;
          fprintf(stderr, "[abc_get_left_side_normal_to_xy_line] Identical points!");
          return;
     }

     *nx = dy / ds;
     *ny = - dx / ds;
}


void abc_get_right_side_normal_to_xy_line(
     LineXY *line,
     double *nx,
     double *ny)
{
     double dx = line->x2 - line->x1;
     double dy = line->y2 - line->y1;
     double ds = sqrt(ABC_SQR(dx) + ABC_SQR(dy));

     if (ABC_ABS(ds) < 1.0e-12)
     {
          *nx = 0.0;
          *ny = 0.0;
          fprintf(stderr, "[abc_get_right_side_normal_to_xy_line] Identical points!");
          return;
     }

     *nx = - dy / ds;
     *ny = dx / ds;
}


int abc_is_point_left_of_xy_line(
     LineXY *line,
     double x0,
     double y0)
{
     double dx1 = x0 - line->x1;
     double dy1 = y0 - line->y1;
     double dx2 = line->x2 - line->x1;
     double dy2 = line->y2 - line->y1;
     double det = dx1 * dy2 - dy1 * dx2;

     return (det <= 0.0);
}


int abc_are_xy_lines_intersecting(
     LineXY *line0,
     LineXY *line1,
     double *xc,
     double *yc)
{
     double A[2][2], b[2], x[2], r, s;

     *xc = 0.0;
     *yc = 0.0;
          
     A[0][0] = line0->x2 - line0->x1;     A[0][1] = - (line1->x2 - line1->x1);
     A[1][0] = line0->y2 - line0->y1;     A[1][1] = - (line1->y2 - line1->y1);

     b[0] = line1->x1 - line0->x1;
     b[1] = line1->y1 - line0->y1;

     if (not abc_solve_2x2_xy_system(A, b, x))
          return FALSE;   /* Parallel lines! */

     r = x[0];
     s = x[1];

     if ((r < 0.0 or 1.0 < r) or (s < 0.0 or 1.0 < s))
          return FALSE;

     *xc = line0->x1 + (line0->x2 - line0->x1) * r;
     *yc = line0->y1 + (line0->y2 - line0->y1) * r;

     return TRUE;
}


int abc_solve_2x2_xy_system(
     double A[2][2],
     double b[2],
     double x[2])
{
     double det = A[0][0] * A[1][1] - A[0][1] * A[1][0];

     x[0] = x[1] = 0.0;

     if (ABC_ABS(det) < 1.0e-12) return FALSE;

     x[0] = (A[1][1] * b[0] - A[0][1] * b[1]) / det;
     x[1] = (- A[1][0] * b[0] + A[0][0] * b[1]) / det;

     return TRUE;
}


int abc_is_point_strictly_inside_xy_polygon(
     AbcXYPolygon *polygon,
     double x0,
     double y0)
{
     /*
     ** NOTE: Assuming a convex polygon.
     */

     double epsilon = 1.0e-12;
     double *xcoord = polygon->xcoord;
     double *ycoord = polygon->ycoord;
     double xside, yside, xpoint, ypoint, det;
     int n_coords = polygon->n_coords;
     int i;

     for (i = 0; i < n_coords; i++)
     {
          xside = xcoord[(i + 1) % n_coords] - xcoord[i];
          yside = ycoord[(i + 1) % n_coords] - ycoord[i];
          xpoint = x0 - xcoord[i];
          ypoint = y0 - ycoord[i];

          det = xside * ypoint - yside * xpoint;

          /* 
          ** "epsilon" makes sure that points on the boundary of the
          ** polygon, (or close to the boundary), are counted as outside.
          */

          if (det < epsilon) 
               return FALSE;
     }

     return TRUE;
}


int abc_find_point_along_xy_polygon(
     AbcXYPolygon *polygon,
     double spos,
     double *xx,
     double *yy)
{
     int n_last = polygon->n_coords - 1;
     double dds, ds, dx, dy, weight;
     double *xcoord = polygon->xcoord;
     double *ycoord = polygon->ycoord;
     double *scoord = polygon->scoord;
     double smin = scoord[0];
     double smax = scoord[n_last];
     double epsilon = 0.5e-6 * (smin + smax);
     int k = -1;
     int i;

     *xx = 0.0;
     *yy = 0.0;

     if ((spos < smin - epsilon) or  (smax + epsilon < spos))
     {
          fprintf(stderr, "[abc_find_point_along_xy_polygon] s-value outside range!\n");
          fprintf(stderr, "(s-value=%g, s-min=%g and s-max=%g)\n", spos, smin, smax);
     }

     if (spos <= smin)
          spos = smin + epsilon;

     if (spos >= smax)
          spos = smax - epsilon;

     for (i = 1; i < polygon->n_coords; i++)
          if ((scoord[i-1] <= spos) and (spos < scoord[i]))
          {
               k = i;
               break;
          }
               
     if (k == -1)
     {
          fprintf(stderr, "[abc_find_point_along_xy_polygon] k == -1 !!\n");
          return FALSE;
     }

     dds = spos - scoord[k-1];
     ds = scoord[k] - scoord[k-1];

     if (ds > epsilon)
          weight = dds / ds;
     else 
          weight = 0.0;
          
     dx = xcoord[k] - xcoord[k-1];
     dy = ycoord[k] - ycoord[k-1];

     *xx = xcoord[k-1] + weight * dx;
     *yy = ycoord[k-1] + weight * dy;
     
     return TRUE;
}


