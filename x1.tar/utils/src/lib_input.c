/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1987-2002 by M. Wangen.
**
**   Info: A small input library
**   Date: Version 6.0, November 1993
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <lib_math.h>
#include <lib_system.h>
#include <lib_hash_table.h>
#include <lib_input.h>
#include <lib_alloc.h>
#include <lib_macros.h>

/* Array dimensions. */

#define MAXWORD ABC_INPUT_WORD
#define MAXBUF  ABC_INPUT_BUFFER
#define MAXARGS    16
#define MAXHASH  1024
#define MINHASH   128

/* Comparison characters. */

#define OP_EQ 1   /* == */
#define OP_NE 2   /* != */
#define OP_LT 3   /* <  */
#define OP_LE 4   /* <= */
#define OP_GT 5   /* >  */
#define OP_GE 6   /* >= */
#define OP_OR 7   /* || */
#define OP_AND 8  /* && */

/* Macros for comparing characters. */

#define SIGN(c) ((c) == '-' or (c) == '+')
#define DIGIT(c) ('0' <= (c) and (c) <= '9')
#define ALPHA(c) (('a' <= (c) and (c) <= 'z') or ('A' <= (c) and (c) <= 'Z'))
#define BLANKS(c) ((c) == ' ' or (c) == '\t' or (c) == '\n' or (c) == '\r')
#define SIGNED(c) (DIGIT(c) or SIGN(c))
#define ALPHANUM(c) (ALPHA(c) or DIGIT(c) or (c) == '_')

/* Private types. */

typedef struct MacroDef {        /* Macro element in hash table. */
     char *name;                 /* Macro name. */
     char *def;                  /* Macro definition. */
     int argc;                   /* Number of arguments. */
     int constant;               /* True if macro is constant. */
} MacroDef;

typedef struct MathFunc {        /* Math func in hash table. */
     char *name;                 /* Function name. */
     double (*func)(double x);
} MathFunc;

typedef struct RealVar {         /* A real variable. */
     char *name;                 /* The variable name. */
     double value;               /* The variable value. */
     int constant;               /* True if the variable is const. */
} RealVar;

typedef struct BuiltIn {         /* A real variable. */
     char *name;                 /* The command name. */
     void (*func)(AbcInput *in);
     char *comment;              /* A descriptive comment. */
} BuiltIn;

typedef struct StringVar {       /* Macro element in hash table. */
     char *name;                 /* String variable name. */
     char *def;                  /* String definition. */
} StringVar;

typedef struct OutputDesc {
     int mode;                   /* 'a' = append, 'w' = write */
     FILE *out;                  /* == NULL for a closed file. */
     char *desc_name;            /* Descriptor name. */
     char *file_name;            /* File name. */
} OutputDesc;

/* Private variables. */

static int
     ran_seed = -412349,         /* Seed for random number generator. */
     skip_comments = TRUE,       /* True if comments are wanted skipped. */
     use_promt = TRUE,           /* True if the prompt is written out. */
     use_macro_expansion = TRUE, /* True if macros are wanted expanded. */
     is_initialized = FALSE,     /* True if tables are initialized. */
     is_key_word_sensitiv = TRUE,/* True if key words are wanted. */
     debug_cmd = FALSE,          /* True if debugging commands. */
     debug_levels = FALSE,       /* True if the levels are debugged. */
     debug_condition = FALSE,    /* True if the conditions are debugged. */
     debug_macro_redef = FALSE,  /* True if macro-redef is reported. */
     debug_include_files = FALSE,   /* True if include-files are debugged. */
     debug_macro_expansion = FALSE, /* True if echo of macro expansion. */
     debug_substrings = FALSE;   /* True if echo of macro expansion. */

static char
     c_begin = '#',              /* A comment is started with this char. */
     c_end = '#',                /* A commnet is ended with this char. */
     promt[MAXWORD] = "",        /* Command line promt. */
     var_format[MAXWORD] = "%g", /* The printvar format. */
     argument[MAXARGS][MAXWORD]; /* Store for macro arguments. */

static char
     log_file_name[MAXWORD] = ".inputlog";
static const char
     *op_name[] = {"", "==", "!=", "<", "<=", ">", ">=", "||", "&&", ""};

static AbcHashTable
     *var_table = NULL,          /* Hash table of variables. */
     *func_table = NULL,         /* Hash table of math functions. */
     *macro_table = NULL,        /* Hash table of macros. */
     *command_table = NULL,      /* Hash table of build-ins. */
     *string_table = NULL,       /* Hash table of string variables. */
     *desc_table = NULL;         /* Hash table of output file-descriptors. */

static FILE
     *log_file = NULL;

/* Prototypes for private variables. */

static void delete_var_item(void **buffer);
static void delete_func_item(void **buffer);
static void delete_macro_item(void **buffer);
static void delete_command_item(void **buffer);
static void delete_string_item(void **buffer);
static void delete_desc_item(void **buffer);
static void insert_substrings(char *string, int max_size);
static int get_string_name_and_def(const char *string, char *name, char *def);
static double get_quotient(double dividend, double divisor);
static void print_variable(FILE *out, void const *buffer);
static void print_macro_def(FILE *out, void const *buffer);
static void print_math_func(FILE *out, void const *buffer);
static void print_built_ins(FILE *out, void const *buffer);
static void print_strings(FILE *out, void const *buffer);
static char *save_string(const char *string);
static int is_name_ok_for_table(AbcHashTable *table1, const char *name);
static const char *get_hash_table_name(AbcHashTable *table);
static double int_func(double x);
static double abs_func(double x);
static double exp10_func(double x);
static double ran_func(double x);
static double set_ran_seed(double x);
static void cmd_close_log_file(AbcInput *in);
static void cmd_open_log_file(AbcInput *in);
static void cmd_var_def(AbcInput *in);
static void cmd_const_def(AbcInput *in);
static void cmd_string_def(AbcInput *in);
static void cmd_macro_def(AbcInput *in);
static void cmd_const_macro_def(AbcInput *in);
static void cmd_what_is_macro(AbcInput *in);
static void cmd_show_macros(AbcInput *in);
static void cmd_show_vars(AbcInput *in);
static void cmd_abc_show_math_funcs(AbcInput *in);
static void cmd_abc_show_built_ins(AbcInput *in);
static void cmd_abc_show_strings(AbcInput *in);
static void cmd_eval(AbcInput *in);
static void cmd_exit(AbcInput *in);
static void cmd_print(AbcInput *in);
static void cmd_print_word(AbcInput *in);
static void cmd_print_line(AbcInput *in);
static void cmd_print_new_line(AbcInput *in);
static void cmd_print_line_no(AbcInput *in);
static void cmd_print_var(AbcInput *in);
static void cmd_set_format(AbcInput *in);
static void cmd_set_promt(AbcInput *in);
static void cmd_use_promt(AbcInput *in);
static void cmd_unix(AbcInput *in);
static void cmd_include(AbcInput *in);
static void cmd_include_file(AbcInput *in);
static void cmd_debug_include_files(AbcInput *in);
static void cmd_debug_cmd(AbcInput *in);
static void cmd_debug_macro(AbcInput *in);
static void cmd_debug_macro_redef(AbcInput *in);
static void cmd_if(AbcInput *in);
static void cmd_open_file(AbcInput *in);
static void cmd_close_file(AbcInput *in);


#ifdef _CALC_MAIN
int main(
     int argc, 
     char **argv)
#else
int abc_interpreter_main(
     int argc, 
     char **argv)
#endif
{
     abc_get_input_lib_options(&argc, argv);
     abc_install_built_in("include", cmd_include,
          "include <file name> (file name in double quotes)");
     abc_install_var("a", 0.0, ABC_NON_CONST_VAR);
     abc_init_input_main();
     abc_interpret_input_file(NULL);
     abc_delete_input_lib();
     return 0;
}


void abc_init_input_main(
     void)
{    
     char *file_dir, file_name[ABC_MAX_WORD];

     if ((file_dir = getenv("CALC")) == NULL)
     {
          fprintf(stderr, "Can't get environment variable \"CALC\"!\n");
          strcpy(file_name, "");
     }
     else
     {
          strcpy(file_name, file_dir);
          strcat(file_name, "/def1.calc");
          abc_interpret_input_file(file_name);
     }

     if ((file_dir = getenv("HOME")) == NULL)
     {
          fprintf(stderr, "Can't get environment variable \"HOME\"!\n");
          strcpy(file_name, "");
     }
     else
     {
          strcpy(file_name, file_dir);
          strcat(file_name, "/.calc");
          abc_interpret_input_file(file_name);
     }
}


int abc_interpret_input_file(
     const char *file_name)
{    
     AbcInput *in;

     ABC_NEW_OBJECT(in, AbcInput);

     if (not abc_begin_input(in, file_name))
     {
          ABC_FREE(in);
          return FALSE;
     }

     abc_set_read_function(in, abc_run_command_loop);
     abc_run_command_loop(in);
     abc_end_input(in);
     ABC_FREE(in);

     return TRUE;
}    


void abc_run_command_loop(
     AbcInput *in) /* Input definition. */
{
     double expr;

     while (not abc_end_of_if_branch(in))
          if (abc_get_expression(in, &expr))
          {
               abc_install_var("a", expr, ABC_NON_CONST_VAR);
               printf("out=");
               printf(var_format, expr);
               printf("\n");
          }
          else
          {
               abc_skip_rest_of_line(in);
               abc_input_error(in, "Can't make expression!");
          }
}


void abc_run_command_string(
     AbcInput *in,
     const char *string)
{
     static char commands[ABC_INPUT_BUFFER];
     FILE *saved_file = in->file;

     in->file = NULL;
     sprintf(commands, "%s end\n", string);
     abc_put_back_word(in, commands);
     abc_run_command_loop(in);
     in->file = saved_file;
}


void abc_test_input_lib(
     void)
{
     static AbcInput in;
     char word[MAXWORD];
     double m;
     float f;
     int n;
     int finished = FALSE;

     abc_begin_input(&in, "");

     while (not finished)
     {
          printf("\n");
          printf("b = bye               B = Begin session.\n");
          printf("c = abc_get_float    E = End session.\n");
          printf("d = abc_get_double   M = Define macro\n");
          printf("f = abc_get_field    R = Read text with macros\n");
          printf("i = abc_get_int      S = Show macro definitions\n");
          printf("s = abc_get_string   V = Set variable\n");
          printf("w = abc_get_word\n");
          printf("x = abc_get_expression\n\n");
          printf("Which func do you want to test ? ");

          /*  Execute the different functions. */

          abc_skip_blanks_and_comments(&in);

          switch (abc_getch(&in)) {

          case 'b':
               finished = TRUE;
               break;

          case 'c':
               while (abc_get_float(&in, &f))
                    printf("float: %g\n", f);
               break;

          case 'd':
               while (abc_get_double(&in, &m))
                    printf("double: %g\n", m);
               break;

          case 'f':
               printf("End test with: '$' \n");

               while (abc_get_field(&in, word, MAXWORD) and word[0] != '$')
                    printf("field: %s\n", word);
               break;

          case 'i':
               while (abc_get_int(&in, &n))
                    printf("int: %d\n", n);
               break;

          case 's':
               printf("Note: a string is delimited by '\"'. \n");

               while (abc_get_string(&in, word, MAXWORD))
                    printf("string: %s\n", word);
               break;

          case 'w':
               printf("End test with: '$' \n");

               while (abc_get_word(&in, word, MAXWORD) != '$')
                    printf("word: %s\n", word);
               break;

          case 'l':
               printf("\n");
               printf("Line no: %d,  ", abc_get_input_line_number(&in));
               printf("char pos: %d\n", abc_get_input_char_number(&in));
               break;

          case 'x':
               while (abc_get_expression(&in, &m))
                    printf("expression: %g\n", m);
               break;

          case 'B':
               abc_test_input_lib();
               break;

          case 'E':
               return;

          case 'M':
               if (not abc_get_macro_def(&in, FALSE))
                    printf("Error in macro def!\n");
               break;

          case 'R':
               printf("End test with: '$' \n");

               while (abc_get_word(&in, word, MAXWORD) != '$')
                    printf("word: %s\n", word);
               break;

          case 'S':
               abc_show_macro_defs(stdout);
               break;

          case 'V':
               if (not abc_get_var_def(&in, TRUE))
                    printf("Error for variable!\n");
               break;

          default:
               printf("Unknown test! \n");
               break;

          }

          abc_skip_rest_of_line(&in);
     }

     exit(0);
}


int abc_begin_input(
     AbcInput *in,         /* Input definition. */
     const char *filename)  /* File name; No file ("") is standard in. */
{
     FILE *newfile;

     /* Default initialization. */
    
     abc_init_input_def(in, NULL, "");

     if (filename == NULL or ABC_MATCH(filename, ""))
          newfile = stdin;
     else
     {
          if ((newfile = fopen(filename, "r")) == NULL)
               return FALSE;
     }

     /* Are hash tables initialized? */

     if (not is_initialized)
     {
          abc_init_input_vars();
          is_initialized = TRUE;
     }

     /* Initialize the input definition. */

     abc_init_input_def(in, newfile, filename);

     /* Promt for commands? */

     if (in->file == stdin and use_promt)
          printf("%s", promt);

     /* Successful beginning of a new file. */

     return TRUE;
}


void abc_init_input_def(
     AbcInput *in,
     FILE *newfile,
     const char *filename)
{
     in->bp = -1;
     in->char_no = 0;
     in->line_no = 1;
     in->file = newfile;
     in->read_input = abc_read_default;
     in->is_open = (newfile != NULL);
     in->prev_in = NULL;

     if (in->file == stdin)
     {
          strcpy(in->file_name, "(stdin)");
          abc_install_string("FILENAME", "(stdin)");
     }
     else
     {
          strcpy(in->file_name, filename);
          abc_install_string("FILENAME", filename);
     }
}


void abc_copy_input_def(
     AbcInput *in1,
     AbcInput *in2)
{
     in2->bp         = in1->bp;
     in2->char_no    = in1->char_no;
     in2->line_no    = in1->line_no;
     in2->file       = in1->file;
     in2->read_input = in1->read_input;
     in2->is_open    = in1->is_open;
     in2->prev_in    = in1->prev_in;
     strcpy(in2->file_name, in1->file_name);
     strcpy(in2->buffer, in1->buffer);
     abc_install_string("FILENAME", in1->file_name);
}


void abc_read_default(
     AbcInput *in)   /* Input definition. */
{
     while (not abc_end_of_if_branch(in))
          abc_look_ahead(in);
}


void abc_init_input_vars(
     void)
{
     if (is_initialized) return;

     /* Math functions. */

     abc_install_all_math_funcs();

     /* Macros */

     abc_install_macro("q", 0, "exit", ABC_NON_CONST_MACRO);
     abc_install_macro("nl", 0, "newline stdout", ABC_CONST_MACRO);
     abc_install_macro("then", 0, "", ABC_CONST_MACRO);
     abc_install_macro("not", 0, "!", ABC_CONST_MACRO);
     abc_install_macro("and", 0, "&&", ABC_CONST_MACRO);
     abc_install_macro("or", 0, "||", ABC_CONST_MACRO);
     abc_install_macro("true", 0, "1", ABC_CONST_MACRO);
     abc_install_macro("false", 0, "0", ABC_CONST_MACRO);
     abc_install_macro("numb", 1, "eval $1 ;", ABC_CONST_MACRO);
     abc_install_macro("system", 0, "unix", ABC_CONST_MACRO);
     abc_install_macro("while", 2, 
         "if ($1) $2 define NEXT0 0 {while($1, $2)} else define NEXT0 0 {} end NEXT0",
          ABC_CONST_MACRO);
     abc_install_macro("while1", 2,
         "if ($1) $2 define NEXT1 0 {while($1, $2)} else define NEXT1 0 {} end NEXT1",
          ABC_CONST_MACRO);
     abc_install_macro("while2", 2,
         "if ($1) $2 define NEXT2 0 {while($1, $2)} else define NEXT2 0 {} end NEXT2",
          ABC_CONST_MACRO);
     abc_install_macro("while3", 2,
         "if ($1) $2 define NEXT3 0 {while($1, $2)} else define NEXT3 0 {} end NEXT3",
          ABC_CONST_MACRO);

     /* Varaibles */

     abc_install_var("e", 2.7182818284590452354, ABC_CONST_VAR);
     abc_install_var("pi", 3.14159265358979323846, ABC_CONST_VAR);
     abc_install_var("zero", 0.0, ABC_CONST_VAR);

#ifdef _SYSTEM_V_UNIX
     abc_install_var("isSystemV", 1.0, ABC_CONST_VAR);
#else
     abc_install_var("isSystemV", 0.0, ABC_CONST_VAR);
#endif

#ifdef _BERKELEY_UNIX
     abc_install_var("isBerkeley", 1.0, ABC_CONST_VAR);
#else
     abc_install_var("isBerkeley", 0.0, ABC_CONST_VAR);
#endif

#ifdef WIN32
     abc_install_var("isWin32", 1.0, ABC_CONST_VAR);
#else
     abc_install_var("isWin32", 0.0, ABC_CONST_VAR);
#endif

     /* Built-ins */

     abc_install_all_built_ins();

     is_initialized = TRUE;
}


void abc_delete_input_lib(
     void)
{
     if (not is_initialized) return;

     abc_delete_hash_table(&var_table);
     abc_delete_hash_table(&func_table);
     abc_delete_hash_table(&macro_table);
     abc_delete_hash_table(&command_table);
     abc_delete_hash_table(&string_table);
     abc_delete_hash_table(&desc_table);

     is_initialized = FALSE;
}


static void delete_var_item(
     void **buffer)
{
     RealVar *var = (RealVar *) *buffer;
     ABC_FREE(var->name);
     ABC_FREE(var);
     var = NULL;
}


static void delete_func_item(
     void **buffer)
{
     MathFunc *func = (MathFunc *) *buffer;
     ABC_FREE(func->name);
     ABC_FREE(func);
     func = NULL;
}


static void delete_macro_item(
     void **buffer)  
{    
     MacroDef *macro = (MacroDef *) *buffer;
     ABC_FREE(macro->name);
     ABC_FREE(macro->def);
     ABC_FREE(macro);
     macro = NULL;
}


static void delete_command_item(
     void **buffer)
{    
     BuiltIn *builtin = (BuiltIn *) *buffer;
     ABC_FREE(builtin->name);
     ABC_FREE(builtin->comment); 
     ABC_FREE(builtin);
     builtin = NULL;
}


static void delete_string_item(
     void **buffer)
{
     StringVar *string = (StringVar *) *buffer;
     ABC_FREE(string->name);
     ABC_FREE(string->def);
     ABC_FREE(string);
     string = NULL;
}


static void delete_desc_item(
     void **buffer)
{   
     OutputDesc *desc = (OutputDesc *) *buffer;
     ABC_FREE(desc->desc_name);
     ABC_FREE(desc->file_name);
     ABC_FREE(desc);
     desc = NULL;
}


void abc_end_input(
     AbcInput *in)   /* Input definition. */
{
     if (not in->is_open) 
          ABC_ERROR_RETURN("Stream is not open!");

     if (in->file != stdin and in->file != NULL) 
          fclose(in->file);

     in->file = NULL;
     in->is_open = FALSE;
}


void abc_get_input_lib_options(
     int *argc,   /* Number of arguments. */
     char **argv) /* Array of argument strings. */
{
     static char string[MAXBUF];
     static AbcInput in;
     char *new_argv[256] = {NULL};
     int new_argc = 0;
     int i;

     for (i = 0; i < *argc; i++)
          if (ABC_MATCH(argv[i], "-debCmd"))
               debug_cmd = TRUE;
          else if (ABC_MATCH(argv[i], "-debCond"))
               debug_condition = TRUE;
          else if (ABC_MATCH(argv[i], "-debMacro"))
               debug_macro_expansion = TRUE;
          else if (ABC_MATCH(argv[i], "-debLevels"))
               debug_levels = TRUE;
          else if (ABC_MATCH(argv[i], "-file"))
               abc_interpret_input_file(argv[++i]);
          else if (ABC_MATCH(argv[i], "-helpInput"))
          {
               abc_show_input_lib_options(stdout);
               exit(1);
          }
          else if (ABC_MATCH(argv[i], "-do"))
          {
               sprintf(string, "%s q ", argv[++i]);
               abc_begin_input(&in, "");
               abc_put_back_word(&in, string);
               abc_run_command_loop(&in);
               abc_end_input(&in);
          }
          else 
               new_argv[new_argc++] = argv[i];

     for (i = 0; i < new_argc; i++)
          argv[i] = new_argv[i];

     *argc = new_argc;
}


void abc_show_input_lib_options(
     FILE *out)
{
     fprintf(out, "Options:\n");
     fprintf(out, "   -do <string>    Run commands enclosed in quotes.\n");
     fprintf(out, "   -file <name>    Run commands in file.\n");
     fprintf(out, "   -debCmd         Debug commands.\n");
     fprintf(out, "   -debCond        Debug if-test conditions.\n");
     fprintf(out, "   -debMacro       Debug macros.\n");
     fprintf(out, "   -debLevels      Debug look-ahead levels.\n");
}


const char *get_promt(
     void)
{
     return promt;
}


void abc_set_read_function(
     AbcInput *in,   /* Input definition. */
     void (*read)(AbcInput *in))
{
     in->read_input = read;
}


void abc_set_comment_delimiters(
     int c1, /* The char beginning a comment. */
     int c2) /* The char ending a comment. */
{
     c_begin = (char) c1;
     c_end = (char) c2;
}


void abc_set_comment_skip(
     int on_off) /* True if comments are wanted skipped. */
{
     skip_comments = on_off;
}


void abc_set_macro_expansion(
     int on_off) /* True if macros are wanted expanded. */
{
     use_macro_expansion = on_off;
}


int abc_getch(
     AbcInput *in) /* Input definition. */
{
     int c = EOF;

     if (in->bp >= 0)
          c = in->buffer[in->bp--];
     else if (in->file == NULL)
          return EOF;
     else
     {
          /***
          while (((c = getc(in->file)) == EOF) and (errno == EINTR))
               errno = 0;
          ***/

          c = getc(in->file);

          if (in->file == stdin and log_file != NULL)
               putc(c, log_file);
     }

     if (c == '\n')
     {
          in->line_no++;
          in->char_no = 0;
     }
     else if (c != EOF)
          in->char_no++;

     if (c == EOF and in->prev_in != NULL)
     {
          AbcInput *in_prev = in->prev_in;
          abc_end_input(in);
          abc_copy_input_def(in_prev, in);
          ABC_FREE(in_prev);
          return abc_getch(in);
     }

     return c;
}


void abc_ungetch(
     AbcInput *in,  /* Input definition. */
     int c)          /* char to be put back */
{
     if (in->bp < MAXBUF - 1)
          in->buffer[++in->bp] = (char) c;
     else
          fprintf(stderr, "Buffer overflow! (Too large macro?) (lost %c)\n", c);

     if (c == '\n')
     {
          if (in->line_no > 0)
               in->line_no--;
          in->char_no = 0;
     }
     else
          in->char_no--;
}


int abc_is_next_word(
     AbcInput *in,
     const char *wanted)
{
     char word[ABC_MAX_WORD];

     if (not abc_get_word(in, word, ABC_MAX_WORD))
          return FALSE;

     abc_put_back_word(in, word);

     if (ABC_MATCH(word, wanted))
          return TRUE;

     return FALSE;
}


void abc_skip_rest_of_line(
     AbcInput *in) /* Input definition. */
{
     abc_skip_until_char(in, '\n');
}


int abc_skip_line(
     AbcInput *in)
{
     return abc_skip_until_char(in, '\n');
}


int abc_skip_until_char(
     AbcInput *in,
     int ch)
{
     int c;

     while ((c = abc_getch(in)) != EOF and c != ch)
          ;

     return (c == ch);
}


int abc_skip_until_word(
     AbcInput *in,
     const char *word)
{
     char text[ABC_MAX_WORD];

     while (abc_get_word(in, text, ABC_MAX_WORD) and (not ABC_MATCH(text, word)))
          ;

     return ABC_MATCH(text, word);
}


void abc_skip_comment_lines(
     AbcInput *in,
     int comment_char)
{
     int c;
     while ((c = abc_getch(in)) == comment_char)
          abc_skip_line(in);
     abc_ungetch(in, c);
}


int abc_get_input_line_number(
     AbcInput *in) /* Input definition. */
{
     return in->line_no;
}


int abc_get_input_char_number(
     AbcInput *in) /* Input definition. */
{
     return in->char_no;
}


FILE *abc_get_input_file_descriptor(
     AbcInput *in) /* Input definition. */
{
     return in->file;
}


char *abc_get_input_file_name(
     AbcInput *in) /* Input definition. */
{
     return in->file_name;
}


int abc_get_field(
     AbcInput *in, /* Input definition. */
     char *field,   /* The field returned. */
     int lim)       /* Number of chars in the word. */
{
     int c, i = 0;

     abc_look_ahead(in);

     for (c = abc_getch(in); not BLANKS(c) and c > 0; c = abc_getch(in))
          if (lim-- > 0)
               field[i++] = (char) c;

     field[i] = '\0';
     abc_ungetch(in, c);

     if (i == 0 and c == EOF)
          return FALSE;
     else
          return TRUE;
}


int abc_get_word(
     AbcInput *in, /* Input definition. */
     char *word,    /* The word returned. */
     int lim)       /* Number of chars in the word. */
{
     int i = 0;
     int c;

     abc_look_ahead(in);
     c = abc_getch(in);
     word[i++] = (char) c;

     if (not ALPHANUM(c))
     {
          word[i] = '\0';

          if (c == EOF)
               return FALSE;
          else
               return c;
     }

     for (c = abc_getch(in); ALPHANUM(c); c = abc_getch(in))
          if (--lim > 0)
               word[i++] = (char) c;

     word[i] = '\0';
     abc_ungetch(in, c);
     return c;
}


int abc_get_string(
     AbcInput *in,  /* Input definition. */
     char *string,   /* The string returned. */
     int size)       /* The size of string. */
{
     int c, i = 0;

     abc_look_ahead(in);
     c = abc_getch(in);

     if (c != '"')
     {
          string[0] = '\0';
          abc_ungetch(in, c);
          return FALSE;
     }

     for (c = abc_getch(in); c != '"'; c = abc_getch(in))
          if (--size > 0)
               string[i++] = (char) ((c == '\\') ? abc_getch(in) : c);

     string[i] = '\0';

     /*
     **  Insert strings.
     */

     insert_substrings(string, size);

     return TRUE;
}


static void insert_substrings(
     char *string,
     int max_size)
{
     char str_name[MAXWORD], str_def[MAXWORD], newstring[MAXWORD];
     int counter = 0;
     int i, k;
     int n = 0;

     for (i = 0; i < (int) strlen(string); i++)
     {
          if (get_string_name_and_def(&string[i], str_name, str_def))
          {
               if (debug_substrings)
                    printf("(inserting substring: $%s=\"%s\")\n", str_name, str_def);

               for (k = 0; k < (int) strlen(str_def); n++, k++)
                    if (n < max_size)
                         newstring[n] = str_def[k];

               i += (int) strlen(str_name);
               counter++;
          }
          else if (n < max_size)
          {
               newstring[n] = string[i];
               n++;
          }
     }

     if (counter == 0)
          return;

     if (n >= max_size) n = max_size - 1;
     newstring[n] = '\0';

     if (debug_substrings)
          printf("(old-string=\"%s\" and new-string=\"%s\"\n", string, newstring);

     for (i = 0; i <= n; i++)
          string[i] = newstring[i];
}


static int get_string_name_and_def(
     const char *string,
     char *name,
     char *def)
{
     int i;
     StringVar *var = NULL;

     if (string[0] != '$')
          return FALSE;

     string++;

     for (i = 0; (i < (int) strlen(string)) and ALPHANUM(string[i]); i++)
          name[i] = string[i];

     name[i] = '\0';

     if (i < 1)
          return FALSE;

     var = (StringVar *) abc_hash_table_lookup(string_table, name);

     if (var == 0)
          return FALSE;

     strcpy(def, var->def);

     return TRUE;
}


int abc_get_int(
     AbcInput *in,  /* Input definition. */
     int *value)     /* The integer returned. */
{
     char field[MAXWORD];
     int c, i = 0;

     abc_look_ahead(in);

     for (c = abc_getch(in); SIGNED(c); c = abc_getch(in))
           if (i < MAXWORD - 1)
                field[i++] = (char) c;

     field[i] = '\0';
     abc_ungetch(in, c);

     if (sscanf(field, "%d", value) > 0)
          return TRUE;
     else
          return FALSE;
}


int abc_get_float(
     AbcInput *in, /* Input definition. */
     float *value)  /* The float returned */
{
     double dummy;

     if (abc_get_double(in, &dummy))
     {
          *value = (float) dummy;
          return TRUE;
     }
     else
          return FALSE;
}


int abc_get_double(
     AbcInput *in,  /* Input definition. */
     double *value)  /* The double returned */
{
     char field[MAXWORD];
     int c;
     int i = 0;

     *value = 0.0; /* if error */
     abc_look_ahead(in);
     c = abc_getch(in);

     if (c == '+' or c == '-')
          field[i++] = (char) c;
     else
          abc_ungetch(in, c);

     for (c = abc_getch(in); DIGIT(c); c = abc_getch(in))
          if (i < MAXWORD - 1)
               field[i++] = (char) c;

     if (c == '.')
          field[i++] = (char) c;
     else
          abc_ungetch(in, c);

     for (c = abc_getch(in); DIGIT(c); c = abc_getch(in))
          if (i < MAXWORD - 1)
               field[i++] = (char) c;

     if (c == 'e' or c == 'E')
     {
          field[i++] = (char) c;
          c = abc_getch(in);

          if (c == '+' or c == '-' or DIGIT(c))
               field[i++] = (char) c;
          else
               return FALSE;

          for (c = abc_getch(in); DIGIT(c); c = abc_getch(in))
               if (i < MAXWORD - 1)
                    field[i++] = (char) c;
     }

     abc_ungetch(in, c);
     field[i] = '\0';

     if (sscanf(field, "%lf", value) > 0)
          return TRUE;
     else
          return FALSE;
}


int abc_get_expression(
     AbcInput *in, /* Input definition. */
     double *numb)  /* The expression. */
{
     int c = 0;
     int op = 0;
     double expr = 0.0;

     abc_look_ahead(in);

     if (not abc_get_simple_expr(in, numb))
          return FALSE;

     while (abc_get_logical_op(in, &op))
     {
          if (not abc_get_simple_expr(in, &expr))
               return FALSE;

          if (debug_condition)
          {
               if (op == OP_OR or op == OP_AND)
                    printf("%d %s %d\n", (int) (*numb), op_name[op], (int) expr);
               else
                    printf("%g %s %g\n", (*numb), op_name[op], expr);
          }

          switch(op)
          {
               case OP_EQ:  *numb = (int) (fabs(*numb - expr) < 1.0e-25); break;
               case OP_NE:  *numb = (int) (fabs(*numb - expr) >= 1.0e-25); break;
               case OP_LT:  *numb = (int) (*numb <  expr); break;
               case OP_LE:  *numb = (int) (*numb <= expr); break;
               case OP_GT:  *numb = (int) (*numb >  expr); break;
               case OP_GE:  *numb = (int) (*numb <= expr); break;
               case OP_OR:  *numb = (int) (*numb) || (int) expr; break;
               case OP_AND: *numb = (int) (*numb) && (int) expr; break;
               default:
                    fprintf(stderr, "[abc_get_expression] Illegal logical operator!\n");
                    return FALSE;
          }
     }

     abc_skip_blanks_and_comments(in);
     c = abc_getch(in);
     if (c != ';') abc_ungetch(in, c);
     return TRUE;
}


int abc_get_simple_expr(
     AbcInput *in, /* Input definition. */
     double *numb)  /* The simple expression. */
{
     int c = 0;
     int negate = FALSE;
     double term = 0.0;
     double sign = 1.0;

     abc_skip_blanks_and_comments(in);
     abc_try_to_expand_text(in);
     c = abc_getch(in);

     if (c == '!')
          negate = TRUE;
     else
          abc_ungetch(in, c);

     abc_skip_blanks_and_comments(in);
     c = abc_getch(in);

     if (c == '+')
          sign = 1.0;
     else if (c == '-')
          sign = -1.0;
     else
          abc_ungetch(in, c);

     if (not abc_get_term(in, numb))
          ABC_RETURN_FALSE("Missing term in expression!");

     *numb *= sign;
     abc_skip_blanks_and_comments(in);
     abc_try_to_expand_text(in);

     for (c = abc_getch(in); c == '-' or c == '+'; c = abc_getch(in))
     {
          if (not abc_get_term(in, &term))
               ABC_RETURN_FALSE("Missing term after '+' or '-'!");

          if (c == '+')
               *numb += term;
          else
               *numb -= term;
     }

     abc_ungetch(in, c);
     if (negate) *numb = ! (int) (*numb);
     return TRUE;
}


int abc_get_term(
     AbcInput *in,  /* Input definition. */
     double *term)  /* The term. */
{
     int c;
     double factor;

     if (not abc_get_factor(in, term))
          ABC_RETURN_FALSE("Can't get factor!");

     abc_skip_blanks_and_comments(in);
     abc_try_to_expand_text(in);

     for (c = abc_getch(in); 
          c == '*' or c == '/' or c == '%' or c == '|' or c == '&'; 
          c = abc_getch(in))
     {
          if (not abc_get_factor(in, &factor))
               ABC_RETURN_FALSE("Missing factor after '*', '/' or '%' !");

          switch (c)
          {
               case '*': *term *= factor;                      break;
               case '/': *term = get_quotient(*term, factor);  break;
               case '%': *term = (int) (*term) % (int) factor; break;
               case '|': *term = (int) (*term) | (int) factor; break;
               case '&': *term = (int) (*term) & (int) factor; break;
               default: 
                    fprintf(stderr, "Error: Illegal operand! (op=%c)\n", c);
                    *term = 0.0;
                    return FALSE;
          }
             
          abc_skip_blanks_and_comments(in);
     }

     abc_ungetch(in, c);
     return TRUE;
}


static double get_quotient(
     double dividend,
     double divisor)
{
     if (abs_func(divisor) < 1.0e-50)
     {
          fprintf(stderr, "Error: Division by zero!\n");
          return 0.0;
     }

     return (dividend / divisor);
}


int abc_get_factor(
     AbcInput *in,   /* Input definition. */
     double *factor)  /* The factor. */
{
     int c;

     abc_skip_blanks_and_comments(in);
     abc_try_to_expand_text(in);
     c = abc_getch(in);

     if (c == '(')
     {
          abc_get_expression(in, factor);
          abc_look_ahead(in);
          c = abc_getch(in);

          if (c != ')')
               ABC_RETURN_FALSE("Missing ')' in factor!");
     }
     else
     {
          abc_ungetch(in, c);

          if (ALPHA(c))
               return abc_get_var_or_func(in, factor);
          else
               return abc_get_double(in, factor);
     }

     return TRUE;
}


int abc_get_var_or_func(
     AbcInput *in, /* Input definition. */
     double *numb)  /* A variable or function value. */
{
     RealVar *var;
     MathFunc *func;
     char name[MAXWORD], word[MAXWORD];

     if (not abc_get_word(in, name, MAXWORD))
          return FALSE;

     if (func_table == NULL)
          abc_install_all_math_funcs();

     if ((func = (MathFunc *) abc_hash_table_lookup(func_table, name)) != NULL)
     {
          if (not abc_get_word(in, word, MAXWORD)) return FALSE;
          if (word[0] != '(') return FALSE;
          abc_get_expression(in, numb);
          if (not abc_get_word(in, word, MAXWORD)) return FALSE;
          if (word[0] != ')') return FALSE;
          *numb = func->func(*numb);
          return TRUE;
     }

     if (var_table == NULL)
     {
          abc_install_var("pi", 3.141592653, ABC_CONST_VAR);
          abc_install_var("zero", 0.0, ABC_CONST_VAR);
     }

     if ((var = (RealVar *) abc_hash_table_lookup(var_table, name)) != NULL)
     {
          *numb = var->value;
          return TRUE;
     }

     abc_put_back_word(in, name);
     fprintf(stderr, "%s is neither variable or function!\n", name);
     return FALSE;
}


int abc_get_var_def(
     AbcInput *in, /* Input definition. */
     int constant)  /* True for constants. */
{
     double value;
     char name[MAXWORD], word[MAXWORD];

     if (not abc_get_word(in, name, MAXWORD))
          return FALSE;

     if (not abc_get_word(in, word, MAXWORD))
          return FALSE;

     if (word[0] != '=')
          return FALSE;

     if (not abc_get_expression(in, &value))
          return FALSE;

     abc_install_var(name, value, constant);
     return TRUE;
}


int abc_get_macro_def(
     AbcInput *in, /* Input definition. */
     int constant)  /* True for constant macros. */
{
     int c, i, argc, level, inside_string = FALSE;
     int counter = 0;
     static char def[MAXBUF] = "";
     char name[MAXWORD];

     if (not abc_next_alphanum_word(in, name, MAXWORD))
     {
          abc_input_error(in, "Illegal macro name!");
          return FALSE;
     }

     if (not abc_next_int(in, &argc))
     {
          abc_input_error(in, "Can't get number of arguments!");
          return FALSE;
     }

     if (argc < 0 or MAXARGS <= argc)
     {
          abc_input_error(in, "Illegal number of arguments!");
          return FALSE;
     }

     abc_skip_blanks_and_comments(in);

     if ((c = abc_getch(in)) != '{')
          return FALSE;

     for (c = abc_getch(in), i = 0, level = 0;
         ((c != EOF) and (c != '}')) or inside_string or level;
          c = abc_getch(in))
     {
          /* Comments are skipped. */

          if (not inside_string and c == c_begin)
          {
               abc_ungetch(in, c);
               abc_skip_blanks_and_comments(in);
               continue;
          }

          /* Is this the beginning or the end of a string? */

          if (c == '"' and i == 0)
               inside_string = TRUE;
          else if (c == '"' and i > 0 and def[i-1] != '\\')
               inside_string = not inside_string;

          /* The escape backslash '\' is used for to protection. */

          if (c == '\\' and not inside_string)
               if ((c = abc_getch(in)) == EOF)
                    continue;

          /* The char '\n' in macro defs are skipped, so the
          line counter "line_no" won't be disturbed because of
          an expanded macro. */

          if (c == '\n' and not inside_string)
               continue;

          /* Multiple blanks are skipped. */

          if (not inside_string and BLANKS(c) and i > 0 and def[i-1] == ' ')
               continue;

          /* Count level of parentheses. */

          if (c == '{') level++;
          if (c == '}') level--;

          if (i < MAXBUF - 2)
               def[i++] = (char) c;
          else
               counter++;
     }

     def[i] = '\0';

     if (counter > 0)
          fprintf(stderr, "Error: Macro \"%s\" is too large!\n", name);

     abc_install_macro(name, argc, def, constant);

     if (c == '}')
          return TRUE;
     else
          return FALSE;
}


int abc_get_condition(
     AbcInput *in, /* Input definition. */
     int *cond)     /* Condition (TRUE or FALSE) */
{
     int c;
     double expr;

     abc_skip_blanks_and_comments(in);
     abc_try_to_expand_text(in);
     c = abc_getch(in);

     if (c != '(')
          return FALSE;

     if (not abc_get_expression(in, &expr))
          return FALSE;

     abc_skip_blanks_and_comments(in);
     c = abc_getch(in);

     if (c != ')')
          return FALSE;

     *cond = (int) expr;
     return TRUE;
}


int abc_get_logical_op(
     AbcInput *in, /* Input definition. */
     int *op)       /* The logical operator. */
{
     int c;

     abc_skip_blanks_and_comments(in);
     c = abc_getch(in);

     switch(c)
     {
          case '=':
               if ((c = abc_getch(in)) == '=')
                    *op = OP_EQ;
               else
                    return FALSE;
               break;

          case '!':
               if ((c = abc_getch(in)) == '=')
                    *op = OP_NE;
               else
                    return FALSE;
               break;

          case '<':
               if ((c = abc_getch(in)) == '=')
                    *op = OP_LE;
               else {
                    *op = OP_LT;
                    abc_ungetch(in, c);
               }
               break;

          case '>':
               if ((c = abc_getch(in)) == '=')
                    *op = OP_GE;
               else {
                    *op = OP_GT;
                    abc_ungetch(in, c);
               }
               break;

          case '|':
               if ((c = abc_getch(in)) == '|')
                    *op = OP_OR;
               else
                    return FALSE;
               break;

          case '&':
               if ((c = abc_getch(in)) == '&')
                    *op = OP_AND;
               else
                    return FALSE;
               break;

          default:
               abc_ungetch(in, c);
               return FALSE;
     }

     return TRUE;
}


void abc_look_ahead(
     AbcInput *in) /* Input definition. */
{
     char word[MAXWORD];
     static int current_level = 0;  /* For debugging */

     abc_skip_blanks_and_comments(in);
     abc_try_to_expand_text(in);

     if (not is_key_word_sensitiv)
          return;

     current_level++;

     if (debug_levels)
          printf("Enter look ahead = %d\n", current_level);

     while(abc_next_alphanum_word(in, word, MAXWORD))
     {
          if (not abc_run_built_in(in, word))
          {
               abc_put_back_word(in, word);
               break;
          }

          abc_skip_blanks_and_comments(in);
          abc_try_to_expand_text(in);
     }

     if (debug_levels)
          printf("Leaving look ahead = %d\n", current_level);

     current_level--;
}


void abc_skip_until_key_word(
     AbcInput *in,           /* Input definition. */
     const char *key_word)   /* Skip input until this key word. */
{
     char word[MAXWORD];
     int previous_state = is_key_word_sensitiv;
     int previous_macro = use_macro_expansion;

     is_key_word_sensitiv = FALSE;
     use_macro_expansion = FALSE;

     while(abc_get_word(in, word, MAXWORD))
          if (ABC_MATCH(word, "\""))
               abc_skip_until_end_of_string(in);
          else if (ABC_MATCH(word, "if"))
               abc_skip_until_key_word(in, "end");
          else if (ABC_MATCH(word, key_word))
               break;

     is_key_word_sensitiv = previous_state;
     use_macro_expansion = previous_macro;
}


void abc_skip_until_end_of_string(
     AbcInput *in)     /* Input definition. */
{
     int c, c_prev;
     int end_of_string = FALSE;

     for (c_prev = 0, c = abc_getch(in); 
          not end_of_string; 
          c_prev = c, c = abc_getch(in))
     {
          if (c_prev != '\\' and c == '"') end_of_string = TRUE;
          if (c == EOF) return;
     }

     abc_ungetch(in, c);
}


int abc_end_of_if_branch(
     AbcInput *in)     /* Input definition. */
{
     char word[MAXWORD];

     if (not abc_get_word(in, word, MAXWORD))
          return TRUE;

     abc_put_back_word(in, word);

     if (ABC_MATCH(word, "elseif") or 
         ABC_MATCH(word, "else") or 
         ABC_MATCH(word, "end"))
          return TRUE;
     else
          return FALSE;
}


int abc_search_for_next_branch(
     AbcInput *in)     /* Input definition. */
{
     char word[MAXWORD];
     int result = FALSE;
     int previous_state = is_key_word_sensitiv;
     int previous_macro = use_macro_expansion;

     is_key_word_sensitiv = FALSE;
     use_macro_expansion = FALSE;

     while(abc_get_word(in, word, MAXWORD))
          if (ABC_MATCH(word, "\""))
               abc_skip_until_end_of_string(in);
          else if (ABC_MATCH(word, "if"))
               abc_skip_until_key_word(in, "end");
          else if (ABC_MATCH(word, "else"))
          {
               result = TRUE;
               break;
          }
          else if (ABC_MATCH(word, "elseif"))
          {
               result = FALSE;
               break;
          }
          else if (ABC_MATCH(word, "end"))
          {
               result = FALSE;
               break;
          }

     abc_put_back_word(in, word);
     is_key_word_sensitiv = previous_state;
     use_macro_expansion = previous_macro;
     return result;
}


int abc_skip_blanks_and_comments(
     AbcInput *in)     /* Input definition. */
{
     int c;
     int got_new_line = FALSE;

     if (not skip_comments)
          return got_new_line;

     for (c = abc_getch(in); BLANKS(c) or c == c_begin; c = abc_getch(in))
     {
          if (c == '\n') 
               got_new_line = TRUE;

          if (c == c_begin)
               for (c = abc_getch(in); c != c_end; c = abc_getch(in))
                    if (c == '\n')
                         got_new_line = TRUE;

          if (c == '\n' and in->file == stdin and use_promt)
               printf("%s", promt);
     }

     abc_ungetch(in, c);
     return got_new_line;
}


int abc_read_key_word_and_number(
     AbcInput *in,
     const char *keyword,
     double *numb)
{
     char word[MAXWORD];

     if (not abc_get_word(in, word, MAXWORD) or not ABC_MATCH(word, keyword))
     {
          abc_read_error2(in, "Can't read keyword!", keyword);
          return FALSE;
     }

     if (not abc_get_word(in, word, MAXWORD) or not ABC_MATCH(word, "="))
     {
          abc_read_error(in, "Can't read equal sign!");
          return FALSE;
     }

     if (not abc_get_double(in, numb))
     {
          abc_read_error2(in, "Can't read number after keyword!", keyword);
          return FALSE;
     }

     return TRUE;
}


int abc_read_key_word_and_yes_no(
     AbcInput *in,
     const char *keyword,
     int *yes_no)
{
     char word[MAXWORD];

     if (not abc_get_word(in, word, MAXWORD) or not ABC_MATCH(word, keyword))
     {
          abc_read_error2(in, "Can't read keyword!", keyword);
          return FALSE;
     }

     if (not abc_get_word(in, word, MAXWORD) or not ABC_MATCH(word, "="))
     {
          abc_read_error(in, "Can't read equal sign!");
          return FALSE;
     }

     if (not abc_get_word(in, word, MAXWORD))
     {
          abc_read_error(in, "Can't read \"yes\" or \"no\"!");
          return FALSE;
     }

     if (not ABC_MATCH(word, "yes") and not ABC_MATCH(word, "no"))
     {
          abc_read_error(in, "Expected keyword \"yes\" or \"no\"!");
          return FALSE;
     }

     *yes_no = FALSE;
     if (ABC_MATCH(word, "yes")) *yes_no = TRUE;

     return TRUE;
}


void abc_read_error(
     AbcInput *in,
     const char *text)
{
     fprintf(stderr, "(file: %s, line: %d) %s\n",
          abc_get_input_file_name(in),
          abc_get_input_line_number(in),
          text);
}


void abc_read_error2(
     AbcInput *in,
     const char *text1,
     const char *text2)
{
     fprintf(stderr, "(file: %s, line: %d) %s %s\n",
          abc_get_input_file_name(in),
          abc_get_input_line_number(in),
          text1, text2);
}


int abc_run_built_in(
     AbcInput *in,      /* Input definition. */
     const char *name)   /* Command name. */
{
     BuiltIn *built_in;
     char word[MAXWORD];

     if (command_table == NULL)
          abc_install_all_built_ins();

     if ((built_in = (BuiltIn *) abc_hash_table_lookup(command_table, name)) != NULL)
     {
          if (debug_cmd) printf("Running: %s\n", name);
          built_in->func(in);
          while (abc_next_alphanum_word(in, word, MAXWORD) and ABC_MATCH(word, ";"))
               ;
          abc_put_back_word(in, word);
          return TRUE;
     }

     return FALSE;
}


void abc_show_variables(
     FILE *out) /* write defined variables to the file "out" */
{
     fprintf(out, "Variables:\n");
     fprintf(out, "==========\n");
     abc_print_hash_table(out, var_table, print_variable);
}


static void print_variable(
     FILE *out,
     void const *buffer)
{
     RealVar *var = (RealVar *) buffer;
     fprintf(out, "=%g", var->value);
     fprintf(out, "%s\n", (var->constant) ? " (const)" : "");
}


void abc_show_macro_defs(
     FILE *out) /* write macro definitions to the file "out" */
{
     fprintf(out, "Macro definitions:\n");
     fprintf(out, "==================\n");
     abc_print_hash_table(out, macro_table, print_macro_def);
}


static void print_macro_def(
     FILE *out,
     void const *buffer)
{
     MacroDef *macro = (MacroDef *) buffer;
     fprintf(out, "=%s", macro->def);
     fprintf(out, "%s\n", (macro->constant) ? " (const)" : "");
}


void abc_show_math_funcs(
     FILE *out) /* write defined math functions to the file "out" */
{
     fprintf(out, "Mathematical functions:\n");
     fprintf(out, "=======================\n");
     abc_print_hash_table(out, func_table, print_math_func);
}


static void print_math_func(
     FILE *out,
     void const *buffer)
{
     fprintf(out, "(x)\n");

     ABC_UNUSED_PARAMETER(buffer);
}


void abc_show_built_ins(
     FILE *out) /* write built-in commands to the file "out" */
{
     fprintf(out, "Built-in commands:\n");
     fprintf(out, "==================\n");
     abc_print_hash_table(out, command_table, print_built_ins);
}


void abc_show_strings(
     FILE *out) /* write built-in commands to the file "out" */
{
     fprintf(out, "Strings:\n");
     fprintf(out, "========\n");
     abc_print_hash_table(out, string_table, print_strings);
}


static void print_built_ins(
     FILE *out,
     void const *buffer)
{
     int i;
     BuiltIn *built_in = (BuiltIn *) buffer;

     for (i = 20 - strlen(built_in->name); i > 0; i--)
          fprintf(out, " ");

     fprintf(out, "%s\n", built_in->comment);
}


static void print_strings(
     FILE *out,
     void const *buffer)
{
     int i;
     StringVar *string = (StringVar *) buffer;

     for (i = 20 - strlen(string->name); i > 0; i--)
          fprintf(out, " ");

     fprintf(out, "%s\n", string->def);
}


void abc_what_is_next_word(
     AbcInput *in, /* Input definition. */
     FILE *out)     /* write macro def to the file "file" */
{
     char word[MAXWORD];
     MacroDef *macro;

     if (not abc_next_alphanum_word(in, word, MAXWORD))
          fprintf(out, "(unable to read word)\n");

     macro = (MacroDef *) abc_hash_table_lookup(macro_table, word);

     if (macro == NULL)
          fprintf(out, "(undefined)\n");
     else
          fprintf(out, "%s is defined as: %s\n", word, macro->def);
}


void abc_try_to_expand_text(
     AbcInput *in) /* Input definition. */
{
     char word[MAXWORD];

     if (not use_macro_expansion) return;
     while(abc_next_alphanum_word(in, word, MAXWORD) and abc_expand_macro(in, word))
          ;
     abc_put_back_word(in, word);
}


int abc_next_int(
     AbcInput *in, /* Input definition. */
     int *value)    /* Int value. */
{
     char field[MAXWORD];
     int c, i = 0;

     abc_skip_blanks_and_comments(in);

     for (c = abc_getch(in); SIGNED(c); c = abc_getch(in))
           if (i < MAXWORD-1)
                field[i++] = (char) c;
     field[i] = '\0';

     abc_ungetch(in, c);

     if (sscanf(field, "%d", value) > 0)
          return TRUE;
     else
          return FALSE;
}


int abc_next_alphanum_word(
     AbcInput *in, /* Input definition. */
     char *field,   /* Char field. */
     int size)      /* Max allowed size of field. */
{
     int c, i = 0;

     abc_skip_blanks_and_comments(in);

     for (c = abc_getch(in); ALPHANUM(c); c = abc_getch(in))
          if (size-- > 0)
               field[i++] = (char) c;

     field[i] = '\0';
     abc_ungetch(in, c);

     if (i > 0)
          return TRUE;
     else
          return FALSE;
}


int abc_expand_macro(
     AbcInput *in, /* Input definition. */
     char *word)    /* try to expand "word" as a macro */
{
     int i, n, inside_string = FALSE;
     MacroDef *macro;

     if ((macro = (MacroDef *) abc_hash_table_lookup(macro_table, word)) == NULL)
          return FALSE;

     if (not abc_get_macro_args(in, word, macro->argc))
          return FALSE;

     for (i = strlen(macro->def) - 1; i >= 0; i--)
     {
          if (i > 0)
               if (macro->def[i] == '"' and macro->def[i-1] != '\\')
                    inside_string = not inside_string;

          if (macro->def[i] == '$' and not inside_string)
          {
               if (not abc_get_int(in, &n))
                    abc_input_error(in, "Can't get argument number!");
               else if (n < 0 or macro->argc < n)
                    abc_input_error(in, "Undefined macro argument!");
               else
                    abc_put_back_word(in, argument[n]);
          }
          else
               abc_ungetch(in, macro->def[i]);
     }

     if (debug_macro_expansion)
          printf("%s ==> %s\n", word, macro->def);

     return TRUE;
}


int abc_expand_var(
     AbcInput *in, /* Input definition. */
     char *name)    /* Variable name. */
{
     RealVar *var = NULL;

     if ((var = (RealVar *) abc_hash_table_lookup(var_table, name)) != NULL)
     {
          double numb = (double) var->value;
          abc_put_back_double(in, numb, "%g");
          return TRUE;
     }

     return FALSE;
}


int abc_get_macro_args(
     AbcInput *in,    /* Input definition. */
     const char *name, /* Macro name */
     int n)            /* read "n" macro args */
{
     int c, i;

     /* Turn macro expansion off; macros may be arguments. */

     int result, save_macro_expansion;

     if (n == 0) return TRUE;
     save_macro_expansion = use_macro_expansion;
     use_macro_expansion = FALSE;
     abc_skip_blanks_and_comments(in);
     c = abc_getch(in);
     abc_ungetch(in, c);

     if (c == '(')
          result = abc_get_new_macro_args(in, name, n);
     else
          result = abc_get_old_macro_args(in, n);

     if (debug_macro_expansion)
          for (i = 1; i <= n; i++)
               printf("arg[%d]=%s\n", i, argument[i]);

     use_macro_expansion = save_macro_expansion;
     return result;
}


int abc_get_old_macro_args(
     AbcInput *in, /* Input definition. */
     int n)         /* read "n" macro args */
{
     int c, i;
     char arg[MAXWORD];

     /* Turn macro expansion off; macros may be arguments. */

     int save_macro_expansion = use_macro_expansion;
     use_macro_expansion = FALSE;

     /* Read all n arguments. */

     for (i = 0; i < n; i++)
     {
          abc_skip_blanks_and_comments(in);
          c = abc_getch(in);
          abc_ungetch(in, c);

          /* Skip blanks, expand text, and read field/string. */

          if (c == '"') {
               if (not abc_get_string(in, arg, MAXWORD)) {
                    use_macro_expansion = save_macro_expansion;
                    return FALSE;
               }
          }
          else {
               if (not abc_get_field(in, arg, MAXWORD)) {
                    use_macro_expansion = save_macro_expansion;
                    return FALSE;
               }
          }

          /* A string argument is enclosed by double quotes. */

          if (c == '"')
          {
               strcpy(argument[i+1], "\"");
               strcat(argument[i+1], arg);
               strcat(argument[i+1], "\"");
          }
          else
               strcpy(argument[i+1], arg);
     }

     /* Restore macro expansion state, and return. */

     use_macro_expansion = save_macro_expansion;
     return TRUE;
}


int abc_get_new_macro_args(
     AbcInput *in,    /* Input definition. */
     const char *name, /* Macro name */
     int n)            /* read "n" macro args */
{
     int c, c_prev, i, j, inside_string, level;

     /* Turn macro expansion off; macros may be arguments. */

     int save_macro_expansion = use_macro_expansion;
     use_macro_expansion = FALSE;
     abc_skip_blanks_and_comments(in);
     c = abc_getch(in);

     if (c != '(')
     {
          abc_ungetch(in, c);
          use_macro_expansion = save_macro_expansion;

          if (n == 0)
               return TRUE;
          else
               return FALSE;
     }

     /* Read all n arguments. */

     for (i = 1; c != ')'; i++)
     {
          if (i == MAXARGS)
          {
               abc_input_error(in, "Too many macro arguments!");
               exit(1);
          }

          abc_skip_blanks_and_comments(in);
          inside_string = FALSE;

          for (c_prev = 0, c = abc_getch(in), j = 0, level = 0;
               inside_string or level or ((c != ',') and (c != ')'));
               c_prev = c, c = abc_getch(in))
          {
               if ((c == '(' or c == '[' or c == '{') and not inside_string) level++;
               if ((c == ')' or c == ']' or c == '}') and not inside_string) level--;
               if (c_prev != '\\' and c == '"') inside_string = not inside_string;
               if (j < MAXWORD - 1) argument[i][j++] = (char) c;
          }

          argument[i][j] = '\0';

          if (j == 0)
               i--;  /* Empty arguments don't count! */
          else if (j == MAXWORD - 1)
               fprintf(stderr, "[abc_get_new_macro_args] Arg %d may be to large!", j);
     }

     /* Check the number of arguments */

     if (i - 1 != n)
          fprintf(stderr, "Expected %d args for \"%s\", but got %d args!\n", 
               n, name, i - 1);

     /* Restore macro expansion state, and return. */

     use_macro_expansion = save_macro_expansion;
     return TRUE;
}


void abc_put_back_word(
     AbcInput *in,      /* Input definition. */
     const char *word)   /* put "word" back into input buffer */
{
     int i;

     for (i = strlen(word) - 1; i >= 0; i--)
          abc_ungetch(in, word[i]);
}


void abc_put_back_int(
     AbcInput *in,      /* Input definition. */
     int numb,           /* put int "numb" back into input buffer */
     const char *format) /* use this format */
{
     char word[MAXWORD];

     sprintf(word, format, numb);
     abc_put_back_word(in, word);
}


void abc_put_back_double(
     AbcInput *in,      /* Input definition. */
     double numb,        /* put double "numb" back into input buffer */
     const char *format) /* use this format */
{
     char word[MAXWORD];

     sprintf(word, format, numb);
     abc_put_back_word(in, word);
}


void abc_report_abc_input_error(
     AbcInput *in,      /* Input definition. */
     FILE *out,          /* write the error message to file "out" */
     const char *text)   /* the error message */
{
     if (in->file != stdin)
          fprintf(out, "File: \"%s\", ", in->file_name);

     if (in->is_open)
          fprintf(out, "line %d: %s\n", in->line_no, text);
     else
          fprintf(out, "%s\n", text);
}


void abc_input_error(
     AbcInput *in,      /* Input definition. */
     const char *text)   /* the error message */
{
     abc_report_abc_input_error(in, stderr, text);
}


static char *save_string(
     const char *string) /* string to be saved */
{
     char *p;

     ABC_NEW_ARRAY(p, char, (strlen(string) + 1));
     strcpy(p, string);

     return p;
}


static int is_name_ok_for_table(
     AbcHashTable *table1,
     const char *name)
{
     int i;
     int is_ok_for_table = TRUE;
     AbcHashTable *hashtable[5] = {
          macro_table, 
          var_table, 
          func_table, 
          command_table, 
          desc_table
     };

     if (table1 == NULL)
          return TRUE;

     for (i = 0; i < 5; i++)
     {
          if ((hashtable[i] == NULL) or (hashtable[i] == table1))
               continue;

          if (abc_hash_table_lookup(hashtable[i], name) != NULL)
          {
               const char *type1 = get_hash_table_name(table1);
               const char *type2 = get_hash_table_name(hashtable[i]);
               fprintf(stderr, "Can't define \"%s\" as %s! ", name, type1);
               fprintf(stderr, "(it's a %s)\n", type2);
               is_ok_for_table = FALSE;
          }
     }

     return is_ok_for_table;
}


static const char *get_hash_table_name(
     AbcHashTable *table)
{
     if (table == var_table) return "variable";
     if (table == func_table) return "math-function";
     if (table == desc_table) return "file-descriptor";
     if (table == macro_table) return "macro";
     if (table == string_table) return "string";
     if (table == command_table) return "command";

     return "unknown";
}

     
void abc_install_macro(
     const char *name,
     int argc,
     const char *def,
     int constant)
{
     MacroDef *macro;

     if (macro_table == NULL)
          macro_table = abc_create_hash_table(MAXHASH, "Macros", delete_macro_item);

     if (not is_name_ok_for_table(macro_table, name))
          return;

     if ((macro = (MacroDef *) abc_hash_table_lookup(macro_table, name)) == NULL)
     {
          ABC_NEW_OBJECT(macro, MacroDef);
          macro->name = save_string(name);
          abc_hash_table_insert(macro_table, name, (char *) macro);
     }
     else if (macro->constant)
     {
          fprintf(stderr, "[abc_install_macro] %s is constant!\n", macro->name);
          return;
     }
     else
     {
          if (debug_macro_redef)
               printf("(%s is redefined)\n", name);
          ABC_FREE(macro->def);
     }

     macro->argc = argc;
     macro->def = save_string(def);
     macro->constant = constant;
}


void abc_install_var(
     const char *name,
     double value,
     int constant)
{
     RealVar *var;

     if (var_table == NULL)
          var_table = abc_create_hash_table(MINHASH, "Variables", delete_var_item);

     if (not is_name_ok_for_table(var_table, name))
          return;

     if ((var = (RealVar *) abc_hash_table_lookup(var_table, name)) == NULL)
     {
          ABC_NEW_OBJECT(var, RealVar);
          var->name = save_string(name);
          var->constant = constant;
          abc_hash_table_insert(var_table, name, (char *) var);
     }
     else if (var->constant)
     {
          fprintf(stderr, "[abc_install_var] %s=%g is constant!\n", var->name, var->value);
          return;
     }

     var->value = value;
}


void abc_install_all_math_funcs(
     void)
{
     abc_install_math_func("sqrt",  sqrt);
     abc_install_math_func("sin",   sin);
     abc_install_math_func("cos",   cos);
     abc_install_math_func("tan",   tan);
     abc_install_math_func("asin",  asin);
     abc_install_math_func("acos",  acos);
     abc_install_math_func("atan",  atan);
     abc_install_math_func("exp",   exp);
     abc_install_math_func("exp10", exp10_func);
     abc_install_math_func("log",   log);
     abc_install_math_func("log10", log10);
     abc_install_math_func("ceil",  ceil);
     abc_install_math_func("floor", floor);
     abc_install_math_func("int",   int_func);
     abc_install_math_func("abs",   abs_func);
     abc_install_math_func("erf",   abc_erf);
     abc_install_math_func("erfc",  abc_erfc);
     abc_install_math_func("E1",    abc_E1);
     abc_install_math_func("Ei",    abc_Ei);
     abc_install_math_func("cosh",  cosh);
     abc_install_math_func("sinh",  sinh);
     abc_install_math_func("tanh",  tanh);
     abc_install_math_func("ran",   ran_func);
     abc_install_math_func("seed",  set_ran_seed);
}


void abc_install_math_func(
     const char *name,
     double (*func)(double x))
{
     MathFunc *math_func;

     if (func_table == NULL)
          func_table = abc_create_hash_table(MINHASH, "Math functions", delete_func_item);

     if (not is_name_ok_for_table(func_table, name))
          return;

     if ((math_func = (MathFunc *) abc_hash_table_lookup(func_table, name)) == NULL)
     {
          ABC_NEW_OBJECT(math_func, MathFunc);
          math_func->name = save_string(name);
          abc_hash_table_insert(func_table, name, (char *) math_func);
     }

     math_func->func = func;
}


void abc_install_string(
     const char *name,
     const char *def)
{
     StringVar *string;

     if (string_table == NULL)
          string_table = abc_create_hash_table(MINHASH, "Strings", delete_string_item);

     if (not is_name_ok_for_table(string_table, name))
          return;

     if ((string = (StringVar *) abc_hash_table_lookup(string_table, name)) == NULL)
     {
          ABC_NEW_OBJECT(string, StringVar);
          string->name = save_string(name);
          string->def = save_string(def);
          abc_hash_table_insert(string_table, name, (char *) string);
     }
     else
     {
          ABC_FREE(string->def);
          string->def = save_string(def);
     }
}


void abc_install_file_desc(
     const char *desc_name,
     const char *file_name,
     FILE *out,
     int mode)
{
     OutputDesc *desc;

     if (desc_table == NULL)
          desc_table = abc_create_hash_table(MINHASH, "Outfile descriptors", delete_desc_item);

     if (not is_name_ok_for_table(desc_table, desc_name))
          return;

     if ((desc = (OutputDesc *) abc_hash_table_lookup(desc_table, desc_name)) == NULL)
     {
          ABC_NEW_OBJECT(desc, OutputDesc);
          desc->desc_name = save_string(desc_name);
          desc->file_name = NULL;
          abc_hash_table_insert(desc_table, desc_name, (char *) desc);
     }

     if (desc->file_name != NULL)
          ABC_FREE(desc->file_name);

     desc->out = out;
     desc->mode = mode;
     desc->file_name = save_string(file_name);
}


FILE *abc_get_output_file_stream(
     AbcInput *in)
{
     OutputDesc *desc;
     char name[ABC_MAX_WORD];

     if (not abc_get_word(in, name, ABC_MAX_WORD))
          return stdout;

     if (ABC_MATCH(name, "stdout"))
          return stdout;
     else if (ABC_MATCH(name, "stderr"))
          return stderr;

     if ((desc = (OutputDesc *) abc_hash_table_lookup(desc_table, name)) == NULL)
     {
          abc_put_back_word(in, name);
          return stdout;
     }

     if (desc->out == NULL)
          return stdout;

     return (desc->out);
}


static double int_func(
     double x)
{
     int ix = (int) x;
     double dx = (double) ix;
     return dx;
}


static double abs_func(
     double x)
{
     return (x < 0.0) ? -x : x;
}


static double exp10_func(
     double x)
{
     return pow(10.0, x);
}


static double ran_func(
     double x)
{
     double y = nr_ran1(&ran_seed);
     ABC_UNUSED_PARAMETER(x);
     return y;
}


static double set_ran_seed(
     double x)
{
     ran_seed = (int) x;
     return x;
}


void abc_install_all_built_ins(
     void)
{
     abc_install_built_in("openlogfile",  cmd_open_log_file,
          "openlogfile <file name>");
     abc_install_built_in("closelogfile",  cmd_close_log_file,
          "close the log file");
     abc_install_built_in("set",          cmd_var_def,
          "set <name> = <expression>;");
     abc_install_built_in("const",        cmd_const_def,
          "const <name> = <expression>;");
     abc_install_built_in("string",       cmd_string_def,
          "string <name> = <string> (use double quotes);");
     abc_install_built_in("define",       cmd_macro_def,
          "define <name> <args> {<body>}");
     abc_install_built_in("DEFINE",       cmd_const_macro_def,
          "DEFINE <name> <args> {<body>}");
     abc_install_built_in("eval",         cmd_eval,
          "eval <expression>;");
     abc_install_built_in("exit",         cmd_exit,
          "exit the program");
     abc_install_built_in("includefile",  cmd_include_file,
          "includefile <word> (use double quotes)");
     abc_install_built_in("whatis",       cmd_what_is_macro,
          "whatis <word>");
     abc_install_built_in("showvars",     cmd_show_vars,
          "show all variables");
     abc_install_built_in("showmacros",   cmd_show_macros,
          "show all macros");
     abc_install_built_in("showfuncs",    cmd_abc_show_math_funcs,
          "show all mathematical functions");
     abc_install_built_in("showcommands", cmd_abc_show_built_ins,
          "show all commands");
     abc_install_built_in("showstrings",  cmd_abc_show_strings,
          "show all strings");
     abc_install_built_in("print",        cmd_print,
          "print [file] <string> (use double quotes)");
     abc_install_built_in("printword",   cmd_print_word,
          "printword [file] <word> (no quotes)");
     abc_install_built_in("printline",    cmd_print_line,
          "printline [file] <string> (use double quotes)");
     abc_install_built_in("newline",      cmd_print_new_line,
          "newline <file>");
     abc_install_built_in("printlineno",  cmd_print_line_no,
          "print current input line number");
     abc_install_built_in("printvar",     cmd_print_var,
          "printvar [file] <name>");
     abc_install_built_in("setformat",    cmd_set_format,
          "setformat <format> (use double quotes)");
     abc_install_built_in("setpromt",     cmd_set_promt,
          "setpromt <promt> (use double quotes)");
     abc_install_built_in("usepromt",     cmd_use_promt,
          "usepromt <0/1>");
     abc_install_built_in("unix",         cmd_unix,
          "unix <command> (use double quotes)");
     abc_install_built_in("openfile",     cmd_open_file,
          "openfile <file> <mode> <filename>");
     abc_install_built_in("closefile",    cmd_close_file,
          "closefile <file>");
     abc_install_built_in("debugcmd",     cmd_debug_cmd,
          "debugcmd <0/1> (debug built-in commands)");
     abc_install_built_in("debugmacro",   cmd_debug_macro,
          "debugmacro <0/1> (debug macro expansions)");
     abc_install_built_in("debugredef",   cmd_debug_macro_redef,
          "debugredef <0/1> (report macro redefinitions)");
     abc_install_built_in("debuginclude", cmd_debug_include_files,
          "debuginclude <0/1> (report include-files)");
     abc_install_built_in("if",           cmd_if,
          "if (cond1) ... elseif (cond2) ... else ... end");
}


void abc_install_built_in(
     const char *name,
     void (*command)(AbcInput *in),
     const char *comment)
{
     BuiltIn *built_in;
     const char *table_name = "Build-in commands";

     if (command_table == NULL)
          command_table = abc_create_hash_table(MINHASH, table_name, delete_command_item);

     if (not is_name_ok_for_table(command_table, name))
          return;

     if ((built_in = (BuiltIn *) abc_hash_table_lookup(command_table, name)) == NULL)
     {
          ABC_NEW_OBJECT(built_in, BuiltIn);
          built_in->name = save_string(name);
          built_in->func = NULL;
          built_in->comment = NULL;
          abc_hash_table_insert(command_table, name, (char *) built_in);
     }

     ABC_FREE(built_in->comment);
     built_in->func = command;
     built_in->comment = save_string(comment);
}


static void cmd_close_log_file(
     AbcInput *in)
{
     if (log_file != NULL)
     {
          fclose(log_file);
          log_file = NULL;
     }
     else
          ABC_ERROR_RETURN("The log file isn't open!");

     ABC_UNUSED_PARAMETER(in);
}


static void cmd_open_log_file(
     AbcInput *in)
{
     char file_name[MAXWORD];

     if (not abc_get_field(in, file_name, MAXWORD))
          ABC_ERROR_RETURN("Expected a file name!");

     if (log_file != NULL)
     {
          fclose(log_file);
          log_file = NULL;
     }

     if ((log_file = fopen(file_name, "w")) == NULL)
     {
          fprintf(stderr, "Error: Can't open log file: %s\n", file_name);
          return;
     }

     strcpy(log_file_name, file_name);
}


static void cmd_var_def(
     AbcInput *in)
{
     abc_get_var_def(in, FALSE);
}


static void cmd_const_def(
     AbcInput *in)
{
     abc_get_var_def(in, TRUE);
}


static void cmd_string_def(
     AbcInput *in)
{
     char name[MAXWORD], def[MAXWORD];

     if (not abc_get_word(in, name, MAXWORD))
          ABC_ERROR_RETURN("Expected string name!");

     if (not abc_get_word(in, def, MAXWORD))
          ABC_ERROR_RETURN("Expected character \"=\"!");

     if (def[0] != '=')
          ABC_ERROR_RETURN("Expected character \"=\"!");

     if (not abc_get_string(in, def, MAXWORD))
          ABC_ERROR_RETURN("Expected a string after \"=\"!");

     abc_install_string(name, def);
}


static void cmd_macro_def(
     AbcInput *in)
{
     abc_get_macro_def(in, FALSE);
}


static void cmd_const_macro_def(
     AbcInput *in)
{
     abc_get_macro_def(in, TRUE);
}


static void cmd_what_is_macro(
     AbcInput *in)
{
     abc_what_is_next_word(in, stdout);
}


static void cmd_show_macros(
     AbcInput *in)
{
     abc_show_macro_defs(stdout);
     ABC_UNUSED_PARAMETER(in);
}


static void cmd_show_vars(
     AbcInput *in)
{
     abc_show_variables(stdout);
     ABC_UNUSED_PARAMETER(in);
}


static void cmd_abc_show_math_funcs(
     AbcInput *in)
{
     abc_show_math_funcs(stdout);
     ABC_UNUSED_PARAMETER(in);
}


static void cmd_abc_show_built_ins(
     AbcInput *in)
{
     abc_show_built_ins(stdout);
     ABC_UNUSED_PARAMETER(in);
}


static void cmd_abc_show_strings(
     AbcInput *in)
{
     abc_show_strings(stdout);
     ABC_UNUSED_PARAMETER(in);
}


static void cmd_eval(
     AbcInput *in)
{
     double numb = 0.0;

     if (not abc_get_expression(in, &numb))
          ABC_ERROR_RETURN("Can't read expression!");

     abc_put_back_double(in, numb, "%g");
}


static void cmd_exit(
     AbcInput *in)
{
     if (log_file != NULL) fclose(log_file);
     ABC_UNUSED_PARAMETER(in);
     exit(0);
}


static void cmd_print(
     AbcInput *in)
{
     char string[MAXWORD];
     FILE *out = abc_get_output_file_stream(in);

     if (not abc_get_string(in, string, MAXWORD))
          ABC_ERROR_RETURN("Expected a string!");

     fprintf(out, "%s", string);
}


static void cmd_print_word(
     AbcInput *in)
{
     char string[MAXWORD];
     FILE *out = abc_get_output_file_stream(in);

     if (not abc_get_field(in, string, MAXWORD))
          ABC_ERROR_RETURN("Expected a field!");

     fprintf(out, "%s", string);
}


static void cmd_print_line(
     AbcInput *in)
{
     char string[MAXWORD];
     FILE *out = abc_get_output_file_stream(in);

     if (not abc_get_string(in, string, MAXWORD))
          ABC_ERROR_RETURN("Expected a string!");

     fprintf(out, "%s\n", string);
}


static void cmd_print_new_line(
     AbcInput *in)
{
     FILE *out = abc_get_output_file_stream(in);
     fprintf(out, "\n");
}


static void cmd_print_line_no(
     AbcInput *in)
{
     printf("%d", abc_get_input_line_number(in));
}


static void cmd_print_var(
     AbcInput *in)
{
     RealVar *var;
     char name[MAXWORD];
     FILE *out = abc_get_output_file_stream(in);

     if (not abc_get_word(in, name, MAXWORD))
          ABC_ERROR_RETURN("Expected a variable name!");

     if ((var = (RealVar *) abc_hash_table_lookup(var_table, name)) != NULL)
          fprintf(out, var_format, var->value);
     else
          fprintf(stderr, "\"%s\" is undefined variable!\n", name);
}


static void cmd_set_format(
     AbcInput *in)
{
     char string[MAXWORD];

     if (not abc_get_string(in, string, MAXWORD))
          ABC_ERROR_RETURN("Expected a format by a string!");

     strcpy(var_format, string);
}


static void cmd_set_promt(
     AbcInput *in)
{
     char string[MAXWORD];

     if (not abc_get_string(in, string, MAXWORD))
          ABC_ERROR_RETURN("Expected a new promt by a string!");

     strcpy(promt, string);
}


static void cmd_use_promt(
     AbcInput *in)
{
     int yes_or_no = 1;

     if (not abc_get_int(in, &yes_or_no))
          ABC_ERROR_RETURN("Expected an integer answer!");

     use_promt = yes_or_no;
}
     

static void cmd_unix(
     AbcInput *in)
{
     char string[MAXWORD];

     if (not abc_get_string(in, string, MAXWORD))
          ABC_ERROR_RETURN("Expected a unix command by a string!");

     system(string);
}


static void cmd_include(
     AbcInput *in)
{
     char file_name[ABC_MAX_WORD];

     if (not abc_get_field(in, file_name, ABC_MAX_WORD))
     {
          fprintf(stderr, "[include] Expected a file name in double quotes!");
          return;
     }

     if (debug_include_files)
          printf("(is including file: %s)\n", file_name);
     
     if (not abc_interpret_input_file(file_name))
          fprintf(stderr, "Can't read file: %s\n", file_name);
}


static void cmd_include_file(
     AbcInput *in)
{
     static AbcInput in_local; 
     AbcInput *in_new;
     char file_name[ABC_MAX_WORD];
      
     if (not abc_get_field(in, file_name, ABC_MAX_WORD))
     {
          fprintf(stderr, "[includefile] Expected a file name in double quotes!");
          return;
     }
      
     if (not abc_begin_input(&in_local, file_name))
     {
          fprintf(stderr, "[includefile] Can't open: %s\n", file_name);
          return;
     }
      
     if (debug_include_files)
          printf("(is including file: %s)\n", file_name);
     
     ABC_NEW_OBJECT(in_new, AbcInput);
     abc_copy_input_def(in, in_new);
     abc_copy_input_def(&in_local, in);
     in->prev_in = in_new;
}


static void cmd_debug_include_files(
     AbcInput *in)
{
     int yes_or_no = 1;

     if (not abc_get_int(in, &yes_or_no))
          ABC_ERROR_RETURN("Expected an integer answer!");

     debug_include_files = yes_or_no;
}


static void cmd_debug_cmd(
     AbcInput *in)
{
     int yes_or_no = 1;

     if (not abc_get_int(in, &yes_or_no))
          ABC_ERROR_RETURN("Expected an integer answer!");

     debug_cmd = yes_or_no;
     debug_levels = yes_or_no;
}


static void cmd_debug_macro(
     AbcInput *in)
{
     int yes_or_no = 1;

     if (not abc_get_int(in, &yes_or_no))
          ABC_ERROR_RETURN("Expected an integer answer!");

     debug_macro_expansion = yes_or_no;
}


static void cmd_debug_macro_redef(
     AbcInput *in)
{
     int yes_or_no = 1;

     if (not abc_get_int(in, &yes_or_no))
          ABC_ERROR_RETURN("Expected an integer answer!");

     debug_macro_redef = yes_or_no;
}


static void cmd_if(
     AbcInput *in)
{
     char word[MAXWORD];
     int found_branch = FALSE;

     abc_put_back_word(in, "if");

     while (not found_branch)
     {
          if (not abc_next_alphanum_word(in, word, MAXWORD))
               return;

          if (ABC_MATCH(word, "if") or ABC_MATCH(word, "elseif"))
          {
               if (not abc_get_condition(in, &found_branch))
                    abc_input_error(in, "Can't get condition after \"if\"!");

               if (not found_branch)
                    abc_search_for_next_branch(in);
          }
          else if (ABC_MATCH(word, "else"))
               found_branch = TRUE;
          else if (ABC_MATCH(word, "end"))
               return;
     }

     in->read_input(in);

     if (not abc_next_alphanum_word(in, word, MAXWORD))
          return;

     if (ABC_MATCH(word, "end"))
          return;

     if (ABC_MATCH(word, "else") or ABC_MATCH(word, "elseif"))
          abc_skip_until_key_word(in, "end");
}


static void cmd_open_file(
     AbcInput *in)
{
     int mode;
     FILE *out = NULL;
     OutputDesc *desc;
     char desc_name[ABC_MAX_WORD], mode_name[ABC_MAX_WORD], file_name[ABC_MAX_WORD];

     if (not abc_get_word(in, desc_name, ABC_MAX_WORD))
          ABC_ERROR_RETURN("Expected a file descriptor name!");

     if (not abc_get_word(in, mode_name, ABC_MAX_WORD))
          ABC_ERROR_RETURN("Expected a file mode name!");

     if (not abc_get_field(in, file_name, ABC_MAX_WORD))
          ABC_ERROR_RETURN("Expected a file name!");

     if (ABC_MATCH(file_name, "stdout"))
          ABC_ERROR_RETURN("Can't use \"stdout\" as file descriptor name!");

     if (ABC_MATCH(file_name, "stderr"))
          ABC_ERROR_RETURN("Can't use \"stderr\" as file descriptor name!");

     desc = (OutputDesc *) abc_hash_table_lookup(desc_table, desc_name);

     if ((desc != NULL) and (desc->out != NULL))
     {
           fprintf(stderr, "File \"%s\" is already open!\n", file_name);
           return;
     }

     if (ABC_MATCH(mode_name, "write"))
     {
          out = fopen(file_name, "w");
          mode = 'w';
     }
     else if (ABC_MATCH(mode_name, "append"))
     {
          out = fopen(file_name, "a");
          mode = 'a';
     }
     else
     {
          fprintf(stderr, "File mode: %s is unknown!\n", mode_name);
          return;
     }

     if (out == NULL)
     {
          fprintf(stderr, "Can't open file: %s in mode: %s!\n", file_name, mode_name);
          return;
     }

     abc_install_file_desc(desc_name, file_name, out, mode);
}


static void cmd_close_file(
     AbcInput *in)
{
     OutputDesc *desc;
     char desc_name[ABC_MAX_WORD];

     if (not abc_get_word(in, desc_name, ABC_MAX_WORD))
          ABC_ERROR_RETURN("Expected a file descriptor name!");

     if ((desc = (OutputDesc *) abc_hash_table_lookup(desc_table, desc_name)) == NULL)
     {
          fprintf(stderr, "%s is not a file descriptor!\n", desc_name);
          return;
     }

     if (desc->out == NULL)
     {
          fprintf(stderr, "%s isn't open any more!\n", desc_name);
          return;
     }

     fclose(desc->out);
     desc->out = NULL;
}


