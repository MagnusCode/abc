/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998-1999 by M. Wangen.
**
**   Info: A library of system dependent functions.
**   Date: Version 1.0, Desember 1998
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef WIN32
#define _BSD_SOURCE
#undef  _POSIX_SOURCE
#endif

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>

#ifdef WIN32
#include <direct.h>
#define stat     _stat
#define S_IFMT   _S_IFMT
#define S_IFDIR  _S_IFDIR
#else
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/file.h>
#endif

#include <lib_macros.h>
#include <lib_math.h>
#include <lib_system.h>

#define IS_DIRECTORY(x) (((x).st_mode & S_IFMT) == S_IFDIR)

#ifdef ABC_RETURN_FALSE
#undef ABC_RETURN_FALSE
#endif

#define ABC_RETURN_FALSE(text1, text2)\
     {fprintf(stderr, "[lib_system] Error: %s (%s)\n", text1, text2);}

void abc_init_exception_handler(
     void)
{
#ifdef _USE_FPE
     enable_floating_point_exceptions();
#endif
}


int abc_is_existing_file(
      char const *filename)
{
    struct stat st;
    int result = stat(filename, &st);
    return (result == 0);
}


void abc_make_day_time(
     char *text)
{    
     int i;
     time_t tp;  

     time(&tp);
     sprintf(text, "%s", asctime(localtime(&tp)));

     /* Remove new-line character. */

     for (i = 0; i < (int) strlen(text); i++)
          if (text[i] == '\n') text[i] = '\0';
}


int abc_make_dir(
     char const *dirname)
{
     struct stat status;
     char dirname_copy[ABC_MAX_WORD];

     if (ABC_MATCH(dirname, "") or ABC_MATCH(dirname, "."))
          return TRUE;
     
     strcpy(dirname_copy, dirname);
     abc_fix_dir_separator(dirname_copy);
     
     if (stat(dirname_copy, &status) == -1)
     {
#ifdef PERL
          char command[ABC_MAX_WORD];
     
          sprintf(command, "perl -e 'if (! -e \"%s\") {mkdir(\"%s\", 0755);}'",
                  dirname_copy, dirname_copy);
          if (system(command) != 0)
               ABC_RETURN_FALSE("Unable to create directory!", dirname_copy);
 
#elif defined(WIN32)
          if (_mkdir(dirname_copy) == -1)
               ABC_RETURN_FALSE("Unable to create directory!", dirname_copy);
#else
          mode_t mode = S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH;
          mkdir(dirname_copy, mode);
#endif
     }
     else if (not IS_DIRECTORY(status))
          ABC_RETURN_FALSE("The directory name is a file!", dirname_copy);
    
     return TRUE;
}


int abc_change_dir(
     char const *dirname)
{
     char dirname_copy[ABC_MAX_WORD];

     strcpy(dirname_copy, dirname);
     abc_fix_dir_separator(dirname_copy);

#ifdef WIN32
     if (_chdir(dirname_copy) == -1)
          ABC_RETURN_FALSE("Unable to change directory!", dirname_copy);
#else
     if (chdir(dirname_copy) == -1)
          ABC_RETURN_FALSE("Unable to change directory!", dirname_copy);
#endif

     return TRUE;
}


void abc_fix_dir_separator( 
     char *filename)
{
     int i;

     for (i = 0; i < (int) strlen(filename); i++)
#ifdef WIN32
          if (filename[i] == '/')
               filename[i] = '\\'; 
#else
          if (filename[i] == '\\')
               filename[i] = '/';
#endif
}

