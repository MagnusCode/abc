/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1986-1999 by M. Wangen.
**
**   Info: A library for the solution of 1D elliptic/parabolic equations
**   Date: Version 1.0, December 1993
**
**   $Id$
*/   

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_SIMPLE_1D_H_
#define _LIB_SIMPLE_1D_H_

#define ABC_1D_DEBUG_TIME_STEPPING   1
#define ABC_1D_DEBUG_Ab              2
#define ABC_1D_DEBUG_MAP             4

#define ABC_1D_BC_UNDEFINED 0
#define ABC_1D_BC_1ST_KIND  1
#define ABC_1D_BC_2ND_KIND  2

#define ABC_1D_BOUNDARY_LEFT  1
#define ABC_1D_BOUNDARY_RIGHT 2

/* These are the values for the arguments "code" in ABC_1D_MAKE_COEF2. */
#define ABC_1D_DUMMY      0
#define ABC_1D_MINUS_HALF 1
#define ABC_1D_PLUS_HALF  2

typedef struct _AbcSimple1D_ AbcSimple1D;

typedef double (*ABC_1D_MAKE_COEF1)(AbcSimple1D *sol, double t, int i);
typedef double (*ABC_1D_MAKE_COEF2)(AbcSimple1D *sol, double t, int i, int code);
typedef double (*ABC_1D_MAKE_BC)(AbcSimple1D *sol, double t);

struct _AbcSimple1D_ {
     int size;
     double t1;           /* Current time. */
     double dt;           /* Step from previous time to current time. */
     int bc_left;
     int bc_right;
     double *xcoord;
     double *solution0;   /* Solution at previous time step. */
     double *solution1;   /* Solution at current time step. */
     double *solution2;   /* Exact solution (if it exists). */
     double *sol_mapped;  /* The mapped solution. */
     double *b_vector;
     double **A_matrix;
     ABC_1D_MAKE_BC value_left;
     ABC_1D_MAKE_BC value_right;
     ABC_1D_MAKE_COEF1 acoef;
     ABC_1D_MAKE_COEF1 source;
     ABC_1D_MAKE_COEF2 lambda;
     int has_overlapping_nodes;
     int debugging;
     int size2;
     int *map;
     int *inv_map;
};

/* Prototypes for: lib_simple_1d.c */

void abc_1d_demo_simple_1d(int argc, char **argv);
void abc_1d_read_options(int argc, char **argv);
AbcSimple1D *abc_1d_new(int size);
void abc_1d_free(AbcSimple1D **sol);
int abc_1d_is_ok(AbcSimple1D *sol);
void abc_1d_set_debugging(AbcSimple1D *sol, int code);
void abc_1d_set_coef_funcs(AbcSimple1D *sol, ABC_1D_MAKE_COEF1 acoef, 
     ABC_1D_MAKE_COEF2 lambda, ABC_1D_MAKE_COEF1 source);
void abc_1d_set_bc(AbcSimple1D *sol, int boundary, int BC, ABC_1D_MAKE_BC func);
void abc_1d_stationary_solution(AbcSimple1D *sol);
void abc_1d_do_one_time_step(AbcSimple1D *sol, double t, double dt);
void abc_1d_store_solution(AbcSimple1D *sol, FILE *out);
void abc_1d_solve(AbcSimple1D *sol);
int abc_1d_has_overlapping_nodes(AbcSimple1D *sol);
void abc_1d_print_map(AbcSimple1D *sol, FILE *out);
void abc_1d_solve_overlapping_nodes(AbcSimple1D *sol);


#endif
