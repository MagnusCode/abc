/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2000-2002 by M. Wangen.
**
**   Info: Functions processing command line arguments.
**   Date: Version 1.0, November 2000
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_ARGS_H_
#define _LIB_ARGS_H_

#include <stdio.h>

#define MAX_ARGS         512
#define MAX_ARGS_BUFFER 4096

typedef struct AbcArgs {
     char buffer[MAX_ARGS_BUFFER];
     int buf_pos;     /* Next free char in buffer. */
     int cur_arg;     /* Index of current arg in argv. */
     int prev_arg;    /* Index of previous arg in argv.*/
     int argc;        /* Number of args in argv. */
     int n_errors;    /* Number of reading errors. */
     char *argv[MAX_ARGS];
     int is_used[MAX_ARGS];
} AbcArgs;

typedef int (*ABC_READ_ONE_ARG)(const char *string);

int abc_test_args(int argc, char **argv);
void abc_test_reading_args(AbcArgs *args);
int abc_read_args(int argc, char **argv, ABC_READ_ONE_ARG read_one_arg);
int abc_get_boolen_arg(AbcArgs *args, 
     const char *wanted_name, int default_value);
int abc_get_int_arg(AbcArgs *args, const char *wanted_name, 
     int min_value, int max_value, int default_value);
double abc_get_double_arg(AbcArgs *args, const char *wanted_name, 
     double min_value, double max_value, double default_value);
void abc_get_field_arg(AbcArgs *args, const char *wanted_name, 
     const char *default_field, char *field);
void abc_init_args(AbcArgs *args);
void abc_init_arg_lib0(AbcArgs *args, int argc, char **argv);
void abc_init_arg_lib(AbcArgs *args, int argc, char **argv);
void abc_add_args0(AbcArgs *args, int argc, char **argv);
void abc_add_args(AbcArgs *args, int argc, char **argv);
void abc_add_unused_args(AbcArgs *dest, AbcArgs *src);
void abc_add_args_by_string(AbcArgs *args, const char *string);
void abc_add_one_arg(AbcArgs *args, const char *text);
void abc_restart_reading_args(AbcArgs *args);
void abc_begin_reading_args(AbcArgs *args);
void abc_mark_all_args_as_unused(AbcArgs *args);
void abc_exit_with_arg_info(AbcArgs *args);
int abc_get_arg_errors(AbcArgs *args);
void abc_inc_arg_error_counter(AbcArgs *args);
const char *abc_get_and_remove_last_arg(AbcArgs *args);
const char *abc_get_next_arg(AbcArgs *args);
const char *abc_get_carg(AbcArgs *args);
int abc_get_iarg(AbcArgs *args);
float abc_get_farg(AbcArgs *args);
double abc_get_darg(AbcArgs *args);
void abc_current_arg_is_unused(AbcArgs *args);
void abc_exit_if_unused_args(AbcArgs *args);
int abc_get_unused_args(AbcArgs *args);
void abc_show_unused_args(AbcArgs *args, FILE *out);
void abc_show_all_args(AbcArgs *args, FILE *out);
void abc_make_all_args_unused(AbcArgs *args);


#endif
