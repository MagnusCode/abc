/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1993-1998 by M. Wangen.
**
**   Info: Functions for array manipulation
**   Date: Version 1.0, November 1993
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_array.h>

static int compare_strings(const void *p1, const void *p2);
static char *save_string(const char *string);

#ifdef _ABC_MAIN_ARRAY
int main(int argc, char **argv)
#else
int abc_test_array(
     int argc,
     char **argv)
#endif
{
     int i;
     AbcArray strings;

     abc_init_array(&strings, 2, NULL, compare_strings);

     abc_add_array_elem(&strings, (void *) save_string("Sandstone"));
     abc_add_array_elem(&strings, (void *) save_string("Limestone"));
     abc_add_array_elem(&strings, (void *) save_string("Chalk"));
     abc_add_array_elem(&strings, (void *) save_string("Shale"));
     abc_add_array_elem(&strings, (void *) save_string("Siltstone"));
     abc_add_array_elem(&strings, (void *) save_string("ShalySilt"));

     abc_sort_array(&strings);

     for (i = 0; i < abc_get_array_size(&strings); i++)
          printf("array[%d]=%s\n", i, (char *) abc_get_array_elem(&strings, i));

     abc_delete_array(&strings);

     ABC_UNUSED_PARAMETER(argc);
     ABC_UNUSED_PARAMETER(argv);

     return 0;
}


static int compare_strings(
     const void *p1,
     const void *p2)
{
     return strcmp(*(const char **) p1, *(const char **) p2);
}


static char *save_string(
     const char *string)
{
     char *buffer;
     ABC_NEW_ARRAY(buffer, char, strlen(string) + 1);
     strcpy(buffer, string);
     return buffer;
}


void abc_init_array(
     AbcArray *array,
     int max_size,
     ABC_DELETE_ARRAY_ELEM delete_elem,
     ABC_COMPARE_ARRAY_ELEMS compare_elems)
{
     if (max_size < 1)
          ABC_ERROR_EXIT("[abc_init_array] max_size < 1!");

     array->size = 0;
     array->max_size = max_size;
     array->delete_elem = delete_elem;
     array->compare_elems = compare_elems;
     ABC_NEW_ARRAY(array->array, void *, max_size);
}


void abc_delete_array(
     AbcArray *array)
{
     int i;

     for (i = 0; i < array->size; i++)
          abc_delete_array_elem(array, &array->array[i]);

     ABC_FREE_ARRAY(array->array);
}


void abc_delete_array_elem(
     AbcArray *array,
     void **pp)
{
     if (array->delete_elem != NULL)
          array->delete_elem(pp);
     else
          ABC_FREE(*pp);

     *pp = NULL;
}


void abc_add_array_elem(
     AbcArray *array,
     void *elem)
{
     if (array->size >= array->max_size)
          abc_resize_array(array, (int) (1.5 * array->max_size));

     if (array->size >= array->max_size)
          ABC_ERROR_EXIT("[abc_add_array_elem] No space left in array!");

     array->array[array->size] = elem;
     array->size++;
}


void abc_resize_array(
     AbcArray *array,
     int max_size)
{
     int i;
     void **new_array = NULL;
     int new_size = ABC_MIN(max_size, array->size);

     ABC_NEW_ARRAY(new_array, void *, max_size);

     for (i = 0; i < new_size; i++)
          new_array[i] = array->array[i];

     for (i = new_size; i < array->size; i++)
          abc_delete_array_elem(array, &array->array[i]);

     ABC_FREE_ARRAY(array->array);
     array->size = new_size;
     array->max_size = max_size;
     array->array = new_array;
}


void abc_replace_array_elem(
     AbcArray *array,
     int index,
     void *elem)
{
     if (index < 0 or array->size <= index)
          ABC_ERROR_EXIT("[abc_replace_array_elem] Illegal index!");

     abc_delete_array_elem(array, &array->array[index]);
     array->array[index] = elem;
}


int abc_get_array_index(
     AbcArray *array,
     void *elem)
{
     int i;

     for (i = 0; i < array->size; i++)
          if (array->array[i] == elem)
               return i;

     return -1;
}


void *abc_get_array_elem(
     AbcArray *array,
     int index)
{
     if (index < 0 or array->size <= index)
          ABC_ERROR_EXIT("[abc_get_array_elem] Illegal index!");

     return array->array[index];
}


int abc_get_array_size(
     AbcArray *array)
{
     return array->size;
}


int abc_get_array_max_size(
     AbcArray *array)
{
     return array->max_size;
}


int abc_get_array_free_capacity(
     AbcArray *array)
{
     return (array->max_size - array->size);
}


void abc_sort_array(
     AbcArray *array)
{
     if (array->compare_elems == NULL)
     {
          fprintf(stderr, "[abc_sort_array] Missing compare-elements-function!\n");
          return;
     }

     qsort((void *) array->array, (size_t) array->size, 
          (size_t) sizeof(void *), array->compare_elems);
}
