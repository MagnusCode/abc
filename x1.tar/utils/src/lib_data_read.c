/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1994-2011 by Magnus Wangen.
**
**   Info: Functions for storing results.
**   Date: Version 2.0, June 2011
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   History:
**   Version: 1.00 May 1994: First (old) version based xdr.
**   Version: 2.00 Jun 2001: New version: Always little-endian instead of xdr.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_alloc.h>
#include <lib_utils.h>
#include <lib_input.h>
#include <lib_data_read.h>

#define IS_LITTLE_ENDIAN
#define ERROR_EXIT(text) {fprintf(stderr, "Error: %s\n", text); exit(1);}

#define RETURN_FALSE(text) {\
     fprintf(stderr, "%s!\n", text); return FALSE;}

#define RETURN_FALSE_CLOSE_ABC(in, text) {\
     abc_end_input(in); fprintf(stderr, "%s!\n", text); return FALSE;}

#define RETURN_FALSE_CLOSE_C(IN, TEXT) {\
     fprintf(stderr, "(file: %s, line: %d) %s\n",\
          abc_get_input_file_name(IN),\
          abc_get_input_line_number(IN),\
          TEXT); return FALSE;}

#define RETURN_FALSE_ELEM(var, i) {\
     fprintf(stderr, "Can't read element %d for %s! (size=%d)\n",\
          i, var->name, var->size);\
     return FALSE;}

#define RETURN_FALSE_CLOSE_SII(in) {\
     close_input_sII(in); return FALSE;}

#define RETURN_FALSE_CLOSE_SII2(in, text) {\
     fprintf(stderr, "Error: %s\n", text);\
     close_input_sII(in); return FALSE;}

static void report_about_input(AbcFileContents *cont, 
     int i1, int i2, const char *filename);
static void add_prename_to_var(AbcFileVar *var, const char *prename);
static int is_max_word_var(AbcFileVar *var);
static int read_ascii_int_var(AbcFileVar *var, AbcInput *in);
static int read_ascii_double_var(AbcFileVar *var, AbcInput *in);
static int read_ascii_string_var(AbcFileVar *var, AbcInput *in);
static int is_end_of_sII(AbcInputStreamII *stream);
static int open_input_sII(AbcInputStreamII *stream, const char *filename);
static int close_input_sII(AbcInputStreamII *stream);
static int get_var_info_from_sII(AbcInputStreamII *stream, AbcFileVar *var);
static int is_ok_type(int type);
static int read_sII_int_var(AbcFileVar *var, AbcInputStreamII *stream);
static int read_sII_double_var(AbcFileVar *var, AbcInputStreamII *stream);
static int read_sII_string_var(AbcFileVar *var, AbcInputStreamII *stream);
static int get_int_from_sII(AbcInputStreamII *stream, int *numb);
static int get_double_from_sII(AbcInputStreamII *stream, double *numb);
static int get_string_from_sII(AbcInputStreamII *stream, char *text, int max_word);
static int get_ordered_bytes(AbcInputStreamII *stream, char *bytes, int size);
static int get_endianess(void);
static int read_size_of_columns(const char *filename, int *cols, int *rows);
static int get_and_store_int( AbcInput *in, AbcFileVar *var,
     const char *name, const char *filename);
static int get_and_store_double( AbcInput *in, AbcFileVar *var,
     const char *name, const char *filename);

/*
**   =============
**   Demo programs
**   =============
*/

int abc_rw_main_contents(
     int argc,
     char **argv)
{
     int i;
     AbcFileContents cont;

     for (i = 1; i < argc; i++)
     {
          const char *filename = argv[i];

          abc_rw_init_file_contents(&cont);
          abc_rw_set_debugging_on_off(&cont, FALSE);

          if (not abc_rw_read_file_contents(&cont, filename, 0, ""))
          {
               fprintf(stderr, "Can't read contents from file: %s\n", filename);
               continue;
          }

          abc_rw_list_contents(&cont);
     }

     abc_rw_delete_file_contents(&cont);
     abc_delete_input_lib();

     return 0;
}


int abc_rw_main_test1(
     int argc,
     char **argv)
{
     int ok1, ok2, ok3, ok4;
     AbcFileContents cont;
     const char *filename1 = "xres-ascii.xy";
     const char *filename2 = "xres-binary.xy";
     const char *filename3 = "xres-cols.xy";
     const char *filename4 = "xres-old-ascii.xy";

     /* Initialize the contents-struct. */

     abc_rw_init_file_contents(&cont);
     abc_rw_set_debugging_on_off(&cont, FALSE);

     /* Try to read files. */

     ok1 = abc_rw_read_ascii_file_contents(&cont, filename1, 50, "aaa_");
     ok2 = abc_rw_read_binary_file_contents(&cont, filename2, 110, "bbb_");
     ok3 = abc_rw_read_columns_file_contents(&cont, filename3, 210, "ccc_");
     ok4 = abc_rw_read_old_serie_file_contents(&cont, filename4, 330, "ddd_");

     if (not ok1 and not ok2 and not ok3 and not ok4)
     {
          fprintf(stderr, "Can't read files: %s, %s, %s, %s\n", 
               filename1, filename2, filename3, filename4);
          return 1;
     }

     abc_rw_list_contents(&cont);
     abc_rw_delete_file_contents(&cont);
     abc_delete_input_lib();

     ABC_UNUSED_PARAMETER(argc);
     ABC_UNUSED_PARAMETER(argv);

     return 0;
}


int abc_rw_main_test2(
     int argc,
     char **argv)
{
     int i, ok1, ok2, ok3;
     AbcFileVar *var;
     AbcFileContents cont;
     const char *filename1 = "xres-ascii.xy";
     const char *filename2 = "xres-binary.xy";
     const char *filename3 = "xres-cols.xy";

     /* Initialize the contents-struct. */

     abc_rw_init_file_contents(&cont);
     abc_rw_set_debugging_on_off(&cont, FALSE);

     /* Read an ascii file. */

     ok1 = abc_rw_read_ascii_file_contents(&cont, filename1, 50, "aaa_");
     ok2 = abc_rw_read_binary_file_contents(&cont, filename2, 110, "bbb_");
     ok3 = abc_rw_read_columns_file_contents(&cont, filename3, 210, "ccc_");
     /***
     ok1 = abc_rw_add_ascii_file_contents(&cont, filename1);
     ok2 = abc_rw_add_binary_file_contents(&cont, filename2);
     ***/

     if (not ok1 and not ok2 and not ok3)
     {
          fprintf(stderr, "Can't read files: %s, %s\n", filename1, filename2);
          return 1;
     }

     /* List contents. */

     for (i = 0; i < ABC_MAX_RW_VARS; i++)
     {
          var = abc_rw_get_var_by_index(&cont, i);
          if (not abc_rw_is_used_var(var)) continue;

          printf("name=%s, type=%s, size=%d file=%s\n",
               abc_rw_get_var_name(var),
               abc_rw_get_var_type_name(var),
               abc_rw_get_var_size(var),
               abc_rw_get_var_filename(var));

          /***
          abc_rw_print_var(var);
          ***/
     }

     abc_rw_list_contents(&cont);

     /* Write out one specific array. */

     /***
     var = abc_rw_get_var_by_name(&cont, "some_string");
     if (var != NULL) abc_rw_print_var(var);
     ***/

     /* Clean up. */

     abc_rw_delete_file_contents(&cont);

     ABC_UNUSED_PARAMETER(argc);
     ABC_UNUSED_PARAMETER(argv);

     return 0;
}


void abc_rw_print_var(
     AbcFileVar *var)
{
     int n;

     int type = abc_rw_get_var_type(var);
     int size = abc_rw_get_var_size(var);
     int max_10 = ABC_MIN(10, size);

     printf("(max 10 first elements)\n");
          
     switch (type)
     {
          case ABC_RW_TYPE_INT: 
               for (n = 0; n < max_10; n++)
                    printf("array[%d]=%d\n", n, abc_rw_get_int(var, n));
               break;

          case ABC_RW_TYPE_DOUBLE:
               for (n = 0; n < max_10; n++)
                    printf("array[%d]=%g\n", n, abc_rw_get_double(var, n));
               break;

          case ABC_RW_TYPE_STRING:
               for (n = 0; n < max_10; n++)
                    printf("array[%d]=\"%s\"\n", n, abc_rw_get_string(var, n));
               break;

          default:
               printf("Unknown data type: %d!\n", type);
     }
}

/*
**   ===================================
**   Functions for reading file contents.
**   ===================================
*/

void abc_rw_set_debugging_on_off(
     AbcFileContents *cont,
     int on_off)
{
     cont->is_debugging = on_off;
}


void abc_rw_init_file_contents(
     AbcFileContents *cont)
{
     int i;

     cont->is_silent = FALSE;
     cont->is_debugging = FALSE;

     for (i = 0; i < ABC_MAX_RW_VARS; i++)
     {
          AbcFileVar *var = &(cont->var[i]);
          abc_rw_init_var(var, 0, -1, "", "");
          var->index = i;
     }
}


void abc_rw_init_var(
     AbcFileVar *var,
     int size,
     int type,
     const char *varname,
     const char *filename)
{
     var->array = NULL;
     var->size = size;
     strcpy(var->name, varname);
     strcpy(var->filename, filename);
     var->type = type;
     var->max_word = 0;
     var->min = 0.0;
     var->max = 0.0;

     abc_rw_init_fem_info(&(var->fem_info));
}


void abc_rw_init_fem_info(
     AbcFileFemInfo *fem_info)
{
     fem_info->grid_type = 0;
     fem_info->n_elems = 0;
     fem_info->n_nodes = 0;
     fem_info->n_x_elems = 0;
     fem_info->n_y_elems = 0;
     fem_info->n_z_elems = 0;
     fem_info->n_x_nodes = 0;
     fem_info->n_y_nodes = 0;
     fem_info->n_z_nodes = 0;
     fem_info->n_local_nodes = 0;
}


void abc_rw_delete_file_contents(
     AbcFileContents *cont)
{
     int i;

     for (i = 0; i < ABC_MAX_RW_VARS; i++)
          if (cont->var[i].array != NULL)
               ABC_FREE_ARRAY(cont->var[i].array);
}


void abc_rw_read_file_contents_or_exit(
     AbcFileContents *cont,
     const char *filename,
     int i1,
     const char *prename)
{
     if (abc_rw_read_file_contents(cont, filename, i1, prename)) return;
     fprintf(stderr, "Can't read file: %s\n", filename);
     exit(1);
}


int abc_rw_read_file_contents(
     AbcFileContents *cont,
     const char *filename,
     int i1,
     const char *prename)
{
     char extension[ABC_MAX_WORD];

     abc_get_extension(filename, extension);

     if      (ABC_MATCH(extension, ".a2"))
          return abc_rw_read_ascii_file_contents(cont, filename, i1, prename);
     else if (ABC_MATCH(extension, ".b2"))
          return abc_rw_read_binary_file_contents(cont, filename, i1, prename);
     else if (ABC_MATCH(extension, ".csv"))
          return abc_rw_read_columns_file_contents(cont, filename, i1, prename);
     else 
          return abc_rw_read_old_serie_file_contents(cont, filename, i1, prename);

     return FALSE;
}


int abc_rw_get_number_of_vars(
     AbcFileContents *cont)
{
     int i;
     int counter = 0;

     for (i = 0; i < ABC_MAX_RW_VARS; i++)
          if (cont->var[i].array != NULL)
               counter++;

     return counter;
}


AbcFileVar *abc_rw_get_var_by_index(
     AbcFileContents *cont,
     int i)
{
     if (i < 0) return NULL;
     if (i >= ABC_MAX_RW_VARS) return NULL;
     return (&cont->var[i]);
}


AbcFileVar *abc_rw_get_var_by_name(
     AbcFileContents *cont,
     const char *name)
{
     int i;

     for (i = 0; i < ABC_MAX_RW_VARS; i++)
     {
          if (cont->var[i].array == NULL)
               continue;

          if (ABC_MATCH(name, cont->var[i].name))
               return (&cont->var[i]);
     }

     return NULL;
}


void abc_rw_allocate_one_int(
     AbcFileVar *var,
     int value,
     const char *varname,
     const char *filename)
{
     int *iarray;

     abc_rw_allocate_ints(var, 1, varname, filename);
     iarray = abc_rw_get_int_array(var);
     iarray[0] = value;
     var->min = (double) value;
     var->max = (double) value;
}


void abc_rw_allocate_ints(
     AbcFileVar *var,
     int size,
     const char *varname,
     const char *filename)
{
     int i;
     int *iarray;

     if (var->array != NULL)
          ABC_FREE_ARRAY(var->array);

     abc_rw_init_var(var, size, ABC_RW_TYPE_INT, varname, filename);
     ABC_NEW_ARRAY(iarray, int, var->size);

     for (i = 0; i < var->size; i++)
          iarray[i] = 0.0;

     var->array = (void *) iarray;
}


void abc_rw_allocate_one_double(
     AbcFileVar *var,
     double value,
     const char *varname,
     const char *filename)
{
     double *darray;

     abc_rw_allocate_doubles(var, 1, varname, filename);
     darray = abc_rw_get_double_array(var);
     darray[0] = value;
     var->min = value;
     var->max =  value;
}


void abc_rw_allocate_doubles(
     AbcFileVar *var,
     int size,
     const char *varname,
     const char *filename)
{
     int i;
     double *darray;

     if (var->array != NULL)
          ABC_FREE_ARRAY(var->array);

     abc_rw_init_var(var, size, ABC_RW_TYPE_DOUBLE, varname, filename);
     ABC_NEW_ARRAY(darray, double, var->size);

     for (i = 0; i < var->size; i++)
          darray[i] = 0.0;

     var->array = (void *) darray;
}


void abc_rw_allocate_strings(
     AbcFileVar *var,
     int size,
     const char *varname,
     const char *filename)
{
     int i;
     int max_word = var->max_word;
     int n_chars = size * max_word;
     char *carray;

     if (var->array != NULL)
          ABC_FREE_ARRAY(var->array);

     abc_rw_init_var(var, size, ABC_RW_TYPE_STRING, varname, filename);
     ABC_NEW_ARRAY(carray, char, n_chars);

     for (i = 0; i < n_chars; i++)
          carray[i] = '\0';

     var->array = (void *) carray;
     var->max_word = max_word;
}


void abc_rw_reallocate_var(
     AbcFileVar *var,
     int size,
     int type,
     const char *varname,
     const char *filename)
{

     if (type == ABC_RW_TYPE_INT)
          abc_rw_allocate_ints(var, size, varname, filename);
     else if (type == ABC_RW_TYPE_DOUBLE)
          abc_rw_allocate_doubles(var, size, varname, filename);
     else if (type == ABC_RW_TYPE_STRING)
          abc_rw_allocate_strings(var, size, varname, filename);
     else
          fprintf(stderr, "[abc_rw_reallocate_var] Illegal type!\n");
}


int abc_rw_get_next_free_pos(
     AbcFileContents *cont)
{
     int i_last = ABC_MAX_RW_VARS - 1;
     int i = i_last;

     while ((i >= 0) and (cont->var[i].array == NULL))
          i--;

     if ((i < i_last) and (cont->var[i].array != NULL))
          return (i + 1);

     fprintf(stderr, "Warning: No free positions in ABC file-contents!\n");
     return 0;
}


void abc_rw_list_contents(
     AbcFileContents *cont)
{
     int i;
     AbcFileVar *var;

     printf("Buffer  Name             Type       Size           Min         Max File name\n");
     printf("======  ====             ====       ====           ===         === =========\n");

     for (i = 0; i < ABC_MAX_RW_VARS; i++)
     {
          var = abc_rw_get_var_by_index(cont, i);
          if (not abc_rw_is_used_var(var)) continue;

          printf(" %5d ",    i);
          printf(" %-16s",   var->name);
          printf(" %-8s",    abc_rw_get_var_type_name(var));
          printf(" %6d  ",   var->size);
          printf(" %11g",    var->min);
          printf(" %11g",    var->max);
          printf(" \"%-s\"", var->filename);

          printf("\n");
     }
}


int abc_rw_get_max_array_size_in_bytes(
     AbcFileContents *cont)
{
     int total_size, max_array_size;

     abc_rw_find_storage_size_in_bytes(cont, &total_size, &max_array_size);
     return max_array_size;
}


int abc_rw_get_total_storage_size_in_bytes(
     AbcFileContents *cont)
{
     int total_size, max_array_size;

     /* Only array sizes are counted. */
     abc_rw_find_storage_size_in_bytes(cont, &total_size, &max_array_size);
     return total_size;
}


void abc_rw_find_storage_size_in_bytes(
     AbcFileContents *cont,
     int *total_size,
     int *max_array_size)
{
     int i, size;
     int size_of_int = sizeof(int);
     int size_of_char = sizeof(char);
     int size_of_double = sizeof(double);
     AbcFileVar *var;

     *total_size = 0;
     *max_array_size = 0;

     if (cont == NULL) return;

     for (i = 0; i < ABC_MAX_RW_VARS; i++)
     {
	  var = abc_rw_get_var_by_index(cont, i);
          if (not abc_rw_is_used_var(var)) continue;

          switch (var->type)
          {
               case ABC_RW_TYPE_INT: 
                    size = size_of_int * var->size;
               break;

               case ABC_RW_TYPE_DOUBLE: 
                    size = size_of_double * var->size;
               break;

               case ABC_RW_TYPE_STRING: 
                    size = size_of_char * var->size * var->max_word;
               break;

               default:
                    fprintf(stderr, "[abc_rw_max_var_size_in_bytes] Illegal type!\n");
                    fprintf(stderr, "type=%d, size=%d, name=%s\n", 
                         var->type, var->size, var->name);
                    size = 0;
          }

          *max_array_size = ABC_MAX(*max_array_size, size);
          *total_size += size;
     }
}

/*
**   =====================================
**   Functions for accessing one variables
**   =====================================
*/

int abc_rw_is_used_var(
     AbcFileVar *var)
{
     if (var == NULL) return FALSE;
     if (var->type < 0) return FALSE;
     if (var->array != NULL) return TRUE;
     return FALSE;
}


const char *abc_rw_get_var_name(
     AbcFileVar *var)
{
     if (var == NULL) return "";
     return var->name;
}


const char *abc_rw_get_var_filename(
     AbcFileVar *var)
{
     if (var == NULL) return "";
     return var->filename;
}


int abc_rw_get_var_size(
     AbcFileVar *var)
{
     if (var == NULL) return 0;
     return var->size;
}


int abc_rw_get_var_type(
     AbcFileVar *var)
{
     if (var == NULL) return 0;
     return var->type;
}


const char *abc_rw_get_var_type_name(
     AbcFileVar *var)
{
     if (var == NULL) return "NULL-pointer";
     return abc_rw_get_name_of_type(var->type);
}


int *abc_rw_get_int_array(
     AbcFileVar *var)
{
     if (var == NULL) return NULL;
     if (var->type != ABC_RW_TYPE_INT) return NULL;
     return ((int *) var->array);
}


double *abc_rw_get_double_array(
     AbcFileVar *var)
{
     if (var == NULL) return NULL;
     if (var->type != ABC_RW_TYPE_DOUBLE) return NULL;
     return ((double *) var->array);
}


char *abc_rw_get_char_array(
     AbcFileVar *var)
{
     if (var == NULL) return NULL;
     if (var->type != ABC_RW_TYPE_STRING) return NULL;
     return ((char *) var->array);
}


int abc_rw_get_int_by_name(
     AbcFileContents *cont,
     const char *name,
     int i,
     int *numb)
{
     int *iarray;
     AbcFileVar *var = abc_rw_get_var_by_name(cont, name);
     if (var == NULL) return FALSE;
     if (var->type != ABC_RW_TYPE_INT) return FALSE;
     if (i < 0) return FALSE;
     if (i >= var->size) return FALSE;
     iarray = (int *) var->array;
     *numb = iarray[i];
     return TRUE;
}


int abc_rw_get_double_by_name(
     AbcFileContents *cont,
     const char *name,
     int i,
     double *numb)
{
     int *darray;
     AbcFileVar *var = abc_rw_get_var_by_name(cont, name);
     if (var == NULL) return FALSE;
     if (var->type != ABC_RW_TYPE_DOUBLE) return FALSE;
     if (i < 0) return FALSE;
     if (i >= var->size) return FALSE;
     darray = (int *) var->array;
     *numb = darray[i];
     return TRUE;
}


int *abc_rw_get_int_array_by_name(
     AbcFileContents *cont,
     const char *name,
     int *size)
{
     int *iarray;
     AbcFileVar *var = abc_rw_get_var_by_name(cont, name);
     if (var == NULL) return NULL;
     if (var->type != ABC_RW_TYPE_INT) return NULL;
     iarray = (int *) var->array;
     *size = var->size;
     return iarray;
}


double *abc_rw_get_double_array_by_name(
     AbcFileContents *cont,
     const char *name,
     int *size)
{    
     double *darray;
     AbcFileVar *var = abc_rw_get_var_by_name(cont, name);
     if (var == NULL) return NULL;
     if (var->type != ABC_RW_TYPE_DOUBLE) return NULL;
     darray = (double *) var->array;
     *size = var->size;
     return darray;
}


char *abc_rw_get_string_array_by_name(
     AbcFileContents *cont,
     const char *name,
     int *size,
     int *max_word)
{
     char *carray;
     AbcFileVar *var = abc_rw_get_var_by_name(cont, name);
     if (var == NULL) return NULL;
     if (var->type != ABC_RW_TYPE_STRING) return NULL;
     carray = (char *) var->array;
     *size = var->size;
     *max_word = var->max_word;
     return carray;
}


int abc_rw_get_int(
     AbcFileVar *var, 
     int i)
{
     int *iarray;
     iarray = abc_rw_get_int_array(var);
     if (iarray == NULL) return 0;
     if (var->type != ABC_RW_TYPE_INT) return 0;
     if (i < 0 or i >= var->size) return 0;
     return iarray[i];
}


double abc_rw_get_double(
     AbcFileVar *var,
     int i)
{
     double *darray = abc_rw_get_double_array(var);
     if (darray == NULL) return 0.0;
     if (var->type != ABC_RW_TYPE_DOUBLE) return 0;
     if (i < 0 or i >= var->size) return 0.0;
     return darray[i];
}


const char *abc_rw_get_string(
     AbcFileVar *var,
     int i)
{
     char *array = abc_rw_get_char_array(var);
     if (array == NULL) return "";
     if (i < 0 or i >= var->size) return "";
     return &array[i * var->max_word];
}


void abc_rw_find_min_and_max_var(
     AbcFileVar *var)
{
     var->min = abc_rw_get_min_var(var);
     var->max = abc_rw_get_max_var(var);
}


double abc_rw_get_min_var(
     AbcFileVar *var)
{
     int i;
     double value;
     double min_value = abc_rw_get_var_value(var, 0);
     
     for (i = 1; i < var->size; i++)
     {
          value = abc_rw_get_var_value(var, i);
          if (value < min_value) min_value = value;
     }

     return min_value;
}


double abc_rw_get_max_var(
     AbcFileVar *var)
{
     int i;
     double value;
     double max_value = abc_rw_get_var_value(var, 0);

     for (i = 1; i < var->size; i++)
     {
          value = abc_rw_get_var_value(var, i);
          if (value > max_value) max_value = value;
     }

     return max_value;
}


double abc_rw_get_var_value(
     AbcFileVar *var,
     int i)
{
     const char *string;
     double value = 0.0;

     switch (var->type)
     {
          case ABC_RW_TYPE_INT: 
               value = (double) abc_rw_get_int(var, i);
               break;

          case ABC_RW_TYPE_DOUBLE: 
               value = abc_rw_get_double(var, i);
               break;

          case ABC_RW_TYPE_STRING: 
               string = abc_rw_get_string(var, i);
               value = (double) strlen(string); 
               break;

          default: 
               fprintf(stderr, "Illegal type! (type=%d)\n", var->type);
     }

     return value;
}


void abc_rw_rename_var(
     AbcFileVar *var,
     const char *new_name)
{
     if (strlen(new_name) >= ABC_RW_VAR_NAME)
     {
          fprintf(stderr, "[abc_rw_rename_var] Name \"%s\" is too long!", new_name);
          return;
     }

     strcpy(var->name, new_name);
}


void abc_rw_update_fem_info(
     AbcFileVar *var,
     AbcFileFemInfo *fem_info)
{
     int value;

     if (var->size != 1) return;
     if (var->type != ABC_RW_TYPE_INT) return;

     value = abc_rw_get_int(var, 0);

     if      (ABC_MATCH(var->name, "grid_type")) fem_info->grid_type = value;
     else if (ABC_MATCH(var->name, "n_elems"))   fem_info->n_elems   = value;
     else if (ABC_MATCH(var->name, "n_nodes"))   fem_info->n_nodes   = value;
     else if (ABC_MATCH(var->name, "n_x_elems")) fem_info->n_x_elems = value;
     else if (ABC_MATCH(var->name, "n_y_elems")) fem_info->n_y_elems = value;
     else if (ABC_MATCH(var->name, "n_z_elems")) fem_info->n_z_elems = value;
     else if (ABC_MATCH(var->name, "n_x_nodes")) fem_info->n_x_nodes = value;
     else if (ABC_MATCH(var->name, "n_y_nodes")) fem_info->n_y_nodes = value;
     else if (ABC_MATCH(var->name, "n_z_nodes")) fem_info->n_z_nodes = value;
     else if (ABC_MATCH(var->name, "n_corners")) fem_info->n_local_nodes = value;
     else if (ABC_MATCH(var->name, "n_local_nodes")) fem_info->n_local_nodes = value;
}


void abc_rw_print_fem_info(
     AbcFileVar *var,
     FILE *out)
{
     AbcFileFemInfo *fem = &(var->fem_info);

     fprintf(out, "int grid_type 1 %d\n", fem->grid_type);
     fprintf(out, "int n_elems 1 %d\n", fem->n_elems);
     fprintf(out, "int n_nodes 1 %d\n", fem->n_nodes);
     fprintf(out, "int n_x_elems 1 %d\n", fem->n_x_elems);
     fprintf(out, "int n_y_elems 1 %d\n", fem->n_y_elems);
     fprintf(out, "int n_z_elems 1 %d\n", fem->n_z_elems);
     fprintf(out, "int n_x_nodes 1 %d\n", fem->n_x_nodes);
     fprintf(out, "int n_y_nodes 1 %d\n", fem->n_y_nodes);
     fprintf(out, "int n_z_nodes 1 %d\n", fem->n_z_nodes);
     fprintf(out, "int n_local_nodes 1 %d\n", fem->n_local_nodes);
}


void abc_rw_copy_fem_info(
     AbcFileFemInfo *fem1,
     AbcFileFemInfo *fem2)
{
     fem2->grid_type = fem1->grid_type;
     fem2->n_elems   = fem1->n_elems;
     fem2->n_nodes   = fem1->n_nodes;
     fem2->n_x_elems = fem1->n_x_elems;
     fem2->n_y_elems = fem1->n_y_elems;
     fem2->n_z_elems = fem1->n_z_elems;
     fem2->n_x_nodes = fem1->n_x_nodes;
     fem2->n_y_nodes = fem1->n_y_nodes;
     fem2->n_z_nodes = fem1->n_z_nodes;
     fem2->n_local_nodes = fem1->n_local_nodes;
}


const char *abc_rw_get_name_of_type(
     int type)
{
     switch (type)
     {
          case ABC_RW_TYPE_INT:      return "int";
          case ABC_RW_TYPE_DOUBLE:   return "double";
          case ABC_RW_TYPE_STRING:   return "strings";
          default:
               fprintf(stderr, "Illegal RW-type: %d\n", type);
     }

     return "undefined type";
}


int abc_rw_get_var_type_from_name(
     const char *typename)
{
     if      (ABC_MATCH(typename, "int"))     return ABC_RW_TYPE_INT;
     else if (ABC_MATCH(typename, "double"))  return ABC_RW_TYPE_DOUBLE;
     else if (ABC_MATCH(typename, "char"))    return ABC_RW_TYPE_STRING;
     else if (ABC_MATCH(typename, "strings")) return ABC_RW_TYPE_STRING;

     return -1;
}


static int is_ok_type(
     int type)
{
     if (type == ABC_RW_TYPE_INT)      return TRUE;
     if (type == ABC_RW_TYPE_DOUBLE)   return TRUE;
     if (type == ABC_RW_TYPE_STRING)   return TRUE;

     return FALSE;
}

/*
**   ============================
**   PART I: ASCII storage format
**   ============================
*/

int abc_rw_add_ascii_file_contents(
     AbcFileContents *cont,
     const char *filename)
{
     int pos = abc_rw_get_next_free_pos(cont);
     return abc_rw_read_ascii_file_contents(cont, filename, pos, "");
}


int abc_rw_read_ascii_file_contents(
     AbcFileContents *cont,
     const char *filename,
     int first_index,
     const char *prename)
{
     AbcFileVar *var;
     AbcFileFemInfo fem_info;
     static AbcInput in;
     char keyword[ABC_MAX_WORD], typename[ABC_MAX_WORD];
     int n = first_index;
     int max_word = 32;

     abc_rw_init_fem_info(&fem_info);

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Can't open file: %s!\n", filename);
          return FALSE;
     }

     while (abc_get_word(&in, keyword, ABC_MAX_WORD) and not ABC_MATCH(keyword, "begin_results2"))
          ;

     if (not ABC_MATCH(keyword, "begin_results2"))
          RETURN_FALSE_CLOSE_C(&in, "Expected keyword \"begin_results2\"!");

     while (abc_get_word(&in, typename, ABC_MAX_WORD) and not ABC_MATCH(typename, "end_results2"))
     {
          if (n >= ABC_MAX_RW_VARS)
               RETURN_FALSE_CLOSE_C(&in, "Too many variables!");

          var = &(cont->var[n]);
          abc_rw_init_var(var, 0, -1, "", filename);

          if (not abc_get_word(&in, var->name, ABC_MAX_WORD))
               RETURN_FALSE_CLOSE_C(&in, "Can't read variable name!");

          if (not abc_get_int(&in, &var->size))
               RETURN_FALSE_CLOSE_C(&in, "Can't read variable size!");

          var->type = abc_rw_get_var_type_from_name(typename);
          var->max_word = max_word;

          if (var->array != NULL)
               ABC_FREE_ARRAY(var->array);

          switch (var->type)
          {
               case ABC_RW_TYPE_INT:
                   if (not read_ascii_int_var(var, &in))
                        RETURN_FALSE_CLOSE_C(&in, "Can't read ascii integer array!"); 
                   break;

               case ABC_RW_TYPE_DOUBLE:
                   if (not read_ascii_double_var(var, &in))
                        RETURN_FALSE_CLOSE_C(&in, "Can't read ascii double array!");
                   break;
               
               case ABC_RW_TYPE_STRING:
                   if (not read_ascii_string_var(var, &in))
                        RETURN_FALSE_CLOSE_C(&in, "Can't read ascii string array!");
                   break;
               
               default:
                    fprintf(stderr, "Error: type=%d is illegal!\n", var->type);
          }

          if (is_max_word_var(var))
               max_word = abc_rw_get_int(var, 0);

          abc_rw_update_fem_info(var, &fem_info);
          abc_rw_copy_fem_info(&fem_info, &(var->fem_info));
          abc_rw_find_min_and_max_var(var);
          /* Changing the name is done after the original name might be used.*/
          add_prename_to_var(var, prename);

          if (cont->is_debugging)
               printf("(has read %s-array \"%s\" of size %d from \"%s\")\n",
                    abc_rw_get_var_type_name(var), var->name, var->size, filename);
          n++;
     }

     report_about_input(cont, first_index, n - 1, filename);
     abc_end_input(&in);

     return TRUE;
}


static void report_about_input(
     AbcFileContents *cont,
     int i1,
     int i2,
     const char *filename)
{
     if (cont->is_silent) return;

     if (i1 == i2)
          printf("(buffer %d filled from %s)\n",
               i1, filename);
     else
          printf("(buffers %d-%d filled from %s)\n",
               i1, i2, filename);
}


static void add_prename_to_var(
     AbcFileVar *var,
     const char *prename)
{
     char new_name[ABC_MAX_WORD];

     if (ABC_MATCH(prename, "")) 
          return;

     sprintf(new_name, "%s%s", prename, var->name);

     if (strlen(new_name) >= ABC_RW_VAR_NAME)
     {
          fprintf(stderr, "New name \"%s\" is too long!", new_name);
          return;
     }

     strcpy(var->name, new_name);
}


static int is_max_word_var(
     AbcFileVar *var)
{
     if (not ABC_MATCH(var->name, "max_word")) return FALSE;
     if (var->type != ABC_RW_TYPE_INT) return FALSE;
     if (var->size != 1) return FALSE;

     return TRUE;
}


static int read_ascii_int_var(
     AbcFileVar *var,
     AbcInput *in)
{
     int i;
     int *iarray;

     ABC_NEW_ARRAY(iarray, int, var->size);
     var->array = (void *) iarray;

     for (i = 0; i < var->size; i++)
          if (not abc_get_int(in, &iarray[i]))
               RETURN_FALSE_ELEM(var, i);

     return TRUE;
}


static int read_ascii_double_var(
     AbcFileVar *var,
     AbcInput *in)
{
     int i;
     double *darray;

     ABC_NEW_ARRAY(darray, double, var->size);
     var->array = (void *) darray;

     for (i = 0; i < var->size; i++)
          if (not abc_get_double(in, &darray[i]))
               RETURN_FALSE_ELEM(var, i);

     return TRUE;
}


static int read_ascii_string_var(
     AbcFileVar *var,
     AbcInput *in)
{
     int i;
     int max_word = var->max_word;
     char *carray;

     ABC_NEW_ARRAY(carray, char, (var->size * max_word));
     var->array = (void *) carray;

     for (i = 0; i < var->size; i++)
     {
          if (not abc_get_string(in, &carray[i * max_word], max_word))
               RETURN_FALSE_ELEM(var, i);
     }

     return TRUE;
}

/*
**   ==========================================
**   PART II: Binary (stream-II) storage format
**   ==========================================
*/

int abc_rw_add_binary_file_contents(
     AbcFileContents *cont,
     const char *filename)
{
     int pos = abc_rw_get_next_free_pos(cont);
     return abc_rw_read_binary_file_contents(cont, filename, pos, "");
}


int abc_rw_read_binary_file_contents(
     AbcFileContents *cont,
     const char *filename,
     int first_index,
     const char *prename)
{
     AbcFileVar *var;
     AbcFileFemInfo fem_info;
     AbcInputStreamII stream;
     char code[34];
     int max_word = 32;
     int n = first_index;

     abc_rw_init_fem_info(&fem_info);

     if (not open_input_sII(&stream, filename))
          RETURN_FALSE_CLOSE_SII(&stream);

     if (not get_string_from_sII(&stream, code, ABC_STREAM_II_CODE_MAX_WORD))
          RETURN_FALSE_CLOSE_SII(&stream);

     if (not ABC_MATCH(code, "ABC-ABC-ABC"))
          RETURN_FALSE_CLOSE_SII(&stream);

     while (not is_end_of_sII(&stream))
     {
          if (n >= ABC_MAX_RW_VARS)
               RETURN_FALSE_CLOSE_SII2(&stream, "Too many variables!");

          var = &(cont->var[n]);
          abc_rw_init_var(var, 0, -1, "", filename);

          if (not get_var_info_from_sII(&stream, var))
               RETURN_FALSE_CLOSE_SII(&stream);

          strcpy(var->filename, filename);
          var->max_word = max_word;

          if (var->array != NULL) 
               ABC_FREE_ARRAY(var->array);

          switch (var->type)
          {
               case ABC_RW_TYPE_INT:
                   if (not read_sII_int_var(var, &stream))
                        RETURN_FALSE_CLOSE_SII2(&stream, "Can't read integer array!");
                   break;

               case ABC_RW_TYPE_DOUBLE:
                   if (not read_sII_double_var(var, &stream))
                        RETURN_FALSE_CLOSE_SII2(&stream, "Can't read double array!");
                   break;

               case ABC_RW_TYPE_STRING:
                   if (not read_sII_string_var(var, &stream))
                        RETURN_FALSE_CLOSE_SII2(&stream, "Can't read string array!");
                   break;

               default:
                    fprintf(stderr, "Error: type=%d is illegal!\n", var->type);
          }

          if (is_max_word_var(var))
               max_word = abc_rw_get_int(var, 0);

          abc_rw_update_fem_info(var, &fem_info);
          abc_rw_copy_fem_info(&fem_info, &(var->fem_info));
          abc_rw_find_min_and_max_var(var);
          /* Changing the name is done after the original name might be used.*/
          add_prename_to_var(var, prename);

          if (cont->is_debugging)
               printf("(has read %s-array \"%s\" of size %d from \"%s\")\n",
                    abc_rw_get_var_type_name(var), var->name, var->size, filename);
          n++;
     }

     report_about_input(cont, first_index, n - 1, filename);
     close_input_sII(&stream);

     return TRUE;
}


static int is_end_of_sII(
     AbcInputStreamII *stream)
{
     int c = getc(stream->in);
     ungetc( c, stream->in);
     return (c == EOF);
}


static int open_input_sII(
     AbcInputStreamII *stream,
     const char *filename)
{
     FILE *in = fopen(filename, "r");

     if (in == NULL)
     {
          fprintf(stderr, "Can't open file: %s!\n", filename);
          return FALSE;
     }

     stream->in = in;
     stream->max_word = 0;
     stream->endian_type = get_endianess();
     strcpy(stream->filename, filename);

     return TRUE;
}


static int close_input_sII(
     AbcInputStreamII *stream)
{
     if (stream->in == NULL) return TRUE;
     fclose(stream->in);
     strcpy(stream->filename, "");
     return TRUE;
}


static int get_var_info_from_sII(
     AbcInputStreamII *stream,
     AbcFileVar *var)
{
     int type, size;
     char name[ABC_STREAM_II_MAX_NAME+1];

     if (not get_int_from_sII(stream, &type)) 
          return FALSE;

     if (not get_string_from_sII(stream, name, ABC_STREAM_II_MAX_NAME)) 
          return FALSE;

     if (not get_int_from_sII(stream, &size)) 
          return FALSE;

     if (not is_ok_type(type))
          return FALSE;

     var->size = size;
     var->type = type;

     /* Adding an end-of-string just to be sure. */
     name[ABC_STREAM_II_MAX_NAME-1] = '\0';
     strcpy(var->name, name);

     return TRUE;
}


static int read_sII_int_var(
     AbcFileVar *var,
     AbcInputStreamII *stream)
{
     int i;
     int *iarray;

     ABC_NEW_ARRAY(iarray, int, var->size);
     var->array = (void *) iarray;

     for (i = 0; i < var->size; i++)
          if (not get_int_from_sII(stream, &iarray[i]))
               RETURN_FALSE_ELEM(var, i);

     return TRUE;
}


static int read_sII_double_var(
     AbcFileVar *var,
     AbcInputStreamII *stream)
{
     int i;
     double *darray;

     ABC_NEW_ARRAY(darray, double, var->size);
     var->array = (void *) darray;

     for (i = 0; i < var->size; i++)
          if (not get_double_from_sII(stream, &darray[i]))
               RETURN_FALSE_ELEM(var, i);

     return TRUE;
}


static int read_sII_string_var(
     AbcFileVar *var,
     AbcInputStreamII *stream)
{
     int i;
     int max_word = var->max_word;
     char *carray;

     ABC_NEW_ARRAY(carray, char, (var->size * max_word));
     var->array = (void *) carray;
     stream->max_word = max_word;

     for (i = 0; i < var->size; i++)
          if (not get_string_from_sII(stream, &carray[i * max_word], max_word))
               RETURN_FALSE_ELEM(var, i);

     return TRUE;
}

/*
**   Low lever function for reading stream-II data.
*/

static int get_int_from_sII(
     AbcInputStreamII *stream,
     int *numb)
{
     char *bytes4 = (char *) numb;
     return get_ordered_bytes(stream, bytes4, 4);
}


static int get_double_from_sII(
     AbcInputStreamII *stream,
     double *numb)
{
     char *bytes8 = (char *) numb;
     return get_ordered_bytes(stream, bytes8, 8);
}


static int get_string_from_sII(
     AbcInputStreamII *stream,
     char *text,
     int max_word) 
{
     int i;

     for (i = 0; i < max_word; i++)
          if ((text[i] = getc(stream->in)) == EOF)
               return FALSE;

     return TRUE;
}


static int get_ordered_bytes(
     AbcInputStreamII *stream,
     char *bytes,
     int size)
{
     int i;
     FILE *in = stream->in;

     if (stream->endian_type == ABC_LITTLE_ENDIAN)
     {
          for (i = size - 1; i >= 0; i--)
               bytes[i] = getc(in);
     }
     else
     {
          for (i = 0; i < size; i--)
               bytes[i] = getc(in);
     }

     return TRUE;
}


static int get_endianess(
     void)
{
    /*
    ** Endianess is the same as byte order. 
    ** A big-endian machine stores the most-significant byte first.
    ** A little-endian machine stores the least-significant byte first. 
    */

    unsigned int tmp = 1;
    char *test = (char*) &tmp;

    if (test[0] == 1)
         return ABC_LITTLE_ENDIAN;

    return ABC_BIG_ENDIAN;
}

/*
**   ============================
**   PART III: Column data format
**   ============================
*/

int abc_rw_read_columns_file_contents(
     AbcFileContents *cont,
     const char *filename,
     int first_index,
     const char *prename)
{
     AbcFileVar *var;
     char varname[ABC_MAX_WORD];
     static AbcInput in;
     int i, j, cols, rows;
     double *array;

     if (not read_size_of_columns(filename, &cols, &rows))
     {
          fprintf(stderr, "Can't read size of file: %s\n", filename);
          return FALSE;
     }

     if (first_index + cols >= ABC_MAX_RW_VARS)
          RETURN_FALSE("Too few buffers!");

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Can't open file: %s\n", filename);
          return FALSE;
     }

     for (i = 0; i < cols; i++)
     {
          sprintf(varname, "%scolumn%-d", prename, i+1);
          var = abc_rw_get_var_by_index(cont, first_index + i);
          abc_rw_allocate_doubles(var, rows, varname, filename);
     }

     for (j = 0; j < rows; j++)
          for (i = 0; i < cols; i++)
          {
               var = abc_rw_get_var_by_index(cont, first_index + i);
               array = abc_rw_get_double_array(var);

               if (not abc_get_double(&in, &array[j]))
                    RETURN_FALSE_CLOSE_ABC(&in, "Expected a number!");
          }

     for (i = 0; i < cols; i++)
     {
          var = abc_rw_get_var_by_index(cont, first_index + i);
          abc_rw_find_min_and_max_var(var);
     }

     report_about_input(cont, first_index, first_index + cols - 1, filename);
     abc_end_input(&in);

     return TRUE;
}


static int read_size_of_columns(
     const char *filename,
     int *cols,
     int *rows)
{
     static AbcInput in;
     double dummy;
     int line0, line1, n_cols, n_data;

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Can't open file: %s\n", filename);
          return FALSE;
     }

     abc_skip_blanks_and_comments(&in);
     line0 = line1 = abc_get_input_line_number(&in);

     for (n_cols = -1; line0 == line1 and abc_get_double(&in, &dummy); n_cols++)
          line0 = abc_get_input_line_number(&in);

     for (n_data = n_cols + 1; abc_get_double(&in, &dummy); n_data++);

     if (n_cols < 1)
          RETURN_FALSE_CLOSE_ABC(&in, "Number of columns is less than 1");

     if (n_data % n_cols != 0)
          RETURN_FALSE_CLOSE_ABC(&in, "Data columns are of different size!");

     *cols = n_cols;
     *rows = n_data / n_cols;

     abc_end_input(&in);
     return TRUE;
}

/*
**   ===============================
**   PART IV: Old data series format
**   ===============================
*/

int abc_rw_read_old_serie_file_contents(
     AbcFileContents *cont,
     const char *filename,
     int first_index,
     const char *prename)
{
     static AbcInput in;
     AbcFileFemInfo fem_info;
     AbcFileVar *var;
     char word[ABC_MAX_WORD];
     int max_word = 0;
     int n = first_index;
     int inumb;

     abc_rw_init_fem_info(&fem_info);

     if (not abc_begin_input(&in, filename)) 
     {
          fprintf(stderr, "Can't open file: %s\n", filename);
          return FALSE; 
     }

     while (abc_get_word(&in, word, ABC_MAX_WORD) and 
          not (ABC_MATCH(word, "begin_results") or ABC_MATCH(word, "begin_results2")))
          ;

     while (abc_get_word(&in, word, ABC_MAX_WORD) and 
          not (ABC_MATCH(word, "end_results") or ABC_MATCH(word, "end_results2")))
     {
          if (n >= ABC_MAX_RW_VARS)
               RETURN_FALSE_CLOSE_ABC(&in, "Too many variables!");

          var = &(cont->var[n]);
          abc_rw_init_var(var, 0, -1, "", filename);
          var->max_word = max_word;

          if (var->array != NULL)
               ABC_FREE_ARRAY(var->array);

          if (ABC_MATCH(word, "data_time"))
          {
               if (not get_and_store_double(&in, var, "data_time", filename))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"data_time\"!");
          }
          else if (ABC_MATCH(word, "grid_type"))
          {
               if (not get_and_store_int(&in, var, "grid_type", filename))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"grid_type\"!");
          }
          else if (ABC_MATCH(word, "n_elems"))
          {
               if (not abc_get_int(&in, &inumb))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"n_elems\"!");
          }
          else if (ABC_MATCH(word, "n_nodes"))
          {
               if (not abc_get_int(&in, &inumb))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"n_nodes\"!");
          }
          else if (ABC_MATCH(word, "n_local_nodes"))
          {
               if (not abc_get_int(&in, &inumb))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"n_local_nodes\"!");
          }
          else if (ABC_MATCH(word, "n_x_nodes"))
          {
               if (not get_and_store_int(&in, var, "n_x_nodes", filename))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"n_x_nodes\"!");
          }
          else if (ABC_MATCH(word, "n_y_nodes"))
          {
               if (not get_and_store_int(&in, var, "n_y_nodes", filename))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"n_y_nodes\"!");
          }
          else if (ABC_MATCH(word, "max_word"))
          {
               if (not get_and_store_int(&in, var, "max_word", filename))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read \"max_word\"!");
          }
          else if (ABC_MATCH(word, "int"))
          {
               if (not read_int_serie(&in, var))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read integers!");
          }
          else if (ABC_MATCH(word, "char") or ABC_MATCH(word, "strings"))
          {
               if (not read_string_serie(&in, var, max_word))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read strings!");
          }
          else if (ABC_MATCH(word, "double"))
          {
               if (not read_double_serie(&in, var))
                    RETURN_FALSE_CLOSE_ABC(&in, "Can't read doubles!");
          }
          else
          {
               fprintf(stderr, "Keyword %s is unknown!\n", word);
               RETURN_FALSE_CLOSE_ABC(&in, "Can't continue!");
          }

          if (is_max_word_var(var))
               max_word = abc_rw_get_int(var, 0);

          strcpy(var->filename, filename);
          abc_rw_update_fem_info(var, &fem_info);
          abc_rw_copy_fem_info(&fem_info, &(var->fem_info));
          abc_rw_find_min_and_max_var(var);
          /* Changing the name is done after the original name might be used.*/
          add_prename_to_var(var, prename);

          if (cont->is_debugging)
               printf("(has read %s-array \"%s\" of size %d from \"%s\")\n",
                    abc_rw_get_var_type_name(var), var->name, var->size, filename);
          n++;
     }

     report_about_input(cont, first_index, n - 1, filename);
     abc_end_input(&in);
     return TRUE;
}


static int get_and_store_int(
     AbcInput *in,
     AbcFileVar *var,
     const char *name,
     const char *filename)
{
     int value;

     if (not abc_get_int(in, &value))
          return FALSE;

     abc_rw_allocate_one_int(var, value, name, filename);
     return TRUE;
}


static int get_and_store_double(
     AbcInput *in,
     AbcFileVar *var,
     const char *name,
     const char *filename)
{
     double value;

     if (not abc_get_double(in, &value))
          return FALSE;

     abc_rw_allocate_one_double(var, value, name, filename);
     return TRUE;
}


int read_int_serie(
     AbcInput *in,
     AbcFileVar *var)
{
     int i, size;
     int *array; 
     char name[ABC_MAX_WORD]; 
 
     if (not abc_get_word(in, name, ABC_MAX_WORD)) 
          ABC_RETURN_FALSE("Can't read variable name!"); 
 
     if (not abc_get_int(in, &size)) 
          ABC_RETURN_FALSE("Can't read the variable size!"); 

     abc_rw_allocate_ints(var, size, name, "");
     array = abc_rw_get_int_array(var);

     for (i = 0; i < size; i++)
          if (not abc_get_int(in, &array[i])) 
               ABC_RETURN_FALSE("Expected an integer!"); 
 
     return TRUE;
}


int read_double_serie(
     AbcInput *in,
     AbcFileVar *var)
{
     int i, size;
     double *array;
     char name[ABC_MAX_WORD];

     if (not abc_get_word(in, name, ABC_MAX_WORD))
          ABC_RETURN_FALSE("Can't read variable name!");

     if (not abc_get_int(in, &size))
          ABC_RETURN_FALSE("Can't read the variable size!");

     abc_rw_allocate_doubles(var, size, name, "");
     array = abc_rw_get_double_array(var);

     for (i = 0; i < size; i++)
          if (not abc_get_double(in, &array[i]))
               ABC_RETURN_FALSE("Expected a double!");

     return TRUE;
}


int read_string_serie(
     AbcInput *in,
     AbcFileVar *var,
     int max_word)
{
     int i, size;
     char *array;
     char name[ABC_MAX_WORD];

     var->max_word = max_word;

     if (not abc_get_word(in, name, ABC_MAX_WORD))
          ABC_RETURN_FALSE("Can't read variable name!");

     if (not abc_get_int(in, &size))
          ABC_RETURN_FALSE("Can't read the variable size!");

     abc_rw_allocate_strings(var, size, name, "");
     array = abc_rw_get_char_array(var);

     for (i = 0; i < size; i++)
          if (not abc_get_string(in, &array[i * max_word], max_word))
               ABC_RETURN_FALSE("Expected a string!");

     return TRUE;
}

/*
**   ====================================
**   PART V: Reading one var from console
**   ====================================
*/

void abc_rw_read_data_one_var(
     AbcFileContents *cont,      
     AbcInput *in,
     int index,
     int size)
{
     int c, n;
     double numb, *array;
     AbcFileVar *var;

     var = abc_rw_get_var_by_index(cont, index);
     abc_rw_allocate_doubles(var, size, "-", "(console)");
     array = abc_rw_get_double_array(var);

     for (n = 0; abc_get_double(in, &numb); n++)
          if (n < size)
                array[n] = numb;

     c = abc_getch(in);
     if (c != ';') abc_ungetch(in, c);

     if (n > size)
     {
          fprintf(stderr, "(%d numbers are skipped)\n", n - size);
          n = size;
     }
   
     var->size = n;
     abc_rw_find_min_and_max_var(var);
}


void abc_rw_read_data_one_string_var(
     AbcFileContents *cont,
     AbcInput *in,
     int index,
     int max_array,
     int max_word)
{
     int c, n;
     AbcFileVar *var;
     char *carray, string[ABC_MAX_WORD];

     var = abc_rw_get_var_by_index(cont, index);
     var->max_word = max_word;
     abc_rw_allocate_strings(var, max_array, "-", "(console)");
     carray = abc_rw_get_char_array(var);

     for (n = 0; abc_get_string(in, string, max_word); n++)
          if (n < max_array)
                strcpy(&carray[n * max_word], string);

     c = abc_getch(in);
     if (c != ';') abc_ungetch(in, c);

     if (n > max_array)
     {
          fprintf(stderr, "(%d strings are skipped)\n", n - max_array);
          n = max_array;
     }

     var->size = n;
}

