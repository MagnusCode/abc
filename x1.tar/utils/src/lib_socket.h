/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1999-2002 by M. Wangen.
**
**   Info: Functions for socket connections
**   Date: Version 1.0, October 2002
**
**   $Id$
*/

#ifndef _LIB_SOCKET_H_
#define _LIB_SOCKET_H_

/* Prototypes for: lib_socket.c */

int run_demo_server(int argc, char **argv);
int run_demo_client(int argc, char **argv);
void socket_init_lib(void);
int socket_begin_client(const char *host_name, const char *port_number);
int socket_begin_server(const char *port_number);
int socket_accept(int socket_listen);
int socket_close(int s1);
int socket_has_data(int fd);
int socket_write_string(int fd, const char *string);
int socket_read_string(int fd, char *string, int max_size);
void socket_chop_string(char *string);


#endif
