/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1994-2011 by Magnus Wangen.
**
**   Info: Functions for storing results.
**   Date: Version 2.0, June 2011
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_DATA_WRITE_H_
#define _LIB_DATA_WRITE_H_

#include <lib_macros.h>
#include <lib_actions.h>
#include <lib_input.h>

#define ABC_UNDEFINED_ENDIAN  0
#define ABC_LITTLE_ENDIAN     1
#define ABC_BIG_ENDIAN        2

#define ABC_STREAM_II_MAX_NAME 32
#define ABC_STREAM_II_CODE "ABC-ABC-ABC"
#define ABC_STREAM_II_CODE_MAX_WORD 32

typedef struct _AbcOutputStreamII_ AbcOutputStreamII;

struct _AbcOutputStreamII_ {
     FILE  *out;
     int (*write_begin)(AbcOutputStreamII *S, char const *filename);
     int (*write_end)(AbcOutputStreamII *S);
     int (*write_ints)(AbcOutputStreamII *S, char const *name, int *array, int size);
     int (*write_strings)(AbcOutputStreamII *S, char const *name, char *array, int size, int max_word);
     int (*write_doubles)(AbcOutputStreamII *S, char const *name, double *array, int size);
     char filename[ABC_MAX_WORD];
     int endian_type;
     int counter;
};

int abc_write_test_II(int argc, char **argv);
int abc_write_test_strings_II(int argc, char **argv);
void abc_write_param_as_string_II(AbcOutputStreamII *stream, const char *name, const char *fmt, double param);
void abc_init_ascii_stream(AbcOutputStreamII *stream);
void abc_init_binary_stream(AbcOutputStreamII *stream);
int abc_is_ok_binary_sizes(void);
int abc_get_endianess(void);
const char *abc_get_endianess_name(int type);
int abc_read_output_times(AbcInput *in, AbcActionList *list, int type,
     char const *begin_key_word, char const *end_key_word);

#define abc_write_begin_II(S, filename)                  ((S)->write_begin(S, filename))
#define abc_write_end_II(S)                              ((S)->write_end(S))
#define abc_write_ints_II(S, name, array, size)          ((S)->write_ints(S, name, array, size))
#define abc_write_strings_II(S, name, array, size, maxw) ((S)->write_strings(S, name, array, size, maxw))
#define abc_write_doubles_II(S, name, array, size)       ((S)->write_doubles(S, name, array, size))

#endif

