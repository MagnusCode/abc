/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1998 by M. Wangen.
**
**   Info: Utility functions
**   Date: Version 1.0, January 1998
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_UTILS_H_
#define _LIB_UTILS_H_

typedef int (*ABC_READ_ONE_OPTION)(const char *string);

typedef enum {
     AbcTimeUnitUndefined,
     AbcTimeUnitMillionYears,
     AbcTimeUnitYears,
     AbcTimeUnitDays,
     AbcTimeUnitHours,
     AbcTimeUnitMinutes,
     AbcTimeUnitSeconds
} AbcTimeUnit;

void abc_do_nothing(void);
void abc_swap_ints(int *n1, int *n2);
void abc_swap_floats(float *n1, float *n2);
void abc_swap_doubles(double *n1, double *n2);
void abc_sort_three_doubles(double *aa, double *bb, double *cc);
void abc_copy_ints(int *a, int *b, int size);
void abc_copy_doubles(double *a, double *b, int size);
void abc_init_ints(int *a, int size, int value);
void abc_init_doubles(double *a, int size, double value);
void abc_interpret_option(const char *string, char *option, char *value_part, double *value);
void abc_read_options_from_file(ABC_READ_ONE_OPTION read_one_option, const char *filename);
int abc_get_one_int_arg(int *argc, char **argv, const char *wanted_option,
     int min_value, int max_value, int default_value);
double abc_get_one_double_arg(int *argc, char **argv, const char *wanted_option,
     double min_value, double max_value, double default_value);
FILE *abc_open_file(char const *basename, char const *extension);
FILE *abc_new_file(char const *basename, char const *extension);
FILE *abc_new_TeX_file2(const char *part1, const char *part2);
FILE *abc_new_TeX_file(char const *basename);
void abc_end_TeX_file(FILE *out);
FILE *abc_begin_reading(char const *filename);
void abc_escape_TeX_underscore(char const *string1, char *string2);
void abc_replace_TeX_underscore(char const *string1, int chr, char *string2);
void abc_print_TeX_number(FILE *out, double numb);
const char *tex_numb(double numb);
char *abc_save_string(char const *string);
int *abc_save_int_array(int *array1, int size);
double *abc_save_double_array(double *array1, int size);
void abc_split_string_to_args(char *string, int *argc, char **argv);
void abc_copy_args(int *argc, char **argv, int new_argc, char **new_argv);
void abc_remove_one_arg(int n, int *argc, char **argv);
void abc_skip_blanks(FILE *in);
int abc_read_int(FILE *in, int *numb);
int abc_read_real(FILE *in, double *numb);
int abc_read_comma(FILE *in);
int abc_read_word(FILE *in, char *word);
int abc_read_string(FILE *in, char *string);
int abc_read_named_ints(FILE *in, char const *name, int max_size, int *array);
int abc_read_named_reals(FILE *in, char const *name, int max_size, double *array);
int abc_read_named_strings(FILE *in, char const *name, int max_size, char **array);
int abc_read_and_match_name(FILE *in, char const *name);
int abc_read_size_of_vector(FILE *in, int *rows);
int abc_read_size_of_matrix(FILE *in, int *rows, int *cols);
int abc_read_ints(FILE *in, int *vector, int size);
int abc_read_reals(FILE *in, double *vector, int size);
int abc_read_matrix_reals(FILE *in, double **matrix, int rows, int cols);
int abc_read_strings(FILE *in, char **array, int size);
int abc_read_mm_banner(FILE *in, char *vec);
void abc_write_ints(FILE *out, char const *name, int size, int *array);
void abc_write_reals(FILE *out, char const *name, int size, double *array);
void abc_write_strings(FILE *out, char const *name, int size, char **array);
void abc_show_vector(FILE *out, char const *name, const double *vector, int rows);
void abc_show_matrix(FILE *out, char const *name, double **matrix, int rows, int cols);
void abc_get_basename(char const *filename, char *basename);
void abc_get_extension(char const *filename, char *extension);
void abc_get_dirname(char const *filename, char *dirname);
int abc_is_number(char const *string);
double abc_max_velocity(double *vx, double *vy, double *vz, int size);
double abc_mean_value(double *array, int size);
int abc_is_equally_spaced_array(double *vec, int size);
const char *abc_get_name_yes_or_no(int is_yes_or_no);
const char *abc_get_name_YES_or_NO(int is_yes_or_no);
const char *abc_get_name_true_or_false(int is_yes_or_no);
const char *abc_get_name_TRUE_or_FALSE(int is_yes_or_no);
void abc_set_output_separator(char ch);
char abc_get_output_separator(void);
void abc_set_margin_size(int size);
const char *abc_get_margin(int level);
int abc_get_number_of_columns(const char *filename);
int abc_get_number_of_lines(const char *filename);
void abc_print_time(FILE *out, double t_sec);
double abc_get_sec_in_time_unit(AbcTimeUnit time_unit);
const char *abc_get_time_unit_name(AbcTimeUnit time_unit);
const char *abc_get_time_unit_full_name(AbcTimeUnit time_unit);
AbcTimeUnit abc_get_time_unit_from_full_name(const char *name);
double abc_get_time_in_new_unit(double t, AbcTimeUnit old_unit, AbcTimeUnit new_unit);
int abc_get_int_option_in_string(const char *text, const char *name, int *numb);
int abc_get_double_option_in_string(const char *text, const char *name, double *numb);
int abc_get_pos_after_substring(const char *text, const char *name);
int abc_get_option_field_in_string(const char *text, const char *name, int max_field, char *field);
void abc_nice_interval(double *min, double *max, int *steps, int steplimit);
void abc_nice_log_interval(double *min, double *max, int *steps);
void abc_init_geom_coord_series(double *rcoord, int nr, double r1, double r2, double k0);
int abc_get_max_bit_ints(void);
int abc_get_bit_as_int(int bit);

#endif
