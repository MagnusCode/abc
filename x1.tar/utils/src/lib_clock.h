/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1999 by M. Wangen.
**
**   Info: A library for measuring CPU-time
**   Date: Version 2.0, February 1990
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_CLOCK_H_
#define _LIB_CLOCK_H_

typedef struct AbcClock {
     char *name;     /* The clock name. */
     int is_running; /* Is true if the clock is running. */
     int used_time;  /* Time used in last periode. */
     int total_time; /* Total cpu time of all periodes. */
     int start_time; /* CPU time when the clock is started. */
     int stop_time;  /* CPU time when the clock is stopped. */
} AbcClock;

void abc_test_clock(void);
int abc_is_clock_running(AbcClock *clock_def);
AbcClock *abc_create_clock(char const *name);
void abc_delete_clock(AbcClock **clock_def);
void abc_reset_clock(AbcClock *clock_def);
void abc_start_clock(AbcClock *clock_def);
void abc_stop_clock(AbcClock *clock_def);
void abc_read_clock(AbcClock *clock_def, int *time_used, int *time_total);
void abc_show_clock(AbcClock *clock_def, FILE *fp);
void abc_print_clock_used_time(AbcClock *clock_def, FILE *fp);
void abc_print_clock_total_time(AbcClock *clock_def, FILE *fp);
void abc_print_clock_time(FILE *fp, int sec);
int abc_get_time_in_sec(void);

#endif
