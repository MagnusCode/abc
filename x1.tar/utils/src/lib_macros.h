/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1998 by M. Wangen.
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_MACRO_H_
#define _LIB_MACRO_H_

#define ABC_VERSION "0.9904, compiled: UNKNOWN_DATE"
 
#ifndef __STDC__
#     define const
#     define void char
#endif
 
#define ABC_REAL double

#ifndef not
#define not !
#endif

#ifndef or
#define or ||
#endif

#ifndef and
#define and &&
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define ABC_ABS(x) ((x) > 0.0 ? (x) : (-(x)))
#define ABC_MAX(x, y) ((x) > (y) ? (x) : (y))
#define ABC_MIN(x, y) ((x) > (y) ? (y) : (x))
#define ABC_SQR(x) ((x) * (x))
#define ABC_CUB(x) ((x) * (x) * (x))

#define ABC_SEC_IN_YEARS 31536000
#define ABC_SEC_IN_MILL_YEARS 3.1536e+13

#define ABC_PI 3.1415926535897932384
#define ABC_E0 2.7182818284590452354
#define ABC_MAX_WORD 256
#define ABC_MAX_ARGS  1024

#define ABC_MATCH(a, b) (strcmp(a,b) == 0)

#define ABC_ERROR_MESSAGE(text) fprintf(stderr, "Error: %s\n", text)
#define ABC_ERROR_RETURN(text) {ABC_ERROR_MESSAGE(text); return;}
#define ABC_ERROR_EXIT(text) {ABC_ERROR_MESSAGE(text); exit(1);}
#define ABC_ERROR_EXIT2(t1, t2) {ABC_ERROR_MESSAGE(t1); ABC_ERROR_MESSAGE(t2); exit(1);}
#define ABC_RETURN_NULL(text) {ABC_ERROR_MESSAGE(text); return NULL;}
#define ABC_RETURN_FALSE(text) {ABC_ERROR_MESSAGE(text); return FALSE;}

#define ABC_IS_SIGN(c) ((c) == '-' || (c) == '+')
#define ABC_IS_DIGIT(c) ('0' <= (c) && (c) <= '9')
#define ABC_IS_NCHAR(c) ((c) == '.' || (c) == 'e' || (c) == 'E')
#define ABC_IS_SIGNED(c) (ABC_IS_DIGIT(c) || ABC_IS_SIGN(c))
#define ABC_IS_NUMERIC(c) (ABC_IS_DIGIT(c) || ABC_IS_SIGN(c) || ABC_IS_NCHAR(c))
#define ABC_IS_BLANK(c) ((c) == ' ' || (c) == '\t' || (c) == '\n')
#define ABC_IS_EOF(c) ((c) == EOF)
#define ABC_SET_BIT(pattern, bit)   {if (not (pattern & bit)) pattern += bit;}
#define ABC_RESET_BIT(pattern, bit) {if (pattern & bit) pattern -= bit;}

/*
** #define ABC_UNUSED_PARAMETER(a) ((a) = (a))
*/
#define ABC_UNUSED_PARAMETER(a) ((void)(a))

#define ABC_ASSERT(ptr, func_name) {                                     \
     if ((void *) ptr == NULL) {                                         \
          fprintf(stderr, "%s called with NULL-pointer!\n", func_name);  \
          ABC_ERROR_EXIT("Can't continue!");                             \
     }                                                                   \
}

#define ABC_INIT_ARRAY(XARRAY, XSIZE, XVALUE) {  \
     int i;                                      \
     if (XARRAY != NULL)                         \
          for (i = 0; i < XSIZE; i++)            \
               XARRAY[i] = XVALUE;               \
}

#define ABC_COPY_ARRAY(ARRAY1, ARRAY2, SIZE) {   \
     int i;                                      \
     if ((ARRAY1 != NULL) and (ARRAY2 != NULL))  \
          for (i = 0; i < SIZE; i++)             \
               ARRAY2[i] = ARRAY1[i];            \
}

#define ABC_DIR_SEPARATOR_MSDOS "\\"
#define ABC_DIR_SEPARATOR_UNIX "/"

#ifdef WIN32
#define ABC_DIR_SEPARATOR ABC_DIR_SEPARATOR_MSDOS
#else
#define ABC_DIR_SEPARATOR ABC_DIR_SEPARATOR_UNIX
#endif

/* Alternative version of MAX-parameters. */

#define MAX_ABC_WORD ABC_MAX_WORD
#define MAX_ABC_ARGS ABC_MAX_ARGS

/* Cleaning up remaining variables. */

#define ABC_DELETE_LIB() {              \
     abc_close_all_listed_files();      \
     fem_delete_library();              \
     abc_delete_input_lib();            \
     abc_delete_all_allocated_once();   \
}

#endif

