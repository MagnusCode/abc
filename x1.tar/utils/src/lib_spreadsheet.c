/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998-2001 by M. Wangen.
**
**   Info: Functions processing spreadsheets
**   Date: Version 1.0, November 1998
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_spreadsheet.h>


static int
     is_verbose = TRUE;


void abc_set_spreadsheet_verbose_mode(
     int on_off)
{
     is_verbose = on_off;
}


int abc_read_spreadsheet_from_file(
     const char *filename,
     AbcSpreadsheet *spreadsheet)
{
     static AbcInput in;

     if (not abc_begin_input(&in, filename))
          return FALSE;

     abc_read_spreadsheet(&in, spreadsheet);
     abc_end_input(&in);
     return TRUE;
}


void abc_read_spreadsheet(
     AbcInput *in,
     AbcSpreadsheet *spreadsheet)
{
     int i = 0;
     int j = 0;
     int cols = 0;
     char field[ABC_MAX_SPREADSHEET_WORD];

     abc_init_spreadsheet(spreadsheet);

     if (not abc_get_field(in, field, ABC_MAX_SPREADSHEET_WORD) and not ABC_MATCH(field, "begin_spreadsheet"))
          ABC_ERROR_RETURN("[abc_read_spreadsheet] Expected \"begin_spreadsheet\"!\n");

     while (abc_get_field(in, field, ABC_MAX_SPREADSHEET_WORD) and not ABC_MATCH(field, "end_spreadsheet"))
     {
          strcpy(spreadsheet->field[i][j], field);
          j++;

          if (abc_skip_blanks_and_comments(in))
          {
               i++;
               if (j > cols) cols = j;
               j = 0;
          }

          if (i >= ABC_MAX_SPREADSHEET_ROWS)
               ABC_ERROR_EXIT("[abc_read_spreadsheet] Too many rows!");

          if (j >= ABC_MAX_SPREADSHEET_COLS)
               ABC_ERROR_EXIT("[abc_read_spreadsheet] Too many colums!");
     }

     spreadsheet->rows = i;
     spreadsheet->cols = cols;
     strcpy(spreadsheet->file_name, in->file_name);
}


int abc_get_spreadsheet_cols(
     AbcSpreadsheet *spreadsheet)
{
     return spreadsheet->cols;
}


int abc_get_spreadsheet_rows(
     AbcSpreadsheet *spreadsheet)
{
     return spreadsheet->rows;
}


void abc_init_spreadsheet(
     AbcSpreadsheet *spreadsheet)
{
     int i, j;

     for (i = 0; i < ABC_MAX_SPREADSHEET_ROWS; i++)
           for (j = 0; j < ABC_MAX_SPREADSHEET_COLS; j++)
                spreadsheet->field[i][j][0] = '\0';
}


void abc_print_spreadsheet(
     FILE *out,
     AbcSpreadsheet *spreadsheet)
{
     int max_col_width[ABC_MAX_SPREADSHEET_COLS];
     const char *spacing = " ";
     char format[ABC_MAX_WORD];   
     int i, j, width;
     
     for (j = 0; j < spreadsheet->cols; j++)
     {
          max_col_width[j] = 0;

          for (i = 0; i < spreadsheet->rows; i++)
          {
               width = strlen(spreadsheet->field[i][j]);
               if (width > max_col_width[j]) max_col_width[j] = width;
          }
     }

     fprintf(out, "begin_spreadsheet #(rows=%d, cols=%d, file=%s)#\n",
          spreadsheet->rows, spreadsheet->cols, spreadsheet->file_name);

     for (i = 0; i < spreadsheet->rows; i++)
     {
          for (j = 0; j < spreadsheet->cols; j++)
          {
               sprintf(format, "%%-%ds%s", max_col_width[j], spacing);
               fprintf(out, format, spreadsheet->field[i][j]);
          }
 
          fprintf(out, "\n");
     }

     fprintf(out, "end_spreadsheet\n");
}


void abc_print_spreadsheet_col_by_name(
     FILE *out, 
     AbcSpreadsheet *spreadsheet, 
     const char *name)
{
     int i;
     int col = abc_get_spreadsheet_col_by_name(spreadsheet, name);

     if (col < 0)
     {
          fprintf(stderr, "There is no column named: %s\n", name);
          return;
     }

     for (i = 0; i < spreadsheet->rows; i++)
          fprintf(out, "%s\n", spreadsheet->field[i][col]);
}


int abc_get_spreadsheet_col_by_name(
     AbcSpreadsheet *spreadsheet,
     const char *name)
{
     int j;

     if (spreadsheet->rows < 1)
     {
          fprintf(stderr, "[abc_get_spreadsheet_col_by_name] No lines in sheet!");
          return -1;
     }

     for (j = 0; j < spreadsheet->cols; j++)
          if (ABC_MATCH(spreadsheet->field[0][j], name))
               return j;

     return -1;
}


const char *abc_get_spreadsheet_field_by_name(
     AbcSpreadsheet *spreadsheet,
     const char *name,
     int row)
{
     static const char *dummy = "";
     int col = abc_get_spreadsheet_col_by_name(spreadsheet, name);

     if (col < 0 and is_verbose)
     {
          fprintf(stderr, "[get_spreadsheet_field_by_name] Unknown column name: %s\n", name);
          return dummy;
     }

     if (row >= spreadsheet->rows)
     {
          fprintf(stderr, "[get_spreadsheet_field_by_name] Too large row number!");
          fprintf(stderr, "(row is %d, max rows is %d)\n", row, spreadsheet->rows);
          return dummy;
     }

     return &(spreadsheet->field[row][col][0]);
}


const char *abc_get_spreadsheet_field_by_row_col(
     AbcSpreadsheet *spreadsheet,
     int row,
     int col)
{
     static const char *dummy = "";

     if (row >= spreadsheet->rows)
     {
          fprintf(stderr, "[abc_get_spreadsheet_field_by_row_col] Too large row number!");
          fprintf(stderr, "(row is %d, max rows is %d)\n", row, spreadsheet->rows);
          return dummy;
     }

     if (col >= spreadsheet->cols)
     {
          fprintf(stderr, "[abc_get_spreadsheet_field_by_row_col] Too large column number!");
          fprintf(stderr, "(colum is %d, max columns is %d)\n", row, spreadsheet->cols);
          return dummy;
     }

     return &(spreadsheet->field[row][col][0]);
}


void abc_set_spreadsheet_field_by_row_col(
     AbcSpreadsheet *spreadsheet,
     int row,
     int col,
     const char *field)
{
     if (row >= spreadsheet->rows)
     {
          fprintf(stderr, "[abc_set_spreadsheet_field_by_row_col] Too large row number!");
          fprintf(stderr, "(row is %d, max rows is %d)\n", row, spreadsheet->rows);
          return;
     }

     if (col >= spreadsheet->cols)
     {
          fprintf(stderr, "[abc_set_spreadsheet_field_by_row_col] Too large column number!");
          fprintf(stderr, "(colum is %d, max columns is %d)\n", row, spreadsheet->cols);
          return;
     }

     if (strlen(field) < ABC_MAX_SPREADSHEET_WORD)
          strcpy(spreadsheet->field[row][col], field);
     else
          fprintf(stderr, "[set_speadsheet_field_by_row_col] Too large field!");
}


int abc_get_spreadsheet_number_by_row_col(
     AbcSpreadsheet *spreadsheet,
     int row,
     int col,
     double *number)
{
     const char *field = abc_get_spreadsheet_field_by_row_col(spreadsheet, row , col);

     if (sscanf(field, "%lf", number) == 1)
          return TRUE;

     return TRUE;
}


int abc_add_spreadsheet_column(
     AbcSpreadsheet *spreadsheet)
{
     spreadsheet->cols++;

     if (spreadsheet->cols >= ABC_MAX_SPREADSHEET_COLS)
          ABC_ERROR_EXIT("[abc_add_spreadsheet_column] Too many columns!");

     return spreadsheet->cols;
}


int abc_add_spreadsheet_row(
     AbcSpreadsheet *spreadsheet)
{
     spreadsheet->rows++;
     
     if (spreadsheet->rows >= ABC_MAX_SPREADSHEET_ROWS)
          ABC_ERROR_EXIT("[abc_add_spreadsheet_rows] Too many rows!");

     return spreadsheet->rows;
}

