/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-2002 by M. Wangen.
**
**   Info: A simple PostScript driver
**   Date: Version 2.0, June 2002
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   Version history:
**
**   1.0, Mar 1995 - First operative version.
**   2.0, Jun 2002 - Pixel buffers
*/


#include <math.h>
#include <stdio.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_plotps.h>

static char
     char_code_map[16] = {
          '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
          'a', 'b', 'c', 'd', 'e', 'f'
     };

static double XPS(double xx);
static double YPS(double yy);
static void ps_install_font(void);
static void ps_recompute_factors(void);
static void ps_translate_and_scale(void);
static int ps_is_unit_coord(double x);
static int fill_in_basic_char_codes(char *buffer, int bits, double unit_value);
static int fill_in_char_codes4(char *buffer, double unit_value);
static int fill_in_char_codes8(char *buffer, double unit_value);
static double hue_comparison(double v1, double v2, double hue);
static void ps_strip_meta_text(const char *text1, char *text2);
static void ps_fix_and_show_char(int ch);

#define DEFAULT_XPS_ABC_MIN  70.0
#define DEFAULT_XPS_ABC_MAX 540.0
#define DEFAULT_YPS_ABC_MIN 200.0
#define DEFAULT_YPS_ABC_MAX 670.0

#define CHECK_INIT {if (output == NULL) ABC_ERROR_RETURN("\"abc_ps_init\" isn't called!");}

static FILE
     *output = NULL;

static char
     font_name[ABC_MAX_WORD] = "Times-Roman";

static int
     page_number = 1,
     is_using_device_coords = FALSE;

static double
     grayness = 0.0,
     font_size = 15.0,
     bullet_size = 2.5,
     line_width = 1.0,
     xfactor = 1.0,
     yfactor = 1.0,
     xorigo = DEFAULT_XPS_ABC_MIN,
     yorigo = DEFAULT_YPS_ABC_MIN,
     x1_ps_space = DEFAULT_XPS_ABC_MIN,
     y1_ps_space = DEFAULT_YPS_ABC_MIN,
     x2_ps_space = DEFAULT_XPS_ABC_MAX,
     y2_ps_space = DEFAULT_YPS_ABC_MAX,
     x1_user_space = 0.0,
     y1_user_space = 0.0,
     x2_user_space = 1.0,
     y2_user_space = 1.0,
     x1_viewport_unit = 0.0,
     y1_viewport_unit = 0.0,
     x2_viewport_unit = 1.0,
     y2_viewport_unit = 1.0;


void abc_ps_meta_text_example(
     void)
{
     double angle = 0.0;
     double factor = 0.0;
     const char *filename = "xmetatext.ps";

     abc_ps_begin(filename, "");
     abc_ps_set_font_size(19.0);

     abc_ps_put_meta_text(0.0, 0.90, angle, factor, "Hei dette er en test!");
     abc_ps_put_meta_text(0.0, 0.85, angle, factor, "E=mc^{2} E=mc^{2} E=mc^{2}");
     abc_ps_put_meta_text(0.0, 0.80, angle, factor, "A=a^{b^{c}} A=a^{b^{c}} A=a^{b^{c}}");
     abc_ps_put_meta_text(0.0, 0.75, angle, factor, "A=T_{ij}, A=T_{n_{i},m_{k}}");
     abc_ps_put_meta_text(0.0, 0.70, angle, factor, "abc ABC {abc} ABC abc");
     abc_ps_put_meta_text(0.0, 0.65, angle, factor, "abc {ABC {a{{b}}c} ABC} abc");
     abc_ps_put_meta_text(0.0, 0.60, angle, factor, "abc {$0 abcdefghijklmnopqrstuvwxyz} abc");
     abc_ps_put_meta_text(0.0, 0.55, angle, factor, "abc {$1 abcdefghijklmnopqrstuvwxyz} abc");
     abc_ps_put_meta_text(0.0, 0.50, angle, factor, "abc \\{ ${ $$ $} \\} abc");

     for (angle = 0.0; angle < 360.0; angle += 30.0)
          abc_ps_put_meta_text(0.40, 0.10, angle, factor, "   E=mc^{2} E=mc^{2} E=mc^{2}");

     abc_ps_put_meta_text(0.70, 0.85, angle, 0.0, "E=mc^{2} E=mc^{2} E=mc^{2}");
     abc_ps_put_meta_text(0.70, 0.80, angle, 0.5, "E=mc^{2} E=mc^{2} E=mc^{2}");
     abc_ps_put_meta_text(0.70, 0.75, angle, 1.0, "E=mc^{2} E=mc^{2} E=mc^{2}");

     abc_ps_put_meta_text(0.80, 0.35, 90.0, 0.0, "E=mc^{2} E=mc^{2} E=mc^{2}");
     abc_ps_put_meta_text(0.85, 0.35, 90.0, 0.5, "E=mc^{2} E=mc^{2} E=mc^{2}");
     abc_ps_put_meta_text(0.90, 0.35, 90.0, 1.0, "E=mc^{2} E=mc^{2} E=mc^{2}");

     abc_ps_end();

     printf("(PostScript test is written to: %s)\n", filename);
}


int abc_ps_begin(
     char const *filename,
     char const *extension) 
{
     FILE *out;
     char string[256];

     sprintf(string, "%s%s", filename, extension);

     if ((out = fopen(string, "w")) == NULL)
     {
          fprintf(stderr, "[abc_ps_begin] Can't open file: %s\n", string);
          return FALSE;
     }

     abc_ps_init(out);
     return TRUE;
}


void abc_ps_end(
  void) 
{
     CHECK_INIT;
     fprintf(output, "showpage\n");
     fclose(output);
     output = NULL;
}


void abc_ps_comment(
     char const *text) 
{
     CHECK_INIT;
     fprintf(output, "%%%% %s\n", text);
}


void abc_ps_use_device_coords(
     int yes_or_no)
{
     is_using_device_coords = yes_or_no;
}


int abc_ps_is_using_device_coords(
     void)
{
     return is_using_device_coords;
}


void abc_ps_draw_line(
     double x1,
     double y1,
     double x2,
     double y2) 
{
     CHECK_INIT;
     fprintf(output, "%g %g %g %g L\n", XPS(x1), YPS(y1), XPS(x2), YPS(y2));
}


void abc_ps_draw_vector(
     double x1,
     double y1,
     double x2,
     double y2) 
{
     CHECK_INIT;
     fprintf(output, "%g %g %g %g V\n", XPS(x1), YPS(y1), XPS(x2), YPS(y2));
}


void abc_ps_draw_vector_old(
     double x1,
     double y1,
     double x2,
     double y2) 
{
     double xvec = x2 - x1;
     double yvec = y2 - y1;
     double xnormal = - yvec;
     double ynormal = xvec;
     double x3 = x2 - 0.7 * xvec + 0.3 * xnormal;
     double y3 = y2 - 0.7 * yvec + 0.3 * ynormal;
     double x4 = x2 - 0.7 * xvec - 0.3 * xnormal;
     double y4 = y2 - 0.7 * yvec - 0.3 * ynormal;

     abc_ps_draw_line(x1, y1, x2, y2);
     abc_ps_draw_line(x2, y2, x3, y3);
     abc_ps_draw_line(x2, y2, x4, y4);
}


void abc_ps_init(
     FILE *out) 
{
     if ((output = out) == NULL)
          ABC_ERROR_RETURN("[abc_ps_init] is called with NULL-pointer!");

     fprintf(output, "%%!PS-Adobe-2.0 EPSF-2.0\n");
     fprintf(output, "%%%%Creator: mw-ps-library (lib_plotps).\n");
     fprintf(output, "%%%%BoundingBox: %g %g %g %g\n",
          x1_ps_space, y1_ps_space, x2_ps_space, y2_ps_space);
     fprintf(output, "/ellipsedict 8 dict def\n");
     fprintf(output, "ellipsedict /mat matrix put\n");
     fprintf(output, "/ellipse { %% stack: x y xradius yradius\n");
     fprintf(output, "   ellipsedict begin\n");
     fprintf(output, "   /yrad exch def\n");
     fprintf(output, "   /xrad exch def\n");
     fprintf(output, "   /y exch def\n");
     fprintf(output, "   /x exch def\n");
     fprintf(output, "   /savematrix mat currentmatrix def\n");
     fprintf(output, "   x y translate\n");
     fprintf(output, "   xrad yrad scale\n");
     fprintf(output, "   0 0 1 0 360 arc\n");
     fprintf(output, "   savematrix setmatrix\n");
     fprintf(output, "   end\n");
     fprintf(output, "} def\n");
     fprintf(output, "/L { %% stack: x1 y1 x2 y2\n");
     fprintf(output, "   newpath moveto lineto stroke\n");
     fprintf(output, "} def\n");
     fprintf(output, "/Bullet { %% stack: x y r1 r2\n");
     fprintf(output, "   newpath ellipse fill\n");
     fprintf(output, "} def\n");
     fprintf(output, "/V { %% stack: x1 y1 x2 y2\n");
     fprintf(output, "   /y2 exch def\n");
     fprintf(output, "   /x2 exch def\n");
     fprintf(output, "   /y1 exch def\n");
     fprintf(output, "   /x1 exch def\n");
     fprintf(output, "   /dx x2 x1 sub def\n");
     fprintf(output, "   /dy y2 y1 sub def\n");
     fprintf(output, "   /normalx dy -0.15 mul def\n");
     fprintf(output, "   /normaly dx 0.15 mul def\n");
     fprintf(output, "   /x0 x1 dx 0.7 mul add def\n");
     fprintf(output, "   /y0 y1 dy 0.7 mul add def\n");
     fprintf(output, "   /x3 x0 normalx add def\n");
     fprintf(output, "   /y3 y0 normaly add def\n");
     fprintf(output, "   /x4 x0 normalx -1 mul add def\n");
     fprintf(output, "   /y4 y0 normaly -1 mul add def\n");
     fprintf(output, "   x1 y1 x0 y0 L\n");
     fprintf(output, "   x3 y3 moveto\n");
     fprintf(output, "   x4 y4 lineto\n");
     fprintf(output, "   x2 y2 lineto\n");
     fprintf(output, "   closepath gsave\n");
     fprintf(output, "   1.0 setgray fill\n");
     fprintf(output, "   grestore stroke\n");
     fprintf(output, "} def\n");
     fprintf(output, "/puttext %% stack: angle factor text\n");
     fprintf(output, "{ /text exch def   %% the text\n");
     fprintf(output, "  /factor exch def %% left = 0, center = 0.5, right = 1\n"); 
     fprintf(output, "  /angle exch def  %% text rotation angle\n");
     fprintf(output, "  currentpoint\n");
     fprintf(output, "  /y exch def\n");
     fprintf(output, "  /x exch def\n");
     fprintf(output, "  text stringwidth\n");
     fprintf(output, "  /dy exch 0 exch sub def\n");
     fprintf(output, "  /dx exch 0 exch sub def\n");
     fprintf(output, "  /dy 0 def\n");
     fprintf(output, "  /dx factor dx mul def\n");
     fprintf(output, "  x y translate\n");
     fprintf(output, "  angle rotate\n");
     fprintf(output, "  dx dy moveto\n");
     fprintf(output, "  text show\n");
     fprintf(output, "  0 angle sub rotate\n");
     fprintf(output, "  0 x sub 0 y sub translate\n");
     fprintf(output, "} def\n");
     fprintf(output, "\n");
     fprintf(output, "/offsettext %% stack: angle factor text\n");
     fprintf(output, "{ /text exch def   %% the text\n");
     fprintf(output, "  /factor exch def %% left = 0, center = 0.5, right = 1\n");
     fprintf(output, "  /angle exch def  %% text rotation angle\n");
     fprintf(output, "  currentpoint\n");
     fprintf(output, "  /y exch def\n");
     fprintf(output, "  /x exch def\n");
     fprintf(output, "  text stringwidth\n");
     fprintf(output, "  /dy exch 0 exch sub def\n");
     fprintf(output, "  /dx exch 0 exch sub def\n");
     fprintf(output, "  /dy 0 def\n");
     fprintf(output, "  /dx factor dx mul def\n");
     fprintf(output, "  x y translate\n");
     fprintf(output, "  angle rotate\n");
     fprintf(output, "  dx dy moveto\n");
     fprintf(output, "  0 angle sub rotate\n");
     fprintf(output, "  0 x sub 0 y sub translate\n");
     fprintf(output, "} def\n");
     fprintf(output, "\n");

     abc_ps_init_scan_fonts(out);
     abc_ps_set_ps_space(70.0, 200.0, 540.0, 670.0);
     abc_ps_set_user_space(0.0, 0.0, 1.0, 1.0);
     abc_ps_set_viewport(0.0, 0.0, 1.0, 1.0);
     abc_ps_set_grayness(0.0);
     abc_ps_set_line_width(1.0);
     abc_ps_set_bullet_size(2.5);
     abc_ps_set_font_size(15.0);
     abc_ps_set_font("Times-Roman");
     abc_ps_set_page_number(1);
     abc_ps_use_device_coords(FALSE);
     ps_recompute_factors();
     ps_install_font();

     fprintf(output, "%%%% PAGE: %d\n", page_number);
}


void abc_ps_init_scan_fonts(
     FILE *out)
{
     fprintf(out, "/reencsmalldict 12 dict def\n");
     fprintf(out, "/ReEncodeSmall\n");
     fprintf(out, "{ reencsmalldict begin\n");
     fprintf(out, "  /newcodesandnames exch def\n");
     fprintf(out, "  /newfontname exch def\n");
     fprintf(out, "  /basefontname exch def\n");
     fprintf(out, "\n");
     fprintf(out, "  /basefontdict basefontname findfont def\n");
     fprintf(out, "  /newfont basefontdict maxlength dict def\n");
     fprintf(out, "\n");
     fprintf(out, "  basefontdict\n");
     fprintf(out, "  { exch dup /FID ne\n");
     fprintf(out, "    { dup /Encoding eq\n");
     fprintf(out, "      { exch dup length array copy\n");
     fprintf(out, "        newfont 3 1 roll put }\n");
     fprintf(out, "      { exch newfont 3 1 roll put }\n");
     fprintf(out, "      ifelse\n");
     fprintf(out, "    }\n");
     fprintf(out, "    { pop pop }\n");
     fprintf(out, "    ifelse\n");
     fprintf(out, "  } forall\n");
     fprintf(out, "\n");
     fprintf(out, "  newfont /FontName newfontname put\n");
     fprintf(out, "  newcodesandnames aload pop\n");
     fprintf(out, "  newcodesandnames length 2 idiv\n");
     fprintf(out, "  { newfont /Encoding get 3 1 roll put }\n");
     fprintf(out, "  repeat\n");
     fprintf(out, "\n");
     fprintf(out, "  newfontname newfont definefont pop\n");
     fprintf(out, "  end\n");
     fprintf(out, "} def\n");
     fprintf(out, "\n");
     fprintf(out, "/scandvec [\n");
     fprintf(out, "8#300 /Oacute\n");
     fprintf(out, "8#311 /Adieresis\n");
     fprintf(out, "8#321 /oacute\n");
     fprintf(out, "8#322 /Ograve\n");
     fprintf(out, "8#323 /Scaron\n");
     fprintf(out, "8#324 /ograve\n");
     fprintf(out, "8#325 /scaron\n");
     fprintf(out, "8#330 /Edieresis\n");
     fprintf(out, "8#331 /adieresis\n");
     fprintf(out, "8#332 /edieresis\n");
     fprintf(out, "8#333 /Odieresis\n");
     fprintf(out, "8#334 /odieresis\n");
     fprintf(out, "8#340 /Aacute\n");
     fprintf(out, "8#342 /Aring\n");
     fprintf(out, "8#344 /Zcaron\n");
     fprintf(out, "8#347 /Eacute\n");
     fprintf(out, "8#360 /aacute\n");
     fprintf(out, "8#362 /aring\n");
     fprintf(out, "8#364 /zcaron\n");
     fprintf(out, "8#367 /eacute\n");
     fprintf(out, "] def\n");
     fprintf(out, "\n");
     fprintf(out, "/Times-Roman /Times-Roman-Scan scandvec ReEncodeSmall\n");
     fprintf(out, "/Times-Roman-Scan findfont 22 scalefont setfont\n");
}


void abc_ps_begin_panel(
     double x,
     double y) 
{
     CHECK_INIT;
     fprintf(output, "newpath\n");
     fprintf(output, "%g %g moveto\n", XPS(x), YPS(y));
}


void abc_ps_draw_panel(
     double x,
     double y) 
{
     CHECK_INIT;
     fprintf(output, "%g %g lineto\n", XPS(x), YPS(y));
}


void abc_ps_end_panel(
     double gray,
     int show_boundary) 
{
     CHECK_INIT;
     fprintf(output, "closepath\n");

     if (show_boundary)
          fprintf(output, "gsave\n");

     fprintf(output, "%5.3f setgray fill\n", gray);

     if (show_boundary)
          fprintf(output, "grestore stroke\n");

     fprintf(output, "%g setgray\n", grayness);
}


void abc_ps_end_color_panel(
     double hue,
     double saturation,
     double brightness,
     int show_boundary)
{    
     CHECK_INIT;
     fprintf(output, "closepath\n");
     
     if (show_boundary)
          fprintf(output, "gsave\n");
     
     fprintf(output, "%5.3f %5.3f %5.3f sethsbcolor fill\n",
          (hue / 360), saturation, brightness);
     
     if (show_boundary)
          fprintf(output, "grestore stroke\n");

     fprintf(output, "%g setgray\n", grayness);
}


void abc_ps_draw_polygon(
     double *xcoord,
     double *ycoord,
     int steps,
     double gray,
     int show_bounary)
{
     int i;

     if (steps < 1) return;

     abc_ps_begin_panel(xcoord[0], ycoord[0]);

     for (i = 1; i < steps; i++)
          abc_ps_draw_panel(xcoord[i], ycoord[i]);

     abc_ps_end_panel(gray, show_bounary);
}


void abc_ps_draw_color_polygon(
     double *xcoord,
     double *ycoord,
     int steps,
     double hue,
     double saturation,
     double brightness,
     int show_boundary)
{
     int i;

     if (steps < 1) return;

     abc_ps_begin_panel(xcoord[0], ycoord[0]);

     for (i = 1; i < steps; i++)
          abc_ps_draw_panel(xcoord[i], ycoord[i]);

     abc_ps_end_color_panel(hue, saturation, brightness, show_boundary);
}


void abc_ps_draw_legend_by_hue(
     double hue1,
     double hue2,
     double value1,
     double value2,
     int steps)
{
     AbcPSState saved_state;

     abc_ps_get_state(&saved_state);
     abc_ps_set_line_width(1.0);
     abc_ps_set_font_size(12.0);
     abc_ps_set_user_space(0.0, 0.0, 1.0, 1.0);

     abc_ps_draw_basic_legend_by_hue(0.82, 0.2, 0.03, 0.35, 
          hue1, hue2, value1, value2, steps, " %g");

     abc_ps_set_state(&saved_state);
}


void abc_ps_draw_basic_legend_by_hue(
     double xpos,
     double ypos,
     double xlength,
     double ylength,
     double hue1,
     double hue2,
     double value1,
     double value2,
     int steps,
     const char *format)
{
     double x[4], y[4], dh, dv, dy, hue, value;
     char text[ABC_MAX_WORD];
     int i;

     if (steps < 1)
          ABC_ERROR_RETURN("Too few steps!");

     dy = ylength / steps;
     dh = (hue2 - hue1) / steps;
     dv = (value2 - value1) / steps;

     for (i = 0; i < steps; i++)
     {
          x[0] = xpos;
          y[0] = ypos + i * dy;

          x[1] = xpos + xlength;
          y[1] = ypos + i * dy;

          x[2] = xpos + xlength;
          y[2] = ypos + (i + 1) * dy;

          x[3] = xpos;
          y[3] = ypos + (i + 1) * dy;

          hue = hue1 + i * dh;
          abc_ps_draw_color_polygon(x, y, 4, hue, 1.0, 1.0, FALSE);

          if (steps > 20 and (i % 2) == 1) continue;

          value = value1 + i * dv;
          sprintf(text, format, value);
          abc_ps_put_text(x[1], y[1], text);
     }

     abc_ps_draw_line(xpos, ypos, xpos + xlength, ypos);
     abc_ps_draw_line(xpos + xlength, ypos, xpos + xlength, ypos + ylength);
     abc_ps_draw_line(xpos + xlength, ypos + ylength, xpos, ypos + ylength);
     abc_ps_draw_line(xpos, ypos + ylength, xpos, ypos);
}


FILE *abc_ps_get_output_stream(
     void) 
{
     return output;
}


void abc_ps_set_output_stream(
     FILE *out)
{
     output = out;
}


void abc_ps_new_page(
     void) 
{
     CHECK_INIT;
     fprintf(output, "showpage\n");
     fprintf(output, "%%%% PAGE: %d\n", page_number++);
}


void abc_ps_put_text(
     double x,
     double y,
     char const *text) 
{
     fprintf(output, "%g %g moveto\n", XPS(x), YPS(y));
     fprintf(output, "(");
     abc_ps_fix_and_print_text(output, text);
     fprintf(output, ") show\n");
}


void abc_ps_put_rotated_text(
     double x,
     double y,
     double angle,
     double factor,
     const char *text)
{
     fprintf(output, "%7.2f %7.2f moveto\n", XPS(x), YPS(y));
     fprintf(output, "%7.2f %7.2f", angle, factor);
     fprintf(output, "(");
     abc_ps_fix_and_print_text(output, text);
     fprintf(output, ") puttext\n");
}


void abc_ps_put_meta_text(
     double x,
     double y,
     double angle,
     double factor,
     const char *text)
{
     char comment[ABC_MAX_WORD];

     fprintf(output, "%7.2f %7.2f moveto\n", XPS(x), YPS(y));

     ps_strip_meta_text(text, comment);
     abc_ps_comment(comment);
     fprintf(output, "%7.2f %7.2f", angle, factor);
     fprintf(output, " (");
     abc_ps_fix_and_print_text(output, text);
     fprintf(output, ") offsettext\n");

     fprintf(output, "%7.2f rotate\n", angle);
     abc_ps_parse_meta_text(text);
     fprintf(output, "%7.2f rotate\n", -angle);
}


int abc_ps_parse_meta_text(
     const char *text)
{
     char saved_font[ABC_MAX_WORD];
     int length = strlen(text);
     int i;

     abc_ps_get_font(saved_font);

     for (i = 0; i < (int) strlen(text); i++)
     {
          if (text[i] == '{')
               i += abc_ps_parse_meta_text(&text[i+1]) + 1;
          else if ((text[i] == '\\') and (i < length - 1))
          {
               ps_fix_and_show_char(text[i+1]);
               i++;
          }
          else if (text[i] == '}')
          {
               abc_ps_set_font(saved_font);
               return i;
          }
          else if ((text[i] == '$') and (i < length - 1))
          {
               if (text[i+1] == '0')
               {
                    abc_ps_set_font("Times-Roman");
                    i++;
               }
               else if (text[i+1] == '1' or text[i+1] == '2')
               {
                    abc_ps_set_font("Symbol");
                    i++;
               }
               else
               {
                    ps_fix_and_show_char(text[i+1]);
                    i++;
               }
          }
          else if ((text[i] == '^') and (i < length - 1))
          {
               double saved_font_size = abc_ps_get_font_size();
               double dy = 0.3 * saved_font_size;
               double new_font_size = 0.8 * saved_font_size;

               fprintf(output, "0 %g rmoveto\n", dy); 
               abc_ps_set_font_size(new_font_size);

               if (text[i+1] == '{')
                    i += abc_ps_parse_meta_text(&text[i+2]) + 2;
               else
                    fprintf(stderr, "Expected { after ^!\n");

               fprintf(output, "0 %g rmoveto\n", -dy);
               abc_ps_set_font_size(saved_font_size);
          }
          else if ((text[i] == '_') and (i < length - 1))
          {
               double saved_font_size = abc_ps_get_font_size();
               double dy = 0.3 * saved_font_size;
               double new_font_size = 0.8 * saved_font_size;

               fprintf(output, "0 %g rmoveto\n", -dy);
               abc_ps_set_font_size(new_font_size);

               if (text[i+1] == '{')
                    i += abc_ps_parse_meta_text(&text[i+2]) + 2;
               else
                    fprintf(stderr, "Expected { after ^!\n");

               fprintf(output, "0 %g rmoveto\n", dy);
               abc_ps_set_font_size(saved_font_size);
          }
          else
               ps_fix_and_show_char(text[i]);
     }

     return strlen(text);
}


static void ps_fix_and_show_char(
     int ch)
{
     fprintf(output, "(");
     abc_ps_fix_and_print_char(output, ch);
     fprintf(output, ") show\n");
}


void abc_ps_fix_and_print_text(
     FILE *out,
     const char *text)
{
     int i;

     for (i = 0; text[i] != '\0'; i++)
          abc_ps_fix_and_print_char(out, text[i]);
}


void abc_ps_fix_and_print_char(
     FILE *out,
     char ch)
{
     int ic = (int) ch;

     char chr_ae = (char) (-26);
     char chr_oe = (char) (-8);
     char chr_aa = (char) (-27);
     char chr_AE = (char) (-58);
     char chr_OE = (char) (-40);
     char chr_AA = (char) (-59);

     /* Testing:
     ** printf("ae=%c, oe=%c, aa=%c\n", chr_ae, chr_oe, chr_aa);
     ** printf("AE=%c, OE=%c, AA=%c\n", chr_AE, chr_OE, chr_AA);
     */

     /* 
     ** Not all compilers like characters (signs) like '�', '�' and '�'.
     */

     /***
     if (ch == '\\' or ch == '(' or ch == ')')
          fprintf(out, "%c%c", '\\', ch);
     else if (ic == 198 || ch == '�') fprintf(out, "\\341");
     else if (ic == 216 || ch == '�') fprintf(out, "\\351");
     else if (ic == 197 || ch == '�') fprintf(out, "\\342");
     else if (ic == 230 || ch == '�') fprintf(out, "\\361");
     else if (ic == 248 || ch == '�') fprintf(out, "\\371");
     else if (ic == 229 || ch == '�') fprintf(out, "\\362");
     else fprintf(out, "%c", ch);
     ***/

     /* 
     ** PostScript codes: AE,OE,AA=\341\351\342; ae,oe,aa=\361\371\362 
     */

     if (ch == '\\' or ch == '(' or ch == ')')
          fprintf(out, "%c%c", '\\', ch);
     else if (ic == 198 || ch == chr_AE) fprintf(out, "\\341");
     else if (ic == 216 || ch == chr_OE) fprintf(out, "\\351");
     else if (ic == 197 || ch == chr_AA) fprintf(out, "\\342");
     else if (ic == 230 || ch == chr_ae) fprintf(out, "\\361");
     else if (ic == 248 || ch == chr_oe) fprintf(out, "\\371");
     else if (ic == 229 || ch == chr_aa) fprintf(out, "\\362");
     else fprintf(out, "%c", ch);
}


void abc_ps_put_bullet(
     double x,
     double y) 
{
     fprintf(output, "%g %g %g %g Bullet\n",
          XPS(x), YPS(y), bullet_size, bullet_size);
}


void abc_ps_set_bullet_size(
     double size) 
{
     bullet_size = size;
}


double abc_ps_get_bullet_size(
    void) 
{
    return bullet_size;
}


void abc_ps_set_font(
     char const *name) 
{
     strcpy(font_name, name);
     ps_install_font();
}


void abc_ps_get_font(
     char *name) 
{
     strcpy(name, font_name);
}


void abc_ps_set_font_size(
     double size) 
{
     font_size = size;
     ps_install_font();
}


double abc_ps_get_font_size(
     void) 
{
     return font_size;
}


void abc_ps_set_grayness(
     double gray)
{
     grayness = gray;
}


double abc_ps_get_grayness(
     void)
{
     return grayness;
}


void abc_ps_set_line_stype(
     int style) 
{
     ABC_UNUSED_PARAMETER(style);
}


int abc_ps_get_line_stype(
     void)
{
     return 0;
}


void abc_ps_set_line_width(
     double width) 
{
     CHECK_INIT;
     line_width = width;
     fprintf(output, "%g setlinewidth\n", line_width);
}


double abc_ps_get_line_width(
     void) 
{
     return line_width;
}


void abc_ps_set_page_number(
     int page)
{
     page_number = page;
}


int abc_ps_get_page_number(
     void)
{
     return page_number;
}


void abc_ps_set_ps_space(
     double x1, /* units is pt */
     double y1, /* units is pt */
     double x2, /* units is pt */
     double y2) /* units is pt */
{
     if (x1 > x2) ABC_ERROR_RETURN("[abc_ps_set_ps_space] x1 > x2!");
     if (y1 > y2) ABC_ERROR_RETURN("[abc_ps_set_ps_space] y1 > y2!");

     x1_ps_space = x1;
     y1_ps_space = y1;
     x2_ps_space = x2;
     y2_ps_space = y2;

     ps_recompute_factors();
}


void abc_ps_get_ps_space(
     double *x1,
     double *y1,
     double *x2,
     double *y2) 
{
     *x1 = x1_ps_space;
     *y1 = y1_ps_space;
     *x2 = x2_ps_space;
     *y2 = y2_ps_space;
}


void abc_ps_set_user_space(
     double x1,
     double y1,
     double x2,
     double y2) 
{
     if (x1 > x2) ABC_ERROR_RETURN("[abc_ps_set_user_space] x1 > x2!");
     if (y1 > y2) ABC_ERROR_RETURN("[abc_ps_set_user_space] y1 > y2!");

     x1_user_space = x1;
     y1_user_space = y1;
     x2_user_space = x2;
     y2_user_space = y2;

     ps_recompute_factors();
}


void abc_ps_get_user_space(
     double *x1,
     double *y1,
     double *x2,
     double *y2) 
{
     *x1 = x1_user_space;
     *y1 = y1_user_space;
     *x2 = x2_user_space;
     *y2 = y2_user_space;
}


void abc_ps_set_viewport(
     double x1,
     double y1,
     double x2,
     double y2)
{
     if (x1 > x2) 
          ABC_ERROR_RETURN("[abc_ps_set_viewport] x1 > x2!");

     if (y1 > y2) 
          ABC_ERROR_RETURN("[abc_ps_set_viewport] y1 > y2!");

     if (not ps_is_unit_coord(x1)) 
          ABC_ERROR_RETURN("[abc_ps_set_viewport] x1 isn't unit coordiate");

     if (not ps_is_unit_coord(y1)) 
          ABC_ERROR_RETURN("[abc_ps_set_viewport] y1 isn't unit coordiate");

     if (not ps_is_unit_coord(x2)) 
          ABC_ERROR_RETURN("[abc_ps_set_viewport] x2 isn't unit coordiate");

     if (not ps_is_unit_coord(y2)) 
          ABC_ERROR_RETURN("[abc_ps_set_viewport] y2 isn't unit coordiate");

     x1_viewport_unit = x1;
     y1_viewport_unit = y1;

     x2_viewport_unit = x2;
     y2_viewport_unit = y2;
     
     ps_recompute_factors();
}


void abc_ps_get_viewport(
     double *x1,
     double *y1,
     double *x2,
     double *y2)
{
     *x1 = x1_viewport_unit;
     *y1 = y1_viewport_unit;
     *x2 = x2_viewport_unit;
     *y2 = y2_viewport_unit;
}


void abc_ps_set_state(
     AbcPSState *state) 
{
     abc_ps_set_output_stream(state->out);
     abc_ps_set_font(state->font_name);
     abc_ps_set_font_size(state->font_size);
     abc_ps_set_line_width(state->line_width);
     abc_ps_set_bullet_size(state->bullet_size);
     abc_ps_set_grayness(state->grayness);

     abc_ps_set_ps_space(state->x1_ps_space, state->y1_ps_space,
          state->x2_ps_space, state->y2_ps_space);

     abc_ps_set_user_space(state->x1_user_space, state->y1_user_space,
          state->x2_user_space, state->y2_user_space);

     abc_ps_set_viewport(state->x1_viewport_unit, state->y1_viewport_unit,
          state->x2_viewport_unit, state->y2_viewport_unit);

     abc_ps_set_page_number(state->page_number);
     abc_ps_use_device_coords(state->is_using_device_coords);
}


void abc_ps_get_state(
     AbcPSState *state) 
{
     abc_ps_get_font(state->font_name);
     state->out = abc_ps_get_output_stream();
     state->font_size = abc_ps_get_font_size();
     state->line_width = abc_ps_get_line_width();
     state->bullet_size = abc_ps_get_bullet_size();
     state->page_number = abc_ps_get_page_number();
     state->is_using_device_coords = abc_ps_is_using_device_coords();
     state->grayness = abc_ps_get_grayness();

     abc_ps_get_ps_space(&(state->x1_ps_space), &(state->y1_ps_space),
          &(state->x2_ps_space), &(state->y2_ps_space));

     abc_ps_get_user_space(&(state->x1_user_space), &(state->y1_user_space),
          &(state->x2_user_space), &(state->y2_user_space));

     abc_ps_get_viewport(&(state->x1_viewport_unit), &(state->y1_viewport_unit),
          &(state->x2_viewport_unit), &(state->y2_viewport_unit));
}


int abc_ps_is_in_use(
     void) 
{
     return (output != NULL);
}

/*
**   ======================
**   Pixel buffer functions
**   ======================
*/

AbcPSPixelBuffer *abc_ps_create_pixel_buffer(
     int nx,
     int ny,
     int nbits,
     int colors,
     const char *name)
{
     AbcPSPixelBuffer *pixbuf;
     int ncomps = (colors) ? 3 : 1;
     int size = nx * ny * nbits * ncomps / 4;
     int n;

     if (nx < 0 or 2048 < nx)
          ABC_ERROR_EXIT("[ps_create_pixel_buffer] Illegal size: nx < 0 or 2048 < nx");

     if (ny < 0 or 2048 < ny)
          ABC_ERROR_EXIT("[ps_create_pixel_buffer] Illegal size: ny < 0 or 2048 < ny");

     if (nbits != 4 and nbits != 8)
          ABC_ERROR_EXIT("[ps_create_pixel_buffer] Illegal bit-size! (should be 4 or 8)");

     ABC_NEW_OBJECT(pixbuf, AbcPSPixelBuffer);
     ABC_NEW_ARRAY(pixbuf->buffer, char, size);
     ABC_NEW_ARRAY(pixbuf->bufname, char, (strlen(name) + 1));
     strcpy(pixbuf->bufname, name);

     pixbuf->nx = nx;
     pixbuf->ny = ny;
     pixbuf->nbits = nbits;
     pixbuf->ncomps = ncomps;
     pixbuf->bufsize = size;

     for (n = 0; n < size; n++)
          pixbuf->buffer[n] = '0';  /* x=undefined pixel value */

     return pixbuf;
}
     

void abc_ps_delete_pixel_buffer(
     AbcPSPixelBuffer **pixbuf2)
{
     AbcPSPixelBuffer *pixbuf1 = *pixbuf2;

     if (pixbuf1 == NULL) return;

     ABC_FREE_ARRAY(pixbuf1->buffer);
     ABC_FREE_ARRAY(pixbuf1->bufname);
     ABC_FREE(pixbuf1);

     pixbuf1 = NULL;
}


void abc_ps_clear_pixel_buffer(
     AbcPSPixelBuffer *pixbuf)
{
     int i, j;
     int has_colors = (pixbuf->ncomps == 3);

     if (has_colors)
     {
          for (j = 0; j < pixbuf->ny; j++)
               for (i = 0; i < pixbuf->nx; i++)
                    abc_ps_set_pixel_rgb(pixbuf, i, j, 1.0, 1.0, 1.0);
     }
     else
     {
          for (j = 0; j < pixbuf->ny; j++)
               for (i = 0; i < pixbuf->nx; i++)
                    abc_ps_set_pixel_hue(pixbuf, i, j, 0.0);
     }
}


void abc_ps_draw_pixel_image(
     AbcPSPixelBuffer *pixbuf)
{
     fprintf(output, "gsave\n");
     ps_translate_and_scale();
     abc_ps_write_pixel_buffer(pixbuf);
     fprintf(output, "grestore\n");

}


void abc_ps_write_pixel_buffer(
     AbcPSPixelBuffer *pixbuf)
{
     int n;
     const char *buffer = pixbuf->buffer;
     FILE *out = abc_ps_get_output_stream();

     fprintf(out, "/picstr %d string def\n", pixbuf->nx);
     fprintf(out, "/DeviceRGB setcolorspace\n");
     fprintf(out, "%d %d %d [%d 0 0 %d 0 0]\n",
          pixbuf->nx, pixbuf->ny, pixbuf->nbits, pixbuf->nx, pixbuf->ny);
     fprintf(out, "{currentfile picstr readhexstring pop}\n");
     fprintf(out, "false 3 colorimage\n");

     for (n = 0; n < pixbuf->bufsize; n++)
     {
          if (n % 70 == 0) fprintf(out, "\n");
          fprintf(out,"%c", buffer[n]);
     }

     fprintf(out, "\n");
}


void abc_ps_store_pixel_buffer(
     AbcPSPixelBuffer *pixbuf)
/*
**   Store pixel buffer in device for later use.
*/
{
     int n;
     int nlast = pixbuf->bufsize - 1;
     const char *buffer = pixbuf->buffer;

     fprintf(output, "/%s", pixbuf->bufname);

     for (n = 0; n < pixbuf->bufsize; n++)
     {
          if (n % 70 == 0) fprintf(output, "\n");
          if (n == 0) fprintf(output, "<");
          fprintf(output,"%c", buffer[n]);
          if (n == nlast) fprintf(output, ">");
     }

     fprintf(output, " def\n");
}


void abc_ps_draw_stored_pixel_buffer(
     AbcPSPixelBuffer *pixbuf)
/*
**   Draw an already stored pixel buffer.
**   Pixel buffers are stored by their names
**   using the function "abc_ps_store_pixel_buffer".
*/
{
     fprintf(output, "gsave\n");
     ps_translate_and_scale();

     if (pixbuf->ncomps == 1)
     {
          fprintf(output, "%d %d %d [%d 0 0 %d 0 0] {%s} image\n", 
               pixbuf->nx, pixbuf->ny, pixbuf->nbits, pixbuf->nx, pixbuf->ny, pixbuf->bufname);
     }
     else if (pixbuf->ncomps == 3)
     {
          fprintf(output, "/DeviceRGB setcolorspace\n");
          fprintf(output, "%d %d %d [%d 0 0 %d 0 0] {%s} false 3 colorimage\n", 
               pixbuf->nx, pixbuf->ny, pixbuf->nbits, pixbuf->nx, pixbuf->ny, pixbuf->bufname);
     }
     else
     {
          fprintf(stderr, "[ps_pixel_buffer_image] Illegal ncomps! (ncomps=%d)\n", pixbuf->ncomps);
     }

     fprintf(output, "grestore\n");
}


void abc_ps_fill_pixel_buffer_hue_values(
     AbcPSPixelBuffer *pixbuf,
     double *hue_values)
{
     int i, j, n;
     int nx = pixbuf->nx;
     int ny = pixbuf->ny;

     for (i = 0; i < nx; i++)
          for (j = 0; j < ny; j++)
          {
               n = j * nx + i;
               
               if (hue_values[n] > 360.0)
                    abc_ps_set_pixel_hls(pixbuf, i, j, 0.0, 1.0, 1.0);
               else  if (hue_values[n] >= 0.0)    
                    abc_ps_set_pixel_hue(pixbuf, i, j, hue_values[n]);
               else
                    abc_ps_set_pixel_hls(pixbuf, i, j, 0.0, 1.0, 0.0);
          }
}


void abc_ps_set_pixel_hue(
     AbcPSPixelBuffer *pixbuf, 
     int i, 
     int j, 
     double hue)
{
     int index = abc_ps_pixel_buffer_index(pixbuf, i, j);
     char *buffer = &(pixbuf->buffer[index]);
     int use_colors = (pixbuf->ncomps == 3);

     if (use_colors)
     {
          double lightness = 0.5;
          double saturation = 1.0;

          abc_ps_set_pixel_hls(pixbuf, i, j, hue, lightness, saturation);
     }
     else
     {
          double unit_value = hue / 360.0;
  
          fill_in_basic_char_codes(buffer, pixbuf->nbits, unit_value);
     }
}


void abc_ps_set_pixel_hls(
     AbcPSPixelBuffer *pixbuf,
     int i,
     int j,
     double hue,
     double lightness,
     double saturation)
{
     double red, green, blue;

     abc_ps_convert_hls_to_rgb(hue, lightness, saturation, &red, &green, &blue);
     abc_ps_set_pixel_rgb(pixbuf, i, j, red, green, blue);
}


void abc_ps_set_pixel_rgb(
     AbcPSPixelBuffer *pixbuf,
     int i,
     int j,
     double red,
     double green,
     double blue)
{
     int index = abc_ps_pixel_buffer_index(pixbuf, i, j);
     char *buffer = &(pixbuf->buffer[index]);
     int has_colors = (pixbuf->ncomps == 3);
     int bits = pixbuf->nbits;
     int n = 0;

     if (not has_colors)
          ABC_ERROR_RETURN("[abc_ps_set_pixel_rgb] Pixel buffer is not for colors!");

     n += fill_in_basic_char_codes(&buffer[n], bits, red);
     n += fill_in_basic_char_codes(&buffer[n], bits, green);
     n += fill_in_basic_char_codes(&buffer[n], bits, blue);
}


int abc_ps_pixel_buffer_index(
     AbcPSPixelBuffer *pixbuf,
     int i,
     int j)
{
     int index = (j * pixbuf->nx + i) * pixbuf->ncomps * pixbuf->nbits / 4;

     if (i < 0)
     {
          fprintf(stderr, "[abc_ps_pixel_buffer_index] Index is less than zero! (i=%d, j=%d)\n", i, j);
          index = 0;
     }
     else if (i >= pixbuf->bufsize)
     {
          fprintf(stderr, "[abc_ps_pixel_buffer_index] Index is too large! (i=%d, j=%d)\n", i, j);
          index = pixbuf->bufsize - 1;
     }

     return index;
}


void abc_ps_convert_hls_to_rgb(
     double hue,
     double lightness,
     double sat,
     double *red,
     double *green,
     double *blue)
{
     double v1, v2;

     if (sat < 0.001)
     {
          *red = *green = *blue = lightness;
          return;
     }

     if (lightness < 0.5)
     {
          v1 = lightness - lightness * sat;
          v2 = lightness + lightness * sat;
     }
     else
     {
          v1 = lightness - (1.0 - lightness * sat);
          v2 = lightness + (1.0 - lightness * sat);
     }

     *red = hue_comparison(v1, v2, hue + 120);
     *green = hue_comparison(v1, v2, hue);
     *blue = hue_comparison(v1, v2, hue - 120.0);
}

/*
**   =================
**   Private functions
**   =================
*/

static double XPS(
     double xx)
{
     double xps;
     if (is_using_device_coords) return xx;
     xps = xfactor * (xx - x1_user_space) + xorigo;
     return xps;
}


static double YPS(
     double yy)
{
     double yps;
     if (is_using_device_coords) return yy;
     yps = yfactor * (yy - y1_user_space) + yorigo;
     return yps;
}


static void ps_install_font(
     void) 
{
     CHECK_INIT;
     fprintf(output, "/%s findfont\n", font_name);
     fprintf(output, "%g scalefont\n", font_size);
     fprintf(output, "setfont\n");
}


static void ps_recompute_factors(
     void) 
{
     double dx_ps = x2_ps_space - x1_ps_space;
     double dy_ps = y2_ps_space - y1_ps_space;
     double dx_user = x2_user_space - x1_user_space;
     double dy_user = y2_user_space - y1_user_space;
     double dx_viewport_unit = (x2_viewport_unit - x1_viewport_unit);
     double dy_viewport_unit = (y2_viewport_unit - y1_viewport_unit);

     xfactor = dx_viewport_unit * dx_ps / dx_user;
     yfactor = dy_viewport_unit * dy_ps / dy_user;

     xorigo = x1_viewport_unit * dx_ps + x1_ps_space;
     yorigo = y1_viewport_unit * dy_ps + y1_ps_space;
}


static void ps_translate_and_scale(
     void)
{
     int x1 = (int) XPS(x1_user_space);
     int x2 = (int) XPS(x2_user_space);

     int y1 = (int) YPS(y1_user_space);
     int y2 = (int) YPS(y2_user_space);

     fprintf(output, "%d %d translate\n", x1, y1);
     fprintf(output, "%d %d scale\n", x2 - x1, y2 - y1);
}


static int ps_is_unit_coord(
     double x)
{
     if (x < 0.0) ABC_RETURN_FALSE("[ps_is_unit_coord] x < 0");
     if (x > 1.0) ABC_RETURN_FALSE("[ps_is_unit_coord] x > 1");
     return TRUE;
}


static int fill_in_basic_char_codes(
     char *buffer,
     int bits,
     double unit_value)
{
     int pos = -1;

     switch (bits)
     {
          case 4:
               pos = fill_in_char_codes4(buffer, unit_value);
               break;

          case 8:
               pos = fill_in_char_codes8(buffer, unit_value);
               break;

          default:
               fprintf(stderr, "Only 4 or 8 bits!\n");
               exit(1);
     }

     return pos;
}


static int fill_in_char_codes4(
     char *buffer,
     double unit_value)
{
     int int_code =  (int) (15.0 * unit_value);

     if (int_code < 0) int_code = 0;
     if (int_code > 15) int_code = 15;

     buffer[0] = char_code_map[int_code];

     return 1;
}


static int fill_in_char_codes8(
     char *buffer,
     double unit_value)
{
     int int_code_low, int_code_high;
     int int_code =  (int) (255.0 * unit_value);

     if (int_code < 0) int_code = 0;
     if (int_code > 255) int_code = 255;

     int_code_low = (int_code & 15);
     int_code_high = ((int_code / 16) & 15);

     buffer[1] = char_code_map[int_code_low];
     buffer[0] = char_code_map[int_code_high];

     return 2;
}


static double hue_comparison(
     double v1,
     double v2,
     double hue)
{
     while (hue > 360.0)
          hue -= 360.0;

     while (hue < 0.0)
          hue += 360.0;
     
     if (hue < 60.0)
          return v1 + (v2 - v1) * hue / 60.0;
     else if (hue < 180.0)
          return v2;
     else if (hue < 240.0)
          return v1 + (v2 - v1) * (240.0 - hue) / 60.0;
     else
          return v1;
}


static void ps_strip_meta_text(
     const char *text1,
     char *text2)
{
     int i;
     int k = 0;

     for (i = 0; i < (int) strlen(text1); i++)
          if ((text1[i] == '\\') or (text1[i] == '$'))
          {
               if (i < (int) strlen(text1) - 1)
               {
                    text2[k] = text1[i+1];
                    k++;
                    i++;
               }
          }
          else if (text1[i] != '_' and text1[i] != '^' and 
                   text1[i] != '{' and text1[i] != '}')
          {
               text2[k] = text1[i];
               k++;
          }

     text2[k] = '\0';
}


