/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1999 by M. Wangen.
**
**   Info: 2-D linear tables
**   Date: Version 1.0, February 1995
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_TABLE2D_H_
#define _LIB_TABLE2D_H_

typedef struct AbcTable2D
{
     char *text;              /* The table heading. */
     char *begin_key;         /* Begin key word. */
     char *end_key;           /* Begin key word. */
     int nx;                  /* Number of cols. */
     int ny;                  /* Number of rows. */
     double *xvec;            /* Column data. */
     double *yvec;            /* Row data. */
     double **data;           /* The data matrix. */
     double xmin;             /* Min of access column data. */
     double ymin;             /* Min of access row data. */
     double xmax;             /* Max of access column data. */
     double ymax;             /* Max of access row data. */
     double min;              /* Table max. */
     double max;              /* Table min. */
     double dx;               /* Step length if equally spaced. */
     double dy;               /* Step length if equally spaced. */
     int is_equally_x_spaced; /* True if equally spaced xvec. */
     int is_equally_y_spaced; /* True if equally spaced yvec. */
} AbcTable2D;

int abc_test_table2d(int argc, char **argv);
int abc_read_2d_table(AbcInput *in, AbcTable2D **table, char const *block_name);
AbcTable2D *abc_create_2d_table(char const *name, int nx, int ny, double *xvec, double *yvec, double **data);
AbcTable2D *abc_create_2d_table_by_file(AbcInput *in, char const *begin_key_word, char const *end_key_word);
AbcTable2D *abc_create_2d_table_from_file(AbcInput *in);
void abc_delete_2d_table(AbcTable2D **table);
double abc_value_2d_table(AbcTable2D *table, double x, double y);
void abc_print_2d_table(FILE *out, AbcTable2D *table, char const *margin1, char const *margin2);

#endif

