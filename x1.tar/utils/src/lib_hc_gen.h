/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2012 by M. Wangen.
**
**   Info: Function for computing HC generation
**   Date: Version 1.1, October 2012
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_HC_GEN_H_
#define _LIB_HC_GEN_H_

#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_utils.h>
#include <lib_input.h>
#include <lib_math.h>

#define MAX_HC_TEMP_HIST   4096
#define MAX_HC_GROUPS        32
#define MAX_HC_KINETICS    1024
#define MAX_HC_WORD         256
#define MAX_HC_LIB         4096

#ifndef GAS_CONST
#define GAS_CONST 8.3317      /* The gas constant, [J/mol K] */
#endif

#ifndef TEMP_ZERO
#define TEMP_ZERO 273.15
#endif

#ifndef SEC_IN_YEARS
#define SEC_IN_YEARS 31536000
#endif

#ifndef SEC_IN_MILL_YEARS
#define SEC_IN_MILL_YEARS 3.1536e+13
#endif

typedef struct _AbcKerogenState_ AbcKerogenState;
typedef struct _AbcKerogenModel_ AbcKerogenModel;

typedef struct AbcKerogenKinetics {
     int size;
     double *w;               /* Distribution, adds up to 1, [-] */
     double *A;               /* Arrhenius prefactor, [1/s] */
     double *E;               /* Activation energy, [kJ/mole] */
} AbcKerogenKinetics;

typedef struct AbcKerogenProps {
     double TOC;              /* Total Organic Carbon, [mg HC / g Sed] */
     double S1;               /* Initial oil content, [mg HC / g Sed] */
     double S2;               /* Reactive kerogen content, [mg HC / g Sed] */
     double W;                /* Carbon fraction of HC, [-] */

     /* For P-C model. */
     int is_PC;               /* True if P-C input */
     double G;                /* Gas/oil ratio of reactive kerogen, [-] */
     double F;                /* Gas/coke ratio of oil decay, [-] */
     double limGas;           /* Expulsion limit gas, [g C gas / g C kerogen] */
     double limOil;           /* Expulsion limit oil, [g C oil / g C kerogen] */
} AbcKerogenProps;

typedef struct AbcKerogenHcGroups {
     int size;
     int is_stable[MAX_HC_GROUPS];
     int is_mobile[MAX_HC_GROUPS];
     const char *name[MAX_HC_GROUPS];
     double expulsion_lim[MAX_HC_GROUPS]; /* Expulsion limit [g C HC / g C kerogen] */
} AbcKerogenHcGroups;

struct _AbcKerogenModel_ {
     char name[MAX_HC_WORD];     /* Model name. */
     AbcKerogenProps prop;       /* Specification of organic matter. */
     AbcKerogenKinetics ker;     /* Kinetics kerogen. */
     AbcKerogenKinetics hc;      /* Kinetics hydrocarbon. */
     AbcKerogenKinetics ko;      /* PC: Kinetics oil generative kerogen. */
     AbcKerogenKinetics kg;      /* PC: Kinetics gas generative kerogen. */
     AbcKerogenHcGroups group;   /* HC-groups. */
     int is_needed;              /* Need kerogen def in library. */
     int n_kerogen_steps;        /* Number of activation steps. */
     int n_hc_groups;            /* Number of HC groups. */
     int n_stable_hc_groups;     /* Number of stable HC groups. */
     int n_unstable_hc_groups;   /* Number of unstable HC groups. */
     double **A;                 /* Kerogen stoichiometry. */
     double **B;                 /* HC stoichiometry. */

     void (*init_state)(AbcKerogenState *state);
     int  (*do_one_time_step)(AbcKerogenState *state, double T1, double T2, double dt);
     void (*print_model)(AbcKerogenModel *model, FILE *out);
     void (*print_model_tex)(AbcKerogenModel *model, FILE *out);
     void (*print_state)(AbcKerogenState *state, FILE *out);
     void (*expell_hc)(AbcKerogenState *state);
};

struct _AbcKerogenState_ {
     int xSize;                  /* The number of kerogen activation steps. */
     int ySize;                  /* The number of hc groups. */
     int vrSize;                 /* The Number of vitrinite reaction steps. */
     double *x;                  /* Kerogen fractions. */
     double *y;                  /* Hydrocarbon groups. */
     double *ye;                 /* Hydrocarbon groups. */
     double *yt;                 /* Total expelled hydrocarbons. */
     double *xvr;                /* Vitrinite reaction steps. */
     double total_mass;          /* Total mass of cell. */
     double init_inert_mass;     /* Initial mass of inert kerogen. */
     double init_reactive_mass;  /* Initial mass of reactive kerogen. */
     double transf_ratio;        /* Kerogen transformation ratio. */
     double tr_vr;               /* Vitrinite reflectance trans. ratio. */
     double vr;                  /* Vitrinite reflectance. */
     AbcKerogenModel *model;     /* HC-generation model. */
};

typedef struct AbcKerogenLib {
     int size;                   /* Number of kerogen models in library. */
     AbcKerogenModel model[MAX_HC_LIB]; /* Array of models. */
} AbcKerogenLib;

typedef struct AbcKerogenTempHist {
     int size;                       /* Number of time/temp-points in history. */
     double time[MAX_HC_TEMP_HIST];  /* Array of time-points, [Ma]. */
     double temp[MAX_HC_TEMP_HIST];  /* Array of temp-points, [C]. */
     char kerogen_name[MAX_HC_WORD]; /* One specific kerogen. */
     char library_name[MAX_HC_WORD]; /* A library for the chosen kerogen. */
     AbcTimeUnit time_unit;          /* The time unit. */
} AbcKerogenTempHist;

/* These codes controll the function "cra_write_state". */

#define ABC_KEROGEN_WRITE_HEADING             1
#define ABC_KEROGEN_WRITE_KEROGEN             2
#define ABC_KEROGEN_WRITE_HC                  4
#define ABC_KEROGEN_WRITE_EXPELLED_HC         8
#define ABC_KEROGEN_WRITE_TOTAL_EXPELLED_HC  16

/* These macros are args to function "cra_crack_state". */

#define ABC_DO_EXPEL      TRUE
#define ABC_DO_NOT_EXPEL  FALSE


/* Prototypes for: lib_hc_gen.c */

int abc_test_kerogen_lib(int argc, char **argv);
void abc_delete_kerogen_lib(AbcKerogenLib *lib);
void abc_init_kerogen_lib(AbcKerogenLib *lib);
int abc_read_kerogen_library(AbcKerogenLib *lib, char const *filename);
int abc_read_kerogen_lib(AbcInput *in, AbcKerogenLib *lib);
void abc_write_kerogen_lib_report(AbcKerogenLib *lib, int use_default, const char *filename);
void abc_print_kerogen_lib(AbcKerogenLib *lib, int use_default, FILE *out);
void abc_print_needed_models_in_lib(AbcKerogenLib *lib, FILE *out);
void abc_write_kerogen_lib_report_TeX(AbcKerogenLib *lib, 
     int use_default, const char *filename, 
     const char *title, const char *author, const char *date);
void abc_print_kerogen_lib_TeX(AbcKerogenLib *lib, int use_default, FILE *out);
int abc_is_consistent_kerogen_lib(AbcKerogenLib *lib);
int abc_get_max_hc_groups_in_kerogen_lib(AbcKerogenLib *lib);
const char *abc_get_hc_group_name_in_kerogen_lib(AbcKerogenLib *lib, int no);
AbcKerogenModel *abc_get_kerogen_model_by_name(AbcKerogenLib *lib, char const *name);
AbcKerogenModel *abc_get_kerogen_model_by_number(AbcKerogenLib *lib, int no);
int abc_read_kerogen_model(AbcInput *in, AbcKerogenModel *model);
void abc_init_kerogen_model(AbcKerogenModel *model);
void abc_delete_kerogen_model(AbcKerogenModel *model);
void abc_mark_kerogen_model_as_needed(AbcKerogenModel *model);
int abc_is_needed_kerogen_model(AbcKerogenModel *model);
void abc_print_kerogen_model(AbcKerogenModel *model, FILE *out);
void abc_print_kerogen_model_default(AbcKerogenModel *model, FILE *out);
void abc_print_kerogen_model_TeX(AbcKerogenModel *model, FILE *out);
void abc_print_kerogen_model_default_TeX(AbcKerogenModel *model, FILE *out);
void abc_get_mobile_hc_groups(AbcKerogenModel *model, int *is_mobile, int *size);
int abc_get_numb_of_hc_groups(AbcKerogenModel *model);
const char *abc_get_name_of_hc_group(AbcKerogenModel *model, int no);
int abc_read_kerogen_properties(AbcInput *in, AbcKerogenProps *prop, int is_PC);
void abc_print_kerogen_props(AbcKerogenProps *prop, FILE *out);
void abc_print_kerogen_props_TeX(AbcKerogenProps *prop, FILE *out);
void abc_init_kerogen_hc_groups(AbcKerogenHcGroups *groups);
int abc_read_kerogen_hc_groups(AbcInput *in, AbcKerogenHcGroups *groups);
void abc_print_kerogen_hc_groups(AbcKerogenHcGroups *groups, FILE *out);
void abc_print_kerogen_hc_groups_TeX(AbcKerogenHcGroups *groups, FILE *out);
int abc_get_number_of_stable_groups(AbcKerogenHcGroups *groups);
int abc_get_number_of_mobile_groups(AbcKerogenHcGroups *groups);
void abc_init_kerogen_kinetics(AbcKerogenKinetics *kin);
int abc_read_kerogen_kinetics(AbcInput *in, AbcKerogenKinetics *kin, char const *keyword);
void abc_delete_kerogen_kinetics(AbcKerogenKinetics *kin);
void abc_print_kerogen_kinetics(AbcKerogenKinetics *kin, char const *keyword, FILE *out);
void abc_print_kerogen_kin_and_stoich(AbcKerogenModel *model, int is_hc, FILE *out);
void abc_print_kerogen_kin_and_stoich_TeX(AbcKerogenModel *model, int is_hc, FILE *out);
int abc_read_kerogen_kin_and_stoich(AbcInput *in, AbcKerogenModel *model, char const *keyword);
void abc_print_kerogen_kinetics_TeX(AbcKerogenKinetics *kin, char const *name, FILE *out);
AbcKerogenState *abc_new_kerogen_state(AbcKerogenModel *model, double total_mass);
AbcKerogenState *abc_new_empty_kerogen_state(AbcKerogenModel *model);
void abc_delete_kerogen_state(AbcKerogenState **state1);
void abc_init_kerogen_state_with_mass(AbcKerogenState *state, double total_mass);
void abc_reset_kerogen_state(AbcKerogenState *state);
void abc_init_kerogen_state_default(AbcKerogenState *state);
int abc_kerogen_state_is_source_rock(AbcKerogenState *state);
int abc_kerogen_state_is_inert(AbcKerogenState *state);
int abc_kerogen_state_is_zero(AbcKerogenState *state);
int abc_check_kerogen_state(AbcKerogenState *state);
void abc_crack_kerogen_state(AbcKerogenState *state, double temp1, double temp2, double dt_input, int do_expulsion);
void abc_do_one_time_step_cracking(AbcKerogenState *state, double temp1, double temp2, double dt);
void abc_do_one_time_step_easy_ro(AbcKerogenState *state, double temp1, double temp2, double dt);
void abc_expell_hc(AbcKerogenState *state);
void abc_expell_hc_default(AbcKerogenState *state);
void abc_set_expelled_mass_to_zero(AbcKerogenState *state);
void abc_write_kerogen_state(AbcKerogenState *state, int code, double time, double temp, FILE *out);
double abc_get_kerogen_transf_ratio(AbcKerogenState *state);
double abc_get_total_generated_hc_mass(AbcKerogenState *state);
double abc_get_total_active_mass(AbcKerogenState *state);
double abc_get_init_reactive_kerogen_mass(AbcKerogenState *state);
double abc_get_current_reactive_kerogen_mass(AbcKerogenState *state);
void abc_move_expelled(AbcKerogenState *state1, AbcKerogenState *state2);
void abc_move_expelled_fraction(double fraction, AbcKerogenState *state1, AbcKerogenState *state2);
double abc_get_expelled_hc(AbcKerogenState *state, double *mass, int size);
void abc_add_expelled_hc(AbcKerogenState *state, double *mass);
double abc_get_total_expelled_hc(AbcKerogenState *state, double *hc);
void abc_unexpell_hc(AbcKerogenState *state);
void abc_pc_expell_hc(AbcKerogenState *state);
void abc_print_state(AbcKerogenState *state, FILE *out);
void abc_print_state_default(AbcKerogenState *state, FILE *out);
int abc_get_kerogen_temp_hist(AbcKerogenTempHist *hist, char const *filename);
int abc_get_simple_temp_hist(AbcInput *in, AbcKerogenTempHist *hist);
int abc_get_column_temp_hist(AbcInput *in, AbcKerogenTempHist *hist);
void abc_print_hc_temp_hist(AbcKerogenTempHist *hist, FILE *out);
void abc_store_temp_hist_info_for_post(AbcKerogenTempHist *hist, const char *filename);
int abc_read_kerogen_pc(AbcInput *in, AbcKerogenModel *model);
void abc_pc_init_state(AbcKerogenState *state);
void abc_pc_print_state(AbcKerogenState *state, FILE *out);
void abc_pc_print_model(AbcKerogenModel *model, FILE *out);
void abc_pc_print_model_TeX(AbcKerogenModel *model, FILE *out);
int  abc_pc_do_one_time_step(AbcKerogenState *state, double temp1, double temp2, double dt1);
void abc_gen_init_state(AbcKerogenState *state);
void abc_gen_print_state(AbcKerogenState *state, FILE *out);
void abc_gen_print_model(AbcKerogenModel *model, FILE *out);
int  abc_gen_do_one_time_step_rk4(AbcKerogenState *state, double temp1, double temp2, double dt1);
int abc_read_kerogen_gen(AbcInput *in, AbcKerogenModel *model);
int abc_gen_do_one_time_step_by_eigenvalues(AbcKerogenState *state, double temp1, double temp2, double dt1);

#endif

