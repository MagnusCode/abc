/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1996-2015 by M. Wangen.
**
**   Info: Repository for file descriptors.
**   Date: Version 1.0, November 2015
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_FILE_LIST_H_
#define _LIB_FILE_LIST_H_

void abc_test_listed_files(void);
FILE *abc_new_listed_file(const char *basename, const char *ext, const char *comment);
FILE *abc_open_listed_file(const char *filename, const char *comment, const char *mode);
void abc_close_one_listed_file(FILE *fd);
void abc_close_all_listed_files(void);
void abc_show_all_listed_files(void);
int abc_get_index_free_listed_file(void);
int abc_get_index_listed_file(FILE *fd);

#endif

