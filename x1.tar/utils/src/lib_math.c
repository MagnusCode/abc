/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1999 by M. Wangen.
**
**   Info: A few mathematical functions
**   Date: Version 1.0, February 1999
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <lib_macros.h>
#include <lib_params.h>
#include <lib_math.h>
#include <lib_alloc.h>
#include <lib_utils.h>
#include <lib_matrix.h>
#include <lib_input.h>

#define ONE_THIRD      0.333333333333333
#define ROOT_OF_THREE  1.73205080756888       

static void comp_exch(double a[3], int i, int j);
static double cube_root(double x);
static void get_cubic_function(double a, double b, double c, double d, 
     AbcComplex *x, AbcComplex *y);
static void get_der_cubic_function(double a, double b, double c, 
     AbcComplex *x, AbcComplex *y);

/*
**   ================================
**   Part 1: Functions for 3D vectors
**   ================================
*/

void abc_vec3_copy(
     double a[3],
     double b[3])
{
     b[0] = a[0];
     b[1] = a[1];
     b[2] = a[2];
}


void abc_vec3_add_vec3(
     double a[3],
     double b[3],
     double c[3])
{
     c[0] = a[0] + b[0];
     c[1] = a[1] + b[1];
     c[2] = a[2] + b[2];
}


void abc_vec3_mul_scalar(
     double a[3], 
     double scalar)
{
     a[0] *= scalar;
     a[1] *= scalar;
     a[2] *= scalar;
}


void abc_vec3_normalize(
     double a[3])
{
     double len2 = abc_vec3_dot_vec3(a, a);
     double len = sqrt(len2);

     if (len < 1.0e-25)
          return;

     abc_vec3_mul_scalar(a, 1.0 / len);
}


void abc_vec3_cross_vec3(
     double a[3],
     double b[3],
     double c[3])
{
     c[0] = a[1] * b[2] - a[2] * b[1];
     c[1] = a[2] * b[0] - a[0] * b[2];
     c[2] = a[0] * b[1] - a[1] * b[0];
}


double abc_vec3_dot_vec3(
     double a[3],
     double b[3])
{
     double sum = (a[0] * b[0]) + (a[1] * b[1]) + (a[2] * b[2]);
     return sum;
}


void abc_vec3_sort(
     double a[3])
{
     comp_exch(a, 0, 1);    /* Puts the two first elements in order. */
     comp_exch(a, 0, 2);    /* Makes the first element the smallest of the three. */
     comp_exch(a, 1, 2);    /* Puts the second and third elements in order.m*/
}


static void comp_exch(
     double a[3],
     int i,
     int j)
{
     if (a[i] > a[j])
     {
          double tmp = a[i];
          a[i] = a[j];
          a[j] = tmp;
     }
}


void abc_mat3x3_set_zero(
     double mat[3][3])
{
     int i, j;

     for (i = 0; i < 3; i++)
          for (j = 0; j < 3; j++)
               mat[i][j] = 0.0;
}


void abc_mat3x3_copy(
     double A[3][3],
     double B[3][3])
{
     int i, j;

     for (i = 0; i < 3; i++)
          for (j = 0; j < 3; j++)
               B[i][j] = A[i][j];
}


void abc_mat3x3_transpose(
     double A[3][3],
     double B[3][3])
{
     int i, j;

     for (i = 0; i < 3; i++)
          for (j = 0; j < 3; j++)
               B[i][j] = A[j][i];
}


void abc_mat3x3_mul_vec3(
     double mat[3][3],
     double vec1[3],
     double vec2[3])
{
     int i, j;

     for (i = 0; i < 3; i++)
     {
          vec2[i] = 0.0;

          for (j = 0; j < 3; j++)
              vec2[i] += mat[i][j] * vec1[j];
     }
}


void abc_mat3x3_mul_mat3x3(
     double mat1[3][3],
     double mat2[3][3],
     double mat3[3][3])
{
     int i, j, k;

     abc_mat3x3_set_zero(mat3);

     for (i = 0; i < 3; i++)
          for (j = 0; j < 3; j++)
               for (k = 0; k < 3; k++)
                    mat3[i][j] += mat1[i][k] * mat2[k][j];
}


void abc_vec3_show(
     FILE *fp,
     char const *name,
     double a[3])
{
     fprintf(fp, "%s=[", name);
     fprintf(fp, "%g, %g, %g]\n", a[0], a[1], a[2]);
}


void abc_mat3x3_show(
     FILE *fp,
     char const *name,
     double mat[3][3])
{
     fprintf(fp, "%s=[\n", name);
     fprintf(fp, "%g, %g, %g;\n", mat[0][0], mat[0][1], mat[0][2]);
     fprintf(fp, "%g, %g, %g;\n", mat[1][0], mat[1][1], mat[1][2]);
     fprintf(fp, "%g, %g, %g]\n", mat[2][0], mat[2][1], mat[2][2]);
}


int abc_mat3x3_is_rotation_matrix(
     double R[3][3],
     int size)
{
     double I[3][3];
     int i, j, k;
     int ok = TRUE;

     if (size == 1)
          return TRUE;

     abc_mat3x3_set_zero(I);

     for (i = 0; i < size; i++)
          for (j = 0; j < size; j++)
               for (k = 0; k < size; k++)
                    I[i][j] += R[k][i] * R[k][j];

     for (i = 0; i < size; i++)
          I[i][i] -= 1.0;

      for (i = 0; i < size; i++)
          for (j = 0; j < size; j++)
               if (ABC_ABS(I[i][j]) > 1.0e-6) 
               {
                    printf("I[%d][%d]=%g\n", i, j, I[i][j]);
                    ok = FALSE;
               }

     return ok;
}


void abc_mat3x3_rotate(
     double M1[3][3],
     double R[3][3],
     double M2[3][3])
{
     double B[3][3], Rt[3][3];

     abc_mat3x3_transpose(R, Rt);
     abc_mat3x3_mul_mat3x3(R, M1, B);
     abc_mat3x3_mul_mat3x3(B, Rt, M2);
}

/*
**   ===========================
**   Part 2: Interface functions
**   ===========================
*/

double abc_rint(
     double numb)
{
     int inumb = (int) numb;
     double dn1 = numb - inumb;
     double dn2 = (dn1 >= 0.0) ? dn1 : -dn1;
     double rnumb;
     
     if (numb > 0.0)
     {
          if (dn2 > 0.5) rnumb = (double) (inumb + 1.0);
          else return rnumb = (double) inumb;
     }
     else
     {
          if (dn2 > 0.5) rnumb = (double) (inumb - 1.0);
          else return rnumb = (double) inumb;
     }

     return rnumb;
}


double abc_erfc(
     double x)
{
     return (1.0 - erf(x));
}


double abc_erf(
     double x)
{
#ifdef SYSTEM_HAS_ERF
     return erf(x);
#else
     return nr_erf(x);
#endif
}


double abc_E1(
     double x)
{
     return matpack_ExpIntegralE1(x);
}


double abc_Ei(
     double x)
{
     return matpack_ExpIntegralEi(x);
}


/*
**   ================================================================
**   Part 3: These functions are adapted from: Numerical Recipes in C
**   ================================================================
*/


void nr_error(
     const char *text)
{
        fprintf(stderr,"Numerical Recipes error: ");
        fprintf(stderr,"%s\n", text);
}


double nr_erf(
     double x)
{
	return (x < 0.0) ? -nr_gammp(0.5,x*x) : nr_gammp(0.5,x*x);
}


double nr_erfc(
     double x)
{
	return (x < 0.0) ? 1.0+nr_gammp(0.5,x*x) : nr_gammq(0.5,x*x);
}


double nr_gammp(
     double a,
     double x)
{
	double gamser,gammcf,gln;

	if (x < 0.0 || a <= 0.0) nr_error("Invalid arguments in routine GAMMP");
	if (x < (a+1.0)) {
		nr_gser(&gamser,a,x,&gln);
		return gamser;
	} else {
		nr_gcf(&gammcf,a,x,&gln);
		return 1.0-gammcf;
	}
}


double nr_gammq(
     double a,
     double x)
{
	double gamser,gammcf,gln;

	if (x < 0.0 || a <= 0.0) nr_error("Invalid arguments in routine GAMMQ");
	if (x < (a+1.0)) {
		nr_gser(&gamser,a,x,&gln);
		return 1.0-gamser;
	} else {
		nr_gcf(&gammcf,a,x,&gln);
		return gammcf;
	}
}

#define ITABC_MAX 100
#define EPS 3.0e-7

void nr_gser(
     double *gamser,
     double a,
     double x,
     double *gln)
{
        int n;
        double sum,del,ap;
                
        *gln=nr_gammln(a);
        if (x <= 0.0) {
                if (x < 0.0) nr_error("x less than 0 in routine GSER");
                *gamser=0.0;
                return;
        } else {
                ap=a;
                del=sum=1.0/a;  
                for (n=1;n<=ITABC_MAX;n++) {
                        ap += 1.0;
                        del *= x/ap;
                        sum += del;
                        if (fabs(del) < fabs(sum)*EPS) {
                                *gamser=sum*exp(-x+a*log(x)-(*gln));
                                return;
                        }
                }
                nr_error("a too large, ITABC_MAX too small in routine GSER");
                return;
        }
}


void nr_gcf(
     double *gammcf,
     double a,
     double x,
     double *gln)
{
        int n;
        double gold=0.0,g,fac=1.0,b1=1.0;
        double b0=0.0,anf,ana,an,a1,a0=1.0;
                
        *gln=nr_gammln(a);
        a1=x;
        for (n=1;n<=ITABC_MAX;n++) {
                an=(double) n;
                ana=an-a;
                a0=(a1+a0*ana)*fac;
                b0=(b1+b0*ana)*fac;
                anf=an*fac;
                a1=x*a0+anf*a1;
                b1=x*b0+anf*b1;
                if (a1) { 
                        fac=1.0/a1;
                        g=b1*fac;
                        if (fabs((g-gold)/g) < EPS) {
                                *gammcf=exp(-x+a*log(x)-(*gln))*g;
                                return;
                        }
                        gold=g;
                }
        }
        nr_error("a too large, ITABC_MAX too small in routine GCF");
}

#undef ITABC_MAX
#undef EPS

        
double nr_gammln(
     double xx)
{
        double x,tmp,ser;
        static double cof[6]={76.18009173,-86.50532033,24.01409822,
                -1.231739516,0.120858003e-2,-0.536382e-5};
        int j;
        
        x=xx-1.0;
        tmp=x+5.5;
        tmp -= (x+0.5)*log(tmp);
        ser=1.0;
        for (j=0;j<=5;j++) {
                x += 1.0;
                ser += cof[j]/x;
        }
        return -tmp + log(2.50662827465*ser);
}


double nr_gauss(
     int *idum)
{
        static int iset=0;
        static double gset;
        double fac,r,v1,v2;

        if  (iset == 0) {
                do {
                        v1=2.0*nr_ran1(idum)-1.0;
                        v2=2.0*nr_ran1(idum)-1.0;
                        r=v1*v1+v2*v2;
                } while (r >= 1.0 || r == 0.0);
                fac=sqrt(-2.0*log(r)/r);
                gset=v1*fac;
                iset=1;
                return v2*fac;
        } else {
                iset=0;
                return gset;
        }
}


#define M1 259200
#define IA1 7141
#define IC1 54773
#define RM1 (1.0/M1)
#define M2 134456
#define IA2 8121
#define IC2 28411
#define RM2 (1.0/M2)
#define M3 243000
#define IA3 4561
#define IC3 51349


double nr_ran1(
     int *idum)
{
        static long ix1,ix2,ix3;
        static double r[98];
        double temp;
        static int iff=0;
        int j;

        if (*idum < 0 || iff == 0) {
                iff=1;
                ix1=(IC1-(*idum)) % M1;
                ix1=(IA1*ix1+IC1) % M1;
                ix2=ix1 % M2;
                ix1=(IA1*ix1+IC1) % M1;
                ix3=ix1 % M3;
                for (j=1;j<=97;j++) {
                        ix1=(IA1*ix1+IC1) % M1;
                        ix2=(IA2*ix2+IC2) % M2;
                        r[j]=(ix1+ix2*RM2)*RM1;
                }
                *idum=1;
        }
        ix1=(IA1*ix1+IC1) % M1;
        ix2=(IA2*ix2+IC2) % M2;
        ix3=(IA3*ix3+IC3) % M3;
        j=1 + ((97*ix3)/M3);
        if (j > 97 || j < 1) {
                printf("RAN1: This cannot happen.");
                exit(1);
        }
        temp=r[j];
        r[j]=(ix1+ix2*RM2)*RM1;
        return temp;
}


#undef M1
#undef IA1
#undef IC1
#undef RM1
#undef M2
#undef IA2
#undef IC2
#undef RM2
#undef M3
#undef IA3
#undef IC3

/*
**   ===============================================
**   Part 4: These functions are taken from: Matpack
**   ===============================================
*/

/*-----------------------------------------------------------------------------*\
| Matpack special functions - exponential integral function               ei.cc |
|                                                                               |
| Matpack Library Release 1.7.2                                                 |
| Copyright (C) 1991-1996 by Berndt M. Gammel                                   |
|                                                                               |
| Permission to  use, copy, and  distribute  Matpack  in  its entirety  and its |
| documentation  for non-commercial purpose and  without fee is hereby granted, |
| provided that this license information and copyright notice appear unmodified |
| in all copies.  This software is provided 'as is'  without express or implied |
| warranty.  In no event will the author be held liable for any damages arising |
| from the use of this software.						|
| Note that distributing Matpack 'bundled' in with any product is considered to |
| be a 'commercial purpose'.							|
| The software may be modified for your own purposes, but modified versions may |
| not be distributed without prior consent of the author.			|
|                                                                               |
| Read the  COPYRIGHT and  README files in this distribution about registration	|
| and installation of Matpack.							|
|                                                                               |
\*-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------**
**
** PROTOTYPES:
**
**-----------------------------------------------------------------------------**
** double ExpIntegralEi (double x);
**-----------------------------------------------------------------------------**
** 
**    This routine computes the exponential integral Ei(x) for real 
**    arguments x where
**
**              /  integral (from t=-infinity to t=x) (exp(t)/t),  x > 0
**     Ei(x) = <
**              \ -integral (from t=-x to t=infinity) (exp(t)/t),  x < 0
**
**    and where the first integral is a principal value integral. 
**    The argument x must not be equal to 0.
**
**    Error returns:  -x >  xbig   underflow  returns  0
**                     x >= xmax   overflow   returns  xinf
**                     x == 0      illegal    returns  -xinf
**                     (xbig = 701.84, xmax = 716.351, xinf = 1.79e308)
**
**-----------------------------------------------------------------------------**
** double ExpIntegralExpEi (double x);
**-----------------------------------------------------------------------------**
**
**    This routine computes the exponential integral  exp(-x) * Ei(x). 
**    The argument x must not be equal to 0.
**
**    Error returns:   x == 0      illegal    returns  -xinf
**                     (xbig = 701.84, xmax = 716.351, xinf = 1.79e308)
**
**-----------------------------------------------------------------------------**
** double ExpIntegralE1 (double x);
**-----------------------------------------------------------------------------**
**
**    This routine computes the exponential integral E1(x). 
**    The argument x must be greater than  0.
**
**    Error returns:   x >  xbig   underflow  returns  0
**                     x == 0      illegal    returns  xinf
**                     x <  0                 returns E1(-x) instead !
**                     (xbig = 701.84, xmax = 716.351, xinf = 1.79e308)
**
**-----------------------------------------------------------------------------**
**  INTERNAL INFORMATION:
**-----------------------------------------------------------------------------**
**
**  The routine double calcei(double arg, int ii) is intended for internal
**  use only, all computations within the packet being concentrated 
**  in this routine.  The parameter usage is as follows:
**
**      Function Call                   Parameters
**                            arg             return           ii
**
**      ExpIntegralEi(x)      x != 0          Ei(X)            1
**      ExpIntegralE1(x)      x >  0         -Ei(-X)           2
**      ExpIntegralExpEi(x)   x != 0          exp(-X)*Ei(X)    3
**
**  The main computation involves evaluation of rational Chebyshev
**  approximations published in Math. Comp. 22, 641-649 (1968), and
**  Math. Comp. 23, 289-303 (1969) by Cody and Thacher.  This
**  transportable program is patterned after the machine-dependent
**  FUNPACK packet  NATSEI,  but cannot match that version for
**  efficiency or accuracy.  This version uses rational functions
**  that theoretically approximate the exponential integrals to
**  at least 18 significant decimal digits.  The accuracy achieved
**  depends on the arithmetic system, the compiler, the intrinsic
**  functions, and proper selection of the machine-dependent
**  constants.
**
**-----------------------------------------------------------------------------**
** EXPLANATION OF MACHINE-DEPENDENT CONSTANTS:
**-----------------------------------------------------------------------------**
**
**   beta = radix for the floating-point system.
**   minexp = smallest representable power of beta.
**   maxexp = smallest power of beta that overflows.
**   XBIG = largest argument acceptable to E1; solution to
**          equation:
**                     exp(-x)/x * (1 + 1/x) = beta ** minexp.
**   XINF = largest positive machine number; approximately
**                     beta ** maxexp
**   XABC_MAX = largest argument acceptable to EI; solution to
**          equation:  exp(x)/x * (1 + 1/x) = beta ** maxexp.
**
**     Approximate values for some important machines are:
**
**                           beta      minexp      maxexp
**
**  CRAY-1        (S.P.)       2       -8193        8191
**  Cyber 180/185 
**    under NOS   (S.P.)       2        -975        1070
**  IEEE (IBM/XT,
**    SUN, etc.)  (S.P.)       2        -126         128
**  IEEE (IBM/XT,
**    SUN, etc.)  (D.P.)       2       -1022        1024
**  IBM 3033      (D.P.)      16         -65          63
**  VAX D-Format  (D.P.)       2        -128         127
**  VAX G-Format  (D.P.)       2       -1024        1023
**
**                           XBIG       XINF       XABC_MAX
**
**  CRAY-1        (S.P.)    5670.31  5.45E+2465   5686.21
**  Cyber 180/185 
**    under NOS   (S.P.)     669.31  1.26E+322     748.28
**  IEEE (IBM/XT,
**    SUN, etc.)  (S.P.)      82.93  3.40E+38       93.24
**  IEEE (IBM/XT,
**    SUN, etc.)  (D.P.)     701.84  1.79D+308     716.35
**  IBM 3033      (D.P.)     175.05  7.23D+75      179.85
**  VAX D-Format  (D.P.)      84.30  1.70D+38       92.54
**  VAX G-Format  (D.P.)     703.22  8.98D+307     715.66
**
**-----------------------------------------------------------------------------**
**
**  Original Author: W. J. Cody
**                   Mathematics abd Computer Science Division
**                   Argonne National Laboratory
**                   Argonne, IL 60439
**                   Latest modification: September 9, 1988
**
** Recoding in C++:  Dr. Berndt M. Gammel
**                   Physik Department TU Muenchen
**                   85747 Garching, Germany
**                   Latest modification: October 30, 1996
**-----------------------------------------------------------------------------*/

static double calcei (double arg, int ii)
{
    int i;
    double  ei,frac,sump,sumq,t,w,xmx0,y,ysq,px[10],qx[10];

    /*-------------------------------------------------------------------------**
    ** Mathematical constants
    ** exp40 = exp(40)
    ** x0 = zero of Ei
    ** x01/x11 + x02 = zero of Ei to extra precision
    **-------------------------------------------------------------------------*/

    const double zero   = 0.0,
                 p037   = 0.037,
	         half   = 0.5,
	         one    = 1.0,
	         two    = 2.0,
	         three  = 3.0,
	         four   = 4.0,
	         six    = 6.0,
	         twelve = 12.0,
	         two4   = 24.0,
	         fourty = 40.0,
	         exp40  = exp(40.0),  /* 2.3538526683701998541e17 */
	         x01    = 381.5,
	         x11    = 1024.0,
	         x02    = -5.1182968633365538008e-5,
	         x0     = 3.7250741078136663466e-1;

    /*-------------------------------------------------------------------------**
    ** Machine-dependent constants for IEEE arithmetics
    **-------------------------------------------------------------------------*/

    const double xinf = 1.79e+308,
                 xmax = 716.351,
                 xbig = 701.84;

    /*-------------------------------------------------------------------------**
    ** Coefficients  for -1.0 <= x < 0.0
    **-------------------------------------------------------------------------*/

    const double a[7] = {
      1.1669552669734461083368e2, 2.1500672908092918123209e3,
      1.5924175980637303639884e4, 8.9904972007457256553251e4,
      1.5026059476436982420737e5,-1.4815102102575750838086e5,
      5.0196785185439843791020e0 
    };
    const double b[6] = {
      4.0205465640027706061433e1, 7.5043163907103936624165e2,
      8.1258035174768735759855e3, 5.2440529172056355429883e4,
      1.8434070063353677359298e5, 2.5666493484897117319268e5
    };

    /*-------------------------------------------------------------------------**
    ** Coefficients for -4.0 <= x < -1.0
    **-------------------------------------------------------------------------*/

    const double c[9] = {
      3.828573121022477169108e-1, 1.107326627786831743809e+1,
      7.246689782858597021199e+1, 1.700632978311516129328e+2,
      1.698106763764238382705e+2, 7.633628843705946890896e+1,
      1.487967702840464066613e+1, 9.999989642347613068437e-1,
      1.737331760720576030932e-8
    };
    const double d[9] = {
      8.258160008564488034698e-2, 4.344836335509282083360e+0,
      4.662179610356861756812e+1, 1.775728186717289799677e+2,
      2.953136335677908517423e+2, 2.342573504717625153053e+2,
      9.021658450529372642314e+1, 1.587964570758947927903e+1,
      1.000000000000000000000e+0
    };

    /*-------------------------------------------------------------------------**
    ** Coefficients for x < -4.0
    **-------------------------------------------------------------------------*/

    const double e[10] = {
      1.3276881505637444622987e+2,3.5846198743996904308695e+4,
      1.7283375773777593926828e+5,2.6181454937205639647381e+5,
      1.7503273087497081314708e+5,5.9346841538837119172356e+4,
      1.0816852399095915622498e+4,1.0611777263550331766871e03,
      5.2199632588522572481039e+1,9.9999999999999999087819e-1
    };
    const double f[10] = {
      3.9147856245556345627078e+4,2.5989762083608489777411e+5,
      5.5903756210022864003380e+5,5.4616842050691155735758e+5,
      2.7858134710520842139357e+5,7.9231787945279043698718e+4,
      1.2842808586627297365998e+4,1.1635769915320848035459e+3,
      5.4199632588522559414924e+1,1.0e0
    };

    /*-------------------------------------------------------------------------**
    **  Coefficients for rational approximation to ln(x/a), |1-x/a| < .1
    **-------------------------------------------------------------------------*/
    
    const double plg[4] = {
      -2.4562334077563243311e+01,2.3642701335621505212e+02,
      -5.4989956895857911039e+02,3.5687548468071500413e+02
    };
    const double qlg[4] = {
      -3.5553900764052419184e+01,1.9400230218539473193e+02,
      -3.3442903192607538956e+02,1.7843774234035750207e+02
    };
    
    /*-------------------------------------------------------------------------**
    ** Coefficients for  0.0 < x < 6.0,
    ** ratio of Chebyshev polynomials
    **-------------------------------------------------------------------------*/

    const double p[10] = {
      -1.2963702602474830028590e01,-1.2831220659262000678155e03,
      -1.4287072500197005777376e04,-1.4299841572091610380064e06,
      -3.1398660864247265862050e05,-3.5377809694431133484800e08,
       3.1984354235237738511048e08,-2.5301823984599019348858e10,
       1.2177698136199594677580e10,-2.0829040666802497120940e11
    };
    const double q[10] = {
      7.6886718750000000000000e01,-5.5648470543369082846819e03,
      1.9418469440759880361415e05,-4.2648434812177161405483e06,
      6.4698830956576428587653e07,-7.0108568774215954065376e08,
      5.4229617984472955011862e09,-2.8986272696554495342658e10,
      9.8900934262481749439886e10,-8.9673749185755048616855e10
    };

    /*-------------------------------------------------------------------------**
    ** j-fraction coefficients for 6.0 <= x < 12.0
    **-------------------------------------------------------------------------*/

    const double r[10] = {
      -2.645677793077147237806e00,-2.378372882815725244124e00,
      -2.421106956980653511550e01, 1.052976392459015155422e01,
       1.945603779539281810439e01,-3.015761863840593359165e01,
       1.120011024227297451523e01,-3.988850730390541057912e00,
       9.565134591978630774217e00, 9.981193787537396413219e-1
    };
    const double s[9] = {
      1.598517957704779356479e-4, 4.644185932583286942650e00,
      3.697412299772985940785e02,-8.791401054875438925029e00,
      7.608194509086645763123e02, 2.852397548119248700147e01,
      4.731097187816050252967e02,-2.369210235636181001661e02,
      1.249884822712447891440e00
    };

    /*-------------------------------------------------------------------------**
    ** j-fraction coefficients for 12.0 <= x < 24.0
    **-------------------------------------------------------------------------*/

    const double p1[10] = {
      -1.647721172463463140042e00,-1.860092121726437582253e01,
      -1.000641913989284829961e01,-2.105740799548040450394e01,
      -9.134835699998742552432e-1,-3.323612579343962284333e01,
       2.495487730402059440626e01, 2.652575818452799819855e01,
      -1.845086232391278674524e00, 9.999933106160568739091e-1
    };
    const double q1[9] = {
      9.792403599217290296840e01, 6.403800405352415551324e01,
      5.994932325667407355255e01, 2.538819315630708031713e02,
      4.429413178337928401161e01, 1.192832423968601006985e03,
      1.991004470817742470726e02,-1.093556195391091143924e01,
      1.001533852045342697818e00
    };

    /*-------------------------------------------------------------------------**
    ** j-fraction coefficients for  X >= 24.0
    **-------------------------------------------------------------------------*/

    const double p2[10] = {
       1.75338801265465972390e02,-2.23127670777632409550e02,
      -1.81949664929868906455e01,-2.79798528624305389340e01,
      -7.63147701620253630855e00,-1.52856623636929636839e01,
      -7.06810977895029358836e00,-5.00006640413131002475e00,
      -3.00000000320981265753e00, 1.00000000000000485503e00
    };
    const double q2[9] = {
       3.97845977167414720840e04, 3.97277109100414518365e00,
       1.37790390235747998793e02, 1.17179220502086455287e02,
       7.04831847180424675988e01,-1.20187763547154743238e01,
      -7.99243595776339741065e00,-2.99999894040324959612e00,
       1.99999999999048104167e00
    };

    /*-------------------------------------------------------------------------**
    ** code starts here
    **-------------------------------------------------------------------------*/

    double x = arg;
    if (x == zero) {

        ei = -xinf;
	if (ii == 2) ei = -ei;

    } else if ((x < zero) || (ii == 2)) { 

        /*---------------------------------------------------------------------**
        ** Calculate Ei for negative argument or for E1.
        **---------------------------------------------------------------------*/

        y = fabs(x);
	if (y <= one) {
	    sump = a[6] * y + a[0];
	    sumq = y + b[0];
	    for (i = 1; i < 6; i++) {
	        sump = sump * y + a[i];
		sumq = sumq * y + b[i];
	    }
	    ei = log(y) - sump / sumq;
	    if (ii == 3) ei *= exp(y);
	} else if (y <= four) {
	    w = one / y;
	    sump = c[0];
	    sumq = d[0];
	    for (i = 1; i < 9; i++) {
	        sump = sump * w + c[i];
		sumq = sumq * w + d[i];
	    }
	    ei = -sump / sumq;
	    if (ii != 3) ei *= exp(-y);
	} else {
	    if ((y > xbig) && (ii < 3)) {
	        ei = zero;
	    } else {
	        w = one / y;
		sump = e[0];
		sumq = f[0];
		for (i = 1; i < 10; i++) {
		   sump = sump * w + e[i];
		   sumq = sumq * w + f[i];
		}
		ei = -w * (one - w * sump / sumq );
		if (ii != 3) ei *= exp(-y);
	    }
	}
	if (ii == 2) ei = -ei;

    } else if (x < six) {

        /*---------------------------------------------------------------------**
        **  To improve conditioning, rational approximations are expressed
        **  in terms of Chebyshev polynomials for 0 <= x < 6, and in
        **  continued fraction form for larger x.
        **---------------------------------------------------------------------*/

        t = x + x;
	t = t / three - two;
	px[0] = zero;
	qx[0] = zero;
	px[1] = p[0];
	qx[1] = q[0];
	for (i = 1; i < 9; i++) {
	    px[i+1] = t * px[i] - px[i-1] + p[i];
	    qx[i+1] = t * qx[i] - qx[i-1] + q[i];
	}
	sump = half * t * px[9] - px[8] + p[9];
	sumq = half * t * qx[9] - qx[8] + q[9];
	frac = sump / sumq;
	xmx0 = (x - x01/x11) - x02;

	if (fabs(xmx0) >= p037) {

	    ei = log(x/x0) + xmx0 * frac;
	    if (ii == 3) ei *= exp(-x);

	} else {

            /*-----------------------------------------------------------------**
	    ** Special approximation to  ln(x/x0)  for x close to x0
            **-----------------------------------------------------------------*/

	    y = xmx0 / (x + x0);
	    ysq = y*y;
	    sump = plg[0];
	    sumq = ysq + qlg[0];
	    for (i = 1; i < 4; i++) {
	        sump = sump*ysq + plg[i];
		sumq = sumq*ysq + qlg[i];
	    }
	    ei = (sump / (sumq*(x+x0)) + frac) * xmx0;
	    if (ii == 3) ei *= exp(-x);
	}

    } else if (x < twelve) {

        frac = zero;
	for (i = 0; i < 9; i++)
	    frac = s[i] / (r[i] + x + frac);
	ei = (r[9] + frac) / x;
	if (ii != 3) ei *= exp(x);

    } else if (x <= two4) {

        frac = zero;
	for (i = 0; i < 9; i++)
	    frac = q1[i] / (p1[i] + x + frac);
	ei = (p1[9] + frac) / x;
	if (ii != 3) ei *=exp(x);

    } else {

        if ((x >= xmax) && (ii < 3)) {
	    ei = xinf;
	} else {
	    y = one / x;
	    frac = zero;
	    for (i = 0; i < 9; i++)
	        frac = q2[i] / (p2[i] + x + frac);
	    frac = p2[9] + frac;
	    ei = y + y * y * frac;
	    if (ii != 3) {
	        if (x <= xmax-two4) {
		    ei *= exp(x);
		} else {
		    /*---------------------------------------------------------**
		    ** Calculation reformulated to avoid premature overflow
		    **---------------------------------------------------------*/
		    ei = (ei * exp(x-fourty)) * exp40;
		}
	    }
	}
    }   
    return ei;
}

/*-----------------------------------------------------------------------------**
** This function program computes approximate values for the
** exponential integral  Ei(x), where  x  is real.
**-----------------------------------------------------------------------------*/

double matpack_ExpIntegralEi(
     double x)
{
    return calcei(x,1);
}

/*-----------------------------------------------------------------------------**
** This function program computes approximate values for the
** function  exp(-x) * Ei(x), where  Ei(x)  is the exponential
** integral, and  x  is real.
**-----------------------------------------------------------------------------*/

double matpack_ExpIntegralExpEi(
     double x)
{
    return calcei(x,3);
}

/*-----------------------------------------------------------------------------**
** This function program computes approximate values for the
** exponential integral E1(x), where  x  is real.
**-----------------------------------------------------------------------------*/

double matpack_ExpIntegralE1(
     double x)
{
    return calcei(x,2);
}

/*-----------------------------------------------------------------------------*/

/*
**   =======================
**   Part 5: Complex numbers
**   =======================
*/

double abc_complex_abs(
     AbcComplex *x1)
{
     return sqrt((x1->re * x1->re) + (x1->im * x1->im));
}


void abc_complex_add(
     AbcComplex *x1,
     AbcComplex *x2,
     AbcComplex *x3)
{
     x3->re = x1->re + x2->re;
     x3->im = x1->im + x2->im;
}


void abc_complex_sub(
     AbcComplex *x1,
     AbcComplex *x2,
     AbcComplex *x3)
{
     x3->re = x1->re - x2->re;
     x3->im = x1->im - x2->im;
}


void abc_complex_mul(
     AbcComplex *x1,
     AbcComplex *x2,
     AbcComplex *x3)
{
     x3->re = (x1->re * x2->re) - (x1->im * x2->im);
     x3->im = (x1->re * x2->im) + (x2->re * x1->im);
}


void abc_complex_div(
     AbcComplex *x1,
     AbcComplex *x2,
     AbcComplex *x3)
{
     double denom = (x2->re * x2->re) + (x2->im * x2->im);

     if (denom < 1.0e-64) 
          ABC_ERROR_RETURN("[abc_complex_div] div by zero!");

     x3->re = ((x1->re * x2->re) + (x1->im * x2->im)) / denom;
     x3->im = ((x2->re * x1->im) - (x1->re * x2->im)) / denom;
}


void abc_complex_set(
     AbcComplex *x,
     double re,
     double im)
{
     x->re = re;
     x->im = im;
}


void abc_complex_zero(
     AbcComplex *x)
{
     x->re = 0.0;
     x->im = 0.0;
}


void abc_complex_print(
     FILE *out,
     const char *name,
     AbcComplex *x)
{
     if (name != NULL) fprintf(out, "%s", name);
     fprintf(out, "%g + %gj\n", x->re, x->im);
}


int abc_complex_is_real(
     AbcComplex *x)
{
     if (x->im == 0.0) return TRUE;
     return FALSE;
}


void abc_complex_to_polar(
     AbcComplex *u,
     double *r,
     double *w)
{
     if (ABC_ABS(u->re) < 1.0e-64)
     {
          double pi_half = ABC_PI / 2.0;
          *r = ABC_ABS(u->im);
          *w = (u->im < 0.0) ? -pi_half : pi_half;
          return;
     }

     *r = sqrt((u->re * u->re) + (u->im * u->im));
     *w = atan(u->im / u->re);
}

/*
**   =============================================
**   Part 6: The quadratic and the cubic equations
**   =============================================
*/

#define MODE_ABCD   1
#define MODE_ABC    2
#define MODE_x1x2   3
#define MODE_x1x2x3 4

int abc_main_solve_quad_or_cub(
     int argc, 
     char **argv)
{
     int mode;
     int P1 = 1;
     double a, b, c, d, x1, x2, x3;
     AbcParams *params = NULL;

     params = abc_new_params(16);
     abc_def_param_group(params, "Parameters:", P1);

     abc_def_double_param(params, &a,  "a",  "-", "Parameter a", 1.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &b,  "b",  "-", "Parameter b", 1.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &c,  "c",  "-", "Parameter c", 1.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &d,  "d",  "-", "Parameter d", 0.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &x1, "x1", "-", "Solution x1", 1.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &x2, "x2", "-", "Solution x2", 2.0, -1.0e+32, 1.0e+32, P1);
     abc_def_double_param(params, &x3, "x3", "-", "Solution x3", 3.0, -1.0e+32, 1.0e+32, P1);

     abc_def_label_param(params, &mode, "mode", "Mode", "abcd", MODE_ABCD, P1);
     abc_add_label(params, "mode", "abc", MODE_ABC);
     abc_add_label(params, "mode", "x1x2", MODE_x1x2);
     abc_add_label(params, "mode", "x1x2x3", MODE_x1x2x3);

     abc_read_all_params_by_args(params, argc, argv);

     if (mode == MODE_ABC)
     {
          abc_test_solve_quadratic(a, b, c);
     }
     else if (mode == MODE_ABCD)
     {
          abc_test_solve_cubic(a, b, c, d);
     }
     else if (mode == MODE_x1x2)
     {
          a = 1.0;
          b = - (x1 + x2);
          c = x1 * x2;
          abc_test_solve_quadratic(a, b, c);
     }
     else if (mode == MODE_x1x2x3)
     {
          a = 1.0;
          b = - (x1 + x2 + x3);
          c = (x1 * x2) + (x2 * x3) + (x3 * x1);
          d = - x1 * x2 * x3;
          abc_test_solve_cubic(a, b, c, d);
     }
     else
          ABC_ERROR_EXIT("Unknown mode!");

     abc_delete_params(&params);

     return 1;
}


void abc_test_solve_quadratic(
     double a, 
     double b, 
     double c)
{
     AbcComplex x1, x2, cb, cc;

     abc_solve_quadratic(a, b, c, &x1, &x2);

     /*
     **  (x - x1)(x - x2) = x^2 + b*x + c
     **
     **  b = - (x1 + x2)
     **  c = x1*x2
     **
     **  Ex: (x-1)(x-2) gives: a=1, b=-3, c=2
     **
     **  Check using Octave: roots([1 -3 2])
     */

     abc_complex_print(stdout, "x1 = ", &x1);
     abc_complex_print(stdout, "x2 = ", &x2);
     abc_complex_add(&x1, &x2, &cb);
     abc_complex_mul(&x1, &x2, &cc);

     printf("check: b=%g, c=%g\n", - (a * cb.re), (a * cc.re));
}


void abc_test_solve_cubic(
     double a, 
     double b, 
     double c, 
     double d)
{
     AbcComplex x1, x2, x3;
     AbcComplex cb, cc, cd;
     AbcComplex t1, t2, t3;
     AbcComplex minus_one = {-1.0, 0.0};

     abc_solve_cubic(a, b, c, d, &x1, &x2, &x3);

     abc_complex_print(stdout, "x1 = ", &x1);
     abc_complex_print(stdout, "x2 = ", &x2);
     abc_complex_print(stdout, "x3 = ", &x3);

     /*
     **  (x - x1)(x - x2)(x - x3) = x^3 + b*x^2 + c*x + d
     **
     **  b = - (x1 + x2 + x3)
     **  c = x1*x2 + x2*x3 + x3*x1
     **  d = - x1*x2*x3
     **
     **  Ex: (x-1)(x-2)(x-3) gives: a=1, b=-6, c=11, d=-6
     **
     **  Check using Octave: roots([1 -6 11 -6])
     */

     abc_complex_set(&cb, 0.0, 0.0);
     abc_complex_add(&cb, &x1, &cb);
     abc_complex_add(&cb, &x2, &cb);
     abc_complex_add(&cb, &x3, &cb);
     abc_complex_mul(&cb, &minus_one, &cb);

     abc_complex_set(&cc, 0.0, 0.0);
     abc_complex_mul(&x1, &x2, &t1);
     abc_complex_mul(&x2, &x3, &t2);
     abc_complex_mul(&x3, &x1, &t3);
     abc_complex_add(&cc, &t1, &cc);
     abc_complex_add(&cc, &t2, &cc);
     abc_complex_add(&cc, &t3, &cc);

     abc_complex_set(&cd, 1.0, 0.0);
     abc_complex_mul(&cd, &x1, &cd);
     abc_complex_mul(&cd, &x2, &cd);
     abc_complex_mul(&cd, &x3, &cd);
     abc_complex_mul(&cd, &minus_one, &cd);

     abc_complex_print(stdout, "cb = ", &cb);
     abc_complex_print(stdout, "cc = ", &cc);
     abc_complex_print(stdout, "cd = ", &cd);

     abc_check_cubic_root(a, b, c, d, "sum1 = ", &x1);
     abc_check_cubic_root(a, b, c, d, "sum2 = ", &x2);
     abc_check_cubic_root(a, b, c, d, "sum3 = ", &x3);
}


void abc_solve_quadratic(
     double a,
     double b,
     double c,
     AbcComplex *x1,
     AbcComplex *x2)
{
     double D1 =  (b * b) - (4.0 * a * c);
     double D2 = (D1 > 0.0) ? D1 : -D1;
     double sqrt_D = sqrt(D2);
     double two_a = 2.0 * a;

     abc_complex_zero(x1);
     abc_complex_zero(x2);

     if (ABC_ABS(a) < 1.0e-64)
          ABC_ERROR_RETURN("[abc_solve_quadratic] a=0!");

     if (D1 >= 0.0)
     {
          x1->re = (-b + sqrt_D) / two_a;
          x1->im = 0.0;
          x2->re = (-b - sqrt_D) / two_a;
          x2->im = 0.0;
     }
     else
     {
          x1->re = -b / two_a;
          x1->im = sqrt_D / two_a;
          x2->re = -b / two_a;
          x2->im = -sqrt_D / two_a;
     }
}


void abc_solve_cubic(
     double a, 
     double b, 
     double c, 
     double d,
     AbcComplex *x1,
     AbcComplex *x2,
     AbcComplex *x3)
{
     /* 
     ** See: http://en.wikipedia.org/wiki/Cubic_function#Roots_of_a_cubic_function
     ** Using: Cardano's method
     */

     double hh, pp, qq, a2, a3, b2, b3;

     abc_complex_zero(x1);
     abc_complex_zero(x2);
     abc_complex_zero(x3);

     if (ABC_ABS(a) < 1.0e-32)
          ABC_ERROR_RETURN("[abc_solve_cubic] Coefficient a=0 !");

     a2 = a * a;
     b2 = b * b;
     a3 = a2 * a;
     b3 = b2 * b;

     pp = (3.0 * c * a - b2) / (3.0 * a2);
     qq = (2.0 * b3 - 9.0 * a * b * c + 27.0 * a2 * d) / (27.0 * a3);
     hh = (qq * qq / 4.0) + (pp * pp * pp / 27.0);

     if ((pp == 0) and (qq == 0) and (hh == 0))
     {
          /* There are 3 equal roots:  */
          double x = - cube_root(d / a);
          x1->re = x;
          x2->re = x;
          x3->re = x;
     }
     else if (hh <= 0)
     {
          /* There are 3 real roots: */
          double i = pow(pow(qq, 2) / 4 - hh, 0.5);
          double j = cube_root(i);
          double k = acos(-(qq / (2 * i)));
          double m = cos(k / 3);
          double n = ROOT_OF_THREE * sin(k / 3);
          double p = -(b / (3 * a));
          x1->re = (2 * j * m + p);
          x2->re = (-j * (m + n) + p);
          x3->re = (-j * (m - n) + p);
    }
    else if (hh > 0)
    {
          /* There are 1 real root and 2 complex conjugate roots: */
          double r = -(qq / 2.0) + pow(hh, 0.5);
          double s = cube_root(r);
          double t = -(qq / 2.0) - pow(hh, 0.5);
          double u = cube_root(t);
          double p = -(b / (3.0 * a));
          x1->re = ((s + u) + p);
          x2->re = (-(s + u) / 2.0 + p);  x2->im = ((s - u) * ROOT_OF_THREE / 2.0);
          x3->re = x2->re;                x3->im = - x2->im;
    }

    /* One Newton step is used to reduce rounding errors. */

    abc_newton_step_on_cubic_root(a, b, c, d, x1);
    abc_newton_step_on_cubic_root(a, b, c, d, x2);
    abc_newton_step_on_cubic_root(a, b, c, d, x3);
}


static double cube_root(
     double x)
{
     if (x < 0) return -pow(-x, ONE_THIRD);
     return pow(x, ONE_THIRD);
}


void abc_check_cubic_root(
     double a,
     double b,
     double c,
     double d,
     const char *text,
     AbcComplex *x)
{
     AbcComplex sum;

     get_cubic_function(a, b, c, d, x, &sum);
     abc_complex_print(stdout, text, &sum);
}


void abc_newton_step_on_cubic_root(
     double a,
     double b,
     double c,
     double d,
     AbcComplex *x)
{
     int i;
     int max_iterations = 1;
     AbcComplex fx, dfx, dx;
     double abs_dfx;

     for (i = 0; i < max_iterations; i++)
     {
          get_cubic_function(a, b, c, d, x, &fx);
          get_der_cubic_function(a, b, c, x, &dfx);
          abs_dfx = abc_complex_abs(&dfx);
          if (abs_dfx < 1.0e-32) return;
          abc_complex_div(&fx, &dfx, &dx);
          abc_complex_sub(x, &dx, x);
          /***
          printf("==================\n");
          printf("I=%d\n", i);
          abc_complex_print(stdout, "x=", x);
          abc_complex_print(stdout, "dx=", &dx);
          abc_complex_print(stdout, "fx=", &fx);
          abc_complex_print(stdout, "dfx=", &dfx);
          ***/
     }
}


static void get_cubic_function(
     double a,
     double b,
     double c,
     double d,
     AbcComplex *x,
     AbcComplex *y)
{
     AbcComplex p1, p2, p3, cc, dd;

     abc_complex_set(y, 0.0, 0.0);

     abc_complex_set(&p1, x->re, x->im);
     abc_complex_mul(&p1, &p1, &p2);
     abc_complex_mul(&p1, &p2, &p3);

     abc_complex_set(&cc, a, 0.0);
     abc_complex_mul(&cc, &p3, &dd);
     abc_complex_add(&dd, y, y);

     abc_complex_set(&cc, b, 0.0);
     abc_complex_mul(&cc, &p2, &dd);
     abc_complex_add(&dd, y, y);

     abc_complex_set(&cc, c, 0.0);
     abc_complex_mul(&cc, &p1, &dd);
     abc_complex_add(&dd, y, y);

     abc_complex_set(&cc, d, 0.0);
     abc_complex_add(&cc, y, y);
}


static void get_der_cubic_function(
     double a,
     double b,
     double c,
     AbcComplex *x,
     AbcComplex *y)
{
     AbcComplex p1, p2, cc, dd;

     abc_complex_set(y, 0.0, 0.0);

     abc_complex_set(&p1, x->re, x->im);
     abc_complex_mul(&p1, &p1, &p2);

     abc_complex_set(&cc, 3.0 * a, 0.0);
     abc_complex_mul(&cc, &p2, &dd);
     abc_complex_add(&dd, y, y);

     abc_complex_set(&cc, 2.0 * b, 0.0);
     abc_complex_mul(&cc, &p1, &dd);
     abc_complex_add(&dd, y, y);

     abc_complex_set(&cc, c, 0.0);
     abc_complex_add(&cc, y, y);
}

