/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2011 by M. Wangen.
**
**   Info: Functions for reading a geohistory.
**   Date: Version 1.1, October 2011
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   A test program:
**   
**   #include <stdio.h>
**   #include <math.h>
**   #include <lib_geohist.h>
**   
**   int main(int argc, char **argv)
**   {
**        return abc_test_geohist(argc, argv);
**   }
*/

#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_matrix.h>
#include <lib_utils.h>
#include <lib_input.h>
#include <lib_params.h>
#include <lib_data_write.h>
#include <lib_geohist.h>

static void init_boundary_hist(AbcXYBoundaryHist *bp, const char *name, const char *name2);
static void delete_boundary_hist(AbcXYBoundaryHist *bp);
static void show_lith_no(AbcGeohistory *hist);
static void show_zcoords(AbcGeohistory *hist);
static void print_pause(FILE *out, AbcLayer *layer);
static void print_sedimentation(FILE *out, AbcLayer *layer);
static void print_erosion(FILE *out, AbcLayer *layer);
static void print_dt_max(FILE *out, AbcLayer *layer);
static void print_formation_name(FILE *out, AbcLayer *layer);
static void print_vline_values(FILE *out, double *values, int n_h_nodes);
static int read_geohistory(AbcInput *in, AbcGeohistory *hist);
static int read_start_time(AbcInput *in, AbcGeohistory *hist);
static int read_max_time_step(AbcInput *in, AbcGeohistory *hist);
static int read_formation_name(AbcInput *in, AbcGeohistory *hist);
static int add_formation_name(AbcGeohistory *hist, const char *name);
static int add_lithology_name(AbcGeohistory *hist, const char *name);
static int read_erosion(AbcInput *in, AbcGeohistory *hist);
static int read_sedimentation(AbcInput *in, AbcGeohistory *hist);
static int fix_zero_deposition_nodes(AbcGeohistory *hist, int n0);
static int is_legal_erosion_node(int *lithology, double *layer_height, int n0);
static int read_layer_def(AbcInput *in, AbcGeohistory *hist);
static int read_row_of_layer_defs(AbcInput *in, AbcGeohistory *hist, int *n0, int *n1);
static int read_vline_triplet(AbcInput *in, AbcGeohistory *hist, 
                int *vline, double *height, int *lith_no);
static int read_pause(AbcInput *in, AbcGeohistory *hist);
static int read_node_values(AbcInput *in, AbcGeohistory *hist, double *values);
static int read_row_of_node_values(AbcInput *in, AbcGeohistory *hist, 
                double *values, int *n0, int *n1);
static int read_node_and_value(AbcInput *in, int *some_node, double *some_value);
static int read_number_of_horizontal_nodes(AbcInput *in, AbcGeohistory *hist);
static int read_horizontal_nodes(AbcInput *in, AbcGeohistory *hist);
static int read_name(AbcInput *in, char *name, int max_length);
static int read_base_temp_bc(AbcInput *in, AbcGeohistory *hist);
static int read_base_pres_bc(AbcInput *in, AbcGeohistory *hist);
static int read_xy_boundary_hist(AbcInput *in, AbcGeohistory *hist, AbcXYBoundaryHist *bp);
static void read_error(AbcInput *in, char const *text);
static void print_geohistory_xy_lith_no(FILE *out, int nx, int ny, int row_no, int *lith_no);

static int
     run_silent = TRUE,
     debug_lith_no = FALSE;

#define P1 1
#define LITH_EROSION 0
#define RETURN_FALSE(in, text) {read_error(in, text); return FALSE;}


int abc_test_geohist(
     int argc,
     char **argv)
{
     AbcGeohistory *hist;
     AbcParams *params = abc_new_params(1024);
     const char *output_file = "x-abc-geohist.bas";
     char input_file[ABC_MAX_WORD];
     int debug_zcoords = FALSE;
     int debug_lith_no = FALSE;
     FILE *out;

     abc_def_param_group(params, "Read geohistory parameters:", P1);
     abc_def_yes_no_param(params, &debug_zcoords, "zcoords", "Show z-coordinates", 0, P1);
     abc_def_yes_no_param(params, &debug_lith_no, "lith-no", "Show lithology numbers", 0, P1);
     abc_def_string_param(params, input_file, "input", "Input file", "xbasin.bas", ABC_MAX_WORD, P1);

     if (not abc_read_params(params, &argc, argv))
          ABC_ERROR_EXIT("Can't continue!");

     hist = abc_create_geohistory_from_bas_file(input_file);

     printf("(has read BAS geohistory from: %s)\n", input_file);
     printf("(rows = %d, nodes = %d, elements = %d)\n",
          abc_get_rows_in_geohistory(hist), 
          abc_get_nodes_in_geohistory(hist),
          abc_get_elems_in_geohistory(hist));

     out = abc_new_file(output_file, "");
     abc_print_geohistory(out, hist);
     fclose(out);
     printf("(has written BAS geohistory to: %s)\n", output_file);

     if (debug_zcoords) show_zcoords(hist);
     if (debug_lith_no) show_lith_no(hist);

     abc_delete_params(&params);
     abc_delete_geohistory(&hist);
     abc_delete_input_lib();

     return 0;
}


static void show_lith_no(
     AbcGeohistory *hist)
{
     int i, elem;
     int *lith_no, *form_no;
     int n_elems = abc_get_elems_in_geohistory(hist);
     int n_h_elems = abc_get_h_elems_in_geohistory(hist);

     ABC_NEW_ARRAY(lith_no, int, n_elems);
     ABC_NEW_ARRAY(form_no, int, n_elems);
     abc_fill_in_geohistory_lith_no(hist, lith_no, form_no);

     for (elem = n_elems - n_h_elems; elem >= 0; elem -= n_h_elems)
     {
          for (i = 0; i < n_h_elems; i++)
               printf("[L=%2d, F=%d] ", lith_no[elem + i], form_no[elem + i]);
          printf("\n");
     }

     ABC_FREE(lith_no);
     ABC_FREE(form_no);
}


static void show_zcoords(
     AbcGeohistory *hist)
{
     double *zcoord;

     int i, k;
     int n_nodes = abc_get_nodes_in_geohistory(hist);
     int n_h_nodes = abc_get_h_nodes_in_geohistory(hist);

     ABC_NEW_ARRAY(zcoord, double, n_nodes);
     abc_fill_in_geohistory_zcoords(hist, zcoord);

     for (k = n_nodes - n_h_nodes; k >= 0; k -= n_h_nodes)
     {
          for (i = 0; i < n_h_nodes; i++)
               printf("%8.1f ", zcoord[k + i]);
          printf("\n");
     }

     ABC_FREE(zcoord);
}

/*
**   ====================================================
**   Functions for handling the layers in the geohistory.
**   ====================================================
*/

AbcGeohistory *abc_create_geohistory_from_bas_file(
     const char *filename)
{
     static AbcInput in;
     AbcGeohistory *hist;

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Can't open file: %s!\n", filename);
          exit(1);
     }

     hist = abc_read_bas_geohistory(&in);
     abc_end_input(&in);
     printf("(geohistory is read from: %s)\n", filename);

     return hist;
}


AbcGeohistory *abc_read_bas_geohistory(
     AbcInput *in)
{
     AbcGeohistory *hist = abc_new_geohistory();

     if (not abc_skip_until_word(in, "size_of_horizontal_basis"))
          ABC_ERROR_EXIT("Can't find keyword \"size_of_horizontal_basis\"!");

     if (not read_number_of_horizontal_nodes(in, hist))
          ABC_ERROR_EXIT("Can't read size of horizontal basis!");
          
     if (not abc_skip_until_word(in, "horizontal_node_pos"))
          ABC_ERROR_EXIT("Can't find keyword \"horizontal_node_pos\"!");

     if (not read_horizontal_nodes(in, hist))
          ABC_ERROR_EXIT("Can't read horizontal nodes!");
          
     if (not abc_skip_until_word(in, "begin_history_at"))
          ABC_ERROR_EXIT("Can't find keyword \"begin_history_at\"!");
          
     if (not read_geohistory(in, hist))
          ABC_ERROR_EXIT("Can't read geohistory!");

     if (not read_xy_boundary_hist(in, hist, &(hist->water_depth)))
          ABC_ERROR_EXIT("Can't read water depth history!");

     if (not read_xy_boundary_hist(in, hist, &(hist->temp_surface)))
          ABC_ERROR_EXIT("Can't read surface temperature history!");

     if (not read_base_temp_bc(in, hist))
          ABC_ERROR_EXIT("Can't read temperature BC at the base!");

     if (abc_geohist_has_base_heat_flux(hist))
     {
          if (not read_xy_boundary_hist(in, hist, &(hist->heat_flux_base)))
               ABC_ERROR_EXIT("Can't read base temperature history!");
     }
     else
     {
          if (not read_xy_boundary_hist(in, hist, &(hist->temp_base)))
               ABC_ERROR_EXIT("Can't read base temperature history!");
     }

     if (not read_base_pres_bc(in, hist))
          ABC_ERROR_EXIT("Can't read temperature BC at the base!");

     if (abc_geohist_has_base_pressure(hist))
     {
          if (not read_xy_boundary_hist(in, hist, &(hist->pres_base)))
               ABC_ERROR_EXIT("Can't read base pressure history!");
     }
     else if (abc_geohist_has_base_darcy_flux(hist))
     {
          if (not read_xy_boundary_hist(in, hist, &(hist->darcy_flux_base)))
               ABC_ERROR_EXIT("Can't read base darcy flux history!");
     }

     return hist;
}


AbcGeohistory *abc_new_geohistory(
     void)
{
     AbcGeohistory *hist;

     ABC_NEW_OBJECT(hist, AbcGeohistory);

     hist->type_base_pres_BC = ABC_BC_BASE_CLOSED;
     hist->type_base_temp_BC = ABC_BC_BASE_2ND_KIND;

     hist->n_x_nodes = 0;
     hist->n_y_nodes = 0;
     hist->n_h_nodes = 0;
     hist->n_layers = 0;

     /* LITH_EROSION = 0; is the first lithology. */
     hist->n_lithologies = 0;
     add_lithology_name(hist, "erosion");

     /* A default name in case no formation names are given. */
     hist->n_formations = 0;
     add_formation_name(hist, "no-name");
     hist->current_formation_no = 0;

     hist->time_begin_hist = 0.0;
     hist->time_end_hist = 0.0;

     hist->xcoord = NULL;
     hist->ycoord = NULL;
     hist->total_height = NULL;
     hist->current_thickness = NULL;
     hist->current_lith_no = NULL;
     hist->current_formation_no = 0;

     init_boundary_hist(&(hist->water_depth), "water_depth", "depth");
     init_boundary_hist(&(hist->temp_surface), "surface_temperature", "temp");
     init_boundary_hist(&(hist->temp_base), "base_temperature", "temp");
     init_boundary_hist(&(hist->heat_flux_base), "base_heat_flux", "flux");
     init_boundary_hist(&(hist->pres_base), "base_pressure", "pres");
     init_boundary_hist(&(hist->darcy_flux_base), "base_darcy_flux", "flux");

     return hist;
}


static void init_boundary_hist(
     AbcXYBoundaryHist *bp,
     const char *name,
     const char *short_name)
{
     int i;

     strcpy(bp->name, name);
     strcpy(bp->short_name, short_name);
     bp->n_times = 0;
     bp->current_index = 0;

     for (i = 0; i < MAX_GEOHIST_LAYERS; i++)
     {
          bp->time[i] = 0.0;
          bp->array[i] = NULL;
     }
}


void abc_delete_geohistory(
     AbcGeohistory **pp)
{
     int i;
     AbcGeohistory *hist = *pp;

     if (hist == NULL) return;

     ABC_FREE(hist->xcoord);
     ABC_FREE(hist->ycoord);
     ABC_FREE(hist->total_height);
     ABC_FREE(hist->current_thickness);
     ABC_FREE(hist->current_lith_no);

     for (i = 0; i < hist->n_formations; i++)
          ABC_FREE(hist->formation_name[i]);

     for (i = 0; i < hist->n_lithologies; i++)
          ABC_FREE(hist->lithology_name[i]);

     for (i = 0; i < hist->n_layers; i++)
          abc_delete_layer(&(hist->layer[i]));

     delete_boundary_hist(&(hist->water_depth));
     delete_boundary_hist(&(hist->temp_surface));
     delete_boundary_hist(&(hist->temp_base));
     delete_boundary_hist(&(hist->heat_flux_base));

     ABC_FREE(hist);
}


static void delete_boundary_hist(
     AbcXYBoundaryHist *bp)
{
     int i;

     for (i = 0; i < MAX_GEOHIST_LAYERS; i++)
     {
          bp->time[i] = 0.0;

          if (bp->array[i] != NULL)
          {
               ABC_FREE(bp->array[i]);
               bp->array[i] = NULL;
          }
     }
}
     

void abc_add_layer_to_geohistory(
     AbcGeohistory *hist,
     int type,
     ABC_PRINT_LAYER func)
{
     int k = hist->n_layers;

     if (k >= MAX_GEOHIST_LAYERS)
          ABC_ERROR_EXIT("Too many layers in geohistory!");

     hist->layer[k] = abc_create_layer(type, hist, func);
     hist->n_layers++;
}


AbcLayer *abc_create_layer(
     int type,
     AbcGeohistory *hist,
     ABC_PRINT_LAYER func)
{
     AbcLayer *layer;
     int n_h_nodes = hist->n_h_nodes;
     int *lith_no = hist->current_lith_no;
     double *thickness = hist->current_thickness;

     ABC_NEW_OBJECT(layer, AbcLayer);

     layer->type = type;
     layer->t1 = hist->current_t1;
     layer->t2 = hist->current_t2;
     layer->dt_max = hist->current_dt_max;
     layer->form_no = hist->current_formation_no;
     layer->lith_no = NULL;
     layer->rows = hist->current_rows;
     layer->hist = hist;
     layer->print = func;
     layer->thickness = NULL;

     if (type == ABC_LAYER_SEDIMENTATION)
          layer->lith_no = abc_save_int_array(lith_no, n_h_nodes);
     
     if (type == ABC_LAYER_SEDIMENTATION or type == ABC_LAYER_EROSION)
          layer->thickness = abc_save_double_array(thickness, n_h_nodes);

     return layer;
}


void abc_delete_layer(
     AbcLayer **pp)
{
     AbcLayer *layer = *pp;

     if (layer == NULL) return;
     if (layer->lith_no != NULL) ABC_FREE_ARRAY(layer->lith_no);
     if (layer->thickness != NULL) ABC_FREE_ARRAY(layer->thickness);

     ABC_FREE(layer);
}


void abc_print_geohistory(
     FILE *out,
     AbcGeohistory *hist)
{
     int i;

     fprintf(out, "\n");
     fprintf(out, "define N1 0 {1}\n");
     fprintf(out, "define N2 0 {%d}\n", hist->n_h_nodes);
     fprintf(out, "define NN 0 {%d}\n", hist->n_h_nodes);
     fprintf(out, "define START 0 {%g}\n", hist->time_begin_hist);
     fprintf(out, "\n");

     fprintf(out, "size_of_horizontal_basis %d x %d\n", 
          hist->n_x_nodes, hist->n_y_nodes);
     fprintf(out, "\n");

     fprintf(out, "horizontal_node_pos\n");
     fprintf(out, "     #( x-coordinates )#\n");
     print_vline_values(out, hist->xcoord, hist->n_h_nodes);
     fprintf(out, "\n");
     fprintf(out, "     #( y-coordinates )#\n");
     print_vline_values(out, hist->ycoord, hist->n_h_nodes);
     fprintf(out, "\n");

     fprintf(out, "begin_history_at %g\n", hist->time_begin_hist);

     for (i = 0; i < hist->n_layers; i++)
     {
          AbcLayer *layer = hist->layer[i];
          if (layer->print == NULL) continue;
          layer->print(out, layer);
     }

     fprintf(out, "\n");
     fprintf(out, "end_history\n");
}


static void print_pause(
     FILE *out,
     AbcLayer *layer)
{
     fprintf(out, "\n");
     fprintf(out, "     pause until %g\n", layer->t2);
}


static void print_sedimentation(
     FILE *out,
     AbcLayer *layer)
{
     int i;
     AbcGeohistory *hist = layer->hist;

     fprintf(out, "\n");
     fprintf(out, "     sedimentation\n");

     for (i = 0; i < hist->n_h_nodes; i++)
     {
          double dz = layer->thickness[i];
          int no = layer->lith_no[i];
          const char *name = hist->lithology_name[no];
          
          fprintf(out, "     %d/%s/%g\n", (i + 1), name, dz);
     }

     fprintf(out, "     with %d rows until %g\n", layer->rows, layer->t2);
}


static void print_erosion(
     FILE *out,
     AbcLayer *layer)
{
     AbcGeohistory *hist = layer->hist;

     fprintf(out, "\n");
     fprintf(out, "     erosion\n");
     print_vline_values(out, layer->thickness, hist->n_h_nodes);
}


static void print_dt_max(
     FILE *out,
     AbcLayer *layer)
{
     fprintf(out, "\n");
     fprintf(out, "     set_max_time_step %g\n", layer->dt_max);
}


static void print_formation_name(
     FILE *out,
     AbcLayer *layer)
{
     int i = layer->form_no;
     AbcGeohistory *hist = layer->hist;
     const char *name = hist->formation_name[i];

     fprintf(out, "\n");
     fprintf(out, "     formation \"%s\"\n", name);
}


static void print_vline_values(
     FILE *out,
     double *values,
     int n_h_nodes)
{
     int i;

     for (i = 0; i < n_h_nodes; i++)
          fprintf(out, "     %d/%g\n", (i + 1), values[i]);
}


const char *abc_get_geohistory_formation_name(
     AbcGeohistory *hist,
     int i)
{
     if (i < 0)
          ABC_RETURN_NULL("[abc_get_geohistory_formation_name] index < 0!");

     if (i >= hist->n_formations)
          ABC_RETURN_NULL("[abc_get_geohistory_formation_name] index is too large!");

     return hist->formation_name[i];
}


const char *abc_get_geohistory_lithology_name(
     AbcGeohistory *hist,
     int i)
{
     if (i < 0)
          ABC_RETURN_NULL("[abc_get_geohistory_lithology_name] index < 0!");

     if (i >= hist->n_lithologies)
          ABC_RETURN_NULL("[abc_get_geohistory_lithology_name] index is too large!");

     return hist->lithology_name[i];
}


int abc_geohist_has_base_heat_flux(
     AbcGeohistory *hist)
{
      return (hist->type_base_temp_BC == ABC_BC_BASE_2ND_KIND);
}


int abc_geohist_has_base_pressure(
     AbcGeohistory *hist)
{
      return (hist->type_base_pres_BC == ABC_BC_BASE_1ST_KIND);
}


int abc_geohist_has_base_darcy_flux(
     AbcGeohistory *hist)
{
      return (hist->type_base_pres_BC == ABC_BC_BASE_2ND_KIND);
}


int abc_get_elems_in_geohistory(
     AbcGeohistory *hist)
{
     int n_x_elems = abc_get_x_elems_in_geohistory(hist);
     int n_y_elems = abc_get_y_elems_in_geohistory(hist);
     int n_z_elems = abc_get_z_elems_in_geohistory(hist);
     int n_elems = n_x_elems * n_y_elems * n_z_elems;
     return n_elems;
}


int abc_get_nodes_in_geohistory(
     AbcGeohistory *hist)
{
     int n_x_nodes = abc_get_x_nodes_in_geohistory(hist);
     int n_y_nodes = abc_get_y_nodes_in_geohistory(hist);
     int n_z_nodes = abc_get_z_nodes_in_geohistory(hist);
     int n_nodes = n_x_nodes * n_y_nodes * n_z_nodes;
     return n_nodes;
}


int abc_get_x_nodes_in_geohistory(
     AbcGeohistory *hist)
{
     return hist->n_x_nodes;
}


int abc_get_y_nodes_in_geohistory(
     AbcGeohistory *hist)
{
     return hist->n_y_nodes;
}


int abc_get_z_nodes_in_geohistory(
     AbcGeohistory *hist)
{
     int rows = abc_get_rows_in_geohistory(hist);
     int n_z_nodes = rows + 1;
     return n_z_nodes;
}


int abc_get_h_nodes_in_geohistory(
     AbcGeohistory *hist)
{
     int n_x_nodes = abc_get_x_nodes_in_geohistory(hist);
     int n_y_nodes = abc_get_y_nodes_in_geohistory(hist);
     int n_h_nodes = n_x_nodes * n_y_nodes;
     return n_h_nodes;
}


int abc_get_x_elems_in_geohistory(
     AbcGeohistory *hist)
{
     int n_x_elems = hist->n_x_nodes - 1;
     if (n_x_elems < 1) n_x_elems = 1;
     return n_x_elems;
}


int abc_get_y_elems_in_geohistory(
     AbcGeohistory *hist)
{
     int n_y_elems = hist->n_y_nodes - 1;
     if (n_y_elems < 1) n_y_elems = 1;
     return n_y_elems;
}


int abc_get_z_elems_in_geohistory(
     AbcGeohistory *hist)
{
     int n_z_elems = abc_get_rows_in_geohistory(hist);
     return n_z_elems;
}


int abc_get_h_elems_in_geohistory(
     AbcGeohistory *hist)
{
     int n_x_elems = abc_get_x_elems_in_geohistory(hist);
     int n_y_elems = abc_get_y_elems_in_geohistory(hist);
     int n_h_elems = n_x_elems * n_y_elems;
     return n_h_elems;
}


int abc_get_rows_in_geohistory(
     AbcGeohistory *hist)
{
     int i;
     int rows = 0;

     for (i = 0; i < hist->n_layers; i++)
          if (hist->layer[i]->type == ABC_LAYER_SEDIMENTATION)
               rows += hist->layer[i]->rows;

     return rows;
}


int abc_get_node_col_from_elem_col(
     AbcGeohistory *hist, 
     int elem_col1)
{
     int n_h_elems = abc_get_h_elems_in_geohistory(hist);
     int n_x_nodes = abc_get_x_nodes_in_geohistory(hist);
     int n_x_elems = abc_get_x_elems_in_geohistory(hist);
     int elem_col2 = elem_col1 % n_h_elems;
     int i = elem_col2 % n_x_elems;
     int j = elem_col2 / n_x_elems;
     int n = j * n_x_nodes + i;
     return n;
}


void abc_update_water_depth(
     AbcGeohistory *hist,
     double time,
     double *zcoord)
{
     int n_nodes = abc_get_nodes_in_geohistory(hist);
     int n_h_nodes = hist->n_h_nodes;
     int n, vline, ntop;
     double dz, depth;

     for (vline = 0; vline < n_h_nodes; vline++)
     {
          ntop = n_nodes - n_h_nodes + vline;

          if (not get_geohist_water_depth(hist, vline, time, &depth))
               ABC_ERROR_MESSAGE("Can't find the model water depth!");

          /* 
          ** The water depth is given by positive values in the geohistory.
          ** But these values become negative zcoord-values.
          */

          dz = (-depth) - zcoord[ntop];

          for (n = ntop; n >= 0; n -= n_h_nodes)
               zcoord[n] += dz;
     }
}


void abc_fill_in_geohistory_xcoords(
     AbcGeohistory *hist,
     double *xcoord)
{
     int k, n;
     int n_nodes = abc_get_nodes_in_geohistory(hist);

     for (n = 0; n < n_nodes; n++)
     {
          k = n % hist->n_h_nodes;
          xcoord[n] = hist->xcoord[k];
     }     
}


void abc_fill_in_geohistory_ycoords(
     AbcGeohistory *hist,
     double *ycoord)
{
     int k, n;
     int n_nodes = abc_get_nodes_in_geohistory(hist);

     for (n = 0; n < n_nodes; n++)
     {
          k = n % hist->n_h_nodes;
          ycoord[n] = hist->ycoord[k];
     }
}


void abc_fill_in_geohistory_zcoords(
     AbcGeohistory *hist, 
     double *zcoord)
{
     int i, j, k, n, n0, n1, n2;
     int rows = 0;
     int n_h_nodes = hist->n_h_nodes;
     double dz;

     for (n = 0; n < n_h_nodes; n++)
           zcoord[n] = 0.0;

     for (i = 0; i < hist->n_layers; i++)
     {
          AbcLayer *layer = hist->layer[i];

          if (layer->type != ABC_LAYER_SEDIMENTATION)
               continue;

          for (j = 0; j < layer->rows; j++)
          {
               rows++;
               n0 = n_h_nodes * rows;

               for (k = 0; k < n_h_nodes; k++)
               {
                    n2 = n0 + k;
                    n1 = n2 - n_h_nodes;
                    dz = layer->thickness[k] / layer->rows;
                    zcoord[n2] = zcoord[n1] + dz;
               }
          }
     }
}


void abc_fill_in_geohistory_lith_no(
     AbcGeohistory *hist,
     int *lith_no,
     int *form_no)
{
     int i, j, k, e0, e1, nn;
     int rows = 0;
     int n_h_elems = abc_get_h_elems_in_geohistory(hist);

     for (i = 0; i < hist->n_layers; i++)
     {
          AbcLayer *layer = hist->layer[i];

          if (layer->type != ABC_LAYER_SEDIMENTATION)
               continue;

          for (j = 0; j < layer->rows; j++)
          {
               e0 = n_h_elems * rows;
               rows++;

               for (k = 0; k < n_h_elems; k++)
               {
                    e1 = e0 + k;
                    nn = abc_get_node_col_from_elem_col(hist, e1);
                    lith_no[e1] = layer->lith_no[nn];
                    form_no[e1] = layer->form_no;
               }
          }
     }

     if (debug_lith_no)
          for (i = 0; i < rows; i++)
          {
               int *ln = &lith_no[n_h_elems * i];
               abc_print_geohistory_xy_lith_elem_no(stdout, hist, i, ln);
          }
}


void abc_store_geohistory_names(
     AbcGeohistory *hist,
     FILE* out)
{
     int i;

     fprintf(out, "\n");
     fprintf(out, "   char lith_names %d\n", hist->n_lithologies);

     for ( i = 0; i < hist->n_lithologies; i++)
          fprintf(out, "   \"%s\"\n", hist->lithology_name[i]);

     fprintf(out, "\n");
     fprintf(out, "   char formation_names %d\n", hist->n_formations);

     for ( i = 0; i < hist->n_formations; i++)
          fprintf(out, "   \"%s\"\n", hist->formation_name[i]);
}


void abc_store_geohistory_names_II(
     AbcGeohistory *hist,
     AbcOutputStreamII *stream)
{
     int i;
     int max_word = 32;
     int size1 = ABC_MAX(hist->n_lithologies, hist->n_formations);
     int size2 = max_word * size1;

     char *char_array = NULL;

     ABC_NEW_ARRAY(char_array, char, size2);

     /* Store the lithology names. */

     for (i = 0; i < hist->n_lithologies; i++)
          strcpy(&char_array[i * max_word], hist->lithology_name[i]);

     abc_write_strings_II(stream, "lith_names", 
          char_array, hist->n_lithologies, max_word);

     /* Store the formation names. */

     for ( i = 0; i < hist->n_formations; i++)
          strcpy(&char_array[i * max_word], hist->formation_name[i]);

     abc_write_strings_II(stream, "formation_names", 
          char_array, hist->n_formations, max_word);

     ABC_FREE(char_array);
}


int get_geohist_water_depth(
     AbcGeohistory *hist,
     int vline,
     double time,
     double *value)
{
     return abc_get_xy_boundary_value(hist, &(hist->water_depth), vline, time, value);
}


int get_geohist_temp_surface(
     AbcGeohistory *hist,
     int vline,
     double time,
     double *value)
{
     return abc_get_xy_boundary_value(hist, &(hist->temp_surface), vline, time, value);
}


int get_geohist_temp_base(
     AbcGeohistory *hist,
     int vline,
     double time,
     double *value)
{
     return abc_get_xy_boundary_value(hist, &(hist->temp_base), vline, time, value);
}


int get_geohist_heat_flux_base(
     AbcGeohistory *hist,
     int vline,
     double time,
     double *value)
{
     if (not abc_geohist_has_base_heat_flux(hist))
          ABC_ERROR_EXIT("[get_geohist_heat_flux_base] Missing hist!");

     return abc_get_xy_boundary_value(hist, &(hist->heat_flux_base), vline, time, value);
}


int get_geohist_pres_base(
     AbcGeohistory *hist,
     int vline,
     double time,
     double *value)
{
     if (not abc_geohist_has_base_pressure(hist))
          ABC_ERROR_EXIT("[get_geohist_pres_base] Missing hist!");

     return abc_get_xy_boundary_value(hist, &(hist->pres_base), vline, time, value);
}


int get_geohist_darcy_flux_base(
     AbcGeohistory *hist,
     int vline,
     double time,
     double *value)
{
     if (not abc_geohist_has_base_darcy_flux(hist))
          ABC_ERROR_EXIT("[get_geohist_darcy_flux] Missing hist!");

     return abc_get_xy_boundary_value(hist, &(hist->darcy_flux_base), vline, time, value);
}


int abc_get_xy_boundary_value(
     AbcGeohistory *hist,
     AbcXYBoundaryHist *bp,
     int vline,
     double time,
     double *value)
{
     double dt0, dt1, dt2, weight1, weight2, value1, value2;
     int max_k = bp->n_times - 1;
     int k = bp->current_index;

     *value = 0.0;

     if (vline < 0)
          ABC_RETURN_FALSE("[abc_get_xy_boundary_value] V-line index < 0!");
     
     if (vline > hist->n_h_nodes)
          ABC_RETURN_FALSE("[abc_get_xy_boundary_value] V-line index >= n_h_nodes!");

     if (time < bp->time[0])
          ABC_RETURN_FALSE("[abc_get_xy_boundary_value] Time is before geohistory!");

     if (time > bp->time[max_k])
          ABC_RETURN_FALSE("[abc_get_xy_boundary_value] Time is after geohistory!");

     /* Reset time-index. */

     if (time < bp->time[1])
          k = 1;
     
     while (k < max_k and time > bp->time[k])
          k++;

     dt0 = (bp->time[k] - bp->time[k-1]);

     if (dt0 < 1.0e-6)
          ABC_RETURN_FALSE("[abc_get_xy_boundary_value] BC info is to narrow in time!");

     dt1 = (time - bp->time[k-1]);
     dt2 = (bp->time[k] - time);

     weight1 = dt2 / dt0;
     weight2 = dt1 / dt0;

     value1 = bp->array[k-1][vline];
     value2 = bp->array[k][vline];

     *value = weight1 * value1 + weight2 * value2;
     return TRUE;
}


void abc_inspect_vline(
     AbcGeohistory *hist,
     int vline)
{
     AbcXYBoundaryHist *bp = &(hist->water_depth);
     int k_max = bp->n_times - 1;
     int i;
     double ztop = - bp->array[k_max][vline];
     double dz;

     printf("V-line: %d (for input: %d) at present time:\n", vline, vline+1);
     if (vline < 0 or hist->n_h_nodes <= vline) return;

     for (i = hist->n_layers - 1; i >= 0; i--)
     {
          AbcLayer *layer = hist->layer[i];
          if (layer->type != ABC_LAYER_SEDIMENTATION) continue;
          dz = layer->thickness[vline];
          printf("layer: %3d, dz: %9.3f, top: %10.3f, bot: %10.3f\n",
               i, dz, ztop, ztop - dz);
          ztop -= dz;
     }
}

/*
**   =======================================================
**   Private functions for reading input in BAS like format.
**   =======================================================
*/

static int read_geohistory(
     AbcInput *in,
     AbcGeohistory *hist)
{
     char word[ABC_MAX_WORD];

     abc_basic_zero_vector(hist->total_height, hist->n_h_nodes);

     if (not read_start_time(in, hist))
          RETURN_FALSE(in, "Error after \"begin_history_at\"!");

     while (abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, "end_history"))
     {
          if (ABC_MATCH(word, "formation"))
          {
               if (not read_formation_name(in, hist))
                    RETURN_FALSE(in, "Can't read \"formation\"!");
          }
          else if (ABC_MATCH(word, "set_max_time_step"))
          {
               if (not read_max_time_step(in, hist))
                    RETURN_FALSE(in, "Can't read \"set_max_time_step\"!");
          }
          else if (ABC_MATCH(word, "erosion"))
          {
               if (not read_erosion(in, hist))
                    RETURN_FALSE(in, "Can't read \"erosion\"!");
          }
          else if (ABC_MATCH(word, "sedimentation"))
          {
               if (not read_sedimentation(in, hist))
                    RETURN_FALSE(in, "Can't read \"sedimentation\"!");
          }
          else if (ABC_MATCH(word, "pause"))
          {
               if (not read_pause(in, hist))
                    RETURN_FALSE(in, "Can't read \"pause\"!");
          }
          else
               RETURN_FALSE(in, "Unknown word in history setup!");
     }

     if (not ABC_MATCH(word, "end_history"))
          RETURN_FALSE(in, "History part is not ended with \"end_history\"!");

     hist->time_end_hist = hist->current_t2;

     return TRUE;
}


static int read_start_time(
     AbcInput *in,
     AbcGeohistory *hist)
{
     double time;

     if (not abc_get_double(in, &time))
          RETURN_FALSE(in, "Expected time for simulation start!");

     hist->time_begin_hist = time;
     hist->current_t1 = time;
     hist->current_t2 = time;

     return TRUE;
}


static int read_max_time_step(
     AbcInput *in,
     AbcGeohistory *hist)
{
     double dt;

     if (not abc_get_double(in, &dt))
          RETURN_FALSE(in, "Expected a time step!");

     if (dt < 1.0e-6)
          RETURN_FALSE(in, "Too small time step!");

     hist->current_dt_max = dt;
     abc_add_layer_to_geohistory(hist, ABC_LAYER_DT_MAX, print_dt_max);

     return TRUE;
}


static int read_formation_name(
     AbcInput *in,
     AbcGeohistory *hist)
{
     char name[ABC_MAX_WORD];

     if (not read_name(in, name, ABC_MAX_WORD))
          RETURN_FALSE(in, "Expected a formation name!");

     hist->current_formation_no = abc_get_formation_number(hist, name);
     abc_add_layer_to_geohistory(hist, ABC_LAYER_FORMATION_NAME, print_formation_name);

     return TRUE;
}


int abc_get_formation_number(
     AbcGeohistory *hist,
     const char *name)
{
     int i;

     for (i = 0; i < hist->n_formations; i++)
          if (ABC_MATCH(name, hist->formation_name[i]))
               return i;

     return add_formation_name(hist, name);
}


int abc_get_lithology_number(
     AbcGeohistory *hist,
     const char *name)
{
     int i;
     
     for (i = 0; i < hist->n_lithologies; i++)
          if (ABC_MATCH(name, hist->lithology_name[i]))
               return i;

     return add_lithology_name(hist, name);
}


static int add_formation_name(
     AbcGeohistory *hist,
     const char *name)
{
     int no = hist->n_formations;

     if (no >= MAX_FORM_NAMES)
          ABC_ERROR_EXIT("Too many formation names!");

     hist->formation_name[no] = abc_save_string(name);
     hist->n_formations++;

     return no;
}


static int add_lithology_name(
     AbcGeohistory *hist,
     const char *name)
{
     int no = hist->n_lithologies;

     if (no >= MAX_LITH_NAMES)
          ABC_ERROR_EXIT("Too many lithology names!");

     hist->lithology_name[no] = abc_save_string(name);
     hist->n_lithologies++;

     return no;
}


static int read_erosion(
     AbcInput *in,
     AbcGeohistory *hist)
{
     int n_h_nodes = hist->n_h_nodes;
     double *thickness = hist->current_thickness;
     char word[ABC_MAX_WORD];
     double t2;
     int i;

     if (not read_node_values(in, hist, hist->current_thickness))
          RETURN_FALSE(in, "Error after key word \"erosion\"!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "until"))
          RETURN_FALSE(in, "Expected the key word \"until\"!");

     if (not abc_get_double(in, &t2))
          RETURN_FALSE(in, "Can't read the time after \"until\"!");

     if (t2 <= hist->current_t2)
          RETURN_FALSE(in, "History setup is not sequential in time!");

     /* Update time for end of history. */

     hist->current_t1 = hist->current_t2;
     hist->current_t2 = t2;

     /* Check the amount of erosion. */

     for (i = 0; i < n_h_nodes; i++)
         thickness[i] = - ABC_ABS(thickness[i]);

     for (i = 0; i < n_h_nodes; i++)
          hist->total_height[i] += thickness[i];

     for (i = 0; i < n_h_nodes; i++)
          if (hist->total_height[i] < 0.1)
               RETURN_FALSE(in, "Too much erosion; no basin left!");

     /* Add layer to geohistory. */

     abc_add_layer_to_geohistory(hist, ABC_LAYER_EROSION, print_erosion);

     return TRUE;
}


static int read_sedimentation(
     AbcInput *in,
     AbcGeohistory *hist)
{
     char word[ABC_MAX_WORD];
     int i;
     int n_fixed_nodes = 0;
     int n_h_nodes = hist->n_h_nodes;
     int *lithology = hist->current_lith_no;
     int got_thickness_error = FALSE;
     double *thickness = hist->current_thickness;
     double t2;

     if (hist->n_x_nodes == 0)
          RETURN_FALSE(in, "Number of grid nodes is zero!");

     if (not abc_get_word(in, word, ABC_MAX_WORD))
          RETURN_FALSE(in, "Expected more input after \"sedimentation\"!");

     abc_put_back_word(in, word);

     if (not read_layer_def(in, hist))
          RETURN_FALSE(in, "Error after \"sedimentation\"!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "with"))
          RETURN_FALSE(in, "Expected the key word \"with\"!");

     if (not abc_get_int(in, &hist->current_rows))
          RETURN_FALSE(in, "Can't read number of rows!");

     if (hist->current_rows < 1 or hist->current_rows > 250)
          RETURN_FALSE(in, "Number of rows must be between 1 and 250!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "rows"))
          RETURN_FALSE(in, "Expected the key word \"rows\"!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "until"))
          RETURN_FALSE(in, "Expected the key word \"until\"!");

     if (not abc_get_double(in, &t2))
          RETURN_FALSE(in, "Can't read the time after \"until\"!");

     if (t2 <= hist->current_t2)
          RETURN_FALSE(in, "History setup is not sequential in time!");

     /* Check for illegal sedimentation rates. */

     for (i = 0; i < n_h_nodes; i++)
          if (lithology[i] == LITH_EROSION)
               thickness[i] = - ABC_ABS(thickness[i]);

     for (i = 0; i < n_h_nodes; i++)
          hist->total_height[i] += thickness[i];

     for (i = 0; i < n_h_nodes; i++)
          if (hist->total_height[i] < 0.1)
               RETURN_FALSE(in, "Too much erosion; no basin left!");

     /* Check erosion process. */

     for (i = 0; i < n_h_nodes; i++)
     {
          if (thickness[i] >= 0.0 and lithology[i] != LITH_EROSION)
               continue;

          if (not is_legal_erosion_node(lithology, thickness, i))
               got_thickness_error = TRUE;
     }

     if (got_thickness_error)
          RETURN_FALSE(in, "Error in erosion process!");

     /* Make sure there are zero deposition nodes between erosion and deposition. */

     for (i = 0; i < n_h_nodes; i++)
          if (lithology[i] == LITH_EROSION)
               n_fixed_nodes += fix_zero_deposition_nodes(hist, i);

     if (n_fixed_nodes > 0 and not run_silent)
         printf("(%d zero deposition nodes introduced for time interval %g to %g)\n",
               n_fixed_nodes, hist->current_t1, hist->current_t2);

     /* Update current state and make a new layer. */

     hist->current_t1 = hist->current_t2;
     hist->current_t2 = t2;

     abc_add_layer_to_geohistory(hist, ABC_LAYER_SEDIMENTATION, print_sedimentation);

     /***
     t0 = hist->current_t1;
     dt = (hist->current_t2 - hist->current_t1) / hist->current_rows;

     for (i = 0; i < hist->n_h_nodes; i++)
          hist->current_thickness[i] /= hist->current_rows;

     hist->current_rows = 1;

     for (i = 0; i < rows; i++)
     {
          hist->current_t1 = t0 + i * dt;
          hist->current_t2 = hist->current_t1 + dt;
          abc_add_layer_to_geohistory(hist, ABC_LAYER_SEDIMENTATION);
     }
     ****/

     return TRUE;
}


static int fix_zero_deposition_nodes(
     AbcGeohistory *hist,
     int n0)
{
     int i, nn[4], size;
     int n_fixes = 0;
     int n_x_nodes = hist->n_x_nodes;
     int n_h_nodes = hist->n_h_nodes;
     int is_erosion_process = FALSE;
     int is_right_bounary_node = ((n0 + 1) % n_x_nodes == 0);
     int is_upper_boundary_node = (n0 >= n_h_nodes - n_x_nodes);
     int spatial_dimensions = hist->n_dim;
     double *layer_height = hist->current_thickness;

     if (spatial_dimensions == 1)
     {
          return 0;
     }
     else if (spatial_dimensions == 2)
     {
          if (is_right_bounary_node) return 0;

          nn[0] = n0;
          nn[1] = n0 + 1;
          size = 2;
     }
     else if (spatial_dimensions == 3)
     {
          if (is_right_bounary_node) return 0;
          if (is_upper_boundary_node) return 0;

          nn[0] = n0;
          nn[1] = n0 + 1;
          nn[2] = n0 + n_x_nodes + 1;
          nn[3] = n0 + n_x_nodes;
          size = 4;
     }
     else
          ABC_ERROR_EXIT("[fix_zero_deposition_nodes] Dimension error!");

     for (i = 0; i < size; i++)
          if (layer_height[nn[i]] < 0.0)
               is_erosion_process = TRUE;

     if (not is_erosion_process)
          return 0;

     for (i = 0; i < size; i++)
          if (layer_height[nn[i]] > 0.0)
          {
               layer_height[nn[i]] = 0.0;
               n_fixes++;
          }

     return n_fixes;
}


static int is_legal_erosion_node(
     int *lithology,
     double *layer_height,
     int n0)
{
     if (layer_height[n0] >= 0.0 and lithology[n0] != LITH_EROSION)
          return TRUE;

     if (layer_height[n0] < 0.0 and lithology[n0] == LITH_EROSION)
          return TRUE;

     if (layer_height[n0] < 0.0 and lithology[n0] != LITH_EROSION)
     {
          fprintf(stderr, "Expected a node with lithology \"erosion\" or a pos thickness!\n");
          fprintf(stderr, "(vertical node column = %d, thickness = %g)\n", 
               n0 + 1, layer_height[n0]);
          return FALSE;
     }

     if (layer_height[n0] > 0.0 and lithology[n0] == LITH_EROSION)
     {
          fprintf(stderr, "Can't have deposition and lithology \"erosion\"!\n");
          fprintf(stderr, "(node number on input file is %d)\n", n0 + 1);
          return FALSE;
     }

     /* 
     ** The remaining case is:
     ** (layer_height[n0] == 0.0 and lithology[n0] == LITH_EROSION)
     ** which is allowed.
     */

     return TRUE;
}


static int read_layer_def(
     AbcInput *in,
     AbcGeohistory *hist)
{
     int i, n, n0, n1, n0old, n1old, n0new, n1new;
     double dh, dy, step;
     int n_x_nodes = hist->n_x_nodes;
     int n_h_nodes = hist->n_h_nodes;
     int *lithology = hist->current_lith_no;
     double *thickness = hist->current_thickness;
     double *ycoord = hist->ycoord;

     if (not read_row_of_layer_defs(in, hist, &n0old, &n1old))
          RETURN_FALSE(in, "Can't read a layer definition in x-direction!");

     if (n0old != 0)
          RETURN_FALSE(in, "A triplet for v-line number 1 is missing!");

     while (n1old < n_h_nodes - 1)
     {
          if (not read_row_of_layer_defs(in, hist, &n0new, &n1new))
               RETURN_FALSE(in, "Can't read a layer definition in x-direction!");

          if (n0new <= n0old or n1new <= n1old)
               RETURN_FALSE(in, "Rows are not in increasing order!");

          for (i = 0; i < n_x_nodes; i++)
          {
               n0 = n0old + i;
               n1 = n0new + i;
               dy = ycoord[n1] - ycoord[n0];
               dh = thickness[n1] - thickness[n0];

               for (n = n0 + n_x_nodes; n < n1; n += n_x_nodes)
               {
                    step = ycoord[n] - ycoord[n0];
                    thickness[n] = thickness[n0] + (dh / dy) * step;

                    /* The interpolation can be -1.0e-13 instead of 0! */

                    if (-0.001 < thickness[n] and thickness[n] < 0.001)
                         thickness[n] = 0.0;

                    lithology[n] = lithology[n0];
               }
          }

          n0old = n0new;
          n1old = n1new;
     }

     if (debug_lith_no)
          abc_print_geohistory_xy_lith_node_no(stdout, hist, -1, lithology);

     if (n1old != n_h_nodes - 1)
          RETURN_FALSE(in, "The last triplet in a layer is missing!");

     return TRUE;
}


static int read_row_of_layer_defs(
     AbcInput *in,
     AbcGeohistory *hist,
     int *n0,
     int *n1)
{
     int lith0, lith1;
     int i, node0, node1, first_node_in_row;
     int n_x_nodes = hist->n_x_nodes;
     int n_h_nodes = hist->n_h_nodes;
     int *lithology = hist->current_lith_no;
     double *height = hist->current_thickness;
     double *xcoord = hist->xcoord;
     double grad, step, height0, height1;

     if (n_x_nodes == 0)
          RETURN_FALSE(in, "Number of grid nodes is zero!");

     if (not read_vline_triplet(in, hist, &node1, &height1, &lith1))
          RETURN_FALSE(in, "Error in \"v-line/lithology/height\"!");

     if (node1 % n_x_nodes != 0)
          RETURN_FALSE(in, "Expected the first node in a row!");

     if (n_h_nodes == 1)
     {
          height[0] = height1;
          lithology[0] = lith1;
          *n0 = node1;
          *n1 = node1;
          return TRUE;
     }

     first_node_in_row = node1;

     do
     {
          node0 = node1;
          lith0 = lith1;
          height0 = height1;

          if (not read_vline_triplet(in, hist, &node1, &height1, &lith1))
               RETURN_FALSE(in, "Error in \"v-line/lithology/height\"!");

          if (node1 <= node0)
               RETURN_FALSE(in, "Node numbers must be in increasing order!");

          grad = (height1 - height0) / (xcoord[node1] - xcoord[node0]);

          for (i = node0; i <= node1; i++)
          {
               step = xcoord[i] - xcoord[node0];
               height[i] = height0 + grad * step;

               /* The interpolation can be -1.0e-13 instead of 0! */

               if (-0.001 < height[i] and height[i] < 0.001)
                    height[i] = 0.0;

               if ((i > node0) or (i == first_node_in_row))
                    lithology[i] = lith0;
          }

          node0 = node1;
          lith0 = lith1;
          height0 = height1;

     } while (node1 < first_node_in_row + n_x_nodes - 1);

     if ((node1 + 1) % n_x_nodes != 0)
          RETURN_FALSE(in, "Expected last node in row!");

     *n0 = first_node_in_row;
     *n1 = node1;

     return TRUE;
}


static int read_vline_triplet(
     AbcInput *in,
     AbcGeohistory *hist,
     int *vline,
     double *height,
     int *lith_no)
{
     char c, name[ABC_MAX_WORD], word[ABC_MAX_WORD];

     if (not abc_get_int(in, vline))
          RETURN_FALSE(in, "Error in node number!");

     if ((c = (char) abc_get_word(in, word, ABC_MAX_WORD)) != '/')
          RETURN_FALSE(in, "Missing a \"/\" after v-line number!");

     if (not abc_get_word(in, name, ABC_MAX_WORD))
          RETURN_FALSE(in, "Missing lithology name after \"/\"!");

     *lith_no = abc_get_lithology_number(hist, name);

     if ((c = (char) abc_get_word(in, word, ABC_MAX_WORD)) != '/')
          RETURN_FALSE(in, "Missing a \"/\" after lithology name!");

     if (not abc_get_double(in, height))
          RETURN_FALSE(in, "Error in layer thickness!");

     if (*height < 0.0)
          RETURN_FALSE(in, "Sediment thickness must be a non-negative number!");

     if (ABC_MATCH(name, "erosion"))
          *height = - ABC_ABS(*height);

     /* The numbering of v-lines start at 1 on the input file. */
     (*vline)--; 

     return TRUE;
}


static int read_pause(
     AbcInput *in,
     AbcGeohistory *hist)
{
     double t2;
     char word[ABC_MAX_WORD];

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "until"))
          RETURN_FALSE(in, "Expected the key word \"until\"!");

     if (not abc_get_double(in, &t2))
          RETURN_FALSE(in, "Can't read the time after \"until\"!");

     if (t2 <= hist->current_t2)
          RETURN_FALSE(in, "History setup is not sequential in time!");

     hist->current_t1 = hist->current_t2;
     hist->current_t2 = t2;

     abc_add_layer_to_geohistory(hist, ABC_LAYER_PAUSE, print_pause);

     return TRUE;
}


static int read_node_values(
     AbcInput *in,
     AbcGeohistory *hist,
     double *values)
{
     int n_x_nodes = hist->n_x_nodes;
     int n_h_nodes = hist->n_h_nodes;
     int i, n, n0, n1, n0old, n1old, n0new, n1new;
     double *ycoord = hist->ycoord;
     double df, dy, step;

     if (not read_row_of_node_values(in, hist, values, &n0old, &n1old))
          RETURN_FALSE(in, "Can't read node values in x-direction!");

     if (n0old != 0)
          RETURN_FALSE(in, "Data for the first x-row of v-lines are missing!");

     /* NOTE: "y_node_pos" must be properly initialized. */

     while (n1old < n_h_nodes - 1)
     {
          if (not read_row_of_node_values(in, hist, values, &n0new, &n1new))
               RETURN_FALSE(in, "Can't read node values in x-direction!");

          if (n0new <= n0old or n1new <= n1old)
               RETURN_FALSE(in, "Rows are not in increasing order!");

          for (i = 0; i < n_x_nodes; i++)
          {
               n0 = n0old + i;
               n1 = n0new + i;
               dy = ycoord[n1] - ycoord[n0];
               df = values[n1] - values[n0];

               for (n = n0 + n_x_nodes; n < n1; n += n_x_nodes)
               {
                    step = ycoord[n] - ycoord[n0];
                    values[n] = values[n0] + (df / dy) * step;
               }
          }

          n0old = n0new;
          n1old = n1new;
     }

     if (n1old != n_h_nodes - 1)
          RETURN_FALSE(in, "Data for the last x-row of v-lines are missing!");

     return TRUE;
}


static int read_row_of_node_values(
     AbcInput *in,
     AbcGeohistory *hist,
     double *values,
     int *n0,
     int *n1)
{
     int n_x_nodes = hist->n_x_nodes;
     int n_h_nodes = hist->n_h_nodes;
     int i, node0, node1, first_node_in_row;
     double grad, value0, value1;

     *n0 = 0;
     *n1 = 0;

     if (not read_node_and_value(in, &node1, &value1))
          RETURN_FALSE(in, "Error in first \"v-line/value\"!");

     if (node1 % n_x_nodes != 0)
          RETURN_FALSE(in, "Expected the first v-line in a row!");

     if (n_h_nodes == 1)
     {
          values[0] = value1;
          *n0 = node1;
          *n1 = node1;
          return TRUE;
     }

     first_node_in_row = node1;

     do
     {
          node0 = node1;
          value0 = value1;

          if (not read_node_and_value(in, &node1, &value1))
               RETURN_FALSE(in, "Error in \"v-line/value\"!");

          if (node1 <= node0)
               RETURN_FALSE(in, "Nodes must be in increasing order!");

          grad = (value1 - value0) / (node1 - node0);

          for (i = node0; i <= node1; i++)
               values[i] = value0 + grad * (i - node0);

     } while (node1 < first_node_in_row + n_x_nodes - 1);

     if ((node1 + 1) % n_x_nodes != 0)
          RETURN_FALSE(in, "Expected last node in row!");

     *n0 = first_node_in_row;
     *n1 = node1;

     return TRUE;
}


static int read_node_and_value(
     AbcInput *in,
     int *some_node,
     double *some_value)
{
     char word[ABC_MAX_WORD];

     if (not abc_get_int(in, some_node))
          RETURN_FALSE(in, "Can't find a node number!");

     if (abc_get_word(in, word, ABC_MAX_WORD) != '/')
          RETURN_FALSE(in, "Missing \"/\" between node number and node value!");

     if (not abc_get_double(in, some_value))
          RETURN_FALSE(in, "Missing node value after a \"/\"!");

     (*some_node)--; /* Counting is from 1 on the input file. */

     return TRUE;
}


static int read_number_of_horizontal_nodes(
     AbcInput *in,
     AbcGeohistory *hist)
{
     char word[ABC_MAX_WORD];

     if (not abc_get_int(in, &hist->n_x_nodes))
          RETURN_FALSE(in, "Can't read number of x-nodes!");

     if (not abc_get_word(in, word, ABC_MAX_WORD))
          RETURN_FALSE(in, "Expected the keyword \"x\"!");

     if (not ABC_MATCH(word, "x"))
          RETURN_FALSE(in, "Missing \"x\" between max node numbers!");

     if (not abc_get_int(in, &hist->n_y_nodes))
          RETURN_FALSE(in, "Can't read number of y-nodes!");

     hist->n_h_nodes = hist->n_x_nodes * hist->n_y_nodes;

     if (hist->n_h_nodes < 1)
          RETURN_FALSE(in, "Number horizontal nodes must be larger than zero!");

     if (hist->n_h_nodes > MAX_H_NODES)
          RETURN_FALSE(in, "Number of horizontal nodes is to large!");

     if (hist->n_x_nodes == 1 and hist->n_y_nodes == 1)
          hist->n_dim = 1;
     else if (hist->n_x_nodes > 1 and hist->n_y_nodes > 1)
          hist->n_dim = 3;
     else
          hist->n_dim = 2;

     /* Allocate additional space. */

     ABC_FREE(hist->xcoord);
     ABC_FREE(hist->ycoord);
     ABC_FREE(hist->total_height);
     ABC_FREE(hist->current_thickness);
     ABC_FREE(hist->current_lith_no);

     ABC_NEW_ARRAY(hist->xcoord, double, hist->n_h_nodes);
     ABC_NEW_ARRAY(hist->ycoord, double, hist->n_h_nodes);
     ABC_NEW_ARRAY(hist->total_height, double, hist->n_h_nodes);
     ABC_NEW_ARRAY(hist->current_thickness, double, hist->n_h_nodes);
     ABC_NEW_ARRAY(hist->current_lith_no, int, hist->n_h_nodes);

     return TRUE;
}


static int read_horizontal_nodes(
     AbcInput *in,
     AbcGeohistory *hist)
{
     double *xpos = NULL;
     double *ypos = NULL;
     int n_h_nodes = hist->n_h_nodes;
     int n_x_nodes = hist->n_x_nodes;
     int check_xy_coords = TRUE;
     int i;

     if (n_x_nodes == 0)
          RETURN_FALSE(in, "Number of grid nodes is zero!");

     /* Important: Install default node positions. */

     for (i = 0; i < hist->n_h_nodes; i++)
          hist->xcoord[i] = i % hist->n_x_nodes;

     for (i = 0; i < hist->n_h_nodes; i++)
          hist->ycoord[i] = (int) (i / hist->n_x_nodes);

     ABC_NEW_ARRAY(xpos, double, n_h_nodes);
     ABC_NEW_ARRAY(ypos, double, n_h_nodes);
          
     if (not read_node_values(in, hist, xpos))
          RETURN_FALSE(in, "Can't read x-coords of vertical grid lines!");
          
     if (not read_node_values(in, hist, ypos))
          RETURN_FALSE(in, "Can't read y-coords of vertical grid lines!");
               
     /* Check that x-coords are ordered. */

     if (check_xy_coords)
          for (i = 0; i < n_h_nodes; i++)
          {
               if (i % n_x_nodes == 0)
                    continue;

               if (xpos[i-1] > xpos[i])
                    RETURN_FALSE(in, "X-node coordinats must be in increasing order!");
          }

     /* Check that y-coords are ordered. */

     if (check_xy_coords)
          for (i = n_x_nodes; i < n_h_nodes; i++)
          {
               int j = i - n_x_nodes;

               if (ypos[j] >= ypos[i])
                    RETURN_FALSE(in, "Y-node coords must be in increasing order!");
          }

     abc_basic_copy_vector(hist->xcoord, xpos, n_h_nodes);
     abc_basic_copy_vector(hist->ycoord, ypos, n_h_nodes);

     ABC_FREE_ARRAY(xpos);
     ABC_FREE_ARRAY(ypos);

     return TRUE;
}


static int read_name(
     AbcInput *in,
     char *name,
     int max_length)
{
     int c;

     abc_skip_blanks_and_comments(in);

     if ((c = abc_getch(in)) == '"')
     {
          abc_ungetch(in, c);
          return abc_get_string(in, name, max_length);
     }
     else
     {
          abc_ungetch(in, c);
          return abc_get_field(in, name, max_length);
     }
}


static int read_base_temp_bc(
     AbcInput *in,
     AbcGeohistory *hist)
{
     char word[ABC_MAX_WORD];

     if (not abc_get_word(in, word, ABC_MAX_WORD))
          RETURN_FALSE(in, "Expected \"begin_base_heat_flux\" or \"begin_base_temperature\"!");


     if (ABC_MATCH(word, "begin_base_heat_flux"))
          hist->type_base_temp_BC = ABC_BC_BASE_2ND_KIND;
     else if  (ABC_MATCH(word, "begin_base_temperature"))
          hist->type_base_temp_BC = ABC_BC_BASE_1ST_KIND;
     else
          RETURN_FALSE(in, "Expected \"begin_base_heat_flux\" or \"begin_base_temperature\"!");

     abc_put_back_word(in, word);

     return TRUE;
}


static int read_base_pres_bc(
     AbcInput *in,
     AbcGeohistory *hist)
{
     char word[ABC_MAX_WORD];

     if (not abc_get_word(in, word, ABC_MAX_WORD))
          RETURN_FALSE(in, "Expected \"begin_base_darcy_flux\" or \"begin_base_pressure\"!");


     if (ABC_MATCH(word, "begin_base_darcy_flux"))
          hist->type_base_pres_BC = ABC_BC_BASE_2ND_KIND;
     else if  (ABC_MATCH(word, "begin_base_pressure"))
          hist->type_base_pres_BC = ABC_BC_BASE_1ST_KIND;
     else
          hist->type_base_pres_BC = ABC_BC_BASE_CLOSED;

     abc_put_back_word(in, word);

     return TRUE;
}


static int read_xy_boundary_hist(
     AbcInput *in,
     AbcGeohistory *hist,
     AbcXYBoundaryHist *bp)
{
     int k = 0;
     char message1[ABC_MAX_WORD], message2[ABC_MAX_WORD], message3[ABC_MAX_WORD];
     char message4[ABC_MAX_WORD], message5[ABC_MAX_WORD], message6[ABC_MAX_WORD];
     char word[ABC_MAX_WORD], begin_key_word[ABC_MAX_WORD], end_key_word[ABC_MAX_WORD];

     sprintf(begin_key_word, "begin_%s", bp->name);
     sprintf(end_key_word, "end_%s", bp->name);
     sprintf(message1, "Expected keyword \"%s\"!", begin_key_word);
     sprintf(message2, "Expected keyword \"%s\"!", bp->short_name);
     sprintf(message3, "The %s-history is not sequential in time!", bp->short_name);
     sprintf(message4, "First %s is not at the start of geohistory!", bp->short_name);
     sprintf(message5, "Last %s is not at the end of geohistory!", bp->short_name);
     sprintf(message6, "Expected keyword \"%s\"!", end_key_word);

     /* Read the history of "values". */

     if (not abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, begin_key_word))
          RETURN_FALSE(in, message1);

     while (abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, end_key_word))
     {
          if (k >= MAX_GEOHIST_LAYERS)
               RETURN_FALSE(in, "Too many time steps in history!");

          ABC_NEW_ARRAY(bp->array[k], double, hist->n_h_nodes);

          if (not ABC_MATCH(word, bp->short_name))
               RETURN_FALSE(in, message2);

          if (not read_node_values(in, hist, bp->array[k]))
               RETURN_FALSE(in, "Can't read v-line values!");

          if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "at"))
               RETURN_FALSE(in, "Can't find the key word \"at\"!");

          if (not abc_get_double(in, &bp->time[k]))
               RETURN_FALSE(in, "Can't read the time!");

          if ((k == 0) and (ABC_ABS(bp->time[0] - hist->time_begin_hist) > 2.0e-6))
               RETURN_FALSE(in, message4);

          if ((k > 0) and (bp->time[k] - bp->time[k-1] < 1.0e-6))
               RETURN_FALSE(in, message3)

          k++;
     }

     bp->n_times = k;

     if (bp->n_times < 2)
          RETURN_FALSE(in, "Incomplete history!");

     if (not ABC_MATCH(word, end_key_word))
          RETURN_FALSE(in, message6);

     if (ABC_ABS(bp->time[k-1] - hist->time_end_hist) > 1.0e-6)
          RETURN_FALSE(in, message5);

     return TRUE;
}


static void read_error(
     AbcInput *in,
     char const *text)
{
     fprintf(stderr, "(line: %d, file: %s) %s\n", 
          abc_get_input_line_number(in),
          abc_get_input_file_name(in),
          text);
}


void abc_print_geohistory_xy_lith_elem_no(
     FILE *out,
     AbcGeohistory *hist,
     int row_no,
     int *lith_no)
{
     int nx = abc_get_x_elems_in_geohistory(hist);
     int ny = abc_get_y_elems_in_geohistory(hist);
     print_geohistory_xy_lith_no(out, nx, ny, row_no, lith_no);
}


void abc_print_geohistory_xy_lith_node_no(
     FILE *out,
     AbcGeohistory *hist,
     int row_no,
     int *lith_no)
{
     int nx = abc_get_x_nodes_in_geohistory(hist);
     int ny = abc_get_y_nodes_in_geohistory(hist);
     print_geohistory_xy_lith_no(out, nx, ny, row_no, lith_no);
}


static void print_geohistory_xy_lith_no(
     FILE *out,
     int nx,
     int ny,
     int row_no,
     int *lith_no)
{
     int i, j, n;

     fprintf(out, "LAYER: %d\n", row_no);

     for (j = ny - 1; j >= 0; j--)
     {
          fprintf(out, "row=%2d:", j);
          for (i = 0; i < nx; i++)
          {
               n = j * nx + i;
               fprintf(out, " %2d", lith_no[n]);
          }
          fprintf(out, "\n");
     }
}

