/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2011 by Magnus Wangen.
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
**
**   $Id$
*/

#ifndef _LIB_ROCK_PROP_H_
#define _LIB_ROCK_PROP_H_

#include <lib_input.h>
#include <lib_table.h>

#define ABC_POROSITY_FUNC              1
#define ABC_PERM_FUNC                  2
#define ABC_PERM_X_FUNC                3
#define ABC_PERM_Y_FUNC                4
#define ABC_PERM_Z_FUNC                5
#define ABC_HEAT_COND_FUNC             6
#define ABC_HEAT_COND_X_FUNC           7
#define ABC_HEAT_COND_Y_FUNC           8
#define ABC_HEAT_COND_Z_FUNC           9
#define ABC_HEAT_CAP_FUNC             10
#define ABC_DENSITY_FUNC              11
#define ABC_E_FUNC                    12
#define ABC_NU_FUNC                   13
#define ABC_BIOT_COEF_FUNC            14
#define ABC_ANGLE_INT_FRIC_FUNC       15 
#define ABC_COHESIVE_STRENGTH_FUNC    16
#define ABC_ROCK_STRENGTH_FUNC        17
#define ABC_FRAC_LIM_FUNC             18
#define ABC_FRAC_FAC_FUNC             19

#define ABC_MAX_ROCK_PARAMS           16
#define ABC_MAX_ROCK_NAME             32
#define ABC_MAX_ROCK_PROPS          1024
#define ABC_MAX_ROCK_TABLES         1024
#define ABC_MAX_ROCKS               1024

typedef struct _AbcRockArg_           AbcRockArg;
typedef struct _AbcRockParam_         AbcRockParam;
typedef struct _AbcRockProp_          AbcRockProp;
typedef struct _AbcRock_              AbcRock;
typedef struct _AbcRockLib_           AbcRockLib;
typedef struct _AbcRockPropDef_       AbcRockPropDef;
typedef struct _AbcListOfRockProps_   AbcListOfRockProps;

typedef double (*ABC_GET_ROCK_PROP)(AbcRockProp *prop, AbcRockArg *arg);
typedef void   (*ABC_PRINT_ROCK_PROP)(FILE *out, AbcRockProp *prop);
typedef void   (*ABC_DEF_ROCK_PROP)(AbcRockProp *prop);

struct _AbcRockArg_ {
     double phi;
     double z_depth;
     double zeta_depth;
     double ps;
     double pex;
     double pf;
     double ph;
     double pb;
     double temp1;
     double temp0;
     double dt;
     double heat_cond_fluid;
     /* Not strictly needed, but useful for debugging. */
     AbcRock *rock;
     int elem;
};

struct _AbcRockParam_ {
     char name[ABC_MAX_ROCK_NAME];
     char unit[ABC_MAX_ROCK_NAME];
     double value;
     double default_value;
     double min_value;
     double max_value;
     int is_used;
};

struct _AbcRockProp_ {
     int type;
     char name[ABC_MAX_ROCK_NAME];
     char func[ABC_MAX_ROCK_NAME];
     char unit[ABC_MAX_ROCK_NAME];
     char table_name[ABC_MAX_ROCK_NAME];
     AbcTable *table;
     int n_params;
     AbcRockParam param[ABC_MAX_ROCK_PARAMS];
     ABC_PRINT_ROCK_PROP print;
     ABC_GET_ROCK_PROP get;
     AbcRock *rock;
};

struct _AbcRock_ {
     char name[ABC_MAX_ROCK_NAME];
     int is_needed;
     AbcRockProp porosity;
     AbcRockProp density;
     AbcRockProp heat_cap;
     AbcRockProp perm;
     AbcRockProp perm_x;
     AbcRockProp perm_y;
     AbcRockProp perm_z;
     AbcRockProp heat_cond;
     AbcRockProp heat_cond_x;
     AbcRockProp heat_cond_y;
     AbcRockProp heat_cond_z;
     AbcRockProp E;
     AbcRockProp nu;
     AbcRockProp biot_coef;
     AbcRockProp angle_fric;
     AbcRockProp cohesive_str;
     AbcRockProp rock_strength;
     AbcRockProp frac_lim;
     AbcRockProp frac_fac;
};

struct _AbcRockLib_ {
     int n_rocks;
     AbcRock rock[ABC_MAX_ROCKS];
     int n_tables;
     AbcTable *table[ABC_MAX_ROCK_TABLES];
};

struct _AbcRockPropDef_ {
     char name[ABC_MAX_ROCK_NAME];
     ABC_DEF_ROCK_PROP def_prop;
};    

struct _AbcListOfRockProps_ {
     int n_props;
     AbcRockPropDef prop[ABC_MAX_ROCK_PROPS];
};

int abc_test_rock_lib(int argc, char **argv);
void abc_test_rock(FILE *out, AbcRock *rock);
void abc_init_rock_arg(AbcRockArg *arg);
void abc_print_rock_arg(FILE *out, AbcRockArg *arg);
void abc_set_rock_lib_range_checking(int on_off);
double abc_get_rock_heat_cap(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_density(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_porosity(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_heat_cond(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_heat_cond_x(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_heat_cond_y(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_heat_cond_z(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_perm(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_perm_x(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_perm_y(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_perm_z(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_youngs_modulus(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_poisson_ratio(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_biot_coef(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_angle_friction(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_cohesive_strength(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_strength(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_frac_lim(AbcRock *rock, AbcRockArg *arg);
double abc_get_rock_frac_fac(AbcRock *rock, AbcRockArg *arg);
int abc_rock_has_perm_tensor(AbcRock *rock);
int abc_rock_has_heat_cond_tensor(AbcRock *rock);
void abc_make_diag_perm_tensor(AbcRock *rock, AbcRockArg *arg, double K_diag[3]);
void abc_make_diag_heat_cond_tensor(AbcRock *rock, AbcRockArg *arg, double K_diag[3]);
int abc_rock_has_prop(AbcRockProp *prop);
int abc_rock_has_prop_by_name(AbcRock *rock, const char *name);
int abc_rock_has_prop_by_type(AbcRock *rock, int type);
void abc_init_rock_prop_lib(void);
void abc_add_rock_prop_to_lib(AbcListOfRockProps *list, 
     const char *name, ABC_DEF_ROCK_PROP def_prop);
void abc_init_rock_lib(AbcRockLib *lib);
void abc_delete_rock_lib(AbcRockLib *lib);
void abc_print_rock_lib_to_file(AbcRockLib *lib, const char *filename);
void abc_show_rock_lib(FILE *out, AbcRockLib *lib);
void abc_show_rock(FILE *out, AbcRock *rock);
void abc_show_rock_prop(FILE *out, AbcRockProp *prop);
void abc_show_rock_param(FILE *out, AbcRockParam *param, int ch);
AbcRock *abc_get_rock_from_lib(AbcRockLib *lib, const char *name);
int abc_read_rock_lib_from_file(AbcRockLib *lib, const char *filename);
int abc_read_rock_lib(AbcInput *in, AbcRockLib *rock);
int abc_read_table_to_lib(AbcInput *in, AbcRockLib *lib);
int abc_read_rock_to_lib(AbcInput *in, AbcRockLib *lib);
int abc_read_rock(AbcInput *in, AbcRock *rock);
int abc_read_rock_func(AbcInput *in, char *name);
ABC_DEF_ROCK_PROP abc_get_rock_prop_def_func(
     AbcListOfRockProps *list, const char *name);
int abc_read_rock_prop(AbcInput *in, AbcRockProp *prop, int type);
int abc_read_rock_prop_type(AbcInput *in);
const char *abc_get_rock_prop_name_by_type(int type);
int abc_get_rock_prop_type_by_name(const char *name);
AbcRockProp *abc_get_rock_prop_by_type(AbcRock *rock, int type);
AbcRockProp *abc_get_rock_prop_by_name(AbcRock *rock, const char *name);
int abc_read_rock_prop_params(AbcInput *in, AbcRockProp *prop);
AbcTable *abc_get_rock_prop_table(AbcRockLib *lib, const char *name);
int abc_set_prop_param_values(AbcRockProp *pdef, AbcRockProp *values);
AbcRockParam *abc_get_rock_prop_param(AbcRockProp *p1, const char *name);
int abc_assign_rock_param_value(AbcRockParam *param, AbcRockParam *pval);
void abc_set_rock_prop(AbcRockProp *prop, int type, 
     const char *unit, ABC_GET_ROCK_PROP get);
void abc_def_rock_prop_param(AbcRockProp *prop, int i, 
     const char *name, const char *unit, 
     double default_value, double min_value, double max_value);
int abc_all_rocks_in_lib_have_prop(AbcRockLib *lib, int type, int only_needed);
int abc_is_ok_rock_lib(AbcRockLib *lib);
int abc_is_complete_rock(AbcRock *rock);
int abc_is_needed_rock(AbcRock *rock);
void abc_init_rock(AbcRock *rock);
void abc_init_rock_prop(AbcRockProp *prop, const char *name);

#endif

