/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1999-2001 by M. Wangen.
**
**   Info: Functions for time stepping
**   Date: Version 1.0, November 1999
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   Default time stepping:
**
**   The first time step is "dt_first", which becomes "dt_wanted".
**   The wanted time step is then increased by the factor "dt_factor"
**   after each use.  The wanted time step increases until "dt_max".
**   The time step is not always dt_wanted.  It happens that a
**   short step is made because of an action.  The actual time
**   step used becomes "dt_used".
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_alloc.h>
#include <lib_macros.h>
#include <lib_utils.h>
#include <lib_args.h>
#include <lib_actions.h>
#include <lib_time_stepper.h>

#define RETURN_FALSE(in, text) {abc_read_error(in, text); return FALSE;}
#define RETURN_FALSE2(in, text1, text2) {abc_read_error2(in, text1, text2); return FALSE;}

static void add_my_action(AbcActionList *list, const char *name, double t, int pri);
static void take_action(AbcAction *action);
static int do_time_step(AbcTimeStepper *timestepper, double t1, double dt);
static void action_set_dt_wanted(AbcAction *action);
static void action_set_dt_max(AbcAction *action);
static void action_set_dt_factor(AbcAction *action);
static void action_set_dt_first(AbcAction *action);
static AbcTimeStepper *get_action_time_stepper(AbcAction *action);
static double get_action_value(AbcAction *action);
static void print_action(FILE *out, AbcActionList *list, AbcAction *action);


/*
**   ==================
**   A demo application
**   ==================
*/

#ifdef _ABC_MAIN_TIME_STEPPER
int main(
#else
int abc_test_time_stepper(
#endif
     int argc,
     char **argv)
{
     AbcTimeStepper ts;
     AbcActionList action_list;

     double t_begin = 0.0;
     double t_end = 100.0;
     double dt_wanted = 5.0;

     abc_init_action_list(&action_list);
     add_my_action(&action_list, "PRINT1", 0.0, 1);
     add_my_action(&action_list, "PRINT2", 0.0, 2);
     add_my_action(&action_list, "PRINT3", 0.0, 3);
     add_my_action(&action_list, "PRINT2", 20.0, 2);
     add_my_action(&action_list, "PRINT1", 40.0, 1);
     add_my_action(&action_list, "PRINT2", 40.0, 2);
     add_my_action(&action_list, "PRINT3", 40.0, 3);
     add_my_action(&action_list, "PRINT2", 60.0, 2);
     add_my_action(&action_list, "PRINT2", 80.0, 2);
     add_my_action(&action_list, "PRINT1", 100.0, 1);
     add_my_action(&action_list, "PRINT2", 100.0, 2);
     add_my_action(&action_list, "PRINT3", 100.0, 3);
     abc_print_action_list(stdout, &action_list);
     printf("-------\n");
     abc_print_reverse_action_list(stdout, &action_list);
     printf("-------\n");

     abc_init_time_stepper(&ts, t_begin, t_end, dt_wanted, 
          do_time_step, abc_make_time_stepper_dt);
     abc_init_time_stepper_extra(&ts, 0.1, 0.1, 5.0, 1.2);
     abc_print_time_stepper(stdout, &ts);
     printf("-------\n");
     abc_run_time_stepper(&ts, &action_list);

     ABC_UNUSED_PARAMETER(argc);
     ABC_UNUSED_PARAMETER(argv);
                          
     return 0;
}


static void add_my_action(
     AbcActionList *list,
     const char *name,
     double time,
     int priority)
{
     AbcAction *action = abc_create_action(0, time,
          priority, (void *) name, NULL, take_action);
     abc_insert_action(list, action);
}


static void take_action(
     AbcAction *action)
{
     printf("(time=%g, action: %s, priority: %d)\n", 
          action->time, (char *) action->buffer1, action->priority);
}


static int do_time_step(
     AbcTimeStepper *timestepper,
     double t1,
     double dt)
{
     printf("(time=%g, has done a time step dt=%g from t0=%g)\n", t1, dt, t1 - dt);
     ABC_UNUSED_PARAMETER(timestepper);
     return TRUE;
}

/*
**   =================
**   Library functions
**   =================
*/

void abc_init_time_stepper_with_args(
     AbcTimeStepper *timestepper,
     AbcArgs *args)
{
     char option[ABC_MAX_WORD], value_part[ABC_MAX_WORD];
     const char *arg;
     double value;

     abc_restart_reading_args(args);

     while ((arg = abc_get_next_arg(args)) != NULL)
     {
          abc_interpret_option(arg, option, value_part, &value);

          if      (ABC_MATCH(option, "tBegin"))    timestepper->t_begin = value;
          else if (ABC_MATCH(option, "tEnd"))      timestepper->t_end = value;
          else if (ABC_MATCH(option, "dtMin"))     timestepper->dt_min = value;
          else if (ABC_MATCH(option, "dtMax"))     timestepper->dt_max = value;
          else if (ABC_MATCH(option, "dtFactor"))  timestepper->dt_factor = value;
          else if (ABC_MATCH(option, "dtFirst"))   timestepper->dt_first = value;
          else abc_current_arg_is_unused(args);
     }

     if (not abc_is_ok_time_stepper(timestepper))
          ABC_ERROR_EXIT("[time_stepper] Time stepper is not properly initialized!");
}


void abc_show_time_stepper_options(
     FILE *out)
{
     fprintf(out, "Time stepper options:\n");
     fprintf(out, "   tBegin=<numb>   Time start.\n");
     fprintf(out, "   tEnd=<numb>     Time end.\n");
     fprintf(out, "   dtMin=<numb>    Min allowed time step.\n");
     fprintf(out, "   dtMax=<numb>    Max allowed time step.\n");
     fprintf(out, "   dtFactor=<numb> Time step factor.\n");
     fprintf(out, "   dtFirst=<numb>  First time step.\n");
}


void abc_init_time_stepper_with_args2(
     AbcTimeStepper *timestepper,
     AbcArgs *args)
{
     const char *option;

     abc_restart_reading_args(args);

     while ((option = abc_get_next_arg(args)) != NULL)
     {
          if      (ABC_MATCH(option, "-t-begin"))    timestepper->t_begin = abc_get_darg(args);
          else if (ABC_MATCH(option, "-t-end"))      timestepper->t_end = abc_get_darg(args);
          else if (ABC_MATCH(option, "-dt-min"))     timestepper->dt_min = abc_get_darg(args);
          else if (ABC_MATCH(option, "-dt-max"))     timestepper->dt_max = abc_get_darg(args);
          else if (ABC_MATCH(option, "-dt-factor"))  timestepper->dt_factor = abc_get_darg(args);
          else if (ABC_MATCH(option, "-dt-first"))   timestepper->dt_first = abc_get_darg(args);
          else abc_current_arg_is_unused(args);
     }

     if (not abc_is_ok_time_stepper(timestepper))
          ABC_ERROR_EXIT("[time_stepper] Time stepper is not properly initialized!");
}


void abc_show_time_stepper_options2(
     FILE *out)
{
     fprintf(out, "Time stepper options:\n");
     fprintf(out, "   -t-begin <numb>      Time start.\n");
     fprintf(out, "   -t-end <numb>        Time end.\n");
     fprintf(out, "   -dt-min <numb>       Min allowed time step.\n");
     fprintf(out, "   -dt-max <numb>       Max allowed time step.\n");
     fprintf(out, "   -dt-factor <numb>    Time step factor.\n");
     fprintf(out, "   -dt-first <numb>     First time step.\n");
}


void abc_init_default_time_stepper(
     AbcTimeStepper *timestepper,
     double t_begin,
     double t_end,
     double dt_first,
     double dt_max,
     double dt_factor,
     ABC_DO_ONE_TIME_STEP do_one_timestep)
{
     if (dt_first > dt_max) dt_first = dt_max;
 
     timestepper->t_current = t_begin;
     timestepper->t_begin = t_begin;
     timestepper->t_end = t_end;
     timestepper->dt_wanted = dt_first;
     timestepper->dt_first = dt_first;
     timestepper->dt_min = dt_first;
     timestepper->dt_max = dt_max;
     timestepper->dt_factor = dt_factor;
     timestepper->do_one_timestep = do_one_timestep;
     timestepper->make_time_step = abc_make_time_stepper_dt;
     timestepper->is_debugging = FALSE;
     timestepper->is_verbose = TRUE;

     if (not abc_is_ok_time_stepper(timestepper))
          ABC_ERROR_EXIT("[abc_init_default_time_stepper] Can't continue!");
}


void abc_init_time_stepper(
     AbcTimeStepper *timestepper,
     double t_begin,
     double t_end,
     double dt_wanted,
     ABC_DO_ONE_TIME_STEP do_one_timestep,
     ABC_MAKE_TIME_STEP make_time_step)
{
     timestepper->t_current = t_begin;
     timestepper->t_begin = t_begin;
     timestepper->t_end = t_end;
     timestepper->dt_wanted = dt_wanted;
     timestepper->dt_first = dt_wanted;
     timestepper->dt_min = dt_wanted;
     timestepper->dt_max = dt_wanted;
     timestepper->dt_factor = 1.0;
     timestepper->do_one_timestep = do_one_timestep;
     timestepper->is_debugging = FALSE;
     timestepper->is_verbose = FALSE;

     if (make_time_step == NULL)
          timestepper->make_time_step = abc_make_time_stepper_dt;
     else
          timestepper->make_time_step = make_time_step;

     timestepper->model = NULL;

     if (not abc_is_ok_time_stepper(timestepper))
          ABC_ERROR_EXIT("[time_stepper] Can't continue!");
}


void abc_init_time_stepper_extra(
     AbcTimeStepper *timestepper,
     double dt_first,
     double dt_min,
     double dt_max,
     double dt_factor)
{
     timestepper->dt_first = dt_first / dt_factor;
     timestepper->dt_min = dt_min;
     timestepper->dt_max = dt_max;
     timestepper->dt_factor = dt_factor;

     if (not abc_is_ok_time_stepper(timestepper))
          ABC_ERROR_EXIT("[time_stepper] Can't continue!");
}


void abc_init_time_stepper_do_function(
     AbcTimeStepper *timestepper,
     ABC_DO_ONE_TIME_STEP do_one_timestep)
{
     timestepper->do_one_timestep = do_one_timestep;
}


void abc_init_time_stepper_make_function(
     AbcTimeStepper *timestepper,
     ABC_MAKE_TIME_STEP make_time_step)
{
     timestepper->make_time_step = make_time_step;
}


void abc_init_time_stepper_model(
     AbcTimeStepper *timestepper,
     void *model)
{
     timestepper->model = model;
}


void abc_set_time_stepper_debugging_on_off(
     AbcTimeStepper *timestepper, 
     int on_off)
{
     timestepper->is_debugging = on_off;
}


void abc_set_time_stepper_dt_first(
     AbcTimeStepper *timestepper,
     double dt_first)
{
     if (dt_first > timestepper->dt_max)
          dt_first = timestepper->dt_max;

     if (timestepper->is_debugging)
          printf("(time %g: setting dt_first=%g)\n", timestepper->t_current, dt_first);

     timestepper->dt_first = dt_first;
}


void abc_set_time_stepper_dt_max(
     AbcTimeStepper *timestepper,
     double dt_max)
{
     if (timestepper->dt_min > dt_max)
          timestepper->dt_min = dt_max;

     if (timestepper->is_debugging)
          printf("(time %g: setting dt_max=%g)\n", timestepper->t_current, dt_max);

     timestepper->dt_max = dt_max;
}


void abc_set_time_stepper_dt_wanted(
     AbcTimeStepper *timestepper,
     double dt_wanted)
{
     if (dt_wanted > timestepper->dt_max)
          dt_wanted = timestepper->dt_max;     

     if (dt_wanted < timestepper->dt_min)
          dt_wanted = timestepper->dt_min;     

     if (timestepper->is_debugging)
          printf("(time %g: setting dt_wanted=%g)\n", timestepper->t_current, dt_wanted);

     timestepper->dt_wanted = dt_wanted;
}


void abc_set_time_stepper_dt_factor(
     AbcTimeStepper *timestepper,
     double dt_factor)
{
     if (dt_factor < 1.0)
          dt_factor = 1.0;

     if (timestepper->is_debugging)
          printf("(time %g: setting dt_factor=%g)\n", timestepper->t_current, dt_factor);

     timestepper->dt_factor = dt_factor;
}


int abc_is_ok_time_stepper(
     AbcTimeStepper *timestepper)
{
     double dt_first = timestepper->dt_first;
     double dt_min = timestepper->dt_min;
     double dt_max = timestepper->dt_max;
     double dt_factor = timestepper->dt_factor;
     int is_OK = TRUE;

     if (dt_min > dt_max)
     {
          fprintf(stderr, "[time_stepper] dt_min > dt_max!\n");
          is_OK = FALSE;
     }

     if (dt_factor * dt_first < 0.999 * dt_min)
     {
          fprintf(stderr, "[time_stepper] dt_first < dt_min!\n");
          is_OK = FALSE;
     }

     if (dt_factor < 1.0)
     {
          fprintf(stderr, "[time_stepper] dt_factor < 1!\n");
          is_OK = FALSE;
     }

     if (not is_OK)
          abc_print_time_stepper(stderr, timestepper);
     

     return is_OK;
}


void abc_print_time_stepper(
     FILE *out,
     AbcTimeStepper *timestepper)
{
     fprintf(out, "timestepper->t_begin = %g\n", timestepper->t_begin);
     fprintf(out, "timestepper->t_end = %g\n", timestepper->t_end);
     fprintf(out, "timestepper->dt_wanted = %g\n", timestepper->dt_wanted);
     fprintf(out, "timestepper->dt_first = %g\n", timestepper->dt_first);
     fprintf(out, "timestepper->dt_min = %g\n", timestepper->dt_min);
     fprintf(out, "timestepper->dt_max = %g\n", timestepper->dt_max);
     fprintf(out, "timestepper->dt_factor = %g\n", timestepper->dt_factor);
}


void abc_stop_time_stepper(
     AbcTimeStepper *timestepper)
{
     timestepper->t_end = timestepper->t_current;
}


void abc_make_time_stepper_dt(
     AbcTimeStepper *timestepper)
{
     timestepper->dt_wanted *= timestepper->dt_factor;

     if (timestepper->dt_wanted > timestepper->dt_max)
          timestepper->dt_wanted = timestepper->dt_max;

     if (timestepper->dt_wanted < timestepper->dt_min)
          timestepper->dt_wanted = timestepper->dt_min;
}


void abc_run_time_stepper(
     AbcTimeStepper *timestepper,
     AbcActionList *action_list)
{
     int OK;
     double t, dt, dt_overshoot, t_prev, dt_prev;
     double t_begin = timestepper->t_begin;
     double epsilon = abc_get_action_dt_epsilon();
     AbcAction *action = NULL;

     if (action_list != NULL)
          action = action_list->first;

     if ((action_list != NULL) and (not abc_is_ok_action_list(action_list)))
          ABC_ERROR_EXIT("[time_stepper] Error in action-list!");

     while ((action != NULL) and (action->time + epsilon < t_begin))
          action = action->next;

     while ((action != NULL) and abc_is_same_action_time(t_begin, action->time))
     {
          if (timestepper->is_verbose) print_action(stdout, action_list, action);
          action->take_action(action);
          action = action->next;
     }

     timestepper->dt_wanted = timestepper->dt_first;

     for (t = t_begin; t < timestepper->t_end; )
     {
          do
          {
               t_prev = timestepper->t_current;
               dt_prev = timestepper->dt_used;

               if (timestepper->make_time_step != NULL)
                    timestepper->make_time_step(timestepper);

               dt = timestepper->dt_wanted;
               t += dt;

               if (t > timestepper->t_end)
               {
                    dt_overshoot = t - timestepper->t_end;
                    dt -= dt_overshoot;
                    t -= dt_overshoot;
               }

               if (action != NULL and (t + epsilon >= action->time))
               {
                    dt_overshoot = t - action->time;
                    dt -= dt_overshoot;
                    t -= dt_overshoot;
               }

               timestepper->dt_used = dt;
               timestepper->t_current = t;

               if (timestepper->do_one_timestep == NULL)
                    ABC_ERROR_EXIT("[time_stepper] Missing timestep function!");

               /* NOTE: Time-stepping brings us from time t-dt to t. */

               OK = timestepper->do_one_timestep(timestepper, t, dt);

               if (not OK)
               {
                    t -= dt;
                    timestepper->dt_used = dt_prev;
                    timestepper->t_current = t_prev;
               }
          }
          while (not OK);

          while ((action != NULL) and abc_is_same_action_time(t, action->time))
          {
               if (timestepper->is_verbose) print_action(stdout, action_list, action);
               action->take_action(action);
               action = action->next;
          }
     }
}


static void print_action(
     FILE *out,
     AbcActionList *list,
     AbcAction *action)
{
     fprintf(out, "(time=%g, taking action: \"%s\", type: %d, priority: %d)\n",
          action->time, abc_get_action_name(list, action->type),
          action->type, action->priority);
}

/*
**   =========================================================
**   Functions for adding actions that modify the timestepper.
**   =========================================================
*/

/*
**   An example of a file with time stepper actions.
**   
**   begin_time_step_actions
**        at -175 set_max_time_step 1.0
**        at -175 set_first_time_step 0.001
**        at -175 set_time_step_factor 2.0
**   
**        at -50 set_max_time_step 10.0
**        at -50 set_time_step_factor 1.5
**   end_time_step_actions
*/

int abc_read_time_steps_actions_from_file(
     AbcActionList *list,
     AbcTimeStepper *ts,
     const char *filename)
{
     static AbcInput in;

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Error: Can't open file: %s!\n", filename);
          exit(1);
     }

     if (not abc_read_time_steps_actions(&in, list, ts))
     {
          fprintf(stderr, "Error: Can't read time-step info from: %s!\n", filename);
          exit(1);
     }

     printf("(time-stepper actions are read from: %s)\n", filename);

     abc_end_input(&in);

     return TRUE;
}


int abc_read_time_steps_actions(
     AbcInput *in,
     AbcActionList *list,
     AbcTimeStepper *ts)
{
     char word[ABC_MAX_WORD];

     abc_define_action_type(list, ABC_ACTION_SET_DT_WANTED,   4, "set dt-wanted", action_set_dt_wanted);
     abc_define_action_type(list, ABC_ACTION_SET_DT_MAX,      4, "set dt-max",    action_set_dt_max);
     abc_define_action_type(list, ABC_ACTION_SET_DT_FACTOR,   4, "set dt-factor", action_set_dt_factor);
     abc_define_action_type(list, ABC_ACTION_SET_DT_FIRST,    4, "set dt-first",  action_set_dt_first);

     if (not abc_skip_until_word(in, "begin_time_step_actions"))
          RETURN_FALSE(in, "Expected \"begin_time_step_actions\"!");

     while (abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, "end_time_step_actions"))
     {
          abc_put_back_word(in, word);

          if (not read_one_time_step_action(in, list, ts))
               RETURN_FALSE(in, "Can't read time step action!");
     }

     return TRUE;
}


int read_one_time_step_action(
     AbcInput *in,
     AbcActionList *list,
     AbcTimeStepper *ts)
{
     double time, value;
     char word[ABC_MAX_WORD], keyword[ABC_MAX_WORD];

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "at"))
          RETURN_FALSE(in, "Expected keyword \"at\"!");

     if (not abc_get_double(in, &time))
          RETURN_FALSE(in, "Expected time after \"at\"!");

     if (not abc_get_word(in, keyword, ABC_MAX_WORD))
          RETURN_FALSE(in, "Expected a set-timestepper keyword!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "="))
          RETURN_FALSE(in, "Expected the equal sign!");

     if (not abc_get_double(in, &value))
          RETURN_FALSE(in, "Expected a time-value!");

     if      (ABC_MATCH(keyword, "set_dt_max"))
          abc_add_time_stepper_action(list, ts, ABC_ACTION_SET_DT_MAX, value, time);
     else if (ABC_MATCH(keyword, "set_dt_wanted"))
          abc_add_time_stepper_action(list, ts, ABC_ACTION_SET_DT_WANTED, value, time);
     else if (ABC_MATCH(keyword, "set_dt_factor"))
          abc_add_time_stepper_action(list, ts, ABC_ACTION_SET_DT_FACTOR, value, time);
     else if (ABC_MATCH(keyword, "set_dt_first"))
          abc_add_time_stepper_action(list, ts, ABC_ACTION_SET_DT_FIRST, value, time);
     else
          RETURN_FALSE2(in, "Unknown keyword!", word);

     return TRUE;
}


void abc_add_time_stepper_action(
     AbcActionList *list,
     AbcTimeStepper *ts,
     int type,
     double value,
     double time)
{
     AbcTimeStepper **pts;
     double *pvalue;

     ABC_NEW_OBJECT(pts, AbcTimeStepper*);
     ABC_NEW_OBJECT(pvalue, double);

     *pts = ts;
     *pvalue = value;

     abc_add_defined_action(list, type, time, (void *) pts, (void *) pvalue);
}


static void action_set_dt_wanted(
     AbcAction *action)
{
     double dt_wanted = get_action_value(action);
     AbcTimeStepper *ts = get_action_time_stepper(action);

     abc_set_time_stepper_dt_wanted(ts, dt_wanted);
}


static void action_set_dt_max(
     AbcAction *action)
{
     double dt_max = get_action_value(action);
     AbcTimeStepper *ts = get_action_time_stepper(action);

     abc_set_time_stepper_dt_max(ts, dt_max);
}


static void action_set_dt_factor(
     AbcAction *action)
{
     double dt_factor = get_action_value(action);
     AbcTimeStepper *ts = get_action_time_stepper(action);

     abc_set_time_stepper_dt_factor(ts, dt_factor);
}


static void action_set_dt_first(
     AbcAction *action)
{
     double dt_first = get_action_value(action);
     AbcTimeStepper *ts = get_action_time_stepper(action);

     abc_set_time_stepper_dt_first(ts, dt_first);
}


static AbcTimeStepper *get_action_time_stepper(
     AbcAction *action)
{
     AbcTimeStepper **pts  = (AbcTimeStepper **) action->buffer1;
     AbcTimeStepper *ts = *pts;
     return ts;
}


static double get_action_value(
     AbcAction *action)
{
     double *pvalue = (double *) action->buffer2;
     double value = *pvalue;
     return value;
}


void abc_print_set_time_step_block(
     FILE *out,
     AbcActionList *list)
{
     AbcAction *action;
     const char *text = "";
     const char *margin1 = abc_get_margin(1);

     fprintf(out, "begin_time_step_actions\n");

     for (action = list->first; action != NULL; action = action->next)
     {
          double time = action->time;
          double value = get_action_value(action);

          switch (action->type)
          {
              case ABC_ACTION_SET_DT_MAX:    text = "set_dt_max";    break;
              case ABC_ACTION_SET_DT_WANTED: text = "set_dt_first";  break;
              case ABC_ACTION_SET_DT_FACTOR: text = "set_dt_factor"; break;
              default: continue;
          }

          fprintf(out, "%sat %g %s = %g\n", margin1, time, text, value);
     }

     fprintf(out, "end_time_step_actions\n");
}


double abc_get_current_time_stepper_time(
    AbcTimeStepper *ts)
{
    return ts->t_current;
}



