/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2000-2002 by M. Wangen.
**
**   Info: Functions for pixel processing
**   Date: Version 1.0, September 2000
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_PIXEL_H_
#define _LIB_PIXEL_H_

typedef struct AbcPixelBuffer {
     int nx;                /* Number of pixels in x-direction. */
     int ny;                /* Number of pixels in y-direction. */
     double x0_user_space;  /* User space. */
     double x1_user_space;  /* User space. */
     double y0_user_space;  /* User space. */
     double y1_user_space;  /* User space. */
     double *buffer1;       /* Hue or red */
     double *buffer2;       /* Lightness or green */
     double *buffer3;       /* Saturaton or blue */
     /* Parameters for color intervals. */
     double hue_min;        /* Min hue. */
     double hue_max;        /* Max hue. */
     double hue_steps;      /* Number of intervals. */
} AbcPixelBuffer;

int abc_test_pixel_buffer(int argc, char **argv);
void abc_read_pixel_options(int argc, char **argv);
AbcPixelBuffer *abc_create_pixel_buffer(int nx, int ny);
void abc_delete_pixel_buffer(AbcPixelBuffer **pixbuf);
void abc_set_pixel_buffer_user_space(AbcPixelBuffer *pixbuf, double x0, double y0, double x1, double y1);
void abc_set_pixel_color_intervals(AbcPixelBuffer *pixbuf, double hue_min, double hue_max, int steps);
void abc_show_pixel_buffer_09(AbcPixelBuffer *pixbuf, FILE *out);
void abc_set_pixel_hls(AbcPixelBuffer *pixbuf, double x, double y, double hue, double lightness, double saturation);
void abc_draw_pixel_line_hls(AbcPixelBuffer *pixbuf, double x1, double y1, double x2, double y2, double hue, double lightness, double saturation);
double abc_get_pixel_dx(AbcPixelBuffer *pixbuf);
double abc_get_pixel_dy(AbcPixelBuffer *pixbuf);
void abc_fill_pixel_buffer_black(AbcPixelBuffer *pixbuf);
void abc_fill_pixel_buffer_white(AbcPixelBuffer *pixbuf);
void abc_insert_triangle_in_pixel_buffer_const_hue(AbcPixelBuffer *pixbuf, double x0, double y0, double x1, double y1, double x2, double y2, double hue);
void abc_insert_triangle_in_pixel_buffer_hue(AbcPixelBuffer *pixbuf, double x0, double y0, double x1, double y1, double x2, double y2, double h0, double h1, double h2);

#endif

