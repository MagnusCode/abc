/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1999-2001 by M. Wangen.
**
**   Info: Functions for time stepping
**   Date: Version 1.0, November 1999
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_TIME_STEPPER_H_
#define _LIB_TIME_STEPPER_H_

#include <lib_macros.h>
#include <lib_utils.h>
#include <lib_args.h>
#include <lib_input.h>
#include <lib_actions.h>

#define ABC_ACTION_SET_DT_WANTED              20
#define ABC_ACTION_SET_DT_MAX                 21
#define ABC_ACTION_SET_DT_FACTOR              22
#define ABC_ACTION_SET_DT_FIRST               23

typedef struct _AbcTimeStepper_ AbcTimeStepper;

typedef int (*ABC_DO_ONE_TIME_STEP)(AbcTimeStepper *ts, double t, double dt);
typedef void (*ABC_MAKE_TIME_STEP)(AbcTimeStepper *ts);

/*
**   The first time step is "dt_first", which becomes "dt_wanted".
**   The wanted time step is then increased by the factor "dt_factor"
**   after each use.  The wanted time step increases until "dt_max".
**   The time step is not always dt_wanted.  It happens that a
**   short step is made because of an action.  The actual time
**   step used becomes "dt_used".
*/

struct _AbcTimeStepper_ {
     double t_current;
     double t_begin;
     double t_end;
     double dt_used;
     double dt_first;
     double dt_factor;   
     double dt_wanted;
     double dt_min;
     double dt_max;
     ABC_DO_ONE_TIME_STEP do_one_timestep;
     ABC_MAKE_TIME_STEP make_time_step;
     void *model;   /* Pointer to a specific model or data (when needed). */
     int is_verbose;
     int is_debugging;
};

int abc_test_time_stepper(int argc, char **argv);
void abc_init_time_stepper_with_args(AbcTimeStepper *timestepper,
     AbcArgs *args);
void abc_show_time_stepper_options(FILE *out);
void abc_init_time_stepper_with_args2(AbcTimeStepper *timestepper,
     AbcArgs *args);
void abc_show_time_stepper_options2(FILE *out);
void abc_init_default_time_stepper(AbcTimeStepper *timestepper, 
     double t_begin, double t_end, double dt_first, double dt_max, 
     double dt_factor, ABC_DO_ONE_TIME_STEP do_one_timestep);
void abc_init_time_stepper(AbcTimeStepper *timestepper, 
     double t_begin, double t_end, double dt_wanted, 
     ABC_DO_ONE_TIME_STEP do_one_timestep, 
     ABC_MAKE_TIME_STEP make_time_step);
void abc_init_time_stepper_extra(AbcTimeStepper *timestepper, 
     double dt_first, double dt_min, double dt_max, double dt_factor);
void abc_init_time_stepper_do_function(AbcTimeStepper *timestepper, ABC_DO_ONE_TIME_STEP do_one_timestep);
void abc_init_time_stepper_make_function(AbcTimeStepper *timestepper, ABC_MAKE_TIME_STEP make_time_step);
void abc_init_time_stepper_model(AbcTimeStepper *timestepper, void *model);
void abc_set_time_stepper_debugging_on_off(AbcTimeStepper *timestepper, int on_off);
void abc_set_time_stepper_dt_first(AbcTimeStepper *timestepper, double dt_first);
void abc_set_time_stepper_dt_max(AbcTimeStepper *timestepper, double dt_max);
void abc_set_time_stepper_dt_wanted(AbcTimeStepper *timestepper, double dt_wanted);
void abc_set_time_stepper_dt_factor(AbcTimeStepper *timestepper, double dt_factor);
int abc_is_ok_time_stepper(AbcTimeStepper *timestepper);
void abc_print_time_stepper(FILE *out, AbcTimeStepper *timestepper);
void abc_stop_time_stepper(AbcTimeStepper *timestepper);
void abc_make_time_stepper_dt(AbcTimeStepper *timestepper);
void abc_run_time_stepper(AbcTimeStepper *timestepper, AbcActionList *action_list);
int abc_read_time_steps_actions_from_file(AbcActionList *list, AbcTimeStepper *ts, const char *filename);
int abc_read_time_steps_actions(AbcInput *in, AbcActionList *list, AbcTimeStepper *ts);
int read_one_time_step_action(AbcInput *in, AbcActionList *list, AbcTimeStepper *ts);
void abc_add_time_stepper_action(AbcActionList *list, AbcTimeStepper *ts, 
     int type, double value, double time);
void abc_print_set_time_step_block(FILE *out, AbcActionList *list);
double abc_get_current_time_stepper_time(AbcTimeStepper *ts);

#endif

