/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1999-2013 by M. Wangen.
**
**   Info: Library for hydrocarbon generation
**   Date: Version 2.0, February 2013
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   History:
**   Version 1.0, Apr 1999: Demo version for student use at UNIK.
**   Version 2.0, Nov 2012: Added Easy Ro to the state.
*/

/*
**   To do list:
**   (1) Exact l�sning for Tissot-Welte.
**   (2) Add new expulsion models!
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_utils.h>
#include <lib_input.h>
#include <lib_matrix.h>
#include <lib_lapack.h>
#include <lib_hc_gen.h>

#ifdef RETURN_NULL
#undef RETURN_NULL
#endif
#define RETURN_NULL(in, text) {abc_input_error(in, text); return NULL;}

#ifdef RETURN_FALSE
#undef RETURN_FALSE
#endif
#define RETURN_FALSE(in, text) {abc_input_error(in, text); return FALSE;}

#define MAX_KINETICS 1024

#define SOLVER_RK4    1
#define SOLVER_EIGEN  2

#define DEBUG_STATE         1
#define DEBUG_VEC_AND_MAT   2

static int
     wanted_solver = SOLVER_EIGEN,
     debug = FALSE,
     n_steps_vr = 20;

static double A_vr[MAX_KINETICS] = {
     1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13,
     1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13,
     1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13,
     1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13, 1.00e+13};  

static double E_vr[MAX_KINETICS] = {
     34.0, 36.0, 38.0, 40.0, 42.0, 44.0, 46.0, 48.0, 50.0, 52.0,
     54.0, 56.0, 58.0, 60.0, 62.0, 64.0, 66.0, 68.0, 70.0, 72.0};

static double x0_vr[MAX_KINETICS] = {
     0.03, 0.03, 0.04, 0.04, 0.05, 0.05, 0.06, 0.04, 0.04, 0.07, 
     0.06, 0.06, 0.06, 0.05, 0.05, 0.04, 0.03, 0.02, 0.02, 0.01};

static int read_init_pc_kerogen(AbcInput *in, AbcKerogenProps *prop);
static int is_OK_kerogen_hc_groups(AbcInput *in, AbcKerogenHcGroups *groups);
static int get_kinetics_norm_dist(AbcInput *in, double *w, double *A, double *E, char *keyword_end);
static double normal_dist(double x, double mean, double sigma);
static int get_kinetics_table(AbcInput *in, double *w, double *A, double *E, char *keyword_end);
static int expand_temp_hist(AbcInput *in, double *time, double *temp, int *size1, int max_size);
static int get_numb(AbcInput *in, char const *keyword, double *numb, double lim1, double lim2);
static int get_binary_state(AbcInput *in, int *state, const char *name_true, const char *name_false);
static int get_keyword(AbcInput *in, char const *keyword);
static double get_reaction_const(double A, double E, double RT);
static double **check_and_save_transp_stoich(double **M, int rows, int cols);
static int has_sum_one(double *array, int size);
static int is_zero(double number, char const *text);
static void convert_pc_model_gen_model(AbcKerogenModel *model);
static void func_gen_F(AbcKerogenState *state, double T, double *x, double *k);
static void check_eigen_solution(int n1, double **E, double **V, double *lambda);

/*
**   ==================
**   A demo application
**   ==================
*/

typedef struct AbcTestParams {
     int show_history;
     int show_state;
     int show_model;
     int show_model_TeX;
     int do_expulsion;
     double total_mass;
     const char *filename_output;
} AbcTestParams;

static int read_options(int argc, char **argv, AbcTestParams *param);
static void show_options(FILE *out);
static void change_solver(AbcKerogenModel *model);


int abc_test_kerogen_lib(
     int argc,
     char **argv)
{
     AbcTestParams param;
     AbcKerogenLib lib;
     AbcKerogenModel *model;
     AbcKerogenState *state;
     AbcKerogenTempHist hist;
     char *filename_input = argv[argc-1];
     const char *time_unit;
     double T1, T2, dt, t1, factor; 
     int code2 = ABC_KEROGEN_WRITE_HC + ABC_KEROGEN_WRITE_TOTAL_EXPELLED_HC;
     int code1 = code2 + ABC_KEROGEN_WRITE_HEADING;
     int code;
     FILE *out = NULL;
     int i;

     param.show_history = FALSE;
     param.show_state = FALSE;
     param.show_model = FALSE;
     param.show_model_TeX = FALSE;
     param.do_expulsion = FALSE;
     param.total_mass = 1.0;
     param.filename_output = "xcracker.csv";

     abc_init_kerogen_lib(&lib);

     if (not read_options(argc, argv, &param))
          exit(1);

     if (not abc_get_kerogen_temp_hist(&hist, filename_input))
          ABC_ERROR_EXIT2("Can't read temperature history!", filename_input);

     if (not abc_read_kerogen_library(&lib, hist.library_name))
          ABC_ERROR_EXIT2("Can't read library!", hist.library_name);

     if ((model = abc_get_kerogen_model_by_name(&lib, hist.kerogen_name)) == NULL)
          ABC_ERROR_EXIT2("Can't find the wanted kerogen model!", hist.kerogen_name);

     if ((state = abc_new_kerogen_state(model, param.total_mass)) == NULL)
          ABC_ERROR_EXIT("The kerogen state is a NULL-pointer!");

     if ((out = fopen(param.filename_output, "w")) == NULL)
          ABC_ERROR_EXIT2("Can't open file for results!", param.filename_output);

     if (param.show_history)
          abc_print_hc_temp_hist(&hist, stdout);

     if (param.show_model)
          abc_print_kerogen_model(model, stdout);

     if (param.show_model_TeX)
          abc_print_kerogen_model_TeX(model, stdout);

     change_solver(model);
     abc_store_temp_hist_info_for_post(&hist, "xpost");
     factor = abc_get_sec_in_time_unit(hist.time_unit);
     time_unit = abc_get_time_unit_name(hist.time_unit);

     for (i = 1; i < hist.size; i++)
     {
          code = (i == 1) ? code1 : code2;
          T1 = hist.temp[i-1];
          T2 = hist.temp[i];
          dt = hist.time[i] - hist.time[i-1]; /* time is stored in sec. */
          t1 = hist.time[i] / factor;         /* convert to input units. */

          abc_crack_kerogen_state(state, T1, T2, dt, param.do_expulsion);
          abc_write_kerogen_state(state, code, t1, hist.temp[i], out);

          printf("time=%7.2f [%s], temp=%6.2f [C] ", t1, time_unit, hist.temp[i]);
          printf("tr=%5.3f [-], vr=%5.3f [-]\n", state->transf_ratio, state->vr);

          if (param.show_state)
               abc_print_state(state, stdout);
     }

     printf("Results are written to: %s\n", param.filename_output);
     fclose(out);

     abc_delete_kerogen_lib(&lib);
     abc_delete_kerogen_state(&state);
     abc_delete_input_lib();

     return 0;
}


static int read_options(
     int argc,
     char **argv,
     AbcTestParams *param)
{
     int i;

     if (argc < 2)
     {
          show_options(stderr);
          return FALSE;
     }

     for (i = 1; i < argc - 1; i++)
          if      (ABC_MATCH(argv[i], "-explusion"))       param->do_expulsion = TRUE;
          else if (ABC_MATCH(argv[i], "-show-hist"))       param->show_history = TRUE;
          else if (ABC_MATCH(argv[i], "-show-model"))      param->show_model = TRUE;
          else if (ABC_MATCH(argv[i], "-show-model-tex"))  param->show_model_TeX = TRUE;
          else if (ABC_MATCH(argv[i], "-show-state"))      param->show_state = TRUE;
          else if (ABC_MATCH(argv[i], "-file-output"))     param->filename_output = argv[++i];
          else if (ABC_MATCH(argv[i], "-init-mass"))       param->total_mass = atof(argv[++i]);
          else if (ABC_MATCH(argv[i], "-debug-vec-mat"))   ABC_SET_BIT(debug, DEBUG_VEC_AND_MAT)
          else if (ABC_MATCH(argv[i], "-debug-state"))     ABC_SET_BIT(debug, DEBUG_STATE)
          else if (ABC_MATCH(argv[i], "-solver-rk4"))      wanted_solver = SOLVER_RK4;
          else if (ABC_MATCH(argv[i], "-solver-eigen"))    wanted_solver = SOLVER_EIGEN;
          else
          {
               fprintf(stderr, "Unknown option: %s\n", argv[i]);
               fprintf(stderr, "The program without any options gives help!\n");
               return FALSE;
          }

     return TRUE;
}


static void show_options(
     FILE *out)
{
     fprintf(out, "Usage: cra2 [options] <history-file>\n");
     fprintf(out, "   -explusion           Do HC expulsion.\n");
     fprintf(out, "   -show-hist           Show temperature history.\n");
     fprintf(out, "   -show-model          Show kerogen model.\n");
     fprintf(out, "   -show-model-tex      Show kerogen model (TeX-format).\n");
     fprintf(out, "   -show-state          Show kerogen state at each time step.\n");
     fprintf(out, "   -init-mass <numb>    Assign initial reactive mass.\n");
     fprintf(out, "   -debug-vec-mat       Debug vectors and matrices.\n");
     fprintf(out, "   -debug-state         Debug the kerogen state.\n");
     fprintf(out, "   -solver-rk4          Use a RK4 solver.\n");
     fprintf(out, "   -solver-eigen        Use an eigen-value and -vector solver.\n");
     fprintf(out, "   -file-output <file>  The results file.\n");
}


static void change_solver(
     AbcKerogenModel *model)
{
     int has_rk4_solver = (model->do_one_time_step == abc_gen_do_one_time_step_rk4);
     int has_eigen_solver = (model->do_one_time_step == abc_gen_do_one_time_step_by_eigenvalues);

     if (wanted_solver == SOLVER_RK4 and has_eigen_solver)
          model->do_one_time_step = abc_gen_do_one_time_step_rk4;

     if (wanted_solver == SOLVER_RK4 and has_rk4_solver)
          model->do_one_time_step = abc_gen_do_one_time_step_by_eigenvalues;
}

/*
**   =============================================
**   Functions for dealing with a kerogen library.
**   =============================================
*/

void abc_delete_kerogen_lib(
     AbcKerogenLib *lib)
{
     int i;

     for (i = 0; i < lib->size; i++)
          abc_delete_kerogen_model(&lib->model[i]);
}


void abc_init_kerogen_lib(
     AbcKerogenLib *lib)
{
     lib->size = 0;
}


int abc_read_kerogen_library(
     AbcKerogenLib *lib,
     char const *filename)
{
     static AbcInput in;

     if (not abc_begin_input(&in, filename))
          ABC_RETURN_FALSE("Can't open kerogen library file!");

     if (not abc_read_kerogen_lib(&in, lib))
          ABC_RETURN_FALSE("Can't read kerogen library file!");

     abc_end_input(&in);

     return TRUE;
}


int abc_read_kerogen_lib(
     AbcInput *in,
     AbcKerogenLib *lib)
{
     char word[MAX_HC_WORD];
     int i = lib->size;

     if (i >= MAX_HC_LIB - 1)
          RETURN_FALSE(in, "Kerogen library is full! Can't add definitions!");

     while (abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, "begin_kerogen_library"))
          ;

     for (i = lib->size; i < MAX_HC_LIB; i++)
     {
          if (not abc_get_word(in, word, MAX_HC_WORD))
               RETURN_FALSE(in, "Expected a keyword beginning a kerogen definition!");

          if (ABC_MATCH(word, "end_kerogen_library"))
               break;

          abc_put_back_word(in, word);

          if (not abc_read_kerogen_model(in, &(lib->model[i])))
               return FALSE;
     }

     lib->size = i;

     return TRUE;
}


void abc_write_kerogen_lib_report(
     AbcKerogenLib *lib,
     int use_default,
     const char *filename)
{
     FILE *out = abc_new_file(filename, "");
     fprintf(out, "begin_kerogen_library\n");
     abc_print_kerogen_lib(lib, use_default, out);
     fprintf(out, "end_kerogen_library\n");
     printf("(kerogen library report is written to: %s)\n", filename);
     fclose(out);
}


void abc_print_kerogen_lib(
     AbcKerogenLib *lib,
     int use_default,
     FILE *out)
{
     int i;

     for (i = 0; i < lib->size; i++)
     {
          fprintf(out, "\n");

          if (use_default)
               abc_print_kerogen_model_default(&lib->model[i], out);
          else
               abc_print_kerogen_model(&lib->model[i], out);
     }
}


void abc_print_needed_models_in_lib(
     AbcKerogenLib *lib,
     FILE *out)
{
     int i;

     for (i = 0; i < lib->size; i++)
     {
          if (not abc_is_needed_kerogen_model(&lib->model[i]))
               continue;

          fprintf(out, "\n");
          abc_print_kerogen_model(&lib->model[i], out);
     }
}


void abc_write_kerogen_lib_report_TeX(
     AbcKerogenLib *lib,
     int use_default,
     const char *filename,
     const char *title,
     const char *author,
     const char *date)
{
     FILE *out = abc_new_file(filename, "");

     if (title == NULL) title = "Kerogen library";
     if (author == NULL) author = "Abc-software";
     if (date == NULL) date = "\\today";

     fprintf(out, "\\documentclass[12pt,titlepage]{article}\n");
     fprintf(out, "\\title{%s}\\author{%s}\\date{%s}\n", title, author, date);
     fprintf(out, "\\begin{document}\n");
     fprintf(out, "\\setlength{\\parindent}{0cm}\\setlength{\\parskip}{3mm}\n");
     fprintf(out, "\\maketitle\n");

     abc_print_kerogen_lib_TeX(lib, use_default, out);
     fprintf(out, "\n\\end{document}\n");

     printf("(kerogen library report is written to: %s)\n", filename);
     fclose(out);
}


void abc_print_kerogen_lib_TeX(
     AbcKerogenLib *lib,
     int use_default,
     FILE *out) 
{
     int i;

     for (i = 0; i < lib->size; i++)
     {
          if (use_default)
               abc_print_kerogen_model_default_TeX(&lib->model[i], out);
          else
               abc_print_kerogen_model_TeX(&lib->model[i], out);

          fprintf(out, "\\clearpage\\newpage\n");
     }
}


int abc_is_consistent_kerogen_lib(
     AbcKerogenLib *lib) 
{
     int i, n;

     if (lib->size < 1) 
          return TRUE;

     n = abc_get_numb_of_hc_groups(&lib->model[0]);

     for (i = 1; i < lib->size; i++)
          if (n != abc_get_numb_of_hc_groups(&lib->model[i]))
               return FALSE;

     return TRUE;
}


int abc_get_max_hc_groups_in_kerogen_lib(
     AbcKerogenLib *lib) 
{
     int i, n;
     int max_groups = 0;

     if (lib == NULL) return 0;

     for (i = 0; i < lib->size; i++)
          if ((n = abc_get_numb_of_hc_groups(&lib->model[i])) > max_groups)
               max_groups = n;

     return max_groups;
}


const char *abc_get_hc_group_name_in_kerogen_lib(
    AbcKerogenLib *lib,
    int no)
{
     if (lib->size < 1) 
          return "undefined";

     return abc_get_name_of_hc_group(&lib->model[0], no);
}


AbcKerogenModel *abc_get_kerogen_model_by_name(
     AbcKerogenLib *lib,
     char const *name) 
{
     int i;

     for (i = 0; i < lib->size; i++)
     {
          AbcKerogenModel *model = &(lib->model[i]);

          if (ABC_MATCH(model->name, name))
               return model;
     }

     fprintf(stderr, "Can't find kerogen \"%s\" in library!\n", name);
     return NULL;
}


AbcKerogenModel *abc_get_kerogen_model_by_number(
     AbcKerogenLib *lib,
     int no) 
{
     if (lib == NULL)
          return NULL;

     if (no < 0 or lib->size <= no)
          return NULL;

     return &(lib->model[no]);
}

/*
**   ================================
**   Functions for any kerogen model.
**   ================================
*/

int abc_read_kerogen_model(
     AbcInput *in,
     AbcKerogenModel *model) 
{
     char word[MAX_HC_WORD];

     ABC_ASSERT(model, "[abc_read_kerogen_model]");
     abc_init_kerogen_model(model);

     if (not abc_get_word(in, word, MAX_HC_WORD))
          RETURN_FALSE(in, "Expected a keyword in kerogen library!");

     abc_put_back_word(in, word);

     if      (ABC_MATCH(word, "begin_pc_kerogen")) 
          return abc_read_kerogen_pc(in, model);
     else if (ABC_MATCH(word, "begin_kerogen")) 
          return abc_read_kerogen_gen(in, model);

     return FALSE;
}


void abc_init_kerogen_model(
     AbcKerogenModel *model)
{
     ABC_ASSERT(model, "[abc_init_kerogen_model]");
     strcpy(model->name, "undefined");
     abc_init_kerogen_kinetics(&model->ker);
     abc_init_kerogen_kinetics(&model->ko);
     abc_init_kerogen_kinetics(&model->kg);
     abc_init_kerogen_kinetics(&model->hc);
     model->A = NULL;
     model->B = NULL;
}


void abc_delete_kerogen_model(
     AbcKerogenModel *model) 
{
     ABC_ASSERT(model, "[abc_delete_kerogen_model]");
     abc_delete_kerogen_kinetics(&model->ker);
     abc_delete_kerogen_kinetics(&model->ko);
     abc_delete_kerogen_kinetics(&model->kg);
     abc_delete_kerogen_kinetics(&model->hc);
     if (model->A != NULL) ABC_FREE_MATRIX_2(model->A);
     if (model->B != NULL) ABC_FREE_MATRIX_2(model->B);
}


void abc_mark_kerogen_model_as_needed(
     AbcKerogenModel *model)
{
     ABC_ASSERT(model, "[abc_mark_kerogen_model_as_needed]");
     model->is_needed = TRUE;
}


int abc_is_needed_kerogen_model(
     AbcKerogenModel *model)
{
     ABC_ASSERT(model, "[abc_is_needed_kerogen_model]");
     return model->is_needed;
}


void abc_print_kerogen_model(
     AbcKerogenModel *model,
     FILE *out)
{
     ABC_ASSERT(model, "[abc_print_kerogen_model]");
     model->print_model(model, out);
}


void abc_print_kerogen_model_default(
     AbcKerogenModel *model,
     FILE *out)
{
     int saved_PC = model->prop.is_PC;
     model->prop.is_PC = FALSE;

     fprintf(out, "%sbegin_kerogen\n", abc_get_margin(1));
     fprintf(out, "%sname \"%s\"\n", abc_get_margin(2), model->name);

     fprintf(out, "\n");
     abc_print_kerogen_props(&model->prop, out);

     fprintf(out, "\n");
     abc_print_kerogen_hc_groups(&model->group, out);

     fprintf(out, "\n");
     abc_print_kerogen_kin_and_stoich(model, 0, out);

     fprintf(out, "\n");
     abc_print_kerogen_kin_and_stoich(model, 1, out);

     fprintf(out, "%send_kerogen\n", abc_get_margin(1));
     model->prop.is_PC = saved_PC;
}


void abc_print_kerogen_model_TeX(
     AbcKerogenModel *model,
     FILE *out)
{
     ABC_ASSERT(model, "[abc_print_kerogen_model_TeX]");
     model->print_model_tex(model, out);
}


void abc_print_kerogen_model_default_TeX(
     AbcKerogenModel *model,
     FILE *out)
{
     fprintf(out, "\n\\section{Kerogen: %s}\n", model->name);
     fprintf(out, "\n\\mbox{ }\n");

     abc_print_kerogen_props_TeX(&model->prop, out);
     abc_print_kerogen_hc_groups_TeX(&model->group, out);
     abc_print_kerogen_kin_and_stoich_TeX(model, 0, out);
     abc_print_kerogen_kin_and_stoich_TeX(model, 1, out);
}



void abc_get_mobile_hc_groups(
     AbcKerogenModel *model,
     int *is_mobile,
     int *size)
{
     int i;

     ABC_ASSERT(model, "[abc_get_mobile_hc_groups]");
     *size = model->n_hc_groups;

     for (i = 0; i < model->n_hc_groups; i++)
          is_mobile[i] = model->group.is_mobile[i];
}   


int abc_get_numb_of_hc_groups(
     AbcKerogenModel *model)
{
     ABC_ASSERT(model, "[abc_get_numb_of_hc_groups]");
     return model->n_hc_groups;
}


const char *abc_get_name_of_hc_group(
     AbcKerogenModel *model,
     int no)
{
     ABC_ASSERT(model, "[abc_get_name_of_hc_group]");

     if (no < 0 or model->n_hc_groups <= no)
          ABC_ERROR_EXIT("[abc_get_name_of_hc_group] Illegal index!");

     return model->group.name[no];
}

/*
**   ================================
**   Functions for kerogen properties
**   ================================
*/

int abc_read_kerogen_properties(
     AbcInput *in, 
     AbcKerogenProps *prop,
     int is_PC)
{
     double TOC, S1, S2, W;

     if (not get_keyword(in, "begin_initial_kerogen"))
          RETURN_FALSE(in, "Can't read \"begin_initial_kerogen\"!");

     if (not get_numb(in, "TOC_total_organic_carbon", &TOC, 0.0, 1.0))
          RETURN_FALSE(in, "Can't read keyword \"TOC_total_organic_carbon\"!");

     if (not get_numb(in, "S1_initial_oil", &S1, 0.0, 1000.0))
          RETURN_FALSE(in, "Can't read keyword \"S1_initial_oil\"!");

     if (not get_numb(in, "S2_inital_kerogen", &S2, 0.0, 1000.0))
          RETURN_FALSE(in, "Can't read keyword \"S2_inital_kerogen\"!");

     if (not get_numb(in, "W_carbon_content", &W, 0.0, 1.0))
          RETURN_FALSE(in, "Can't read \"W_carbon_content\"!");

     if (is_PC and not read_init_pc_kerogen(in, prop))
          RETURN_FALSE(in, "Can't read P-C parameters!");

     if (not get_keyword(in, "end_initial_kerogen"))
          RETURN_FALSE(in, "Can't read \"end_initial_kerogen\"!");

     if (TOC < W * (S1 + S2) / 1000.0)
     {
          fprintf(stderr, "Warning: Too little TOC! (Negative inert kerogen).\n"),
          fprintf(stderr, "TOC=%g [g/g], S1=%g [mg/g], S2=%g [mg/g], W=%g [g/g]\n",
               TOC, S1, S2, W);
          TOC = W * (S1 + S2) / 1000.0;
          fprintf(stderr,"TOC is set to: %g (which is the reactive kerogen)\n", TOC);
     }

     prop->is_PC = is_PC;
     prop->TOC = TOC;
     prop->S1 = S1;
     prop->S2 = S2;
     prop->W = W;

     return TRUE;
}


static int read_init_pc_kerogen(
     AbcInput *in,
     AbcKerogenProps *prop)
{
     if (not get_numb(in, "G_gas_oil_kerogen_ratio", &prop->G, 0.0, 1.0))
          RETURN_FALSE(in, "Can't read \"G_gas_oil_kerogen_ratio\"!");

     if (not get_numb(in, "F_gas_coke_ratio", &prop->F, 0.0, 1.0))
          RETURN_FALSE(in, "Can't read \"F_gas_coke_ratio\"!");

     if (not get_numb(in, "expulsion_limit_gas", &prop->limGas, 0.0, 1.0))
          RETURN_FALSE(in, "Can't read \"expulsion_limit_gas\"!");

     if (not get_numb(in, "expulsion_limit_oil", &prop->limOil, 0.0, 1.0))
          RETURN_FALSE(in, "Can't read \"expulsion_limit_oil\"!");

     return TRUE;
}


void abc_print_kerogen_props(
     AbcKerogenProps *prop,
     FILE *out) 
{
     fprintf(out, "%sbegin_initial_kerogen\n", abc_get_margin(2));
     fprintf(out, "%sTOC_total_organic_carbon   %9.3f  #[gCarbon/gSed]#\n",
          abc_get_margin(3), prop->TOC);
     fprintf(out, "%sS1_initial_oil             %9.3f  #[mgHC/gSed]#\n",
          abc_get_margin(3), prop->S1);
     fprintf(out, "%sS2_inital_kerogen          %9.3f  #[mgHC/gSed]#\n",
          abc_get_margin(3), prop->S2);
     fprintf(out, "%sW_carbon_content           %9.3f  #[gCarbon/gHC]#\n",
          abc_get_margin(3), prop->W);

     if (prop->is_PC)
     {
          fprintf(out, "%sG_gas_oil_kerogen_ratio    %9.3f  #[-]#\n",
               abc_get_margin(3), prop->G);
          fprintf(out, "%sF_gas_coke_ratio           %9.3f  #[-]#\n",
               abc_get_margin(3), prop->F);
          fprintf(out, "%sexpulsion_limit_gas        %9.3f  #[gCgas/gCkerogen]#\n",
               abc_get_margin(3), prop->limGas);
          fprintf(out, "%sexpulsion_limit_oil        %9.3f  #[gCoil/gCkerogen]#\n",
               abc_get_margin(3), prop->limOil);
     }

     fprintf(out, "%send_initial_kerogen\n", abc_get_margin(2));
}


void abc_print_kerogen_props_TeX(
     AbcKerogenProps *prop,
     FILE *out) 
{
     char const *units1 = "[g$_{\\rm carbon}$/g$_{\\rm rock}$]";
     char const *units2 = "[mg$_{\\rm HC}$/g$_{\\rm rock}$]";
     char const *units3 = "[g$_{\\rm carbon~gas}$/g$_{\\rm carbon~rock}$]";
     char const *units4 = "[g$_{\\rm carbon~oil}$/g$_{\\rm carbon~rock}$]";

     fprintf(out, "\n\\begin{tabular}{|lrl|}\\hline\\hline\n");
     fprintf(out, "Parameter & Value & Units\\\\ \\hline\\hline\n");
     fprintf(out, "TOC, Total organic carbon & $%.3f$ & %s\\\\ \n", prop->TOC, units1);
     fprintf(out, "$S_1$, Initial oil contents & $%.3f$ & %s\\\\ \n", prop->S1, units2);
     fprintf(out, "$S_2$, Initial kerogen contents & $%.3f$ & %s\\\\ \n", prop->S2, units2);
     fprintf(out, "$W$, Carbon contents & $%.3f$ & %s\\\\ \n", prop->W, units1);

     if (prop->is_PC)
     {
          fprintf(out, "$G$, Gas/oil kerogen ratio & $%.3f$ & %s\\\\ \n", prop->G, "[-]");
          fprintf(out, "$F$, Gas/coke ratio from oil & $%.3f$ &%s\\\\ \n", prop->F, "[-]");
          fprintf(out, "Expulsion limit gas & $%.3f$ & %s\\\\ \n", prop->limGas, units3);
          fprintf(out, "Expulsion limit oil & $%.3f$ & %s\\\\ \n", prop->limOil, units4);
     }
     fprintf(out, "\\hline\\hline\\end{tabular}\n");
}

/*
**   =======================
**   Functions for HC-groups
**   =======================
*/

void abc_init_kerogen_hc_groups(
     AbcKerogenHcGroups *groups)
{
     int i;
     groups->size = 0;

     for (i = 0; i < MAX_HC_GROUPS; i++)
     {
          groups->is_stable[i] = 0;
          groups->is_mobile[i] = 0;
          groups->name[i] = "undefined";
     }
}


int abc_read_kerogen_hc_groups(
     AbcInput *in,
     AbcKerogenHcGroups *groups)
{
     int i = 0;
     int *is_stable = groups->is_stable;
     int *is_mobile = groups->is_mobile;
     double *limit = groups->expulsion_lim;
     char word[MAX_HC_WORD];

     if (not get_keyword(in, "begin_hc_groups"))
          ABC_ERROR_EXIT("Expected keyword \"begin_hc_groups\"!");

     while (abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, "end_hc_groups"))
     {
          abc_put_back_word(in, word);

          if (i >= MAX_HC_GROUPS)
               RETURN_FALSE(in, "Too many HC-groups!");

          if (not abc_get_string(in, word, MAX_HC_WORD))
               RETURN_FALSE(in, "Expected a HC group name!");

          groups->name[i] = abc_save_string(word);

          if (not get_binary_state(in, &is_stable[i], "stable", "unstable"))
               RETURN_FALSE(in, "Expected the keyword \"stable\" or \"unstable\"!");

          if (not get_binary_state(in, &is_mobile[i], "mobile", "immobile"))
               RETURN_FALSE(in, "Expected the keyword \"mobile\" or \"immobile\"!");

          if ((i > 0) and is_stable[i-1] and not is_stable[i])
               RETURN_FALSE(in, "A stable group comes before and an unstable group!");

          if (not abc_get_double(in, &limit[i]))
               RETURN_FALSE(in, "Can't read expulsion limit!");

          if (limit[i] < 0.0)
               RETURN_FALSE(in, "Expulsion limit is less than 0!");

          /* Increment group counter. */
          i++;
     }

     groups->size = i;

     if (not is_OK_kerogen_hc_groups(in, groups))
          RETURN_FALSE(in, "Error in HC-groups!");

     return TRUE;
}


static int is_OK_kerogen_hc_groups(
     AbcInput *in,
     AbcKerogenHcGroups *groups)
{
     int last = groups->size - 1;

     if (groups->size < 1)
          RETURN_FALSE(in, "Must have at least 1 HC group!");

     if (not groups->is_stable[last])
          RETURN_FALSE(in, "The last HC group must be stable!");

     return TRUE;
}


void abc_print_kerogen_hc_groups(
     AbcKerogenHcGroups *groups, 
     FILE *out)
{
     int i;
     char word[MAX_HC_WORD];

     fprintf(out, "%sbegin_hc_groups\n", abc_get_margin(2));

     for (i = 0; i < groups->size; i++)
     {
          sprintf(word, "\"%s\"", groups->name[i]);
          fprintf(out, "%s%-12s %-10s %-10s    %5.3f\n",
               abc_get_margin(3), word,
               (not groups->is_stable[i]) ? "unstable" : "stable",
               (groups->is_mobile[i]) ? "mobile" : "immobile",
               groups->expulsion_lim[i]);
     }

     fprintf(out, "%send_hc_groups\n", abc_get_margin(2));
}


void abc_print_kerogen_hc_groups_TeX(
     AbcKerogenHcGroups *groups, 
     FILE *out)
{
     int i;
     char word[MAX_HC_WORD];

     fprintf(out, "\n\\vspace{5mm}\n");
     fprintf(out, "\\begin{tabular}{|lccc|}\\hline\\hline\n");
     fprintf(out, "Name & Stable & Mobile & Expulsion limit\\\\ \\hline\\hline\n");
     fprintf(out, " -   & -      & -      & (gHc/gKerogen) \\\\ \\hline\\hline\n");

     for (i = 0; i < groups->size; i++)
     {
          sprintf(word, "``%s\"", groups->name[i]);
          fprintf(out, "%-12s &  %-10s & %-10s & %5.3f\\\\\n", word,
               (not groups->is_stable[i]) ? "unstable" : "stable",
               (groups->is_mobile[i]) ? "mobile" : "immobile",
               groups->expulsion_lim[i]);
     }

     fprintf(out, "\\hline\\hline\\end{tabular}\n");
}


int abc_get_number_of_stable_groups(
     AbcKerogenHcGroups *groups)
{
     int i;
     int counter = 0;

     for (i = 0; i < groups->size; i++)
          if (groups->is_stable[i])
               counter++;

     return counter;
}


int abc_get_number_of_mobile_groups(
     AbcKerogenHcGroups *groups)
{
     int i;
     int counter = 0;

     for (i = 0; i < groups->size; i++)
          if (groups->is_mobile[i])
               counter++;

     return counter;
}

/*
**   =============================
**   Functions for simple kinetics
**   =============================
*/

void abc_init_kerogen_kinetics(
     AbcKerogenKinetics *kin)
{
     kin->w = NULL;
     kin->A = NULL;
     kin->E = NULL;
     kin->size = 0;
}


int abc_read_kerogen_kinetics(
     AbcInput *in,
     AbcKerogenKinetics *kin,
     char const *keyword) 
{
     int i;
     int size = 0;
     double sum = 0.0;
     static double A[MAX_KINETICS], E[MAX_KINETICS], w[MAX_KINETICS];
     char word[MAX_HC_WORD], keyword_begin[MAX_HC_WORD], keyword_end[MAX_HC_WORD];

     sprintf(keyword_begin, "begin_%s", keyword);
     sprintf(keyword_end, "end_%s", keyword);

     if (not get_keyword(in, keyword_begin))
          ABC_ERROR_EXIT2("Can't read the beginning of kinetics!", keyword_begin);

     abc_get_field(in, word, MAX_HC_WORD);
     abc_put_back_word(in, word);

     if (ABC_MATCH(word, "A"))
     {
          if ((size = get_kinetics_norm_dist(in, w, A, E, keyword_end)) == 0)
               RETURN_FALSE(in, "Can't read normal distributed data!");
     }
     else
     {
          if ((size = get_kinetics_table(in, w, A, E, keyword_end)) == 0)
               RETURN_FALSE(in, "Can't read kinetics table!");
     }

     for (i = 0, sum = 0.0; i < size; i++)
          sum += w[i];

     if (sum < 0.999 or 1.001 < sum)
          RETURN_FALSE(in, "Fractions does not add up to 1!");

     kin->w = abc_save_double_array(w, size);
     kin->A = abc_save_double_array(A, size);
     kin->E = abc_save_double_array(E, size);
     kin->size = size;

     return TRUE;
}


static int get_kinetics_norm_dist(
     AbcInput *in,
     double *w,
     double *A,
     double *E,
     char *keyword_end) 
{
     double A1, E1, meanE, sigmaE, steps, dE;
     double max_steps = MAX_HC_KINETICS;
     double sum = 0.0;
     int size = 0;
     int i;

     if (not get_numb(in, "A", &A1, 0.0, 1.0e+25))
          RETURN_FALSE(in, "Can't read parameter \"A\" (Arrhenius factor)!");

     if (not get_numb(in, "meanE", &meanE, 0.0, 500.0))
          RETURN_FALSE(in, "Can't read parameter \"meanE\" (Arrhenius factor)!");

     if (not get_numb(in, "sigmaE", &sigmaE, 0.0, meanE))
          RETURN_FALSE(in, "Can't read parameter \"sigmaE\"!");

     if (not get_numb(in, "steps", &steps, 1.0, max_steps))
          RETURN_FALSE(in, "Can't read parameter \"steps\"!");

     dE = 4.0 * sigmaE / steps;
     E1 = meanE - 2 * sigmaE - 0.5 * dE;
     size = (int) steps;

     for (i = 0; i < size; i++)
     {
          A[i] = A1;
          E[i] = (i + 1) * dE + E1;
          w[i] = normal_dist(E[i], meanE, sigmaE) * dE;
          sum += w[i];
     }

     for (i = 0; i < size; i++)
          w[i] /= sum;

     if (not get_keyword(in, keyword_end))
          RETURN_FALSE(in, "Can't read end-keyword!");

     return size;
}


static double normal_dist(
     double x,
     double mean,
     double sigma) 
{
     double fac1, fac2, fac3;

     if (sigma < 1.0e-12)
          ABC_ERROR_EXIT("[normal_dist] Extremly small sigma!");

     fac1 = sqrt(2.0 * ABC_PI) * sigma;
     fac2 = - (x - mean) * (x - mean) / (2.0 * sigma * sigma);
     fac3 = exp(fac2) / fac1;
     return fac3;
}


static int get_kinetics_table(
     AbcInput *in,
     double *w,
     double *A,
     double *E,
     char *keyword_end) 
{
     int size = 0;
     char word[MAX_HC_WORD];

     while(abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, keyword_end))
     {
          abc_put_back_word(in, word);

          if (size >= MAX_HC_KINETICS)
               RETURN_FALSE(in, "Too many kinetic parameters!");

          if (not abc_get_double(in, &w[size]))
               RETURN_FALSE(in, "Couldn't read kerogen distribution!");

          if (not abc_get_double(in, &A[size]))
               RETURN_FALSE(in, "Couldn't read kerogen prefactor!");

          if (not abc_get_double(in, &E[size]))
               RETURN_FALSE(in, "Couldn't read activation energy!");

          size++;
     }

     return size;
}


void abc_delete_kerogen_kinetics(
     AbcKerogenKinetics *kin) 
{
     if (kin->size < 1) return;

     ABC_FREE_ARRAY(kin->w);
     ABC_FREE_ARRAY(kin->A);
     ABC_FREE_ARRAY(kin->E);
     kin->size = 0;
}


void abc_print_kerogen_kinetics(
     AbcKerogenKinetics *kin,
     char const *keyword,
     FILE *out) 
{
     int i;
     double *A = kin->A;
     double *E = kin->E;
     double *w = kin->w;

     fprintf(out, "%sbegin_%s\n", abc_get_margin(2), keyword);
          fprintf(out, "%s# %5s   %8s   %5s #\n", abc_get_margin(3), "[-]", "[1/s]", "[kJ/mole]");
     for (i = 0; i < kin->size; i++)
          fprintf(out, "%s%5.3f   %8.2e   %5.1f\n", abc_get_margin(3), w[i], A[i], E[i]);
     fprintf(out, "%send_%s\n", abc_get_margin(2), keyword);
}


int abc_read_kerogen_kin_and_stoich(
     AbcInput *in,
     AbcKerogenModel *model,
     char const *keyword)
{
     static double A[MAX_KINETICS], E[MAX_KINETICS], w[MAX_KINETICS];
     char word[MAX_HC_WORD], msg_begin[MAX_HC_WORD], msg_end[MAX_HC_WORD];
     char keyword_begin[MAX_HC_WORD], keyword_end[MAX_HC_WORD];
     double **M = NULL;
     int is_hc = (ABC_MATCH(keyword, "unstable_hc"));
     AbcKerogenHcGroups *group = &model->group;
     AbcKerogenKinetics *kin = (is_hc) ? &model->hc : &model->ker;
     int n_hc_groups = group->size;
     int size = 0;
     int i;

     ABC_NEW_MATRIX_2(M, double, MAX_KINETICS, MAX_HC_GROUPS);

     if (n_hc_groups >= MAX_HC_GROUPS)
          RETURN_FALSE(in, "Too many HC-groups!");

     sprintf(keyword_begin, "begin_%s", keyword);
     sprintf(keyword_end, "end_%s", keyword);

     sprintf(msg_begin, "Expected the keyword: %s", keyword_begin);
     sprintf(msg_end, "Expected the keyword: %s", keyword_end);

     if (not get_keyword(in, keyword_begin))
          RETURN_FALSE(in, msg_begin);

     while (abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, keyword_end))
     {
          abc_put_back_word(in, word);

          if (size >= MAX_KINETICS)
               RETURN_FALSE(in, "Too many steps in kinetics!");
 
          if (not abc_get_double(in, &w[size]))
               RETURN_FALSE(in, "Couldn't read kerogen distribution!");

          if (not abc_get_double(in, &A[size]))
               RETURN_FALSE(in, "Couldn't read kerogen prefactor!");

          if (not abc_get_double(in, &E[size]))
               RETURN_FALSE(in, "Couldn't read activation energy!");

          for (i = 0; i < n_hc_groups; i++)
               if (not abc_get_double(in, &M[size][i]))
                    RETURN_FALSE(in, "Could not read stoichiometry!");

          size++;
     }

     if (not ABC_MATCH(word, keyword_end))
          RETURN_FALSE(in, msg_end);

     if (not has_sum_one(w, size))
          RETURN_FALSE(in, "Mass fractions does not add up to 1!");

     for (i = 0; i < size; i++)
          if (not has_sum_one(M[i], n_hc_groups))
               RETURN_FALSE(in, "Stoichiometry does not add up to 1!");

     if (is_hc)
          for (i = 0; i < size; i++)
               if (ABC_ABS(M[i][i]) > 1.0e-6)
                    RETURN_FALSE(in, "Expected zero on diagonal!");

     kin->w = abc_save_double_array(w, size);
     kin->A = abc_save_double_array(A, size);
     kin->E = abc_save_double_array(E, size);
     kin->size = size;

     if (is_hc)
          model->B = check_and_save_transp_stoich(M, size, n_hc_groups);
     else
          model->A = check_and_save_transp_stoich(M, size, n_hc_groups);

     ABC_FREE_MATRIX_2(M);
     return TRUE;
}


void abc_print_kerogen_kin_and_stoich(
     AbcKerogenModel *model,
     int is_hc,
     FILE *out)
{
     AbcKerogenHcGroups *group = &model->group;
     AbcKerogenKinetics *kin = (is_hc) ? &model->hc : &model->ker;
     char const *keyword = (is_hc) ? "unstable_hc" : "kerogen";
     double **M = (is_hc) ? model->B : model->A;
     int cols = group->size;
     int rows = kin->size;
     int i, j;

     fprintf(out, "%sbegin_%s\n", abc_get_margin(2), keyword);
     fprintf(out, "%s#( [-]     [1/s]      [kJ/mole] ", abc_get_margin(3));
     for (j = 0; j < cols; j++)
          fprintf(out, "  %-8s", group->name[j]);
     fprintf(out, ")#\n");

     for (i = 0; i < rows; i++)
     {
          fprintf(out, "%s   %5.3f   %8.2e   %5.1f  ", 
               abc_get_margin(3), kin->w[i], kin->A[i], kin->E[i]);
          for (j = 0; j < cols; j++)
               if (is_hc and (i == j))
                    fprintf(out, "  %8.3f", 0.0);
               else
                    fprintf(out, "  %8.3f", M[j][i]);

          if (is_hc) fprintf(out, "   #(%s)#", group->name[i]);
          fprintf(out, "\n");
     }
     fprintf(out, "%send_%s\n", abc_get_margin(2), keyword);
}


void abc_print_kerogen_kin_and_stoich_TeX(
     AbcKerogenModel *model,
     int is_hc,
     FILE *out)
{
     AbcKerogenHcGroups *group = &model->group;
     AbcKerogenKinetics *kin = (is_hc) ? &model->hc : &model->ker;
     char const *name = (is_hc) ? "Unstable HC" : "Kerogen";
     double **M = (is_hc) ? model->B : model->A;
     int cols = group->size;
     int rows = kin->size;
     int i, j;

     if (rows < 1) return;

     fprintf(out, "\n\\vspace*{5mm}\n");
     fprintf(out, "\\begin{tabular}{|ccc");
     for (j = 0; j < cols; j++) fprintf(out, "c");
     fprintf(out, "|}\\hline\\hline\n");

     fprintf(out, "\\multicolumn{%d}{|c|}{%s}\\\\ \\hline\n", 3 + cols, name);

     fprintf(out, "$W$ [-] & $A$ [1/s] & $E$ [kJ/mole]");
     for (j = 0; j < cols; j++) fprintf(out, "& %s", group->name[j]);
     fprintf(out, "\\\\ \\hline\\hline\n");

     for (i = 0; i < rows; i++)
     {
          fprintf(out, "%.3f & %8.2e & %.1f", 
               kin->w[i], kin->A[i], kin->E[i]);

          for (j = 0; j < cols; j++)
               if (is_hc and (i == j))
                    fprintf(out, " & %8.3f", 0.0);
               else
                    fprintf(out, " & %8.3f", M[j][i]);
          
          fprintf(out, "\\\\\n");
     }

     fprintf(out, "\\hline\\hline\\end{tabular}\n");
}


void abc_print_kerogen_kinetics_TeX(
     AbcKerogenKinetics *kin,
     char const *name,
     FILE *out) 
{
     int i;
     double *A = kin->A;
     double *E = kin->E;
     double *w = kin->w;

     fprintf(out, "\n\\begin{tabular}{|rrr|}\\hline\\hline\n");
     fprintf(out, "\\multicolumn{3}{|c|}{%s}\\\\ \\hline\n", name);
     fprintf(out, "$W$ [-] & $A$ [1/s] & $E$ [kJ/mole]\\\\ \\hline\\hline\n");
     for (i = 0; i < kin->size; i++)
          fprintf(out, "%.3f & %8.2e & %.1f\\\\\n", w[i], A[i], E[i]);
     fprintf(out, "\\hline\\hline\\end{tabular}\n");
}

/*
**   =============================
**   Functions for a kerogen state
**   =============================
*/

AbcKerogenState *abc_new_kerogen_state(
     AbcKerogenModel *model,
     double total_mass)
{
     AbcKerogenState *state;
     ABC_ASSERT(model, "[abc_new_kerogen_state]");

     state = abc_new_empty_kerogen_state(model);

     /*
     ** Total mass is here the total mass of a cell.
     ** There is a large number of cells in a 
     ** basin model and the reactive mass in each
     ** cell is proportional to the total cell mass.
     */

     abc_init_kerogen_state_with_mass(state, total_mass);

     return state;
}


AbcKerogenState *abc_new_empty_kerogen_state(
     AbcKerogenModel *model)
{
     int i;
     int xSize = model->n_kerogen_steps;
     int ySize = model->n_hc_groups;
     AbcKerogenState *state;

     ABC_NEW_OBJECT(state, AbcKerogenState);
     ABC_NEW_ARRAY(state->x, double, xSize);
     ABC_NEW_ARRAY(state->y, double, ySize);
     ABC_NEW_ARRAY(state->ye, double, ySize);
     ABC_NEW_ARRAY(state->yt, double, ySize);
     ABC_NEW_ARRAY(state->xvr, double, n_steps_vr);

     state->model = model;
     state->xSize = xSize;
     state->ySize = ySize;
     state->vrSize = n_steps_vr;
     state->init_reactive_mass = 0.0;
     state->transf_ratio = 0.0;
     state->tr_vr = 0.0;
     state->vr = 0.0;

     for (i = 0; i < xSize; i++)
          state->x[i] = 0.0;

     for (i = 0; i < ySize; i++)
          state->y[i] = state->ye[i] = state->yt[i] = 0.0;

     for (i = 0; i < n_steps_vr; i++)
          state->xvr[i] = x0_vr[i];

     return state;
}


void abc_delete_kerogen_state(
     AbcKerogenState **state1) 
{
     AbcKerogenState *state = *state1;
     ABC_FREE(state->x);
     ABC_FREE(state->y);
     ABC_FREE(state->ye);
     ABC_FREE(state->yt);
     ABC_FREE(state->xvr);
     ABC_FREE(state);
     *state1 = NULL;
}


void abc_init_kerogen_state_with_mass(
     AbcKerogenState *state,
     double total_mass)
{
     /* 
     ** The total mass of the cell is assigned only once.
     */
     state->total_mass = total_mass;

     /* 
     ** But reset is applied whenever the geohistory has to be resimulated.
     */
     abc_reset_kerogen_state(state);
}


void abc_reset_kerogen_state(
     AbcKerogenState *state)
{
     int i;
     AbcKerogenModel *model;

     ABC_ASSERT(state, "[abc_reset_kerogen_state]");
     model = state->model;
     ABC_ASSERT(model, "[abc_reset_kerogen_state]");

     /* Default initialization. */

     for (i = 0; i < state->xSize; i++)
          state->x[i] = 0.0;

     for (i = 0; i < state->ySize; i++)
          state->y[i] = state->ye[i] = state->yt[i] = 0.0;

     for (i = 0; i < state->vrSize; i++)
          state->xvr[i] = x0_vr[i];

     /* Model specific initialization. */

     model->init_state(state);
}


void abc_init_kerogen_state_default(
     AbcKerogenState *state)
{
     AbcKerogenModel *model = state->model;
     AbcKerogenProps *prop = &(model->prop);
     double total_mass = state->total_mass;
     double W_S1 = prop->W * prop->S1 / 1000.0;  /* [S1]=mg/g */
     double W_S2 = prop->W * prop->S2 / 1000.0;  /* [S2]=mg/g */
     double mass_xt = W_S2 * total_mass;
     double mass_yt = W_S1 * total_mass;
     int i;

     /* NOTE: Units for x and y are kg carbon. */

     for (i = 0; i < model->ker.size; i++)
          state->x[i] = model->ker.w[i] * mass_xt;

     /* NOTE: The unstable groups are first in array "y". */

     if (model->hc.size != model->n_unstable_hc_groups)
          ABC_ERROR_EXIT("[abc_gen_init_state] Wrong number of unstable groups!");

     for (i = 0; i < model->hc.size; i++)
          state->y[i] = model->hc.w[i] * mass_yt;

     state->init_inert_mass = (prop->TOC - W_S1 - W_S2) * total_mass;
     state->init_reactive_mass = mass_xt;
     state->transf_ratio = 0.0;
}


int abc_kerogen_state_is_source_rock(
     AbcKerogenState *state)
{
     return (state->xSize > 0);
}


int abc_kerogen_state_is_inert(
     AbcKerogenState *state)
{
     return (state->init_reactive_mass < 1.0e-6);
}


int abc_kerogen_state_is_zero(
     AbcKerogenState *state)
{
     int i;
     double eps = 1.0e-3;

     for (i = 0; i < state->xSize; i++)
          if (state->x[i]  > eps) return FALSE;

     for (i = 0; i < state->ySize; i++)
          if (state->y[i]  > eps) return FALSE;

     return TRUE;
}


int abc_check_kerogen_state(
     AbcKerogenState *state) 
{
     int i;
     int OK = TRUE;
     double eps = 1.0e-3;

     for (i = 0; i < state->ySize; i++)
     {
          if (state->y[i]  < -eps) {fprintf(stderr, " y[%d]", i);  OK = FALSE;}
          if (state->ye[i] < -eps) {fprintf(stderr, " ye[%d]", i); OK = FALSE;}
          if (state->yt[i] < -eps) {fprintf(stderr, " yt[%d]", i); OK = FALSE;}
     }

     if (not OK) fprintf(stderr, " are negative!\n");

     return OK;
}


void abc_crack_kerogen_state(
     AbcKerogenState *state,
     double temp1,
     double temp2,
     double dt_input,
     int do_expulsion) 
{
     double dT_min = 1.0;
     double dT_input = temp2 - temp1;
     int min_steps = (int) (ABC_ABS(dT_input) / dT_min);
     int steps = ABC_MAX(min_steps, 10);
     double dT = dT_input / steps;
     double dt = dt_input / steps;
     int i;

     if (do_expulsion) abc_set_expelled_mass_to_zero(state);

     for (i = 1; i <= steps; i++)
     {
          double T1 = temp1 + (i - 1) * dT;
          double T2 = T1 + dT;

          abc_do_one_time_step_cracking(state, T1, T2, dt);
          if (do_expulsion) abc_expell_hc(state);
     }
}


void abc_do_one_time_step_cracking(
     AbcKerogenState *state,
     double temp1,
     double temp2,
     double dt)
{
     double sum0, sum1;

     ABC_ASSERT(state, "[abc_do_one_time_step_cracking]");
     ABC_ASSERT(state->model, "[abc_do_one_time_step_cracking]");

     if (debug & DEBUG_STATE)
          sum0 = abc_get_total_active_mass(state);

     state->model->do_one_time_step(state, temp1, temp2, dt);
     abc_do_one_time_step_easy_ro(state, temp1, temp2, dt);

     if (debug & DEBUG_STATE)
     {
          sum1 = abc_get_total_active_mass(state);
          printf("sum0=%g, sum1=%g, transf=%g\n",
               sum0, sum1, state->transf_ratio);
          abc_print_state_default(state, stdout);
     }
}


void abc_do_one_time_step_easy_ro(
     AbcKerogenState *state,
     double temp1,
     double temp2,
     double dt)
{
     int i;
     double temp = 0.5 * (temp1 + temp2);
     double *x1 = state->xvr;
     double RT, E2, log_k_dt, k_dt, factor;
     double sum0 = 0.0;
     double sum1 = 0.0;

     for (i = 0; i < n_steps_vr; i++)
     {
          RT = GAS_CONST * (273.0 + temp);
          E2 = 1000 * 4.1868 * E_vr[i];  /* [kcal/mole] to [joule/mole] */
          log_k_dt = log(A_vr[i] * dt) - (E2 / RT);
          k_dt = exp(log_k_dt);
          factor = exp(-k_dt);
          x1[i] *= factor;

          sum0 += x0_vr[i];
          sum1 += x1[i];
     }

     state->tr_vr = (sum0 - sum1);
     state->vr = exp(-1.6 + 3.7 * state->tr_vr);
}


void abc_expell_hc(
     AbcKerogenState *state)
{
     ABC_ASSERT(state, "[abc_expell_hc]");
     ABC_ASSERT(state->model, "[abc_expell_hc]");

     state->model->expell_hc(state);
}


void abc_expell_hc_default(
     AbcKerogenState *state)
{
     AbcKerogenModel *model;
     AbcKerogenHcGroups *group;
     double mass_kerogen, limit, dy;
     int i;

     ABC_ASSERT(state, "[abc_expell_hc_default]");
     model = state->model;
     ABC_ASSERT(model, "[abc_expell_hc_default]");

     group = &(model->group);
     mass_kerogen = state->init_reactive_mass + state->init_inert_mass;

     for (i = 0; i < state->ySize; i++)
     {
          limit = mass_kerogen * group->expulsion_lim[i];

          if (state->y[i] > limit)
          {
               dy = state->y[i] - limit;
               state->ye[i] += dy;
               state->yt[i] += dy;
               state->y[i] = limit;
          }
     }
}


void abc_set_expelled_mass_to_zero(
     AbcKerogenState *state)
{
     int i;

     for (i = 0; i < state->ySize; i++)
          state->ye[i] = 0.0;
}


void abc_write_kerogen_state(
     AbcKerogenState *state,
     int code,
     double time,
     double temp,
     FILE *out) 
{
     int i;
     AbcKerogenModel *M = state->model;

     if (code & ABC_KEROGEN_WRITE_HEADING)
          fprintf(out, "#(%s\t%s\t%s\t%s", "time", "temp", "easy-ro", "transf");

     if ((code & ABC_KEROGEN_WRITE_HEADING) and (code & ABC_KEROGEN_WRITE_KEROGEN))
          for (i = 0; i < state->xSize; i++)
               fprintf(out, "\t%s[%d]", "x", i);

     if ((code & ABC_KEROGEN_WRITE_HEADING) and (code & ABC_KEROGEN_WRITE_HC))
          for (i = 0; i < state->ySize; i++)
               fprintf(out, "\t%s", abc_get_name_of_hc_group(M, i));

     if ((code & ABC_KEROGEN_WRITE_HEADING) and (code & ABC_KEROGEN_WRITE_EXPELLED_HC))
          for (i = 0; i < state->ySize; i++)
               fprintf(out, "\texp:%s", abc_get_name_of_hc_group(M, i));

     if ((code & ABC_KEROGEN_WRITE_HEADING) and (code & ABC_KEROGEN_WRITE_TOTAL_EXPELLED_HC))
          for (i = 0; i < state->ySize; i++)
               fprintf(out, "\ttot:%s", abc_get_name_of_hc_group(M, i));

     if (code & ABC_KEROGEN_WRITE_HEADING)
          fprintf(out, ")#\n");

     fprintf(out, "%g\t%g\t%g\t%g", time, temp, state->vr, state->transf_ratio);

     if (code & ABC_KEROGEN_WRITE_KEROGEN)
          for (i = 0; i < state->xSize; i++)
               fprintf(out, "\t%g", state->x[i]);

     if (code & ABC_KEROGEN_WRITE_HC)
          for (i = 0; i < state->ySize; i++)
               fprintf(out, "\t%g", state->y[i]);

     if (code & ABC_KEROGEN_WRITE_EXPELLED_HC)
          for (i = 0; i < state->ySize; i++)
               fprintf(out, "\t%g", state->ye[i]);

     if (code & ABC_KEROGEN_WRITE_TOTAL_EXPELLED_HC)
          for (i = 0; i < state->ySize; i++)
               fprintf(out, "\t%g", state->yt[i]);

     fprintf(out, "\n");
}


double abc_get_kerogen_transf_ratio(
     AbcKerogenState *state)
{
     int i;
     double transf, sum = 0.0;
     AbcKerogenModel *model;
     ABC_ASSERT(state, "[abc_get_kerogen_transf_ratio]");
     model = state->model;
     ABC_ASSERT(model, "[abc_get_kerogen_transf_ratio]");

     if (state->init_reactive_mass < 1.0e-12)
          return 0.0;

     for (i = 0; i < model->n_kerogen_steps; i++)
          sum += state->x[i];

     transf = (state->init_reactive_mass - sum) / state->init_reactive_mass;

     return transf;
}


double abc_get_total_generated_hc_mass(
     AbcKerogenState *state) 
{
     int i;
     double sum = 0.0;

     for (i = 0; i < state->ySize; i++)
          sum += (state->y[i] + state->ye[i]);

     return sum;
}


double abc_get_total_active_mass(
     AbcKerogenState *state) 
{
     int i;
     double sum = 0.0;

     for (i = 0; i < state->xSize; i++)
          sum += state->x[i];

     for (i = 0; i < state->ySize; i++)
          sum += (state->y[i] + state->yt[i]);

     return sum;
}


double abc_get_current_reactive_kerogen_mass(
     AbcKerogenState *state) 
{
     int i;
     double sum = 0.0;

     for (i = 0; i < state->xSize; i++)
          sum += state->x[i];

     return sum;
}


void abc_move_expelled(
     AbcKerogenState *state1,  /* from */
     AbcKerogenState *state2)  /* to */
{
     int i;

     if (state1->ySize != state2->ySize)
          ABC_ERROR_EXIT("[abc_move_expelled] Incompatible states!");

     for (i = 0; i < state1->ySize; i++)
     {
          state2->ye[i] += state1->ye[i];
          state1->ye[i] = 0.0;
     }
}


void abc_move_expelled_fraction(
     double fraction,          /* number between 0 and 1. */
     AbcKerogenState *state1,  /* from */
     AbcKerogenState *state2)  /* to */
{
     int i;
     double dm;

     if (state1->ySize != state2->ySize)
          ABC_ERROR_EXIT("[abc_move_expelled_fraction] Incompatible states!");

     if (fraction < 0.0 or 1.0 < fraction)
          ABC_ERROR_EXIT("[abc_move_expelled_fraction] Illegal fraction!");

     for (i = 0; i < state1->ySize; i++)
     {
          dm = fraction * state1->ye[i];
          state2->ye[i] += dm;
          state1->ye[i] -= dm;
     }
}


double abc_get_expelled_hc(
     AbcKerogenState *state,
     double *mass,
     int size) 
{
     int i;
     double sum = 0.0;

     if (size != state->ySize)
          fprintf(stderr, "[abc_get_expelled_hc] Incompatible vector size!");

     for (i = 0; i < size; i++)
          mass[i] = state->ye[i];

     for (i = 0; i < state->ySize; i++)
          sum += state->ye[i];

     return sum;
}


void abc_add_expelled_hc(
     AbcKerogenState *state,
     double *mass)
{
     int i;

     for (i = 0; i < state->ySize; i++)
          state->ye[i] += mass[i];
}


double abc_get_total_expelled_hc(
     AbcKerogenState *state,
     double *hc)
{
     int i;
     double sum = 0.0;

     for (i = 0; i < state->ySize; i++)
     {
          hc[i] = state->yt[i];
          sum += state->yt[i];
     }

     return sum;
}


void abc_unexpell_hc(
     AbcKerogenState *state) 
{
     int i;

     for (i = 1; i < state->ySize; i++)
     {
          state->y[i] += state->ye[i];
          state->yt[i] -= state->ye[i];
          state->ye[i] = 0.0;
     }
}


void abc_print_state(
     AbcKerogenState *state,
     FILE *out)
{
     AbcKerogenModel *model;
     ABC_ASSERT(state, "[abc_print_state]");
     model = state->model;
     ABC_ASSERT(model, "[abc_print_state]");
     model->print_state(state, out);
}


void abc_print_state_default(
     AbcKerogenState *state,
     FILE *out)
{
     int i;
     double sum = 0.0;
     AbcKerogenModel *model;
     AbcKerogenHcGroups *group;

     ABC_ASSERT(state, "[abc_print_state]");
     model = state->model;
     ABC_ASSERT(model, "[abc_print_state]");

     group = &(model->group);

     fprintf(out, "Kerogen steps:\n");
     for (i = 0; i < model->n_kerogen_steps; i++)
          fprintf(out, "x[%2d]:  %8.5f\n", i, state->x[i]);

     fprintf(out, "HC-groups:\n");
     for (i = 0; i < model->n_hc_groups; i++)
          fprintf(out, "y[%2d]:  %8.5f (%s)\n", i, state->y[i], group->name[i]);

     fprintf(out, "Expelled HC:\n");
     for (i = 0; i < model->n_hc_groups; i++)
          fprintf(out, "ye[%2d]: %8.5f (%s)\n", i, state->ye[i], group->name[i]);

     fprintf(out, "Total expelled HC:\n");
     for (i = 0; i < model->n_hc_groups; i++)
          fprintf(out, "yt[%2d]: %8.5f (%s)\n", i, state->yt[i], group->name[i]);

     for (i = 0; i < model->n_kerogen_steps; i++)
          sum += state->x[i];

     for (i = 0; i < model->n_hc_groups; i++)
     {
          sum += state->y[i];
          sum += state->ye[i];
          sum += state->yt[i];
     }

     printf("sum=%g\n", sum);
}

/*
**   ====================================
**   Functions for temperature histories.
**   ====================================
*/

int abc_get_kerogen_temp_hist(
     AbcKerogenTempHist *hist,
     char const *filename) 
{
     static AbcInput in;
     double sec_in_time_unit;
     char word[MAX_HC_WORD], lib_name[MAX_HC_WORD], ker_name[MAX_HC_WORD];
     int i;

     if (not abc_begin_input(&in, filename))
          RETURN_FALSE(&in, "Can't open library file!");

     if (not get_keyword(&in, "library_name"))
          RETURN_FALSE(&in, "Can't read kerogen (model) library!");

     if (not abc_get_string(&in, lib_name, MAX_HC_WORD))
          RETURN_FALSE(&in, "Can't read name of kerogen library as string!");

     if (not get_keyword(&in, "kerogen_name"))
          RETURN_FALSE(&in, "Can't read a kerogen selection!");

     if (not abc_get_string(&in, ker_name, MAX_HC_WORD))
          RETURN_FALSE(&in, "Can't read name of kerogen library as string!");

     if (not get_keyword(&in, "time_unit"))
          RETURN_FALSE(&in, "Can't read the time unit!");

     if (not abc_get_word(&in, word, MAX_HC_WORD))
          RETURN_FALSE(&in, "Can't read the time unit!");

     hist->time_unit = abc_get_time_unit_from_full_name(word);

     if (hist->time_unit == AbcTimeUnitUndefined)
          RETURN_FALSE(&in, "Undefined time unit!");

     if (not abc_get_word(&in, word, MAX_HC_WORD))
          RETURN_FALSE(&in, "Expected a keyword!");

     abc_put_back_word(&in, word);

     if (ABC_MATCH(word, "begin_temp_history"))
     {
          if (not abc_get_simple_temp_hist(&in, hist))
               RETURN_FALSE(&in, "Can't read simple temperature history!");
     }
     else if (ABC_MATCH(word, "begin_column_temp_history"))
     {
          if (not abc_get_column_temp_hist(&in, hist))
               RETURN_FALSE(&in, "Can't read column temperature history!");
     }
     else
          RETURN_FALSE(&in, "Unknown keyword for starting a temperature history!");

     strcpy(hist->kerogen_name, ker_name);
     strcpy(hist->library_name, lib_name);

     /* Convert time to seconds. */

     sec_in_time_unit = abc_get_sec_in_time_unit(hist->time_unit);

     for (i = 0; i < hist->size; i++)
          hist->time[i] *= sec_in_time_unit;

     abc_end_input(&in);
     return TRUE;
}
          

int abc_get_simple_temp_hist(
     AbcInput *in,
     AbcKerogenTempHist *hist)
{
     int size = 0;
     char word[MAX_HC_WORD];

     if (not get_keyword(in, "begin_temp_history"))
          RETURN_FALSE(in, "Expected \"begin_temp_history\"!");

     while (abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, "end_temp_history"))
     {
          abc_put_back_word(in, word);

          if (not abc_get_double(in, &hist->time[size]))
               RETURN_FALSE(in, "Expected a number (time)!");

          if (not abc_get_double(in, &hist->temp[size]))
               RETURN_FALSE(in, "Expected a number (temp)!");

          if (size < MAX_HC_TEMP_HIST)
               size++;
          else
               RETURN_FALSE(in, "Array overflow!");

          if (not expand_temp_hist(in, hist->time, hist->temp, &size, MAX_HC_TEMP_HIST))
               RETURN_FALSE(in, "Can't expand temperature history!");
     }

     hist->size = size;
     return TRUE;
}


static int expand_temp_hist(
     AbcInput *in,
     double *time,
     double *temp,
     int *size1,
     int max_size) 
{
     int size = *size1;
     int steps = 1;
     double dt, dT;
     char word[MAX_HC_WORD];
     int i;

     if (abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, "steps"))
     {
          abc_put_back_word(in, word);
          return TRUE;
     }

     if (not abc_get_int(in, &steps))
          RETURN_FALSE(in, "[expand_temp_hist] Can't read number of steps!");

     if (steps < 1)
          return TRUE;

     if (size < 2)
          RETURN_FALSE(in, "[expand_temp_hist] Needs at least two points to expand!");

     if (size + steps > max_size)
          RETURN_FALSE(in, "[expand_temp_hist] Too small buffers!");

     dt = (time[size-1] - time[size-2]) / steps;
     dT = (temp[size-1] - temp[size-2]) / steps;

     for (i = 1; i <= steps; i++)
     {
          time[i+size-2] = i * dt + time[size-2];
          temp[i+size-2] = i * dT + temp[size-2];
     }

     *size1 += (steps - 1);

     return TRUE;
}


int abc_get_column_temp_hist(
     AbcInput *in,
     AbcKerogenTempHist *hist)
{
     int size = 0;
     double *time = hist->time;
     double *temp = hist->temp;

     if (not get_keyword(in, "begin_column_temp_history"))
          RETURN_FALSE(in, "Expected \"begin_column_temp_history\"!");

     while (abc_get_double(in, &time[size]) and abc_get_double(in, &temp[size]))
          if (size < MAX_HC_TEMP_HIST)
               size++;

     if (size >= MAX_HC_TEMP_HIST)
          fprintf(stderr, "Warning: Couldn't store the entire temp history!\n");

     hist->size = size;

     return TRUE;
}    


void abc_print_hc_temp_hist(
     AbcKerogenTempHist *hist,
     FILE *out) 
{
     int i;

     double sec_in_time_unit = abc_get_sec_in_time_unit(hist->time_unit);
     const char *time_unit = abc_get_time_unit_full_name(hist->time_unit);

     fprintf(out, "\n");
     fprintf(out, "library_name \"%s\"\n", hist->library_name);
     fprintf(out, "kerogen_name \"%s\"\n", hist->kerogen_name);
     fprintf(out, "time_unit %s\n", time_unit);
     fprintf(out, "\n");
     fprintf(out, "begin_temp_history\n");
     for (i = 0; i < hist->size; i++)
          fprintf(out, "%s%7.2f  %7.2f\n", abc_get_margin(1), 
               (hist->time[i] / sec_in_time_unit), hist->temp[i]);
     fprintf(out, "end_temp_history\n");
     fprintf(out, "\n");
}


void abc_store_temp_hist_info_for_post(
     AbcKerogenTempHist *hist,
     const char *filename)
{
     FILE *out = abc_new_file(filename, ".a2");
     const char *unit1 = abc_get_time_unit_name(hist->time_unit);
     const char *unit2 = abc_get_time_unit_full_name(hist->time_unit);

     fprintf(out, "begin_results2\n");
     fprintf(out, "     strings temp_hist_info 4\n");
     fprintf(out, "     \"%s\" #(time unit)#\n", unit1);
     fprintf(out, "     \"%s\" #(time unit)#\n", unit2);
     fprintf(out, "     \"%s\" #(library name)#\n", hist->library_name);
     fprintf(out, "     \"%s\" #(kerogen name)#\n", hist->kerogen_name);
     fprintf(out, "end_results2\n");

     fclose(out);
     printf("(temperature history info is written to: %s.a2)\n", filename);
}

/*
**   =====================
**   Some useful functions
**   =====================
*/

static int get_numb(
     AbcInput *in,
     char const *keyword,
     double *numb,
     double lim1,
     double lim2) 
{
     char text1[MAX_HC_WORD], text2[MAX_HC_WORD];

     sprintf(text1, "Can't read number after keyword \"%s\"!", keyword);
     sprintf(text2, "Number \"%s\" is outside [%g, %g]!", keyword, lim1, lim2);

     if (not get_keyword(in, keyword)) RETURN_FALSE(in, "Can't get number!");
     if (not abc_get_double(in, numb)) RETURN_FALSE(in, text1);
     if (*numb < lim1 or lim2 < *numb) RETURN_FALSE(in, text2);

     return TRUE;
}


static int get_binary_state(
     AbcInput *in,
     int *state,
     const char *name_true,
     const char *name_false)
{
     char text[MAX_HC_WORD], word[MAX_HC_WORD];

     sprintf(text, "Expected the keyword \"%s\" or \"%s\"!", name_true, name_false);

     if (not abc_get_word(in, word, MAX_HC_WORD)) 
          RETURN_FALSE(in, text);

     if (ABC_MATCH(word, name_true)) *state = TRUE;
     else if (ABC_MATCH(word, name_false)) *state = FALSE;
     else RETURN_FALSE(in, text);

     return TRUE;
}


static int get_keyword(
     AbcInput *in,
     char const *keyword) 
{
     char word[MAX_HC_WORD], text[MAX_HC_WORD];

     sprintf(text, "Expected the keyword \"%s\"!", keyword);
     if (not abc_get_word(in, word, MAX_HC_WORD)) RETURN_FALSE(in, "Expected a word!");
     if (not ABC_MATCH(word, keyword)) RETURN_FALSE(in, text);

     return TRUE;
}


static double get_reaction_const(
     double A,
     double E,
     double RT) 
{
     if (A > 1e-25) 
     {
          double term1 = log(A);
          double term2 = 1000.0 * E / RT;
          double term3 = exp(term1 - term2);
          return term3;
     }

     return 0.0;
}


static double **check_and_save_transp_stoich(
     double **M, 
     int rows, 
     int cols)
{
     int i, j;
     double **A = NULL;

     ABC_NEW_MATRIX_2(A, double, cols, rows);

     for (i = 0; i < rows; i++)
          for (j = 0; j < cols; j++)
               A[j][i] = M[i][j];

     return A;
}


static int has_sum_one(
     double *array,
     int size)
{
     int i;
     int is_zero;
     double sum = 0.0;

     if (size < 1)
          return TRUE;

     for (i = 0; i < size; i++)
          sum += array[i];

     is_zero = (ABC_ABS(sum - 1.0) < 0.001);

     if (not is_zero)
          fprintf(stderr, "Error: sum=%g\n", sum);

     return is_zero;
}


static int is_zero(
     double number,
     char const *text)
{
     if (ABC_ABS(number) < 1.0e-150)
     {
          fprintf(stderr, "WARNING: \"%s\" is zero! (something wrong?)\n", text);
          return TRUE;
     }

     return FALSE;
}


/*
**   ====================================
**   Functions for the Pepper-Corvi model
**   ====================================
*/

int abc_read_kerogen_pc(
     AbcInput *in,
     AbcKerogenModel *model)
{
     char word[MAX_HC_WORD];
     AbcKerogenHcGroups *group = &(model->group);

     if (not get_keyword(in, "begin_pc_kerogen"))
          RETURN_FALSE(in, "Can't read \"begin_pc_kerogen\"!");

     if (not abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, "name"))
          RETURN_FALSE(in, "Can't read keyword \"name\"!");

     if (not abc_get_string(in, model->name, MAX_HC_WORD))
          RETURN_FALSE(in, "Can't read kerogen name! (expected a string)");

     if (not abc_read_kerogen_properties(in, &model->prop, TRUE))
          RETURN_FALSE(in, "Can't read inital kerogen content!");

     if (not abc_read_kerogen_kinetics(in, &(model->kg), "gas_kerogen"))
          RETURN_FALSE(in, "Can't read gas generative kinetics!");

     if (not abc_read_kerogen_kinetics(in, &(model->ko), "oil_kerogen"))
          RETURN_FALSE(in, "Can't read oil generative kinetics!");

     if (not abc_read_kerogen_kinetics(in, &(model->hc), "unstable_hc"))
          RETURN_FALSE(in, "Can't read oil to gas kinetics!");

     if (not get_keyword(in, "end_pc_kerogen"))
          RETURN_FALSE(in, "Can't read \"end_pc_kerogen\"!");

     /* Assign model data. */

     group->name[0] = "oil";   group->is_stable[0] = FALSE;  group->is_mobile[0] = TRUE;
     group->name[1] = "gas";   group->is_stable[1] = TRUE;   group->is_mobile[1] = TRUE;
     group->name[2] = "coke";  group->is_stable[2] = TRUE;   group->is_mobile[2] = FALSE;
     group->size = 3;

     model->is_needed             = FALSE;
     model->n_kerogen_steps       = model->ko.size + model->kg.size;
     model->n_hc_groups           = 3;
     model->n_stable_hc_groups    = 2;
     model->n_unstable_hc_groups  = 1;

     /* Assign model functions. */

     model->do_one_time_step      = abc_pc_do_one_time_step;
     model->expell_hc             = abc_expell_hc_default;
     model->init_state            = abc_pc_init_state;
     model->print_state           = abc_pc_print_state;
     model->print_model           = abc_pc_print_model;
     model->print_model_tex       = abc_pc_print_model_TeX;

     /* Store the PC model in the general data structure as well. */

     convert_pc_model_gen_model(model);

     return TRUE;
}


static void convert_pc_model_gen_model(
     AbcKerogenModel *model)
{
     AbcKerogenProps *prop = &(model->prop);
     AbcKerogenHcGroups *group = &(model->group);
     int i0, i, j, rows, cols_A, cols_B;

     /* Fill in the A- and B-matrices for PC kerogen. */

     rows = model->n_hc_groups;
     cols_A = model->n_kerogen_steps;
     cols_B = model->n_unstable_hc_groups;

     ABC_NEW_MATRIX_2(model->A, double, rows, cols_A);
     ABC_NEW_MATRIX_2(model->B, double, rows, cols_B);

     abc_basic_zero_matrix(model->A, rows, cols_A);
     abc_basic_zero_matrix(model->B, rows, cols_B);

     for (j = 0; j < model->ko.size; j++)
          model->A[0][j] = 1.0;

     for (j = model->ko.size; j < model->n_kerogen_steps; j++)
          model->A[1][j] = 1.0;

     model->B[1][0] = prop->G;
     model->B[2][0] = 1.0 - prop->G;

     /* Fill in ker that corresponds to ko and kg. */

     ABC_NEW_ARRAY(model->ker.w, double, model->n_kerogen_steps);
     ABC_NEW_ARRAY(model->ker.E, double, model->n_kerogen_steps);
     ABC_NEW_ARRAY(model->ker.A, double, model->n_kerogen_steps);

     for (i = 0; i < model->kg.size; i++)
     {
          model->ker.w[i] = model->kg.w[i] * prop->G;
          model->ker.E[i] = model->kg.E[i];
          model->ker.A[i] = model->kg.A[i];
     }

     i0 = model->kg.size;

     for (i = 0; i < model->ko.size; i++)
     {
          model->ker.w[i+i0] = model->ko.w[i] * (1.0 - prop->G);
          model->ker.E[i+i0] = model->ko.E[i];
          model->ker.A[i+i0] = model->ko.A[i];
     }

     model->ker.size = model->n_kerogen_steps;

     /* Transfer the expulsion limits to HC-groups. */

     group->expulsion_lim[0] = prop->limOil;
     group->expulsion_lim[1] = prop->limGas;
     group->expulsion_lim[2] = 0.0;
}


void abc_pc_init_state(
     AbcKerogenState *state)
{
     AbcKerogenModel *model = state->model;
     AbcKerogenProps *prop = &(model->prop);
     double total_mass = state->total_mass;

     double G = prop->G;
     double W_S1 = prop->W * prop->S1 / 1000.0;  /* [S1]=mg/g */
     double W_S2 = prop->W * prop->S2 / 1000.0;  /* [S2]=mg/g */
     int xgSize = model->kg.size;
     int xoSize = model->ko.size;
     double mass_xt = W_S2 * total_mass;
     double mass_xo = (1 - G) * mass_xt;
     double mass_xg = G * mass_xt;
     double mass_yo = W_S1 * total_mass;
     int i;

     /* NOTE: Units for x and y are kg carbon. */

     for (i = 0; i < xoSize; i++)
          state->x[i] = model->ko.w[i] * mass_xo;

     for (i = 0; i < xgSize; i++)
          state->x[i + xoSize] = model->kg.w[i] * mass_xg;

     state->y[0] = mass_yo;   /* OIL */
     state->y[1] = 0.0;       /* GAS */
     state->y[2] = 0.0;       /* COKE */

     state->init_inert_mass = (prop->TOC - W_S1 - W_S2) * total_mass;
     state->init_reactive_mass = mass_xo + mass_xg;
     state->transf_ratio = 0.0;
}


void abc_pc_print_state(
     AbcKerogenState *state,
     FILE *out)
{
     AbcKerogenModel *model = state->model;
     int xgSize = model->kg.size;
     int xoSize = model->ko.size;
     int i;

     if (state->xSize != (xgSize + xoSize))
          ABC_ERROR_EXIT("[abc_pc_print_state] Kerogen size error!");

     if (state->ySize != 3)
          ABC_ERROR_EXIT("[abc_pc_print_state] HC size error!");

     for (i = 0; i < xoSize; i++)
          fprintf(out, "x(oil):  %.3g\n", state->x[i]);

     for (i = 0; i < xgSize; i++)
          fprintf(out, "x(gas):  %.3g\n", state->x[i + xoSize]);

     fprintf(out, "y(oil):  %.3g\n", state->y[0]);
     fprintf(out, "y(gas):  %.3g\n", state->y[1]);
     fprintf(out, "y(cok):  %.3g\n", state->y[2]);

     fprintf(out, "ye(oil): %.3g\n", state->ye[0]);
     fprintf(out, "ye(gas): %.3g\n", state->ye[1]);
     fprintf(out, "ye(cok): %.3g\n", state->ye[2]);

     fprintf(out, "yt(oil): %.3g\n", state->yt[0]);
     fprintf(out, "yt(gas): %.3g\n", state->yt[1]);
     fprintf(out, "yt(cok): %.3g\n", state->yt[2]);
}


void abc_pc_expell_hc(
     AbcKerogenState *state)
{
     AbcKerogenModel *model = state->model;
     AbcKerogenProps *prop = &(model->prop);
     double mass_kerogen, ylim[5], dy;
     int i;

     if (state->ySize != 3)
          ABC_ERROR_EXIT("[abc_pc_expell_hc] Size error!");

     mass_kerogen = state->init_reactive_mass +
          abc_get_current_reactive_kerogen_mass(state) + state->y[0];

     ylim[1] = mass_kerogen * prop->limOil;
     ylim[2] = mass_kerogen * prop->limGas;

     for (i = 0; i < 2; i++)
          if (state->y[i] > ylim[i])
          {
               dy = state->y[i] - ylim[i];
               state->ye[i] += dy;
               state->yt[i] += dy;
               state->y[i] = ylim[i];
          }
}


void abc_pc_print_model(
     AbcKerogenModel *model,
     FILE *out)
{
     fprintf(out, "%sbegin_pc_kerogen\n", abc_get_margin(1));
     fprintf(out, "%sname \"%s\"\n", abc_get_margin(2), model->name);
     fprintf(out, "\n");
     abc_print_kerogen_props(&model->prop, out);
     fprintf(out, "\n");
     abc_print_kerogen_kinetics(&model->kg, "gas_kerogen", out);
     fprintf(out, "\n");
     abc_print_kerogen_kinetics(&model->ko, "oil_kerogen", out);
     fprintf(out, "\n");
     abc_print_kerogen_kinetics(&model->hc, "unstable_hc", out);
     fprintf(out, "%send_pc_kerogen\n", abc_get_margin(1));
}


void abc_pc_print_model_TeX(
     AbcKerogenModel *model,
     FILE *out)
{
     fprintf(out, "\n\n\\section{%s (Pepper/Corvi)}\n", model->name);
     abc_print_kerogen_props_TeX(&model->prop, out);
     abc_print_kerogen_kinetics_TeX(&model->kg, "Gas generative kerogen", out);
     abc_print_kerogen_kinetics_TeX(&model->ko, "Oil generative kerogen", out);
     abc_print_kerogen_kinetics_TeX(&model->hc, "Oil cracking", out);
}


int abc_pc_do_one_time_step(
     AbcKerogenState *state,
     double temp1,
     double temp2,
     double dt1)
{
     AbcKerogenModel *model = state->model;
     int xgSize = model->kg.size;
     int xoSize = model->ko.size;
     int yoSize = model->hc.size;
     double x1[MAX_HC_KINETICS] = { 0.0 };
     double y1[MAX_HC_KINETICS] = { 0.0 };
     double kx[MAX_HC_KINETICS] = { 0.0 };
     double ex[MAX_HC_KINETICS] = { 0.0 };
     double ya = 0.0;
     double km = 0.0;
     double ko = 0.0;
     double eo = 0.0;
     double fg = model->prop.F;
     double dt = dt1;
     double T = 0.5 * (temp1 + temp2);
     double RT = GAS_CONST * (T + 273.0);
     int i, j;

     if (state->xSize != (xgSize + xoSize))
          ABC_ERROR_EXIT("[cra_pc_crack_state] Kerogen size error!");

     if (state->ySize != 3)
          ABC_ERROR_EXIT("[cra_pc_crack_state] Oil size error!");

     for (i = 0; i < xoSize; i++)
     {
          kx[i] = get_reaction_const(model->ko.A[i], model->ko.E[i], RT);
          ex[i] = exp(-kx[i] * dt);
          x1[i] = state->x[i] * ex[i];
     }

     for (i = 0; i < xgSize; i++)
     {
          j = i + xoSize;
          kx[j] = get_reaction_const(model->kg.A[i], model->kg.E[i], RT);
          ex[j] = exp(-kx[j] * dt);
          x1[j] = state->x[j] * ex[j];
     }

     for (i = 0; i < yoSize; i++)
     {
          km = get_reaction_const(model->hc.A[i], model->hc.E[i], RT);
          ko += model->hc.w[i] * km;
     }

     /* y[0] = oil */

     eo = exp(-ko * dt);
     y1[0] = state->y[0] * eo;

     for (i = 0; i < xoSize; i++)
     {
          if (is_zero(ko - kx[i], "ko-kx[i]")) continue;
          y1[0] += (kx[i] * state->x[i] / (ko - kx[i])) * (ex[i] - eo);
     }

     /* ya = intermediate step. */

     ya = state->y[0] * (1.0 - eo);

     for (i = 0; i < xoSize; i++)
     {
          if (is_zero(ko - kx[i], "ko-kx[i]")) continue;
          ya += (ko * state->x[i] / (ko - kx[i])) * (1.0 - ex[i]);
          ya -= (kx[i] * state->x[i] / (ko - kx[i])) * (1.0 - eo);
     }

     /* y[1] = gas */

     y1[1] = state->y[1] + fg * ya;

     for (i = 0; i < xgSize; i++)
          y1[1] += state->x[i + xoSize] * (1.0 - ex[i + xoSize]);

     /* y[2] = coke */

     y1[2] = state->y[2] + (1.0 - fg) * ya;

     /* Store the new state. */

     for (i = 0; i < state->xSize; i++)
          state->x[i] = x1[i];

     for (i = 0; i < state->ySize; i++)
          state->y[i] = y1[i];

     state->transf_ratio = abc_get_kerogen_transf_ratio(state);

     return TRUE;
}

/*
**   ===============================
**   Functions for the general model
**   ===============================
*/

int abc_read_kerogen_gen(
     AbcInput *in,
     AbcKerogenModel *model)
{
     char word[MAX_HC_WORD];
     int i;

     if (not get_keyword(in, "begin_kerogen"))
          RETURN_FALSE(in, "Can't read \"begin_kerogen\"!");

     if (not abc_get_word(in, word, MAX_HC_WORD) and not ABC_MATCH(word, "name"))
          RETURN_FALSE(in, "Can't read keyword \"name\"!");

     if (not abc_get_string(in, model->name, MAX_HC_WORD))
          RETURN_FALSE(in, "Can't read kerogen name! (expected a string)");

     if (not abc_read_kerogen_properties(in, &model->prop, FALSE))
          RETURN_FALSE(in, "Can't read inital kerogen content!");

     if (not abc_read_kerogen_hc_groups(in, &model->group))
          RETURN_FALSE(in, "Can't definition of HC-groups!");

     if (not abc_read_kerogen_kin_and_stoich(in, model, "kerogen"))
          RETURN_FALSE(in, "Can't read kerogen kinetics!");

     if (not abc_read_kerogen_kin_and_stoich(in, model, "unstable_hc"))
          RETURN_FALSE(in, "Can't read unstable HC-kinetics!");

     model->is_needed             = FALSE;
     model->n_kerogen_steps       = model->ker.size;
     model->n_hc_groups           = model->group.size;
     model->n_stable_hc_groups    = abc_get_number_of_stable_groups(&model->group);
     model->n_unstable_hc_groups  = model->n_hc_groups - model->n_stable_hc_groups;

     if (not get_keyword(in, "end_kerogen"))
          RETURN_FALSE(in, "Can't read \"end_kerogen\"!");

     for (i = 0; i < model->n_unstable_hc_groups; i++)
          model->B[i][i] = -1.0;

     model->do_one_time_step      = abc_gen_do_one_time_step_by_eigenvalues;
     model->expell_hc             = abc_expell_hc_default;
     model->init_state            = abc_init_kerogen_state_default;
     model->print_state           = abc_print_state_default;
     model->print_model           = abc_print_kerogen_model_default;
     model->print_model_tex       = abc_print_kerogen_model_default_TeX;

     return TRUE;
}


int abc_gen_do_one_time_step_rk4(
     AbcKerogenState *state, 
     double temp1, 
     double temp2, 
     double dt1)
{
     double dt = dt1;
     double f1 = dt / 6.0;

     double T0 = temp1;
     double T1 = 0.5 * (temp1 + temp2);
     double T2 = T1;
     double T3 = temp2;

     static double x0[MAX_HC_KINETICS], x1[MAX_HC_KINETICS];
     static double k1[MAX_HC_KINETICS], k2[MAX_HC_KINETICS];
     static double k3[MAX_HC_KINETICS], k4[MAX_HC_KINETICS];

     AbcKerogenModel *model = state->model;

     double sum1;
     double sum0 = abc_get_total_active_mass(state);
     int size = model->n_kerogen_steps + model->n_hc_groups;
     int i0 = model->n_kerogen_steps;
     int i, i1, ok;

     for (i = 0; i < model->n_kerogen_steps; i++)
          x0[i] = state->x[i]; 

     for (i = 0; i < model->n_hc_groups; i++)
          x0[i + i0] = state->y[i];
     
     /* STEP 1: */
     func_gen_F(state, T0, x0, k1);

     /* STEP 2: */
     for (i = 0; i < size; i++)
          x1[i] = x0[i] + 0.5 * k1[i] * dt;

     func_gen_F(state, T1, x1, k2);

     /* STEP 3: */
     for (i = 0; i < size; i++)
          x1[i] = x0[i] + 0.5 * k2[i] * dt;

     func_gen_F(state, T2, x1, k3);

     /* STEP 4: */
     for (i = 0; i < size; i++)
          x1[i] = x0[i] + k3[i] * dt;

     func_gen_F(state, T3, x1, k4);

     /* DONE: */

     for (i = 0; i < model->n_kerogen_steps; i++)
          state->x[i] = x0[i] + f1 * (k1[i] + 2.0 * k2[i] + 2.0 * k3[i] + k4[i]);

     for (i = 0; i < model->n_hc_groups; i++)
     {
          i1 = i0 + i;
          state->y[i] = x0[i1] + f1 * (k1[i1] + 2.0 * k2[i1] + 2.0 * k3[i1] + k4[i1]);
     }

     for (i = 0; i < model->n_kerogen_steps; i++)
          if (state->x[i] < 1.0e-9) state->x[i] = 0.0;

     for (i = 0; i < model->n_hc_groups; i++)
          if (state->y[i] < 1.0e-9) state->y[i] = 0.0;

     sum1 = abc_get_total_active_mass(state);
     ok = (ABC_ABS(sum1 - sum0) < 1.0e-6);

     if (not ok) 
          printf("Warning: total0=%g, total1=%g\n", sum0, sum1);

     return ok;
}


static void func_gen_F(
     AbcKerogenState *state, 
     double T,
     double *x,
     double *k)
{
     AbcKerogenModel *model = state->model;
     static double kA[MAX_HC_KINETICS], kB[MAX_HC_KINETICS];
     double RT = GAS_CONST * (T + 273.0);
     double **A = model->A;
     double **B = model->B;
     int i0 = model->n_kerogen_steps;
     int i, j, i1;
  
     for (i = 0; i < model->ker.size; i++)
          kA[i] = get_reaction_const(model->ker.A[i], model->ker.E[i], RT);

     for (i = 0; i < model->hc.size; i++)
          kB[i] = get_reaction_const(model->hc.A[i], model->hc.E[i], RT);
     
     for (i = 0; i < model->n_kerogen_steps; i++)
          k[i] = - kA[i] * x[i];

     for (i = 0; i < model->n_hc_groups; i++)
     {
          i1 = i0 + i;
          k[i1] = 0.0;

          for (j = 0; j < model->n_kerogen_steps; j++)
               k[i1] += A[i][j] * kA[j] * x[j];
     
          for (j = 0; j < model->n_unstable_hc_groups; j++)
               k[i1] += B[i][j] * kB[j] * x[i0 + j];
     }
}


int abc_gen_do_one_time_step_by_eigenvalues(
     AbcKerogenState *state,
     double temp1,
     double temp2,
     double dt1)
{
     static double kA[MAX_HC_KINETICS], kB[MAX_HC_KINETICS];
     static double u0[MAX_HC_KINETICS], vec1[MAX_HC_KINETICS];
     static double u1[MAX_HC_KINETICS], vec2[MAX_HC_KINETICS];
     static double lambda_re[MAX_HC_KINETICS], lambda_im[MAX_HC_KINETICS];
     static double bvec[MAX_HC_KINETICS], cvec[MAX_HC_KINETICS], dvec[MAX_HC_KINETICS];
     static double v0[MAX_HC_KINETICS], v1[MAX_HC_KINETICS];
     static int ivec[MAX_HC_KINETICS];

     AbcKerogenModel *model = state->model;

     double dt = dt1;
     double T1 = 0.5 * (temp1 + temp2);
     double RT = GAS_CONST * (T1 + 273.0);
     double **A = model->A;
     double **B = model->B;
     double **E = NULL;
     double **F = NULL;
     double **V = NULL;
     double **M = NULL;
     double fac1, fac2;

     int n1 = model->n_kerogen_steps + model->n_unstable_hc_groups;
     int n2 = model->n_stable_hc_groups;
     int n3 = model->n_unstable_hc_groups;
     int i0 = model->n_kerogen_steps;
     int i, j, k;

     ABC_NEW_MATRIX_2(E, double, n1, n1);
     ABC_NEW_MATRIX_2(F, double, n2, n1);
     ABC_NEW_MATRIX_2(V, double, n1, n1);
     ABC_NEW_MATRIX_2(M, double, n1, n1);

     abc_basic_zero_matrix(E, n1, n1);
     abc_basic_zero_matrix(F, n2, n1);

     /* Get the initial state. */

     for (i = 0; i < model->n_kerogen_steps; i++)
          u0[i] = state->x[i];

     for (i = 0; i < model->n_unstable_hc_groups; i++)
          u0[i + i0] = state->y[i];

     for (i = 0; i < model->n_stable_hc_groups; i++)
          v0[i] = state->y[i+n3];

     /* Make Arrhenius reaction constants. */

     for (i = 0; i < model->ker.size; i++)
          kA[i] = get_reaction_const(model->ker.A[i], model->ker.E[i], RT);

     for (i = 0; i < model->hc.size; i++)
          kB[i] = get_reaction_const(model->hc.A[i], model->hc.E[i], RT);

     /* Build the E-matrix. */

     for(i = 0; i < model->n_kerogen_steps; i++)
          E[i][i] = -kA[i];

     for (i = 0; i < model->n_unstable_hc_groups; i++)
     {
          for (j = 0; j < model->n_kerogen_steps; j++)
               E[i+i0][j] = A[i][j] * kA[j];

          for (j = 0; j < model->n_unstable_hc_groups; j++)
               E[i+i0][j+i0] = B[i][j] * kB[j];
     }

     for (j = 0; j < model->n_unstable_hc_groups; j++)
          E[j+i0][j+i0] = -kB[j];

     if (debug & DEBUG_VEC_AND_MAT) abc_show_matrix(stdout, "E", E, n1, n1);

     /* Find the eigenvalues and the eigenvectors of E. */

     abc_find_eigen_values_and_vectors(n1, E, NULL, V, lambda_re, lambda_im);

     if (debug & DEBUG_VEC_AND_MAT) abc_show_vector(stdout, "lambda", lambda_re, n1);
     if (debug & DEBUG_VEC_AND_MAT) abc_show_matrix(stdout, "eigenvectors", V, n1, n1);

     /* Check that the eigenvalues and the eigenvectors are OK! */

     check_eigen_solution(n1, E, V, lambda_re);

     /* Make the projection of initial state u0 on the eigenvectors. */

     abc_basic_copy_matrix(M, V, n1, n1);
     abc_basic_copy_vector(bvec, u0, n1);
     
     if (debug & DEBUG_VEC_AND_MAT) abc_show_matrix(stdout, "M", M, n1, n1);
     if (debug & DEBUG_VEC_AND_MAT) abc_show_vector(stdout, "b-vec", bvec, n1);
     abc_basic_gauss_solver(M, bvec, cvec, dvec, ivec, n1);
     if (debug & DEBUG_VEC_AND_MAT) abc_show_vector(stdout, "c-coefs", cvec, n1);

     /* Check the projection. */

     abc_basic_copy_matrix(M, V, n1, n1);
     abc_basic_matrix_mul_vector(M, cvec, vec1, n1, n1);
     abc_basic_sub_vectors(u0, vec1, vec2, n1); 

     for (i = 0; i < n1; i++)
          if (ABC_ABS(vec2[i]) > 1.0e-12)
               printf("Warning: Decomposition didn't work!, (diff[%d]=%g)\n", i, vec2[i]);

     /* Make first part of the solutions. */

     for (i = 0; i < n1; i++)
     {
          u1[i] = 0.0;

          for (k = 0; k < n1; k++)
               u1[i] += cvec[k] * V[i][k] * exp(lambda_re[k] * dt);

     }

     if (debug & DEBUG_VEC_AND_MAT) abc_show_vector(stdout, "u1", u1, n1);

     /* Make the F-matrix. */

     for (i = 0; i < model->n_stable_hc_groups; i++)
     {
          for (j = 0; j < model->n_kerogen_steps; j++)
               F[i][j] = A[i+n3][j] * kA[j];

          for (j = 0; j < model->n_unstable_hc_groups; j++)
               F[i][j+i0] = B[i+n3][j] * kB[j];
     }

     if (debug & DEBUG_VEC_AND_MAT) abc_show_matrix(stdout, "F", F, n2, n1);

     /* Make second part of the solution. */

     abc_basic_copy_vector(v1, v0, n2);
     abc_basic_copy_matrix(M, V, n1, n1);
     abc_basic_matrix_transpose(M, n1, n1);

     for (k = 0; k < n1; k++)
     {
          /* Eigenvectors are now rows in M-matrix. */
          abc_basic_matrix_mul_vector(F, M[k], vec1, n2, n1);

          fac1 = (cvec[k] / lambda_re[k]);
          fac2 = (exp(lambda_re[k] * dt) - 1.0);

          for (i = 0; i < n2; i++)
               v1[i] += vec1[i] * fac1 * fac2;
     }

     if (debug & DEBUG_VEC_AND_MAT) abc_show_vector(stdout, "v1", v1, n2);

     /* Set the new state. */

     for (i = 0; i < model->n_kerogen_steps; i++)
          state->x[i] = u1[i];

     for (i = 0; i < model->n_unstable_hc_groups; i++)
          state->y[i] = u1[i + i0];

     for (i = 0; i < model->n_stable_hc_groups; i++)
          state->y[i+n3] = v1[i];

     state->transf_ratio = abc_get_kerogen_transf_ratio(state);

     /* Clean up. */

     ABC_FREE_MATRIX_2(E);
     ABC_FREE_MATRIX_2(F);
     ABC_FREE_MATRIX_2(V);
     ABC_FREE_MATRIX_2(M);

     return 0;
}

static void check_eigen_solution(
     int n1,
     double **E,
     double **V,
     double *lambda)
{
     int i, k;
     double diff;
     static double evec[MAX_HC_KINETICS], vec1[MAX_HC_KINETICS];

     for (k = 0; k < n1; k++)
     {
          /* Notice that the eigen-vectors are store as columns. */

          for (i = 0; i < n1; i++)
               evec[i] = V[i][k];

          abc_basic_matrix_mul_vector(E, evec, vec1, n1, n1);

          if (lambda[k] > 0.0)
               printf("Warning: Pos eigenvalue! (lambda[%d]=%g)\n", k, lambda[k]);

          for (i = 0; i < n1; i++)
          {
               diff = vec1[i] - (lambda[k] * evec[i]);
               if (ABC_ABS(diff) > 1.0e-5)
                    printf("Warning: Eigenvalue? Av[%d]-lv[%d]=%11.4e\n", i, i, diff);
          }
     }
}

