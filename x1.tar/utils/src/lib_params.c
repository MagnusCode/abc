/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1996-2010 by M. Wangen.
**
**   Info: Functions for reading parameters
**   Date: Version 1.0, March 2000
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_math.h>
#include <lib_utils.h>
#include <lib_input.h>
#include <lib_args.h>
#include <lib_params.h>

#define MAX_LEVELS 16

static const char *get_extension(const char *file_name);

static void print_underline(FILE *out, const char *text, const char ch);
static int get_param_field(AbcInput *in, char *field, int max_field);
static int get_current_int_value_of_pointer(AbcParams *params, void *pointer);
static int get_param_as_int(AbcParamDef *p);
static double get_param_as_double(AbcParamDef *p);
static void set_param_as_int(AbcParamDef *p, int value);
static void set_param_as_double(AbcParamDef *p, double value);
static int set_param_as_string(AbcParamDef *p, const char *src);

static int dummy_set_param_by_string(AbcParamDef *p, const char *string);
static double dummy_get_param_as_number(AbcParamDef *p);
static void dummy_get_param_as_string(AbcParamDef *p, char *string);
static const char *dummy_get_param_type_name(void);
static void dummy_print_param(AbcParamDef *p, FILE *out);

static int int_set_param_by_string(AbcParamDef *p, const char *string);
static double int_get_param_as_number(AbcParamDef *p);
static void int_get_param_as_string(AbcParamDef *p, char *string);
static const char *int_get_param_type_name(void);
static void int_print_param_info_line(AbcParamDef *p, FILE *out);
static void int_print_param_line(AbcParamDef *p, FILE *out);
static void int_print_param_line_tex(AbcParamDef *p, FILE *out);
static void int_print_param_defaults_line1_tex(AbcParamDef *param, FILE *out);
static void int_print_param_defaults_line2_tex(AbcParamDef *p, FILE *out);

static int double_set_param_by_string(AbcParamDef *p, const char *string);
static double double_get_param_as_number(AbcParamDef *p);
static void double_get_param_as_string(AbcParamDef *p, char *string);
static const char *double_get_param_type_name(void);
static void double_print_param_info_line(AbcParamDef *p, FILE *out);
static void double_print_param_line(AbcParamDef *p, FILE *out);
static void double_print_param_line_tex(AbcParamDef *p, FILE *out);
static void double_print_param_defaults_line1_tex(AbcParamDef *param, FILE *out);
static void double_print_param_defaults_line2_tex(AbcParamDef *p, FILE *out);

static int bit_set_param_by_string(AbcParamDef *param, const char *string);
static int bit_set_param_by_value(AbcParamDef *param, int value);
static int bit_is_set_for_param(AbcParamDef *param);
static double bit_get_param_as_number(AbcParamDef *param);
static void bit_get_param_as_string(AbcParamDef *param, char *string);
static const char *bit_get_param_type_name(void);
static void bit_print_param_info_line(AbcParamDef *p, FILE *out);
static void bit_print_param_line(AbcParamDef *p, FILE *out);
static void bit_print_param_line_tex(AbcParamDef *p, FILE *out);
static void bit_print_param_defaults_line1_tex(AbcParamDef *param, FILE *out);
static void bit_print_param_defaults_line2_tex(AbcParamDef *p, FILE *out);
static int bit_get_bit_number(double value);

static int label_set_param_by_string(AbcParamDef *param, const char *string);
static int get_label_index(AbcParamDef *param, const char *label_name);
static double label_get_param_as_number(AbcParamDef *p);
static void label_get_param_as_string(AbcParamDef *p, char *string);
static const char *get_label_from_value(AbcParamDef *param, int label_ID);
static const char *label_get_param_type_name(void);
static void label_print_param_info_line(AbcParamDef *p, FILE *out);
static void label_print_param_line(AbcParamDef *p, FILE *out);
static void label_print_param_line_tex(AbcParamDef *p, FILE *out);
static void label_print_param_defaults_line1_tex(AbcParamDef *p, FILE *out);
static void label_print_param_defaults_line2_tex(AbcParamDef *p, FILE *out);

static int bool_set_param_by_string(AbcParamDef *p, const char *string);
static double bool_get_param_as_number(AbcParamDef *p);
static void bool_get_param_as_string(AbcParamDef *p, char *string);
static const char *bool_get_param_type_name(void);
static void bool_print_param_info_line(AbcParamDef *p, FILE *out);
static void bool_print_param_line(AbcParamDef *p, FILE *out);
static void bool_print_param_line_tex(AbcParamDef *p, FILE *out);
static void bool_print_param_defaults_line1_tex(AbcParamDef *p, FILE *out);
static void bool_print_param_defaults_line2_tex(AbcParamDef *p, FILE *out);

static int string_set_param_by_string(AbcParamDef *p, const char *string);
static double string_get_param_as_number(AbcParamDef *p);
static void string_get_param_as_string(AbcParamDef *p, char *string);
static const char *string_get_param_type_name(void);
static void string_print_param_info_line(AbcParamDef *p, FILE *out);
static void string_print_param_line(AbcParamDef *p, FILE *out);
static void string_print_param_line_tex(AbcParamDef *p, FILE *out);
static void string_print_param_defaults_line1_tex(AbcParamDef *p, FILE *out);
static void string_print_param_defaults_line2_tex(AbcParamDef *p, FILE *out);

static int func_set_param_by_string(AbcParamDef *p, const char *string);
static double func_get_param_as_number(AbcParamDef *p);
static void func_get_param_as_string(AbcParamDef *p, char *string);
static const char *func_get_param_type_name(void);
static void func_print_param_info_line(AbcParamDef *p, FILE *out);
static void func_print_param_line(AbcParamDef *p, FILE *out);
static void func_print_param_line_tex(AbcParamDef *p, FILE *out);
static void func_print_param_defaults_line1_tex(AbcParamDef *p, FILE *out);
static void func_print_param_defaults_line2_tex(AbcParamDef *p, FILE *out);


static const char
     *margin = "     ";

static int
     show_comment = FALSE,
     do_range_checking = TRUE;

#define P1 1
#define P2 2
#define P3 3
#define P4 4

static int nn, yy, tt, ff;
static int l1, l2;
static int b1, b2, b3;
static int i1, i2;
static int bit_pattern;
static double n1, n2, n3;
static char file_res[ABC_MAX_WORD], file_log[ABC_MAX_WORD], file_plot[ABC_MAX_WORD];


#ifdef _TEST_LIB_PARAMS
int main(int argc, char **argv)
{
     return test_params_main2(argc, argv);
}
#endif

/*
**   ===============================
**   Demo and test functions
**   ===============================
*/

int abc_test_params_main1(
     int argc,
     char **argv)
{
     AbcParams *params = abc_new_params(1024);

     /* Define the parameters. */
     abc_add_some_test_params(params);

     /* Show the parameters. */
     abc_print_param_info(params, stdout);

     /* Read parameters. */
     abc_read_params(params, &argc, argv);

     /* Print current parameters. */
     abc_print_all_params(params, stdout);
     abc_print_params_as_tex_file(params, "xparams");

     abc_delete_params(&params);

     if (params != NULL)
          printf("parameters are not properly deleted!\n");

     printf("bit_pattern=%d\n", bit_pattern);

     return 0;
}


int abc_test_params_main2(
     int argc,
     char **argv)
{
     AbcArgs args;
     AbcParams *params = NULL;

     abc_init_args(&args);
     abc_add_args(&args, argc, argv);

     params = abc_new_params(1024);

     /* Define the parameters. */
     abc_add_some_test_params(params);

     /* Show the parameters. */
     abc_print_param_info(params, stdout);

     /* Read parameters. */
     abc_read_params_by_args(params, &args);
     abc_exit_if_unused_args(&args);

     /* Print current parameters. */
     abc_print_all_params(params, stdout);
     abc_print_params_as_tex_file(params, "xparams");

     abc_delete_params(&params);

     if (params != NULL)
          printf("parameters are not properly deleted!\n");

     printf("bit_pattern=%d\n", bit_pattern);

     return 0;
}


int abc_test_params_main3(
     int argc,
     char **argv)
{
     AbcParams *params = abc_new_params(1024);

     /* Define the parameters. */
     abc_add_some_test_params(params);

     /* Show the parameters. */
     abc_print_param_info(params, stdout);

     /* Read parameters. */
     if (not abc_read_params(params, &argc, argv))
          ABC_ERROR_EXIT("Illegal parameters!");

     /* Print current parameters. */
     abc_print_all_params(params, stdout);
     abc_print_params_as_tex_file(params, "xparams");

     abc_delete_params(&params);

     if (params != NULL)
          printf("parameters are not properly deleted!\n");

     printf("bit_pattern=%d\n", bit_pattern);

     return 0;
}


void abc_add_some_test_params(
     AbcParams *params)
{
     /* Parameter group: P1 */
     abc_def_param_group(params, "Heat flow parameters:", P1);

     abc_def_int_param(params, &i1, "perm_exp", "-", "Surface area exponent", 1, -10, 10, P1);
     abc_def_int_param(params, &i2, "surf_exp", "-", "Permeability exponent", 2, -10, 10, P1);
     abc_def_double_param(params, &n1, "lambda_rock", "W/m2", "Heat conductivity rock", 2.3, 1.0, 7.0, P1);
     abc_def_double_param(params, &n2, "lambda_fluid", "W/m2", "Heat conductivity rock", 1.7, 0.5, 7.0, P1);
     abc_def_double_param(params, &n3, "perm_rock", "m2", "Absolute permeability rock", 2.5e-15, 1.0e-23, 1.0e-8, P1);

     /* Parameter group: P2 */
     abc_def_param_group(params, "Solver parameters:", P2);

     abc_def_boolean_param(params, &b1, "debug_solver", "Debug solver", 0, P2);
     abc_def_boolean_param(params, &b2, "debug_precondition", "Debug precondition", 0, P2);

     abc_def_label_param(params, &l1, "precondition", "Preconditioner", "MX1", 111, P2);
     abc_add_label(params, "precondition", "MX2", 222);
     abc_add_label(params, "precondition", "MX3", 333);

     abc_def_label_param(params, &l2, "temperature_solver", "Temperature solver", "SOR", 66, P2);
     abc_add_label(params, "temperature_solver", "band", 77);
     abc_add_label(params, "temperature_solver", "Gauss", 88);
     abc_add_label(params, "temperature_solver", "PCG", 99);
     abc_add_label(params, "temperature_solver", "GMRES", 11);

     /* Parameter group: P3 */
     abc_def_param_group(params, "Control parameters:", P3);

     abc_def_label_param(params, &b3, "run_silent", "New-boolean-3", "YES", 1, P3);
     abc_add_label(params, "run_silent", "NO", 0);

     abc_def_yes_no_param(params, &nn, "do_time_stepping", "Enable/disable time stepping", 0, P3);
     abc_def_yes_no_param(params, &yy, "use_stationary_temperature", "Disable transient temperature", 1, P3);

     abc_def_true_false_param(params, &ff, "do_porosity_checking", "Check the porosity", 0, P3);
     abc_def_true_false_param(params, &tt, "do_permeability_checking", "Check the permeability", 1, P3);

     abc_def_bit_param(params, &bit_pattern, "debug_temp_coefs", "Debug temperature coefficients", 0, 1, P3);
     abc_def_bit_param(params, &bit_pattern, "debug_pres_coefs", "Debug pressure coefficients", 0, 2, P3);
     abc_def_bit_param(params, &bit_pattern, "debug_bond_strength", "Debug bond strength", 0, 4, P3);
     abc_def_bit_param(params, &bit_pattern, "debug_fracture_pres", "Debug fracture pressure", 0, 8, P3);

     /* Parameter group: P4 */
     abc_def_param_group(params, "File names", P4);

     abc_def_string_param(params, file_res, "result_file", 
          "Output file for results", "x-res.xy", ABC_MAX_WORD, P4);
     abc_def_string_param(params, file_log, "log_file", 
          "Output file for the log", "x-log.xy", ABC_MAX_WORD, P4);
     abc_def_string_param(params, file_plot, "plot_file", 
          "Output file for plots", "x-plot.xy", ABC_MAX_WORD, P4);
}

/*
**   ===============================
**   Main functions
**   ===============================
*/

AbcParams *abc_new_params(
     int max_params)
{
     AbcParams *params;
     int GR1 = 1024;

     ABC_NEW_OBJECT(params, AbcParams);
     ABC_NEW_ARRAY(params->param, AbcParamDef, max_params);

     params->n_groups = 0;
     params->n_params = 0;
     params->max_params = max_params;
     params->read_special_params = NULL;
     params->input_file = NULL;

     params->show_comment = FALSE;
     params->do_range_checking = TRUE;
     params->is_delimited_block = FALSE;
     params->is_sloppy = FALSE;

     abc_def_param_group(params, "Built-in parameters:", GR1);

     abc_def_boolean_param(params, &params->show_comment, 
          "show_parameter_comment", "Show parameter comments", 0, GR1);

     abc_def_boolean_param(params, &params->do_range_checking, 
          "do_range_checking", "Do range checking on parameters", 1, GR1);

     abc_def_func_param(params, abc_param_help_action, 
          "-h", "Give help on options", GR1);

     abc_def_func_param(params, abc_param_inputfile_action, 
          "in", "Read options from input file", GR1);

     abc_def_func_param(params, abc_param_inputfile_action, 
          "inp", "Read options from input file", GR1);

     abc_def_func_param(params, abc_param_inputfile_action, 
          "input", "Read options from input file", GR1);

     return params;
}


void abc_set_params_sloppy_mode(
     AbcParams *params,
     int on_off)
{
     params->is_sloppy = on_off;
}


void abc_set_params_comments(
     AbcParams *params,
     int on_off)
{
     params->show_comment = on_off;
}

void abc_set_params_range_checking(
     AbcParams *params,
     int on_off)
{
     params->do_range_checking = on_off;
}


void abc_use_params_input_block(
     AbcParams *params,
     int on_off)
{
     params->is_delimited_block = on_off;
}


void abc_set_special_param_input(
     AbcParams *params,
     ABC_READ_SPECIAL_PARAMS read_special_params)
{
     params->read_special_params = read_special_params;
}


void abc_delete_params(
     AbcParams **pparams)
{
     int i;
     AbcParams *params = *pparams;

     for (i = 0; i < params->n_params; i++)
          abc_delete_one_param(&(params->param[i]));

     for (i = 0; i < params->n_groups; i++)
          ABC_FREE_ARRAY(params->group_name[i]);

     ABC_FREE_ARRAY(params->input_file);
     ABC_FREE_ARRAY(params->param);
     ABC_FREE(params);
     *pparams = NULL;
}


void abc_delete_one_param(
     AbcParamDef *param)
{
     int i;

     ABC_FREE_ARRAY(param->name); 
     ABC_FREE_ARRAY(param->units); 
     ABC_FREE_ARRAY(param->comment); 
     ABC_FREE_ARRAY(param->default_string);

     for (i = 0; i < param->n_labels; i++)
          ABC_FREE_ARRAY(param->label_name[i]);
}


void abc_def_param_group(
     AbcParams *params,
     const char *group_name,
     int group_code)
{
     int k = params->n_groups;

     if (k >= MAX_ABC_PARAM_GROUPS)
          ABC_ERROR_EXIT("[lib_params] Too many groups!");

     params->group_name[k] = abc_save_string(group_name);
     params->group_code[k] = group_code;
     params->n_groups++;
}


void abc_def_func_param(
     AbcParams *params,
     ABC_PARAM_ACTION take_action,
     const char *name,
     const char *comment,
     int code)
{
     AbcParamDef *param = abc_def_param(params, NULL, name, "-", comment,
          0.0, 0.0, 1.0, code, AbcParamFunction);

     param->take_action = take_action;
     param->set_param_by_string = func_set_param_by_string;
     param->get_param_as_number = func_get_param_as_number;
     param->get_param_as_string = func_get_param_as_string;
     param->get_param_type_name = func_get_param_type_name;

     param->print_param_info_line = func_print_param_info_line;
     param->print_param_line = func_print_param_line;
     param->print_param_line_tex = func_print_param_line_tex;
     param->print_param_defaults_line1_tex = func_print_param_defaults_line1_tex;
     param->print_param_defaults_line2_tex = func_print_param_defaults_line2_tex;
}


void abc_def_string_param(
     AbcParams *params,
     char *pointer,
     const char *name,
     const char *comment,
     const char *default_string,
     int max_size,
     int code)
{
     const char *empty_string = "";

     AbcParamDef *param = abc_def_param(params, 
          (void *) pointer, name, "-", comment,
           0.0, 0.0, 1.0, code, AbcParamString);

     param->set_param_by_string = string_set_param_by_string;
     param->get_param_as_number = string_get_param_as_number;
     param->get_param_as_string = string_get_param_as_string;
     param->get_param_type_name = string_get_param_type_name;

     param->print_param_info_line = string_print_param_info_line;
     param->print_param_line = string_print_param_line;
     param->print_param_line_tex = string_print_param_line_tex;
     param->print_param_defaults_line1_tex = string_print_param_defaults_line1_tex;
     param->print_param_defaults_line2_tex = string_print_param_defaults_line2_tex;

     if (default_string == NULL) default_string = empty_string;

     param->max_string_size = max_size;
     param->default_string = abc_save_string(default_string);
     set_param_as_string(param, default_string);
}


void abc_def_bit_param(
     AbcParams *params,
     int *pointer,
     const char *name,
     const char *comment,
     int default_value,
     int bit_value,
     int code)
{
     int current_value = get_current_int_value_of_pointer(params, (void *) pointer);

     AbcParamDef *param = abc_def_param(params, 
          (void *) pointer, name, "-", comment,
           (double) current_value, 0.0, 1.0e+64, code, AbcParamBit);

     param->set_param_by_string = bit_set_param_by_string;
     param->get_param_as_number = bit_get_param_as_number;
     param->get_param_as_string = bit_get_param_as_string;
     param->get_param_type_name = bit_get_param_type_name;

     param->print_param_info_line = bit_print_param_info_line;
     param->print_param_line = bit_print_param_line;
     param->print_param_line_tex = bit_print_param_line_tex;
     param->print_param_defaults_line1_tex = bit_print_param_defaults_line1_tex;
     param->print_param_defaults_line2_tex = bit_print_param_defaults_line2_tex;

     param->bit_value = bit_value;
     param->default_value = default_value;
     bit_set_param_by_value(param, default_value);
}


void abc_def_boolean_param(
     AbcParams *params,
     int *pointer,
     const char *name,
     const char *comment,
     int default_value,
     int code)
{
     AbcParamDef *param = abc_def_param(params, (void *) pointer, name, "-", comment,
          (double) default_value, 0.0, 1.0, code, AbcParamBoolean);

     param->set_param_by_string = bool_set_param_by_string;
     param->get_param_as_number = bool_get_param_as_number;
     param->get_param_as_string = bool_get_param_as_string;
     param->get_param_type_name = bool_get_param_type_name;

     param->print_param_info_line = bool_print_param_info_line;
     param->print_param_line = bool_print_param_line;
     param->print_param_line_tex = bool_print_param_line_tex;
     param->print_param_defaults_line1_tex = bool_print_param_defaults_line1_tex;
     param->print_param_defaults_line2_tex = bool_print_param_defaults_line2_tex;
}


void abc_def_yes_no_param(
     AbcParams *params,
     int *pointer,
     const char *name,
     const char *comment,
     int default_value,
     int code)
{
     if (default_value == 0)
     {
          abc_def_label_param(params, pointer, name, comment, "no", 0, code);
          abc_add_label(params, name, "yes",  1);
     }
     else
     {
          abc_def_label_param(params, pointer, name, comment, "yes", 1, code);
          abc_add_label(params, name, "no",  0);
     }
     
     abc_add_label(params, name, "YES", 1);
     abc_add_label(params, name, "NO",  0);
}


void abc_def_true_false_param(
     AbcParams *params,
     int *pointer,
     const char *name,
     const char *comment,
     int default_value,
     int code)
{
     /*
     ** Warning: "true" and "false" are defined as 1 and 0 by macros, respectively.
     */

     if (default_value == 0)
     {
          abc_def_label_param(params, pointer, name, comment, "False", 0, code);
          abc_add_label(params, name, "True",  1);
     }
     else
     {
          abc_def_label_param(params, pointer, name, comment, "True", 1, code);
          abc_add_label(params, name, "False",  0);
     }

     abc_add_label(params, name, "TRUE",  1);
     abc_add_label(params, name, "FALSE", 0);
}


void abc_def_label_param2(
     AbcParams *params,
     int *pointer,
     const char *comment,
     const char *name,
     const char *label_name,
     int label_value,
     int code)
{
     abc_def_label_param(params, pointer, name, comment, 
          label_name, label_value, code);
}


void abc_def_label_param(
     AbcParams *params,
     int *pointer,
     const char *name,
     const char *comment,
     const char *label_name,
     int label_value,
     int code)
{
     AbcParamDef *param = abc_def_param(params, 
          (void *) pointer, name, "-", comment,
          (double) label_value, -1.0e+32, 1.0e+32, code, AbcParamLabel);

     param->set_param_by_string = label_set_param_by_string;
     param->get_param_as_number = label_get_param_as_number;
     param->get_param_as_string = label_get_param_as_string;
     param->get_param_type_name = label_get_param_type_name;

     param->print_param_info_line = label_print_param_info_line;
     param->print_param_line = label_print_param_line;
     param->print_param_line_tex = label_print_param_line_tex;
     param->print_param_defaults_line1_tex = label_print_param_defaults_line1_tex;
     param->print_param_defaults_line2_tex = label_print_param_defaults_line2_tex;

     abc_add_label(params, name, label_name, label_value);
}


void abc_def_int_param(
     AbcParams *params,
     int *pointer,
     const char *name,
     const char *units,
     const char *comment,
     int default_value,
     int min_value,
     int max_value,
     int code)
{
     AbcParamDef *param = abc_def_param(params, 
          (void *) pointer, name, units, comment,
          (double) default_value, (double) min_value, (double) max_value, 
          code, AbcParamInt);

     param->set_param_by_string = int_set_param_by_string;
     param->get_param_as_number = int_get_param_as_number;
     param->get_param_as_string = int_get_param_as_string;
     param->get_param_type_name = int_get_param_type_name;

     param->print_param_info_line = int_print_param_info_line;
     param->print_param_line = int_print_param_line;
     param->print_param_line_tex = int_print_param_line_tex;
     param->print_param_defaults_line1_tex = int_print_param_defaults_line1_tex;
     param->print_param_defaults_line2_tex = int_print_param_defaults_line2_tex;
}


void abc_def_double_param(
     AbcParams *params,
     double *pointer,
     const char *name,
     const char *units,
     const char *comment,
     double default_value,
     double min_value,
     double max_value,
     int code)
{
     AbcParamDef *param = abc_def_param(params, 
          (void *) pointer, name, units, comment,
          default_value, min_value, max_value, 
          code, AbcParamDouble);

     param->set_param_by_string = double_set_param_by_string;
     param->get_param_as_number = double_get_param_as_number;
     param->get_param_as_string = double_get_param_as_string;
     param->get_param_type_name = double_get_param_type_name;

     param->print_param_info_line = double_print_param_info_line;
     param->print_param_line = double_print_param_line;
     param->print_param_line_tex = double_print_param_line_tex;
     param->print_param_defaults_line1_tex = double_print_param_defaults_line1_tex;
     param->print_param_defaults_line2_tex = double_print_param_defaults_line2_tex;
}


AbcParamDef *abc_def_param(
     AbcParams *params,
     void *pointer,
     const char *name,
     const char *units,
     const char *comment,
     double default_value,
     double min_value,
     double max_value,
     int code,
     int type)
{
     AbcParamDef *param;
     int i = params->n_params;

     if (i >= params->max_params)
     {
          fprintf(stderr, "[lib_params] No space left for more parameters!\n");
          fprintf(stderr, "Tried to define parameter \"%s\".\n", name);
          exit(1);
     }
          

     if (not abc_is_unused_param_name(params, name))
     {
          fprintf(stderr, "[lib_params] Parameter name \"%s\" is not unique!\n", name);
          fprintf(stderr, "Can't continue!\n");
          exit(1);
     }

     if (min_value > max_value)
     {
          fprintf(stderr, "[lib_params] Parameter \"%s\" has: min > max, ", name);
          fprintf(stderr, "(min=%g and max=%g).\n", min_value, max_value);
          fprintf(stderr, "Can't continue!\n");
          exit(1);
     }

     param = &(params->param[i]);

     param->take_action = abc_param_std_action;
     param->type = type;
     param->pointer = pointer;
     param->name = abc_save_string(name);
     param->units = abc_save_string(units);
     param->comment = abc_save_string(comment);
     param->default_value = default_value;
     param->min_value = min_value;
     param->max_value = max_value;
     param->group_code = code;
     param->bit_value = 0;
     param->n_labels = 0;
     param->default_string = NULL;

     /* Dummy member functions. */

     param->set_param_by_string = dummy_set_param_by_string;
     param->get_param_as_number = dummy_get_param_as_number;
     param->get_param_as_string = dummy_get_param_as_string;
     param->get_param_type_name = dummy_get_param_type_name;
     param->print_param_info_line = dummy_print_param;
     param->print_param_line = dummy_print_param;
     param->print_param_line_tex = dummy_print_param;
     param->print_param_defaults_line1_tex = dummy_print_param;
     param->print_param_defaults_line2_tex = dummy_print_param;

     params->n_params++;

     if (not abc_assign_param_number(param, default_value))
          ABC_ERROR_EXIT("[lib_params] Illegal default-value!");

     return param;
}


void abc_add_label(
     AbcParams *params,
     const char *name,
     const char *label_name,
     int label_value)
{
     AbcParamDef *param;
     int i = abc_get_param_index(params, name);
     int k;

     if (i < 0 )
     {
          fprintf(stderr, "There is no parameter named \"%s\" to add label \"%s\"!\n",
               name, label_name);
          exit(1);
     }

     param = &(params->param[i]);
     k = param->n_labels;

     if (k >= MAX_ABC_PARAM_LABELS)
          ABC_ERROR_EXIT("[lib_params] Too many labels!");

     param->label_name[k] = abc_save_string(label_name);
     param->label_ID[k] = label_value;
     param->n_labels++;

     if (param->n_labels == 1)
          abc_assign_param_number(param, (double) label_value);
}


void abc_debug_params(
     AbcParams *params)
{
     int i;
     AbcParamDef *param;

     for (i = 0; i < params->n_params; i++)
     {
          param = &(params->param[i]);
          printf("param[%d] name=%s, value=%g, pointer=%p\n", i, 
               param->name, abc_get_param_value(param), param->pointer);
     }
}


int abc_is_unused_param_name(
     AbcParams *params,
     const char *name)
{
     return (abc_get_param_index(params, name) < 0);
}


int abc_get_param_index(
     AbcParams *params,
     const char *name)
{
     int i;
     AbcParamDef *param;

     for (i = 0; i < params->n_params; i++)
     {
          param = &(params->param[i]);
          if (ABC_MATCH(param->name, name)) return i;
     }

     return -1;
}


const char *abc_get_params_input_file_name(
     AbcParams *params)
{
     if (params->input_file == NULL) 
          return "";

     return params->input_file;
}


void abc_rename_param(
     AbcParams *params,
     const char *name,
     const char *new_name)
{
     AbcParamDef *param;
     int i = abc_get_param_index(params, name);

     if (i < 0)
     {
          fprintf(stderr, "There is no parameter named \"%s\"!\n", name);
          fprintf(stderr, "Cannot rename it!\n");
          return;
     }
     
     param = &(params->param[i]);
     ABC_FREE_ARRAY(param->name);
     param->name = abc_save_string(new_name);
}

/*
**   ===============================
**   Read functions
**   ===============================
*/

int abc_read_params(
     AbcParams *params,
     int *argc,
     char **argv)
{
     int i;
     int errors = 0;

     for (i = 1; i < *argc; i++)
          if (not abc_read_one_param_option(params, argv[i]))
          {
               fprintf(stderr, "Unknown option: %s\n", argv[i]);
               errors++;
          }

     if (errors > 0)
          fprintf(stderr, "Got %d unknown options!\n", errors);

     return (errors == 0);
}


void abc_read_all_params_by_args(
     AbcParams *params,
     int argc,
     char **argv)
{
     AbcArgs args;

     abc_init_args(&args);
     abc_add_args(&args, argc, argv);
     abc_read_params_by_args(params, &args);

     if (not params->is_sloppy)
          abc_exit_if_unused_args(&args);
}


void abc_read_params_by_args(
     AbcParams *params,
     AbcArgs *args)
{
     int is_special;
     const char *option;

     abc_begin_reading_args(args);

     while ((option = abc_get_next_arg(args)) != NULL)
     {
          is_special = FALSE;

          /* Looking for special params before standard params. */

          if (params->read_special_params != NULL)
               is_special = params->read_special_params(args, option);

          if ((not is_special) and (not abc_read_one_param_option(params, option)))
               abc_current_arg_is_unused(args);
     }
}


int abc_read_one_param_option(
     AbcParams *params,
     const char *string)
{
     int k;
     double value;
     char option_part[ABC_MAX_WORD], value_part[ABC_MAX_WORD];

     abc_interpret_option(string, option_part, value_part, &value);

     show_comment = params->show_comment;
     do_range_checking = params->do_range_checking;

     for (k = 0; k < params->n_params; k++) 
          if (ABC_MATCH(option_part, params->param[k].name))
               return params->param[k].take_action(params, k, (void *) value_part);

     return FALSE;
}


int abc_param_std_action(
     AbcParams *params,
     int k,
     void *data)
{
     char *value_part = (char *) data;

     if (abc_assign_param_value(&(params->param[k]), value_part))
          return TRUE;

     fprintf(stderr, "Can't assign value! (parameter=%s, value=%s)\n",
          params->param[k].name, value_part);

     return FALSE;
}


int abc_param_inputfile_action(
     AbcParams *params,
     int k,
     void *data)
{
     char *value_part = (char *) data;

     abc_read_params_from_file(params, value_part);
     if (params->input_file != NULL) ABC_FREE_ARRAY(params->input_file);
     params->input_file = abc_save_string(value_part);
     ABC_UNUSED_PARAMETER(k);
     return TRUE;
}


int abc_param_help_action(
     AbcParams *params,
     int k,
     void *data)
{
     abc_print_param_info(params, stdout);
     ABC_UNUSED_PARAMETER(k);
     ABC_UNUSED_PARAMETER(data);
     exit(0);
}


int abc_read_params_from_file(
     AbcParams *params,
     const char *filename)
{
     static int level_of_recursion = 0;
     static char *fnames[MAX_LEVELS];
     AbcArgs args;
     AbcInput in;
     char field[ABC_MAX_WORD] = "";
     int n_errors = 0;
     int i;

     if (ABC_MATCH(filename, ""))
          return TRUE;

     fnames[level_of_recursion] = abc_save_string(filename);
     level_of_recursion++;

     if (level_of_recursion >= MAX_LEVELS)
     {
          fprintf(stderr, "Level of recursion has reached %d!\n", MAX_LEVELS);
          fprintf(stderr, "Is there direct or indirect reading of the same input files?\n");
          fprintf(stderr, "These files have been opened so far:\n");

          for (i = 0; i < level_of_recursion; i++)
               fprintf(stderr, "file%d: %s\n", i + 1, fnames[i]);

          exit(1);
     }

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Can't open input-file: %s\n", filename);
          exit(1);
     }

     abc_init_args(&args);

     if (params->is_delimited_block)
     {
          if (not abc_skip_until_word(&in, "begin_parameters"))
          {
               fprintf(stderr, "Can't find \"begin_parameters\" on file: %s!\n", filename);
               exit(1);
          }

          while(not ABC_MATCH(field, "end_parameters"))
          {
               if (not get_param_field(&in, field, ABC_MAX_WORD))
                    ABC_ERROR_EXIT("Expected a parameter statement!");
     
               if (not ABC_MATCH(field, "end_parameters"))
                    abc_add_one_arg(&args, field);
          }
     }
     else
     {
          while(get_param_field(&in, field, ABC_MAX_WORD))
               abc_add_one_arg(&args, field);
     }

     abc_end_input(&in);
     abc_read_params_by_args(params, &args);

     if (not params->is_sloppy)
          abc_exit_if_unused_args(&args);

     level_of_recursion--;
     ABC_FREE(fnames[level_of_recursion]);

     if (n_errors > 0)
          ABC_ERROR_EXIT("Parameter errors! Can't continue!");

     printf("(parameters are read from: %s)\n", filename);
     return TRUE;
}


static int get_param_field(
     AbcInput *in,
     char *field,
     int max_field)
{
     int c;
     char keyword[ABC_MAX_WORD], sign[ABC_MAX_WORD], cmd[ABC_MAX_WORD];

     if (not abc_get_word(in, keyword, ABC_MAX_WORD))
          return FALSE;

     if (ABC_MATCH(keyword, "end_parameters"))
     {
          strcpy(field, "end_parameters");
          return TRUE;
     }

     if (not abc_get_word(in, sign, ABC_MAX_WORD))
          ABC_RETURN_FALSE("Expected \"=\"!");

     if (sign[0] != '=')
          ABC_RETURN_FALSE("Expected \"=\"!");

     abc_skip_blanks_and_comments(in);

     c = abc_getch(in);
     abc_ungetch(in, c);

     if (c == '"')
     {
          if (not abc_get_string(in, cmd, ABC_MAX_WORD))
               ABC_RETURN_FALSE("Expected a command string!");
     }
     else
     {
          if (not abc_get_field(in, cmd, ABC_MAX_WORD))
               ABC_RETURN_FALSE("Expected a command field!");
     }

     if (strlen(keyword) + 1 + strlen(cmd) >= (size_t) max_field)
          ABC_RETURN_FALSE("Too long parameter field!");

     sprintf(field, "%s%s%s", keyword, sign, cmd);
     return TRUE;
}


int abc_assign_param_value(
     AbcParamDef *param,
     const char *string)
{
     return param->set_param_by_string(param, string);
}


int abc_assign_param_number(
     AbcParamDef *param,
     double value)
{
     int ok = TRUE;

     if (do_range_checking and (value < param->min_value))
     {
          fprintf(stderr, "Warning: Default value for \"%s\" is less than min-value!\n", param->name);
          fprintf(stderr, "(value=%g, min=%g and max=%g)\n", value, param->min_value, param->max_value);
          value = param->min_value;
          ok = FALSE;
     }

     if (do_range_checking and (value > param->max_value))
     {
          fprintf(stderr, "Warning: Default value for \"%s\" is larger than max-value!\n", param->name);
          fprintf(stderr, "(value=%g, min=%g and max=%g)\n", value, param->min_value, param->max_value);
          value = param->max_value;
          ok = FALSE;
     }

     /***
     printf("(assigning param=%s the value=%g)\n", param->name, value, param->pointer);
     ***/

     switch (param->type)
     {
          case AbcParamInt: 
          case AbcParamBit: 
          case AbcParamLabel:
          case AbcParamBoolean:
               set_param_as_int(param, (int) value);
               break;

          case AbcParamDouble: 
               set_param_as_double(param, value);
               break;

          case AbcParamString:
          case AbcParamFunction:
               break;

          default: fprintf(stderr, "Parameter %s has unknown type!\n", param->name);
     }

     return ok;
}


double abc_get_param_value(
     AbcParamDef *param)
{
     return param->get_param_as_number(param);
}

/*
**   ===============================
**   Print functions
**   ===============================
*/

void abc_print_param_info(
     AbcParams *params,
     FILE *out)
{
     int i;

     if (params->n_groups == 0)
     {
          abc_print_param_info_for_one_group(params, 0, "", out);
          return;
     }

     for (i = 0; i < params->n_groups; i++)
     {
          if (i > 0) fprintf(out, "\n");
          fprintf(out, "%s\n", params->group_name[i]);
          abc_print_param_info_for_one_group(params, 
               params->group_code[i], "   ", out);
     }
}


void abc_print_param_info_for_one_group(
     AbcParams *params,
     int group_code,
     const char *margin,
     FILE *out)
{
     int i;
     AbcParamDef *p;

     for (i = 0; i < params->n_params; i++)
     {
          p = &(params->param[i]);

          if (p->group_code != group_code)
               continue;

          p->print_param_info_line(p, out);
          fprintf(out, "     %s%s\n", margin, p->comment);
     }
}


void abc_print_input_info_to_tex_file(
     AbcParams *params,
     const char *case_name,
     const char *file_name,
     const char *prog_name)
{
     FILE *out = abc_new_TeX_file2(case_name, file_name);
     fprintf(out, "\\begin{center}{\\bf Program: %s}\\end{center}\n\n", prog_name);
     abc_print_param_info_tex(params, out);
     abc_end_TeX_file(out);
     printf("(input info is rewritten to: %s%s.tex)\n", case_name, file_name);
}


void abc_print_param_info_tex(
     AbcParams *params,
     FILE *out)
{
     int i;

     if (params->n_groups == 0)
     {
          abc_print_param_info_for_one_group(params, 0, "", out);
          return;
     }

     fprintf(out, "\n");
     fprintf(out, "%%%% BEGIN-PARAMETER-INFO\n\n");

     fprintf(out, "\n\n");
     fprintf(out, "\\begin{tabbing}\n");
     fprintf(out, " aaa \\= bbb \\= ccc \\= \\kill\n");

     for (i = 0; i < params->n_groups; i++)
     {
          if (i > 0) fprintf(out, "\\\\ \n");
          fprintf(out, "{\\bf %s} \\\\ \n", params->group_name[i]);
          abc_print_param_info_for_one_group_tex(params,
               params->group_code[i], out);
     }

     fprintf(out, "\\end{tabbing}\n");
     fprintf(out, "\n");
     fprintf(out, "%%%% END-PARAMETER-INFO\n\n");
}


void abc_print_param_info_for_one_group_tex(
     AbcParams *params,
     int group_code,
     FILE *out)
{
     int i;
     AbcParamDef *p;
     char name[MAX_ABC_WORD];

     for (i = 0; i < params->n_params; i++)
     {
          p = &(params->param[i]);

          if (p->group_code != group_code)
               continue;

          abc_escape_TeX_underscore(p->name, name);
          p->print_param_defaults_line2_tex(p, out);         
          fprintf(out, "  \\> \\> %s \\\\ \n", p->comment);
     }
}


void abc_print_all_params_to_a2_file(
     AbcParams *params,
     const char *case_name,
     const char *file_name)
{
     FILE *out = abc_new_file(case_name, file_name);
     abc_print_all_params_as_a2(params, out);
     fclose(out);
     printf("(input parameters are written to: %s%s)\n", case_name, file_name);
}


void abc_print_all_params_with_prename_to_a2_file(
     AbcParams *params,
     const char *case_name,
     const char *file_name,
     const char *prename)
{
     FILE *out = abc_new_file(case_name, file_name);
     abc_print_all_params_with_prename_as_a2(params, out, prename);
     fclose(out);
     printf("(input parameters are written to: %s%s)\n", case_name, file_name);
}


void abc_print_all_params_as_a2(
     AbcParams *params,
     FILE *out)
{
     abc_print_all_params_with_prename_as_a2(params, out, "");
}


void abc_print_all_params_with_prename_as_a2(
     AbcParams *params,
     FILE *out,
     const char *prename)
{
     int i;
     char string[MAX_ABC_WORD];
     AbcParamDef *p;

     fprintf(out, "begin_results2\n\n");
     fprintf(out, "int max_word 1  32\n\n");

     for (i = 0; i < params->n_params; i++)
     {
          p = &(params->param[i]);
          if (p->type == AbcParamFunction) continue;
          p->get_param_as_string(p, string);
          fprintf(out, "strings %s%s 1 \"%s [%s]\"\n", 
               prename, p->name, string, p->units);
     }

     fprintf(out, "\nend_results2\n");
}


void abc_print_all_params_to_file(
     AbcParams *params,
     const char *case_name, 
     const char *file_name)
{
     FILE *out = abc_new_file(case_name, file_name);
     abc_print_all_params(params, out);
     fclose(out);
     printf("(input is rewritten to: %s%s)\n", case_name, file_name);
}


void abc_print_all_params(
     AbcParams *params,
     FILE *out)
{
     int i;

     fprintf(out, "begin_parameters\n\n");

     if (params->n_groups == 0)
     {
          abc_print_params_for_one_group(params, 0, out);
          return;
     }

     for (i = 0; i < params->n_groups; i++)
     {
          if (i > 0) fprintf(out, "\n");
          fprintf(out, "#( %s )#\n", params->group_name[i]);
          print_underline(out, params->group_name[i], '=');
          abc_print_params_for_one_group(params, params->group_code[i], out);
     }

     fprintf(out, "\nend_parameters\n");
}


static void print_underline(
     FILE *out,
     const char *text,
     const char ch)
{
     int i;

     fprintf(out, "#( ");
     for (i = 0; i < (int) strlen(text); i++)
          fprintf(out, "%c", ch);
     fprintf(out, " )#\n");
}


void abc_print_params_for_one_group(
     AbcParams *params,
     int group_code,
     FILE *out)
{
     int i;
     AbcParamDef *p;

     show_comment = params->show_comment;

     for (i = 0; i < params->n_params; i++)
     {
          p = &(params->param[i]);

          if (p->group_code != group_code)
               continue;

          p->print_param_line(p, out);
     }
}


void abc_print_params_as_tex_file(
     AbcParams *params,
     const char *filename)
{
     FILE *out = abc_new_TeX_file(filename);
     const char *ext = get_extension(filename);
     abc_print_params_as_tex(params, out);
     abc_end_TeX_file(out);

     printf("(parameters are written to tex-file: %s%s)\n", filename, ext);
}


void abc_print_all_params_to_tex_file(
     AbcParams *params,
     const char *case_name,
     const char *file_name)
{
     FILE *out = abc_new_TeX_file2(case_name, file_name);
     const char *ext = get_extension(file_name);
     abc_print_all_params_as_tex(params, out);
     abc_end_TeX_file(out);
     printf("(input parameters are written to: %s%s%s)\n", case_name, file_name, ext);
}


void abc_print_case_input_as_tex_file(
     AbcParams *params,
     const char *case_name,
     const char *file_name)
{
     FILE *out = abc_new_TeX_file2(case_name, file_name);
     const char *ext = get_extension(file_name);
     fprintf(out, "\\begin{center}{\\bf Case: %s}\\end{center}\n\n", case_name);
     abc_print_params_as_tex(params, out);
     abc_end_TeX_file(out);
     printf("(input parameters are written to: %s%s%s)\n", case_name, file_name, ext);
}


static const char *get_extension(
     const char *file_name)
{
     char extension[ABC_MAX_WORD];
     abc_get_extension(file_name, extension);
     if (ABC_MATCH(extension, ".tex")) return "";
     return ".tex";
}


void abc_print_all_params_as_tex(
     AbcParams *params,
     FILE *out)
{
     fprintf(out, "\\section{Case parameters}\n");
     abc_print_params_as_tex(params, out);

     fprintf(out, "\\clearpage\\newpage\n");
     fprintf(out, "\\section{Default parameters}\n");
     abc_print_default_params_as_tex(params, out);

     fprintf(out, "\\clearpage\\newpage\n");
     fprintf(out, "\\section{Parameter info}\n");
     abc_print_param_info_tex(params, out);
}


void abc_print_params_as_tex(
     AbcParams *params,
     FILE *out)
{
    int i;

     if (params->n_groups == 0)
     {
          abc_print_params_as_tex_for_one_group(params, 0, out);
          return;
     }

     fprintf(out, "\n");
     fprintf(out, "%%%% BEGIN-ACTUAL-PARAMETER-VALUES\n\n");

     for (i = 0; i < params->n_groups; i++)
     {
          fprintf(out, "\n\n");
          fprintf(out, "\\begin{center}\\begin{tabular}{lcc}\n");
          fprintf(out, "\\hline\\hline\n");
          fprintf(out, "\\multicolumn{3}{c}{%s}\\\\ \n", params->group_name[i]); 
          /**
          fprintf(out, "Parameter & Value & Units \\\\ \n");
          **/
          fprintf(out, "Parameter \\hspace*{4cm} &");
          fprintf(out, " \\hspace*{0.5cm} Value \\hspace*{0.5cm} &");
          fprintf(out, " \\hspace*{0.3cm} Units \\hspace*{0.3cm} \\\\ \n");

          fprintf(out, "\\hline\n");
          abc_print_params_as_tex_for_one_group(params, params->group_code[i], out);
          fprintf(out, "\\hline\\hline\n");
          fprintf(out, "\\end{tabular}\\end{center} \n");
          fprintf(out, "%%%% BEGIN-ACTUAL-PARAMETER-VALUES\n\n");
     }

     fprintf(out, "\n");
     fprintf(out, "%%%% END-ACTUAL-PARAMETER-VALUES\n\n");
}


void abc_print_params_as_tex_for_one_group(
     AbcParams *params,
     int group_code,
     FILE *out)
{
     int i;
     AbcParamDef *p;

     for (i = 0; i < params->n_params; i++)
     {
          p = &(params->param[i]);

          if (p->group_code != group_code)
               continue;

          p->print_param_line_tex(p, out);
     }
}


void abc_print_default_params_as_tex(
     AbcParams *params,
     FILE *out)
{
    int i;

     if (params->n_groups == 0)
     {
          abc_print_params_as_tex_for_one_group(params, 0, out);
          return;
     }

     fprintf(out, "\n");
     fprintf(out, "%%%% BEGIN-DEFAULT-PARAMETER-VALUES\n\n");

     for (i = 0; i < params->n_groups; i++)
     {
          fprintf(out, "\n\n");
          fprintf(out, "\\begin{center}\\begin{tabular}{lcccc}\n");
          fprintf(out, "\\hline\\hline\n");
          fprintf(out, "\\multicolumn{5}{c}{%s}\\\\ \n", params->group_name[i]);
          fprintf(out, "Parameter & Default & Units & Min & Max\\\\ \n");
          fprintf(out, "\\hline\n");
          abc_print_default_params_as_tex_for_one_group(params, params->group_code[i], out);
          fprintf(out, "\\hline\\hline\n");
          fprintf(out, "\\end{tabular}\\end{center} \n");
     }

     fprintf(out, "\n");
     fprintf(out, "%%%% END-DEFAULT-PARAMETER-VALUES\n\n");
}


void abc_print_default_params_as_tex_for_one_group(
     AbcParams *params,
     int group_code,
     FILE *out)
{
     int i;
     AbcParamDef *p;
     char name[MAX_ABC_WORD];

     for (i = 0; i < params->n_params; i++)
     {
          p = &(params->param[i]);

          if (p->group_code != group_code) 
               continue;

          abc_escape_TeX_underscore(p->name, name);
          p->print_param_defaults_line1_tex(p, out);
     }
}

/*
**   ===============================
**   Private functions
**   ===============================
*/

static int get_current_int_value_of_pointer(
     AbcParams *params,
     void *pointer)
{
     int i;
     AbcParamDef *p;

     for (i = 0; i < params->n_params; i++)
     {
          p = &(params->param[i]);

          if (p->pointer == pointer)
               return get_param_as_int(p);
     }

     return 0;
}


static int get_param_as_int(
     AbcParamDef *p)
{
     int value = *((int *) p->pointer);
     return value;
}


static double get_param_as_double(
     AbcParamDef *p)
{
     double value = *((double *) p->pointer);
     return value;
}


static void set_param_as_int(
     AbcParamDef *p,
     int value)
{
     *((int *) p->pointer) = value;
}


static void set_param_as_double(
     AbcParamDef *p,
     double value)
{
     *((double *) p->pointer) = value;
}


static int set_param_as_string(
     AbcParamDef *p,
     const char *src)
{
     char *dest = (char *) p->pointer;

     if ((int) strlen(src) < p->max_string_size)
     {
          strcpy(dest, src);
          return TRUE;
     }

     fprintf(stderr, "[set_param_as_string] String is too long!");
     return FALSE;
}

/*
**   ===============================
**   Parameter type: Dummy
**   ===============================
*/

static int dummy_set_param_by_string(
     AbcParamDef *p, 
     const char *string)
{
     fprintf(stderr, "Error: Undefined member-function for %s!\n", p->name);
     ABC_UNUSED_PARAMETER(string);
     return FALSE;
}


static double dummy_get_param_as_number(
     AbcParamDef *p)
{
     fprintf(stderr, "Error: Undefined member-function for %s!\n", p->name);
     return 0.0;
}


static void dummy_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     fprintf(stderr, "Error: Undefined member-function for %s!\n", p->name);
     strcpy(string, "0");
}


static const char *dummy_get_param_type_name(
     void)
{
     return "dummy";
}


static void dummy_print_param(
     AbcParamDef *p, 
     FILE *out)
{
     fprintf(stderr, "Error: Undefined member-function for %s!\n", p->name);
     ABC_UNUSED_PARAMETER(out);
}

/*
**   ===============================
**   Parameter type: Int
**   ===============================
*/

static int int_set_param_by_string(
     AbcParamDef *p, 
     const char *string)
{
     int value;

     if (sscanf(string, "%d", &value) != 1)
     {
          fprintf(stderr, "Can't read int from: %s=%s\n", p->name, string);
          return FALSE;
     }

     return abc_assign_param_number(p, (double) value);
}


static double int_get_param_as_number(
     AbcParamDef *p)
{
     int value = get_param_as_int(p);
     return ((double) value);
}


static void int_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     sprintf(string, "%d", (int) int_get_param_as_number(p));
}


static const char *int_get_param_type_name(
     void)
{
     return "int";
}


static void int_print_param_info_line(
     AbcParamDef *p, 
     FILE *out)
{
     fprintf(out, "%s%s=<%s> (default=%g) [%s]\n",
          margin, p->name, p->get_param_type_name(),
          p->default_value, p->units);
}


static void int_print_param_line(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD];

     p->get_param_as_string(p, string);
     fprintf(out, "%s=%s #[%s]#", p->name, string, p->units);
     if (show_comment) fprintf(out, "  #( %s )#", p->comment);
     fprintf(out, "\n");
}


static void int_print_param_line_tex(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD], name[MAX_ABC_WORD];

     int_get_param_as_string(p, string);
     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & %s & %s \\\\ \n", name, string, p->units);
}


static void int_print_param_defaults_line1_tex(
     AbcParamDef *p, 
     FILE *out)
{
     double_print_param_defaults_line1_tex(p, out);
}


static void int_print_param_defaults_line2_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, " \\> {\\tt %s}=$<$%s$>$ [%s] (default=%g)\\\\ \n",
          name, p->get_param_type_name(),
          p->units, p->default_value);
}

/*
**   ===============================
**   Parameter type: Double
**   ===============================
*/

static int double_set_param_by_string(
     AbcParamDef *p, 
     const char *string)
{
     double value;

     if (sscanf(string, "%lf", &value) != 1)
     {
          fprintf(stderr, "Can't read double from: %s=%s\n", p->name, string);
          return FALSE;
     }

     return abc_assign_param_number(p, (double) value);
}


static double double_get_param_as_number(
     AbcParamDef *p)
{
     return get_param_as_double(p);
}


static void double_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     sprintf(string, "%g", double_get_param_as_number(p));
}


static const char *double_get_param_type_name(
     void)
{
     return "double";
}


static void double_print_param_info_line(
     AbcParamDef *p, 
     FILE *out)
{
     fprintf(out, "%s%s=<%s> (default=%g) [%s]\n",
          margin, p->name, p->get_param_type_name(),
          p->default_value, p->units);
}


static void double_print_param_line(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD];

     p->get_param_as_string(p, string);
     fprintf(out, "%s=%s #[%s]#", p->name, string, p->units);
     if (show_comment) fprintf(out, "  #( %s )#", p->comment);
     fprintf(out, "\n");
}


static void double_print_param_line_tex(
     AbcParamDef *p,
     FILE *out)
{
     char name[MAX_ABC_WORD];
     double value = double_get_param_as_number(p);

     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & ", name);
     abc_print_TeX_number(out, value);
     fprintf(out, " & %s \\\\ \n", p->units);
}


static void double_print_param_defaults_line1_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);

     fprintf(out, "%s & ", name);
     abc_print_TeX_number(out, p->default_value);
     fprintf(out, " & %s & ", p->units);
     abc_print_TeX_number(out, p->min_value);
     fprintf(out, " & ");
     abc_print_TeX_number(out, p->max_value);
     fprintf(out, "\\\\ \n");
}


static void double_print_param_defaults_line2_tex(
     AbcParamDef *p, 
     FILE *out)     
{
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, " \\> {\\tt %s}=$<$%s$>$ [%s] (default=",
          name, p->get_param_type_name(), p->units);
     abc_print_TeX_number(out, p->default_value);
     fprintf(out, ")\\\\ \n");
}

/*
**   ===============================
**   Parameter type: Bit
**   ===============================
*/

static int bit_set_param_by_string(
     AbcParamDef *p, 
     const char *string)
{
     int value;

     if (sscanf(string, "%d", &value) != 1)
     {
          fprintf(stderr, "Can't read number from: %s=%s\n", p->name, string);
          return FALSE;
     }

     return bit_set_param_by_value(p, value);
}


static int bit_set_param_by_value(
     AbcParamDef *p,
     int value)
{
     int pattern = *((int *) p->pointer);
     int bit_value = (int) p->bit_value;

     if (value == 0)
     {
          if (pattern & bit_value) pattern -= bit_value;
     }
     else
     {
          if (not (pattern & bit_value)) pattern += bit_value;
     }

     abc_assign_param_number(p, (double) pattern);

     return TRUE;
}


static int bit_is_set_for_param(
     AbcParamDef *p)
{
     int pattern = *((int *) p->pointer);
     int bit_value = (int) p->bit_value;
     int is_set = (pattern & bit_value) ? 1 : 0;

     return is_set;
}


static double bit_get_param_as_number(
     AbcParamDef *p)
{
     double value = (double) bit_is_set_for_param(p);
     return value;
}


static void bit_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     sprintf(string, "%d", bit_is_set_for_param(p));
}


static const char *bit_get_param_type_name(
     void)
{
     return "bit";
}


static void bit_print_param_info_line(
     AbcParamDef *p, 
     FILE *out)
{
     fprintf(out, "%s%s=<%s> (default=%d) (bit=%d, value=%d)\n",
          margin, p->name, p->get_param_type_name(),
          (int) p->default_value, 
          bit_get_bit_number(p->bit_value), p->bit_value);
}


static void bit_print_param_line(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD];

     p->get_param_as_string(p, string);
     fprintf(out, "%s=%s", p->name, string);
     if (show_comment) fprintf(out, "  #( %s )#", p->comment);
     fprintf(out, "\n");
}


static void bit_print_param_line_tex(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD], name[MAX_ABC_WORD];

     bit_get_param_as_string(p, string);
     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & %s & %s \\\\ \n", name, string, p->units);
}


static void bit_print_param_defaults_line1_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & ", name);
     abc_print_TeX_number(out, p->default_value);
     fprintf(out, " & - & - & - \\\\ \n");
}


static void bit_print_param_defaults_line2_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, " \\> {\\tt %s}={\\tt 0}$|${\\tt 1} (default=%g) (bit=%d, value=%d)\\\\ \n",
          name, p->default_value, bit_get_bit_number(p->bit_value), p->bit_value);
}


static int bit_get_bit_number(
     double value)
{
     int bit = abc_rint(log(value) / log(2.0));
     return bit;
}

/*
**   ===============================
**   Parameter type: Label
**   ===============================
*/

static int label_set_param_by_string(
     AbcParamDef *p, 
     const char *label_name)
{
     int i = get_label_index(p, label_name);

     if (i < 0)
     {
          fprintf(stderr, "Error: \"%s\" is an unknown label for parameter \"%s\"\n",
               label_name, p->name);
          return FALSE;
     }

     abc_assign_param_number(p, (double) p->label_ID[i]);
     return TRUE;
}


static int get_label_index(
     AbcParamDef *p,
     const char *label_name)
{
     int i;

     for (i = 0; i < p->n_labels; i++)
          if (ABC_MATCH(p->label_name[i], label_name)) return i;

     return -1;
}


static double label_get_param_as_number(
     AbcParamDef *p)
{
     return int_get_param_as_number(p);
}


static void label_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     double value = label_get_param_as_number(p);
     sprintf(string, "%s", get_label_from_value(p, (int) value));
}


static const char *get_label_from_value(
     AbcParamDef *param,
     int label_ID)
{
     int i;

     for (i = 0; i < param->n_labels; i++)
     {
          if (param->label_ID[i] == label_ID)
               return param->label_name[i];
     }

     return "unknown";
}


static const char *label_get_param_type_name(
     void)
{
     return "label";
}


static void label_print_param_info_line(
     AbcParamDef *p, 
     FILE *out)
{
     int j;
     int length = strlen(p->name) + strlen(p->label_name[0]);

     fprintf(out, "%s%s=%s", margin, p->name, p->label_name[0]);

     for (j = 1;j < p->n_labels; j++)
     {
          length += strlen(p->label_name[j]);

          if (length > 50)
          {
               printf("\n%s%s", margin, "   ");
               length = 0;
          }

          fprintf(out, "|%s", p->label_name[j]);
     }

     fprintf(out, " (default=%s)\n", p->label_name[0]);
}


static void label_print_param_line(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD];

     p->get_param_as_string(p, string);
     fprintf(out, "%s=%s", p->name, string);
     if (show_comment) fprintf(out, "  #( %s )#", p->comment);
     fprintf(out, "\n");
}


static void label_print_param_line_tex(
     AbcParamDef *p,
     FILE *out)
{
     char str1[MAX_ABC_WORD], str2[MAX_ABC_WORD], name[MAX_ABC_WORD];

     label_get_param_as_string(p, str1);
     abc_escape_TeX_underscore(str1, str2);
     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & %s & %s \\\\ \n", name, str2, p->units);
}


static void label_print_param_defaults_line1_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char label[MAX_ABC_WORD], name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     abc_escape_TeX_underscore(p->label_name[0], label);

     fprintf(out, "%s & ", name);
     fprintf(out, "%s & ", label);
     fprintf(out, " - & - & - \\\\ \n");
}


static void label_print_param_defaults_line2_tex(
     AbcParamDef *p,
     FILE *out)
{
     int j;
     char label[MAX_ABC_WORD], name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     abc_escape_TeX_underscore(p->label_name[0], label);

     fprintf(out, " \\> {\\tt %s}={\\tt %s", name, label);

     for (j = 1;j < p->n_labels; j++)
     {
          abc_escape_TeX_underscore(p->label_name[j], label);
          fprintf(out, "$|$%s", label);
     }

     fprintf(out, "} (default={\\tt %s})\\\\ \n", label);
}

/*
**   ===============================
**   Parameter type: Boolean
**   ===============================
*/

static int bool_set_param_by_string(
     AbcParamDef *p, 
     const char *string)
{
     return int_set_param_by_string(p, string);
}


static double bool_get_param_as_number(
     AbcParamDef *p)
{
     return int_get_param_as_number(p);
}


static void bool_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     sprintf(string, "%d", (int) bool_get_param_as_number(p));
}


static const char *bool_get_param_type_name(
     void)
{
     return "boolean";
}


static void bool_print_param_info_line(
     AbcParamDef *p, 
     FILE *out)
{
     fprintf(out, "%s%s=0|1 (boolean) (default=%g)\n",
          margin, p->name, p->default_value);
}


static void bool_print_param_line(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD];

     p->get_param_as_string(p, string);
     fprintf(out, "%s=%s", p->name, string);
     if (show_comment) fprintf(out, "  #( %s )#", p->comment);
     fprintf(out, "\n");
}


static void bool_print_param_line_tex(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD], name[MAX_ABC_WORD];

     bool_get_param_as_string(p, string);
     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & %s & %s \\\\ \n", name, string, p->units);
}


static void bool_print_param_defaults_line1_tex(
     AbcParamDef *p, 
     FILE *out)
{
     double_print_param_defaults_line1_tex(p, out);
}


static void bool_print_param_defaults_line2_tex(
     AbcParamDef *p,
     FILE *out)
{  
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);

     fprintf(out, " \\> {\\tt %s}=0$|$1 (boolean) (default=%g)\\\\ \n",
          name, p->default_value);
}

/*
**   ===============================
**   Parameter type: String
**   ===============================
*/

static int string_set_param_by_string(
     AbcParamDef *p, 
     const char *string)
{
     set_param_as_string(p, string);
     return TRUE;
}


static double string_get_param_as_number(
     AbcParamDef *p)
{
     ABC_UNUSED_PARAMETER(p);
     return 0.0;
}


static void string_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     const char *str = (char *) p->pointer;
     sprintf(string, "%s", str);
}


static const char *string_get_param_type_name(
     void)
{
     return "string";
}


static void string_print_param_info_line(
     AbcParamDef *p, 
     FILE *out)
{
     fprintf(out, "%s%s=<\"%s\"> (default=%s)\n",
          margin, p->name, p->get_param_type_name(),
          p->default_string);
}


static void string_print_param_line(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD];

     p->get_param_as_string(p, string);
     fprintf(out, "%s=\"%s\" ", p->name, string);
     if (show_comment) fprintf(out, "  #( %s )#", p->comment);
     fprintf(out, "\n");
}


static void string_print_param_line_tex(
     AbcParamDef *p,
     FILE *out)
{
     char string[MAX_ABC_WORD], string2[MAX_ABC_WORD], name2[MAX_ABC_WORD];

     string_get_param_as_string(p, string);
     abc_escape_TeX_underscore(string, string2);
     abc_escape_TeX_underscore(p->name, name2);

     fprintf(out, "%s & \"%s\" & %s \\\\ \n", name2, string2, "-");
}


static void string_print_param_defaults_line1_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & ", name);
     abc_escape_TeX_underscore(p->default_string, name);
     fprintf(out, "%s & ", name);
     fprintf(out, " - & - & - \\\\ \n");
}


static void string_print_param_defaults_line2_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name1[MAX_ABC_WORD], name2[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name1);
     abc_escape_TeX_underscore(p->default_string, name2);

     fprintf(out, " \\> {\\tt %s}=$<$%s$>$ [%s] (default={\\tt %s})\\\\ \n",
          name1, p->get_param_type_name(),
          p->units, name2);
}

/*
**   ===============================
**   Parameter type: Function
**   ===============================
*/

static int func_set_param_by_string(
     AbcParamDef *p, 
     const char *string)
{
     set_param_as_string(p, string);
     return TRUE;
}


static double func_get_param_as_number(
     AbcParamDef *p)
{
     ABC_UNUSED_PARAMETER(p);
     return 0.0;
}


static void func_get_param_as_string(
     AbcParamDef *p, 
     char *string)
{
     sprintf(string, "%s", "");
     ABC_UNUSED_PARAMETER(p);
}


static const char *func_get_param_type_name(
     void)
{
     return "function";
}


static void func_print_param_info_line(
     AbcParamDef *p, 
     FILE *out)
{
     fprintf(out, "%s%s  (%s)\n", margin, p->name, p->get_param_type_name());
}


static void func_print_param_line(
     AbcParamDef *p,
     FILE *out)
{
     fprintf(out, "#( %s )# #( function )#", p->name);
     if (show_comment) fprintf(out, "  #( %s )#", p->comment);
     fprintf(out, "\n");
}


static void func_print_param_line_tex(
     AbcParamDef *p,
     FILE *out)
{
     char name2[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name2);
     fprintf(out, "%s & \"%s\" & %s \\\\ \n", name2, "-", "-");
}


static void func_print_param_defaults_line1_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name);
     fprintf(out, "%s & ", name);
     fprintf(out, "%s & ", "-");
     fprintf(out, " - & - & - \\\\ \n");
}


static void func_print_param_defaults_line2_tex(
     AbcParamDef *p, 
     FILE *out)
{
     char name1[MAX_ABC_WORD];

     abc_escape_TeX_underscore(p->name, name1);

     fprintf(out, " \\> {\\tt %s} $($%s$)$ \\\\ \n",
          name1, p->get_param_type_name());
}


