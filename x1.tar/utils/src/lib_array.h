/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1993-1998 by M. Wangen.
**
**   Info: Functions for array manipulation
**   Date: Version 1.0, November 1993
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_ARRAY_H_
#define _LIB_ARRAY_H_

typedef void (*ABC_DELETE_ARRAY_ELEM)(void **pp);
typedef int  (*ABC_COMPARE_ARRAY_ELEMS)(const void *p1, const void *p2);

typedef struct AbcArray {
     int size;
     int max_size;
     void **array;
     ABC_DELETE_ARRAY_ELEM delete_elem;
     ABC_COMPARE_ARRAY_ELEMS compare_elems;
} AbcArray;

int abc_test_array(int argc, char **argv);
void abc_init_array(AbcArray *array, int max_size, 
     ABC_DELETE_ARRAY_ELEM abc_delete_elem, 
     ABC_COMPARE_ARRAY_ELEMS compare_elems);
void abc_delete_array(AbcArray *array);
void abc_delete_array_elem(AbcArray *array, void **pp);
void abc_add_array_elem(AbcArray *array, void *elem);
void abc_resize_array(AbcArray *array, int max_size);
void abc_replace_array_elem(AbcArray *array, int index, void *elem);
int abc_get_array_index(AbcArray *array, void *elem);
void *abc_get_array_elem(AbcArray *array, int index);
int abc_get_array_size(AbcArray *array);
int abc_get_array_max_size(AbcArray *array);
int abc_get_array_free_capacity(AbcArray *array);
void abc_sort_array(AbcArray *array);

#endif

