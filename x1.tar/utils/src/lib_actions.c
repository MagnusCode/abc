/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2005 by M. Wangen.
**
**   Info: Functions for handling actions
**   Date: Version 1.0, October 2005
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   NOTICE!
**   See lib_time_stepper.c for an example of how an action list is used.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_actions.h>
#include <lib_utils.h>

static double
     dt_epsilon = 1.0e-6; /* Time intervals less than "dt_epsilon" becomes zero. */

static int is_the_same_action_type(AbcActionList *list, int type, int priority, const char *name);


void abc_init_action_list(
     AbcActionList *list)
{
     int i;

     list->first = NULL;
     list->last = NULL;

     for (i = 0; i < ABC_MAX_ACTIONS; i++)
     {
          list->action_def[i].name = NULL;
          list->action_def[i].type = i;
          list->action_def[i].priority = 5;
          list->action_def[i].action_func = NULL;
          list->action_def[i].is_defined = FALSE;
     }
}


void abc_define_action_type(
     AbcActionList *list,
     int type,
     int priority,
     const char *name,
     ABC_TAKE_ACTION action_func)
{
     if (not abc_is_ok_action_type(type))
          ABC_ERROR_EXIT("[abc_define_action_type] Illegal action type");

     if (is_the_same_action_type(list, type, priority, name))
          return;

     if (name == NULL)
          ABC_ERROR_EXIT("[abc_define_action_type] name==NULL!");

     if (list->action_def[type].name != NULL)
     {
          fprintf(stderr, "Warning: redefining action type %d (name=%s, priority=%d)!\n",
                    type, list->action_def[type].name, list->action_def[type].priority);
          fprintf(stderr, "New action name %s and priority %d!\n",
                    name, priority);

          ABC_FREE(list->action_def[type].name);
     }

     list->action_def[type].name = abc_save_string(name);
     list->action_def[type].priority = priority;
     list->action_def[type].action_func = action_func;
     list->action_def[type].is_defined = TRUE;
}


static int is_the_same_action_type(
     AbcActionList *list,
     int type,
     int priority,
     const char *name)
{
     if (not abc_is_ok_action_type(type))
          ABC_ERROR_EXIT("[is_the_same_action_type] Illegal action type");

     if (not list->action_def[type].is_defined)
          return FALSE;

     if (list->action_def[type].name == NULL)
          return FALSE;

     if (not ABC_MATCH(list->action_def[type].name, name))
          return FALSE;

     if (list->action_def[type].priority != priority)
          return FALSE;

     return TRUE;
}


int abc_get_defined_action_type(
     AbcActionList *list,
     const char *name)
{
     int type;

     for (type = 0; type < ABC_MAX_ACTIONS; type++)
     {
          if (not list->action_def[type].is_defined) 
               continue;

          if (ABC_MATCH(list->action_def[type].name, name))
               return type;
     }

     return -1;
}


void abc_print_defined_actions(
     FILE *out,
     AbcActionList *list)
{
     int type;

     for (type = 0; type < ABC_MAX_ACTIONS; type++)
     {
          if (not list->action_def[type].is_defined) continue;

          fprintf(out, "type: %3d, priority: %3d, action: %s\n",
               type, list->action_def[type].priority,
               abc_get_action_name(list, type));
     }
}


void abc_delete_all_actions(
     AbcActionList *list)
{
     int i;
     AbcAction *p0, *p1;

     if (list->first == NULL)
          return;

     for (p1 = list->first; p1 != NULL; )
     {
          p0 = p1;
          p1 = p1->next;
          abc_delete_action(&p0);
     }

     for (i = 0; i < ABC_MAX_ACTIONS; i++)
          if (list->action_def[i].name != NULL)
               ABC_FREE(list->action_def[i].name);
}


void abc_delete_action(
     AbcAction **pp)
{
     AbcAction *action = NULL;

     if (pp == NULL) return;
     if ((action = *pp) == NULL) return;

     ABC_FREE(action->buffer1);
     ABC_FREE(action->buffer2);
     ABC_FREE(action);
     *pp = NULL;
}


int abc_get_action_priority(
     AbcActionList *list,
     int type)
{
     if (not abc_is_ok_action_type(type))
          ABC_ERROR_EXIT("[abc_define_action] Illegal action type");

     if (not abc_is_defined_action_type(list, type))
          return 0;

     return list->action_def[type].priority;
}


const char *abc_get_action_name(
     AbcActionList *list,
     int type)
{
     if (not abc_is_ok_action_type(type))
          ABC_ERROR_EXIT("[abc_define_action] Illegal action type");

     if (not abc_is_defined_action_type(list, type))
          return "undefined";

     if (list->action_def[type].name == NULL)
          return "no name";

     return list->action_def[type].name;
}


ABC_TAKE_ACTION abc_get_action_func(
     AbcActionList *list,
     int type)
{
     if (not abc_is_ok_action_type(type))
          ABC_ERROR_EXIT("[abc_define_action] Illegal action type");

     if (not abc_is_defined_action_type(list, type))
          return NULL;

     return list->action_def[type].action_func;
}


int abc_is_defined_action_type(
     AbcActionList *list,
     int type)
{
     if (not abc_is_ok_action_type(type))
          ABC_ERROR_EXIT("[abc_is_defined_action_type] Illegal action type");

     return list->action_def[type].is_defined;
}


int abc_is_ok_action_type(
      int type)
{
     if (type < 0)
          ABC_RETURN_FALSE("[abc_is_ok_action_type] type<0 !");

     if (ABC_MAX_ACTIONS <= type)
          ABC_RETURN_FALSE("[abc_is_ok_action_type] type is too large!");

     return TRUE;
}


AbcAction *abc_add_simple_action(
     AbcActionList *list,
     double time,
     int priority,
     ABC_TAKE_ACTION take_action)
{
     return abc_add_action(list, 0, time, priority, NULL, NULL, take_action);
}


AbcAction *abc_add_scalar_action(
     AbcActionList *list,
     double time,
     double scalar,
     int priority,
     ABC_TAKE_ACTION take_action)
{
     double buf1[1] = {scalar};
     double *buf2 = abc_save_double_array(buf1, 1);
     AbcAction *action = abc_create_action(0, time, priority, (void *) buf2, NULL, take_action);
     abc_insert_action(list, action);
     return action;
}



AbcAction *abc_add_action(
     AbcActionList *list,
     int type,
     double time,
     int pri,
     void *buffer1,
     void *buffer2,
     ABC_TAKE_ACTION take_action)
{
     AbcAction *action;

     action = abc_create_action(type, time, pri, buffer1, buffer2, take_action);
     abc_insert_action(list, action);

     return action;
}


AbcAction *abc_add_defined_action(
     AbcActionList *list,
     int type,
     double time,
     void *buffer1,
     void *buffer2)
{
     AbcAction *action;
     ABC_TAKE_ACTION action_func;
     int priority;

     if (not abc_is_defined_action_type(list, type))
          ABC_ERROR_EXIT("[abc_add_defined_action] Undefined action!");

     priority = abc_get_action_priority(list, type);
     action_func = abc_get_action_func(list, type);

     action = abc_create_action(type, time, priority, buffer1, buffer2, action_func);
     abc_insert_action(list, action);

     return action;
}


AbcAction *abc_create_action(
     int type,
     double time,
     int priority,
     void *buffer1,
     void *buffer2,
     ABC_TAKE_ACTION take_action)
{
     AbcAction *action = NULL;

     ABC_NEW_OBJECT(action, AbcAction);
     action->type = type;
     action->time = time;
     action->priority = priority;
     action->buffer1 = buffer1;
     action->buffer2 = buffer2;
     action->take_action = take_action;
     action->next = NULL;
     action->prev = NULL;

     return action;
}


void abc_insert_action(
     AbcActionList *list,
     AbcAction *action)
{
     AbcAction *p1, *p2;

     action->next = NULL;
     action->prev = NULL;

     /* When action list is empty. */

     if (list->first == NULL)
     {
          list->first = action;
          list->last = action;
          return;
     }

     /* When the new action becomes the beginning of the list. */

     if (abc_compare_actions(action, list->first) == -1)
     {
          p1 = list->first;
          list->first = action;
          action->next = p1;
          action->prev = NULL;
          return;
     }

     /* Initialize help pointers. */

     p1 = list->first;
     p2 = p1->next;

     /*
     ** The following loop steps through the list as long as compare == -1 or 0.
     ** Compare == -1 are all elements with an earlier time or a lower
     ** priority than the new element, while compare == 0 are elements
     ** with the same time and same priority as the new element.  It is
     ** important that a new element comes last among elements with same
     ** time and priority.  If several actions, for example set_max_dt,
     ** comes after each other on the input file with the same time then
     ** we want the last set_max_dt from the input to have effect.
     */
     
     /* 
     ** Insert the new action in the list between p1 and p2.
     ** (p2 is the leading pointer, and p1 is one step behind)
     */

     /***
     while ((p2 != NULL) and (abc_compare_actions(p2, action) == -1))
     ***/

     while ((p2 != NULL) and (abc_compare_actions(p2, action) < 1))
     {
          p1 = p2;
          p2 = p1->next;
     }

     p1->next = action;
     action->next = p2;
     action->prev = p1;

     if (p2 != NULL) 
          p2->prev = action;
     else 
          list->last = action;
}


int abc_compare_actions(
     AbcAction *p1,
     AbcAction *p2)
{
     if (abc_is_same_action_time(p1->time, p2->time))
     {
          if (p1->priority < p2->priority)
               return -1;
          else if (p1->priority > p2->priority)
               return +1;
          else
               return 0;
     }
     else if (p1->time < p2->time)
          return -1;

     return +1;
}


int abc_is_same_action_time(
     double t1,
     double t2)
{
     return (ABC_ABS(t1 - t2) < dt_epsilon);
}


int abc_is_ok_action_list(
     AbcActionList *list)
{
     AbcAction *p1 = list->first;
     AbcAction *p2;
     int got_errors = 0;

     /* An empty action list is OK. */

     if (p1 == NULL)
          return TRUE;
     /* 
     **  Check that actions are ordered in time,
     **  and ordered after priority for the same time.
     */

     for (p2 = p1->next; p2 != NULL; p1 = p2, p2 = p1->next)
          if (abc_compare_actions(p1, p2) == 1)
          {
               printf("(AbcAction list error: ");
               printf("action=%d, time=%g, priority=%d comes before ",
                    p1->type, p1->time, p1->priority);
               printf("action=%d, time=%g, priority=%d)\n",
                    p2->type, p2->time, p2->priority);
               got_errors++;
          }

     if (got_errors)
          return FALSE;

     return TRUE;
}


AbcAction *abc_skip_until_action(
     AbcAction *p1,
     int type)
{
     AbcAction *pp;

     for (pp = p1; pp != NULL; pp = pp->next)
          if (pp->type == type)
               return pp;

     return NULL;
}


void abc_print_action_list(
     FILE *out,
     AbcActionList *list)
{
     AbcAction *pp;

     if (list == NULL)
          return;

     for (pp = list->first; pp != NULL; pp = pp->next)
          fprintf(out, "time: %10.2e, priority: %3d, action: %s (type=%d)\n",
               pp->time, pp->priority, 
               abc_get_action_name(list, pp->type), pp->type);
}


void abc_print_reverse_action_list(
     FILE *out,
     AbcActionList *list)
{
     AbcAction *pp;

     if (list == NULL)
          return;

     for (pp = list->last; pp != NULL; pp = pp->prev)
          fprintf(out, "time: %10.2e, priority: %3d, action: %s (type=%d)\n",
               pp->time, pp->priority, 
               abc_get_action_name(list, pp->type), pp->type);
}


double abc_get_action_dt_epsilon(
     void)
{
     return dt_epsilon;
}


