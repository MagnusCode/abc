/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1990-1998 by M. Wangen.
**
**   Info: A library for storage allocation/deallocation.
**   Date: Version 2.0, February 1990
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_ALLOC_H_
#define _LIB_ALLOC_H_

#include <stdio.h>
#include <stdlib.h>

/* Macros for allocating single objects, arrays and matrices. */

#ifdef __STDC__
#define ABC_FATAL_ALLOCATION_ERROR                                         \
{                                                                           \
     fprintf(stderr, "Can't allocate array; no space left!");               \
     fprintf(stderr, " (line: %d, file: %s)\n", __LINE__, __FILE__);        \
     exit(1);                                                               \
}
#endif

#ifndef ABC_FATAL_ALLOCATION_ERROR
#define ABC_FATAL_ALLOCATION_ERROR                                         \
{                                                                           \
     fprintf(stderr, "Can't allocate array; no space left!\n");             \
     exit(1);                                                               \
}
#endif

#define ABC_NEW(type) ((type *) malloc(sizeof(type)))

#define ABC_NEW_OBJECT(object, type)                                        \
{                                                                           \
     if ((object = (type *) malloc(sizeof(type))) == NULL)                  \
           ABC_FATAL_ALLOCATION_ERROR                                       \
}

#define ABC_NEW_ARRAY(array, type, n)                                       \
{                                                                           \
     if ((array = (type *) calloc((unsigned) (n), sizeof(type))) == NULL)   \
          ABC_FATAL_ALLOCATION_ERROR                                        \
}

#define ABC_NEW_ARRAY_INIT(matrix, type, n, value)                          \
{                                                                           \
     int i_;                                                                \
                                                                            \
     ABC_NEW_ARRAY(matrix, type, n);                                        \
                                                                            \
     for (i_ = 0; i_ < (n); i_++)                                           \
          matrix[i_] = value;                                               \
}

#define ABC_NEW_MATRIX_2(matrix, type, d1, d2)                              \
{                                                                           \
     type *p_;                                                              \
     int i_;                                                                \
                                                                            \
     ABC_NEW_ARRAY(p_, type, (d1) * (d2));                                  \
     ABC_NEW_ARRAY(matrix, type *, (d1));                                   \
                                                                            \
     matrix[0] = p_; /* avoids PC-lint message */                           \
                                                                            \
     for (i_ = 0; i_ < (d1); i_++)                                          \
     {                                                                      \
          matrix[i_] = p_;                                                  \
          p_ += (d2);                                                       \
     }                                                                      \
}

#define ABC_NEW_MATRIX_2_INIT(matrix, type, d1, d2, value)                  \
{                                                                           \
     int i_, j_;                                                            \
                                                                            \
     ABC_NEW_MATRIX_2(matrix, type, d1, d2);                            \
                                                                            \
     for (i_ = 0; i_ < (d1); i_++)                                          \
          for (j_ = 0; j_ < (d2); j_++)                                     \
               matrix[i_][j_] = value;                                      \
}

#define ABC_NEW_MATRIX_3(matrix, type, d1, d2, d3)                          \
{                                                                           \
     type *p1_, **p2_;                                                      \
     int i_, j_;                                                            \
                                                                            \
     ABC_NEW_ARRAY(p1_, type, (d1) * (d2) * (d3));                          \
     ABC_NEW_ARRAY(p2_, type *, (d1) * (d2));                               \
     ABC_NEW_ARRAY(matrix, type **, (d1));                                  \
                                                                            \
     matrix[0] = p2_;    /* avoids PC-lint message */                       \
     matrix[0][0] = p1_; /* avoids PC-lint message */                       \
                                                                            \
     for (i_ = 0; i_ < (d1); i_++)                                          \
     {                                                                      \
          matrix[i_] = p2_;                                                 \
          p2_ += (d2);                                                      \
     }                                                                      \
                                                                            \
     for (i_ = 0; i_ < (d1); i_++)                                          \
          for (j_ = 0; j_ < (d2); j_++)                                     \
          {                                                                 \
               matrix[i_][j_] = p1_;                                        \
               p1_ += (d3);                                                 \
          }                                                                 \
}

#define ABC_NEW_MATRIX_3_INIT(matrix, type, d1, d2, d3, value)              \
{                                                                           \
     int i_, j_, k_;                                                        \
                                                                            \
     ABC_NEW_MATRIX_3(matrix, type, d1, d2, d3);                            \
                                                                            \
     for (i_ = 0; i_ < (d1); i_++)                                          \
          for (j_ = 0; j_ < (d2); j_++)                                     \
               for (k_ = 0; k_ < (d3); k_++)                                \
                    matrix[i_][j_][k_] = value;                             \
}

#define ABC_FREE(space)                                                     \
{                                                                           \
     if (space != NULL) {free((void *) space); space = NULL;}               \
}

#define ABC_FREE_ARRAY(array)                                               \
{                                                                           \
     ABC_FREE(array);                                                       \
}

#define ABC_FREE_MEMORY_DEBUG(space)                                        \
{                                                                           \
     printf("ABC_FREE: %x (line: %d, file: %s)\n",                          \
          (int) space, __LINE__, __FILE__);                                 \
     ABC_FREE(space)                                                        \
}

#define ABC_FREE_MATRIX_2(matrix)                                           \
{                                                                           \
     if (matrix != NULL)                                                    \
     {                                                                      \
          ABC_FREE(*matrix);                                                \
          ABC_FREE(matrix);                                                 \
     }                                                                      \
}

#define ABC_FREE_MATRIX_3(matrix)                                           \
{                                                                           \
     if (matrix != NULL)                                                    \
     {                                                                      \
          ABC_FREE(**matrix);                                               \
          ABC_FREE(*matrix);                                                \
          ABC_FREE(matrix);                                                 \
     }                                                                      \
}

#endif

