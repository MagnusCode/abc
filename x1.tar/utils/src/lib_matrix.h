/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998-1999 by M. Wangen.
**
**   Info: A library simple matrix operations
**   Date: Version 1.0, December 1998
**
**   $Id$
*/   

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_MATRIX_H_
#define _LIB_MATRIX_H_

typedef void (*ABC_NEWTON_FUNC1)(int n, double *x, double *f);
typedef void (*ABC_NEWTON_FIX1)(int n, double *x);
typedef struct _AbcNewton1_ AbcNewton1;

struct _AbcNewton1_ {
     int n;
     int max_iter;
     int is_verbose;
     double epsilon;
     double *f;
     double *f1;
     double *x1;
     double *dx;
     double **A;
     double *aux_dbl;
     int *aux_int;
     ABC_NEWTON_FUNC1 func;
     ABC_NEWTON_FIX1 fix;
};

void abc_basic_inverse_matrix(double **a, double **ainv, int n);
void abc_basic_linear_equation_solver(double **a, double *b, double *x, int n);
void abc_basic_gauss_solver(double **a, double *b, double *x, double *s, int *l, int n);
void abc_basic_matrix_triang(double **a, double *s, int *l, int n);
void abc_basic_matrix_back_subst(double **a, double *b, double *x, int *l, int n);
void abc_basic_matrix_mul_scalar(double scalar, double **matrix, int rows, int cols);
void abc_basic_matrix_mul_vector(double **a, const double *b, double *r, int rows, int cols);
void abc_basic_matrix_mul_transp_vector(double **a, const double *b, double *r, int rows, int cols);
void abc_basic_matrix_transpose(double **a, int rows, int cols);
void abc_basic_matrix_mul_matrix(double **a1, int rows1, int cols1, double **a2, int cols2, double **a3);
void abc_basic_copy_vector(double *a, const double *b, int rows);
void abc_basic_copy_matrix(double **a, double **b, int rows, int cols);
void abc_basic_zero_vector(double *a, int rows);
void abc_basic_zero_matrix(double **a, int rows, int cols);
void abc_basic_inc_vector(double *a, const double *da, int rows);
void abc_basic_add_vectors(const double *a, const double *b, double *c, int rows);
void abc_basic_sub_vectors(const double *a, const double *b, double *c, int rows);
void abc_basic_mul_vector_and_scalar(double *vec, double scalar, int rows);
double abc_basic_dot_vectors(double *a, double *b, int rows);
double abc_basic_sum_vector(const double *a, int rows);
double abc_basic_max_vector(const double *a, int rows);
double abc_basic_min_vector(const double *a, int rows);
int abc_basic_max_int_vector(const int *a, int rows);
int abc_basic_min_int_vector(const int *a, int rows);
double abc_basic_norm_l1(const double *a, int rows);
double abc_basic_norm_l2(const double *a, int rows);
double abc_basic_norm_infinity(const double *a, int rows);
void abc_band_gauss_solver(double **a, double *b, double *x, int n, int d);
void abc_band_matrix_triang(double **a, int n, int d);
void abc_band_matrix_back_subst(double **a, double *b, double *x, int n, int d);
void abc_band_matrix_mul_vector(double **a, double *b, double *r, int n, int d);
void abc_band_matrix_mul_transp_vector(double **a, double *b, double *r, int n, int d);
void abc_band_matrix_transpose(double **a, int n, int d);
void abc_demo_newton_solver0(void);
void abc_demo_newton_solver1(void);
int abc_newton_solver0(int n, ABC_NEWTON_FUNC1 func, ABC_NEWTON_FIX1 fix, double *x, double epsilon);
AbcNewton1 *abc_new_newton_solver1(int n, ABC_NEWTON_FUNC1 func, ABC_NEWTON_FIX1 fix);
void abc_delete_newton_solver1(AbcNewton1 **ptr);
int abc_newton_solver1(AbcNewton1 *ns, double *x, double epsilon);

#endif
