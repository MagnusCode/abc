/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2005 by M. Wangen.
**
**   Info: Functions for handling actions
**   Date: Version 1.0, October 2005
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_ACTIONS_H_
#define _LIB_ACTIONS_H_

/* 
**  All ABC-actions are collected here.
**  The list is to be extended with any new action.
*/

#define ABC_MAX_ACTIONS                      1024


typedef struct _AbcAction_ AbcAction;
typedef void (*ABC_TAKE_ACTION)(AbcAction *action);

struct _AbcActionDef_ {
     int type;
     int priority;
     int is_defined;
     const char *name;
     ABC_TAKE_ACTION action_func;
};

struct _AbcAction_ {
     int type;              /* Action type. */
     double time;           /* Action time. */
     int priority;          /* Action priority for actions with same time. */
     void *buffer1;         /* Storage buffer no 1. */
     void *buffer2;         /* Storage buffer no 2. */
     AbcAction *prev;       /* Pointer to previous action in the list. */
     AbcAction *next;       /* Pointer to next action in the list. */
     ABC_TAKE_ACTION take_action; /* The function that takes action. */
};

typedef struct _AbcActionDef_ AbcActionDef;
typedef struct _AbcActionList_ AbcActionList;

struct _AbcActionList_ {
     AbcActionDef action_def[ABC_MAX_ACTIONS];
     AbcAction *first;
     AbcAction *last;
};

void abc_init_action_list(AbcActionList *list);
void abc_define_action_type(AbcActionList *list, int type, 
     int priority, const char *name, ABC_TAKE_ACTION action_func);
int abc_get_defined_action_type(AbcActionList *list, const char *name);
void abc_print_defined_actions(FILE *out, AbcActionList *list);
void abc_delete_all_actions(AbcActionList *list);
void abc_delete_action(AbcAction **pp);
int abc_get_action_priority(AbcActionList *list, int type);
const char *abc_get_action_name(AbcActionList *list, int type);
ABC_TAKE_ACTION abc_get_action_func(AbcActionList *list, int type);
int abc_is_defined_action_type(AbcActionList *list, int type);
int abc_is_ok_action_type(int type);
AbcAction *abc_add_simple_action(AbcActionList *list, double time, 
     int priority, ABC_TAKE_ACTION take_action);
AbcAction *abc_add_scalar_action(AbcActionList *list, double time, double scalar,
     int priority, ABC_TAKE_ACTION take_action);
AbcAction *abc_add_action(AbcActionList *list, int type, double time, 
     int priority, void *buffer1, void *buffer2, ABC_TAKE_ACTION take_action);
AbcAction *abc_add_defined_action(AbcActionList *list,
     int type, double time, void *buffer1, void *buffer2);
AbcAction *abc_create_action(int type, double time, 
     int priority, void *buffer1, void *buffer2, ABC_TAKE_ACTION take_action);
void abc_insert_action(AbcActionList *list, AbcAction *action);
int abc_compare_actions(AbcAction *p1, AbcAction *p2);
int abc_is_same_action_time(double t1, double t2);
int abc_is_ok_action_list(AbcActionList *list);
AbcAction *abc_skip_until_action(AbcAction *p1, int type);
void abc_print_action_list(FILE *out, AbcActionList *list);
void abc_print_reverse_action_list(FILE *out, AbcActionList *list);
double abc_get_action_dt_epsilon(void);

#endif

