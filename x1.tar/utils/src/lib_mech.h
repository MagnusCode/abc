/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2012 by M. Wangen.
**
**   Info: Functions for computing principal components
**   Date: Version 1.1, October 2012
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_MECH_H_
#define _LIB_MECH_H_

typedef struct _AbcTensor3x3_     AbcTensor3x3;
typedef struct _AbcFractureCond_  AbcFractureCond;
typedef struct _AbcStressTest_    AbcStressTest;

struct _AbcTensor3x3_ {
     int is_debugging;
     int dim;     /* dim=2 (2x2 subsystems) and dim=3 (3x3 subsystems) */

     /* Assuming a symmetrical tensor. */
     double s11;
     double s22;
     double s33;
     double s12;
     double s23;
     double s13;

     /* Principal components. */
     double S1;
     double S2;
     double S3;

     /* Invariants. */
     double I1;
     double I2;
     double I3;
};

#define ABC_FRACTURE_NONE      0
#define ABC_FRACTURE_TENSION   1
#define ABC_FRACTURE_SHEAR     2

struct _AbcFractureCond_ {
     double cohesion;        /* [Pa] */
     double angle_oif;       /* [deg] */
     double tension_cutoff;  /* [Pa] */
};

struct _AbcStressTest_ {
     int is_debugging;
     int solver_version;
     double x1;
     double x2;
     double x3;
     double S1;
     double S2;
     double S3;
     double c0;
     double phi;
};


int abc_main_test_mech_functions(int argc, char **argv);
void abc_test_principal_directions(AbcStressTest *data);
void abc_make_test_rotation_matrix(
     double x1, double x2, double x3, double R[3][3], int is_debugging);
int abc_is_equal_tensor3x(AbcTensor3x3 *A, AbcTensor3x3 *B);
void abc_init_tensor3x3(AbcTensor3x3 *T);
void abc_set_tensor3x3_by_vec(AbcTensor3x3 *T, int dim, double *vec);
void abc_set_tensor3x3_by_negative_vec(AbcTensor3x3 *T, int dim, double *vec);
void abc_set_tensor3x3(AbcTensor3x3 *T, double s11, double s22, double s33, 
     double s12, double s23, double s13);
void abc_set_sub2x2_tensor3x3(AbcTensor3x3 *T, double s11, double s22, double s12);
void abc_show_tensor3x3(FILE *out, const char *name, AbcTensor3x3 *T);
double abc_get_invariant_I1(AbcTensor3x3 *T);
double abc_get_invariant_I2(AbcTensor3x3 *T);
double abc_get_invariant_I3(AbcTensor3x3 *T);
void abc_make_principal_components_I(AbcTensor3x3 *T);
void abc_make_principal_components_II(AbcTensor3x3 *T);
int abc_is_fracture_state2x2(AbcFractureCond *FC, double s11, double s22, double s12);
int abc_is_fracture_state3x3(AbcFractureCond *FC, double s11, double s22, double s33, 
     double s12, double s23, double s13);
int abc_is_fracture_state_S1_S3(AbcFractureCond *FC, double S1, double S3);
int abc_is_fracture_state(AbcFractureCond *FC, AbcTensor3x3 *T);
const char *abc_get_name_of_fracture_mode(int mode);
AbcTensor3x3 *abc_get_current_fracture_stress(void);
void abc_print_fracture_stress(AbcTensor3x3 *sigma, FILE *out);
void abc_plot_fracture_envelope_and_stress(AbcFractureCond *FC, AbcTensor3x3 *T, 
     const char *filename);
double abc_get_G_parameter(double E, double nu);
double abc_get_lambda_parameter(double E, double nu);

#endif
