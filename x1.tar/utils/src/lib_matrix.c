/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998-1999 by M. Wangen.
**
**   Info: A library simple matrix operations
**   Date: Version 1.0, December 1998
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#include <math.h>
#include <stdio.h>
#include <lib_alloc.h>
#include <lib_macros.h>
#include <lib_matrix.h>

static void test_func(int n, double *x, double *f);
static void test_fix(int n, double *x);

/*
**   \chapter{Basic matrix functions}
*/


void abc_basic_inverse_matrix(
     double **a,     /* Matrix on left hand side. */
     double **ainv,  /* Inverse matrix. */
     int n)          /* Number of rows. */
{
     int i, j, *l;
     double *s, *b, *x;
      
     if (n < 2)
     {
          if (ABC_ABS(a[0][0]) < 1.0e-46)
               ABC_ERROR_RETURN("[basic_matrix_solver] Singular matrix!");

          ainv[0][0] = 1.0 / a[0][0];
          return;
     }

     ABC_NEW_ARRAY(l, int, n);
     ABC_NEW_ARRAY(s, double, n);
     ABC_NEW_ARRAY(b, double, n);
     ABC_NEW_ARRAY(x, double, n);
     
     abc_basic_matrix_triang(a, s, l, n);

     for (j = 0; j < n; j++)
     {
          abc_basic_zero_vector(b, n);
          b[j] = 1.0;
          abc_basic_matrix_back_subst(a, b, x, l, n);

          for (i = 0; i < n; i++)
               ainv[i][j] = x[i];
     }
 
     ABC_FREE_ARRAY(l);
     ABC_FREE_ARRAY(s);
     ABC_FREE_ARRAY(b);
     ABC_FREE_ARRAY(x);
}


void abc_basic_linear_equation_solver(
     double **a,  /* Matrix on left hand side. */
     double *b,   /* Vector on right hand side. */
     double *x,   /* Vector of unknowns. */
     int n)       /* Number of rows. */
{
     int *l;
     double *s;

     ABC_NEW_ARRAY(l, int, n);
     ABC_NEW_ARRAY(s, double, n);

     abc_basic_gauss_solver(a, b, x, s, l, n);

     ABC_FREE_ARRAY(l);
     ABC_FREE_ARRAY(s);
}


void abc_basic_gauss_solver(
     double **a,  /* Matrix on left hand side. */
     double *b,   /* Vector on right hand side. */
     double *x,   /* Vector of unknowns. */
     double *s,   /* Scale array */
     int *l,      /* Permutation array */
     int n)       /* Number of rows. */
{
     if (n < 2)
     {
          if (ABC_ABS(a[0][0]) < 1.0e-46)
               ABC_ERROR_RETURN("[basic_matrix_solver] Singular matrix!");

          x[0] = b[0] / a[0][0];
          return;
     }


     abc_basic_matrix_triang(a, s, l, n);
     abc_basic_matrix_back_subst(a, b, x, l, n);
}


void abc_basic_matrix_triang(
     double **a,  /* Matrix on left hand side. */
     double *s,   /* Scale array */
     int *l,      /* Permutation array */
     int n)       /* Number of rows. */
{
     int i, j, k, lk;
     double fac, max;

     for (i = 0; i < n; i++)
     {
          l[i] = i;
          s[i] = 0.0;

          for (j = 0; j < n; j++)
               s[i] = ABC_MAX(s[i], ABC_ABS(a[i][j]));
     }

     for (k = 0; k < n - 1; k++)
     {
          max = 0.0;
          j = -1;

          for (i = k; i < n; i++)
          {
               if (ABC_ABS(s[l[i]]) < 1.0e-46)
               {
                    fprintf(stderr, "Max elem in row: %d: is %g\n", l[i], s[l[i]]);
                    fprintf(stderr, "[abc_basic_matrix_triang] Singular matrix!\n");
                    return;
               }

               fac = a[l[i]][k] / s[l[i]];
               fac = ABC_ABS(fac);

               if (fac < max)
                    continue;

               j = i;
               max = fac;
          }

          if (j < 0)
          {
               fprintf(stderr, "[abc_basic_matrix_triang] Singular matrix (j<0)!\n");
               return;
          }

          lk = l[j];
          l[j] = l[k];
          l[k] = lk;

          for (i = k + 1; i < n; i++)
          {
               if (ABC_ABS(a[lk][k]) < 1.0e-46)
               {
                    fprintf(stderr, "a[%d][%d]=%g\n", lk, k, a[lk][k]);
                    fprintf(stderr, "[abc_basic_matrix_triang] Singular matrix!\n");
                    return;
               }

               fac = a[l[i]][k] / a[lk][k];
               a[l[i]][k] = fac;

               for (j = k + 1; j < n; j++)
                    a[l[i]][j] -= fac * a[lk][j];
          }
     }
}


void abc_basic_matrix_back_subst(
     double **a,  /* Matrix on left hand side. */
     double *b,   /* Vector on right hand side. */
     double *x,   /* Vector of unknowns. */
     int *l,      /* Permutation array */
     int n)       /* Number of rows. */
{
     int i, j;
     double sum;

     for (j = 0; j < n - 1; j++)
          for (i = j + 1; i < n; i++)
               b[l[i]] -= a[l[i]][j] * b[l[j]];

     x[n-1] = b[l[n-1]] / a[l[n-1]][n-1];

     for (i = 2; i <= n; i++)
     {
          sum = b[l[n-i]];

          for (j = n - i + 1; j < n; j++)
               sum -= a[l[n-i]][j] * x[j];

          x[n-i] = sum / a[l[n-i]][n-i];
     }
}


void abc_basic_matrix_mul_scalar(
     double scalar,
     double **matrix,
     int rows,
     int cols)
{
     int i, j;

     for (i = 0; i < rows; i++)
          for (j = 0; j < cols; j++)
               matrix[i][j] *= scalar;
}


void abc_basic_matrix_mul_vector(
     double **a,        /* "A" matrix in "r = Axb". */
     const double *b,   /* "b" vector in "r = Axb". */
     double *r,         /* "r" vector in "r = Axb". */
     int rows,          /* Number of rows. */
     int cols)          /* Number of cols. */
{
     int i, j;

     for (i = 0; i < rows; i++)
     {
          r[i] = 0.0;

          for (j = 0; j < cols; j++)
               r[i] += a[i][j] * b[j];
     }
}


void abc_basic_matrix_mul_transp_vector(
     double **a,        /* "A" matrix in "r = bTxA". */
     const double *b,   /* "b" vector in "r = bTxA". */
     double *r,         /* "r" vector in "r = bTxA". */
     int rows,          /* Number of rows. */
     int cols)          /* Number of cols. */
{
     int i, j;

     for (j = 0; j < cols; j++)
     {
          r[j] = 0.0;

          for (i = 0; i < rows; i++)
               r[j] += b[i] * a[i][j];
     }
}


void abc_basic_matrix_transpose(
     double **a,        /* "A" matrix in "r = Axb". */
     int rows,          /* Number of rows. */
     int cols)          /* Number of cols. */
{
     int i, j;
     double numb;

     if (rows != cols)
          ABC_ERROR_RETURN("[abc_basic_matrix_transpose] Not symmetrix matrix!");

     for (i = 0; i < rows; i++)
          for (j = i + 1; j < cols; j++)
          {
               numb = a[i][j];
               a[i][j] = a[j][i];
               a[j][i] = numb;
          }
}


void abc_basic_matrix_mul_matrix(
     double **a1,
     int rows1,
     int cols1,
     double **a2,
     int cols2,
     double **a3)
{
     int i, j, k;

     for (i = 0; i < rows1; i++)
          for (k = 0; k < cols2; k++)
               for (j = 0, a3[i][k] = 0.0; j < cols1; j++)
                    a3[i][k] += a1[i][j] * a2[j][k];
}


void abc_basic_copy_vector(
     double *a,         /* Vector to be written to. */
     const double *b,   /* Vector to copied. */
     int rows)          /* Number of elements. */
{
     int i;

     for (i = 0; i < rows; i++)
          a[i] = b[i];
}


void abc_basic_copy_matrix(
     double **a,   /* Matrix to be written to. */
     double **b,   /* Matrix to be copied. */
     int rows,     /* Number of rows. */
     int cols)     /* Number of cols. */
{
     int i, j;

     for (i = 0; i < rows; i++)
          for (j = 0; j < cols; j++)
               a[i][j] = b[i][j];
}


void abc_basic_zero_vector(
     double *a,   /* Vector to become zero. */
     int rows)    /* Number of elements. */
{
     int i;

     for (i = 0; i < rows; i++)
          a[i] = 0.0;
}


void abc_basic_zero_matrix(
     double **a,   /* Matrix to become zero. */
     int rows,     /* Number of rows in matrix. */
     int cols)     /* Number of cols in matrix. */
{
     int i, j;

     for (i = 0; i < rows; i++)
          for (j = 0; j < cols; j++)
               a[i][j] = 0.0;
}


void abc_basic_inc_vector(
     double *a,
     const double *da,
     int rows)
{
     int i;

     for (i = 0; i < rows; i++)
          a[i] += da[i];
}


void abc_basic_add_vectors(
     const double *a, /* "a" vector in "c = a + b". */
     const double *b, /* "b" vector in "c = a + b". */
     double *c,       /* "c" vector in "c = a + b". */
     int rows)        /* Number of elements. */
{
     int i;

     for (i = 0; i < rows; i++)
          c[i] = a[i] + b[i];
}


void abc_basic_sub_vectors(
     const double *a, /* "a" vector in "c = a - b". */
     const double *b, /* "b" vector in "c = a - b". */
     double *c,       /* "c" vector in "c = a - b". */
     int rows)        /* Number of elements. */
{
     int i;

     for (i = 0; i < rows; i++)
          c[i] = a[i] - b[i];
}


void abc_basic_mul_vector_and_scalar(
     double *vec, 
     double scalar, 
     int rows)
{
     int i;

     for (i = 0; i < rows; i++)
          vec[i] *= scalar;
}


double abc_basic_dot_vectors(
     double *a,       /* Vector 1 */
     double *b,       /* Vector 2 */
     int rows)        /* Number of elements. */
{
     int i;
     double sum = 0.0;

     for (i = 0; i < rows; i++)
          sum += (a[i] * b[i]);

     return sum;
}


double abc_basic_sum_vector(
     const double *a,   /* Input vector. */
     int rows)          /* Number of elements. */
{    
     int i;
     double sum = 0.0;
     
     for (i = 0; i < rows; i++)
          sum += a[i];

     return sum;
}


double abc_basic_max_vector(
     const double *a, /* Input vector. */
     int rows)        /* Number of elements. */
{
     int i;
     double max = 0.0;

     if (rows > 0)
          max = a[0];

     for (i = 1; i < rows; i++)
          max = ABC_MAX(a[i], max);

     return max;
}


double abc_basic_min_vector(
     const double *a, /* Input vector. */
     int rows)        /* Number of elements. */
{
     int i;
     double min = 0.0;

     if (rows > 0)
          min = a[0];

     for (i = 1; i < rows; i++)
          min = ABC_MIN(a[i], min);

     return min;
}


int abc_basic_max_int_vector(
     const int *a,   /* Input vector. */
     int rows)       /* Number of elements. */
{
     int i;
     double max = 0.0;

     if (rows > 0)
          max = a[0];

     for (i = 1; i < rows; i++)
          max = ABC_MAX(a[i], max);

     return max;
}


int abc_basic_min_int_vector(
     const int *a,   /* Input vector. */
     int rows)       /* Number of elements. */
{
     int i;
     double min = 0.0;

     if (rows > 0)
          min = a[0];

     for (i = 1; i < rows; i++)
          min = ABC_MIN(a[i], min);

     return min;
}


double abc_basic_norm_l1(
     const double *a, /* Input vector. */
     int rows)        /* Number of elements. */
{
     int i;
     double sum = 0.0;

     for (i = 0; i < rows; i++)
          sum += ABC_ABS(a[i]);

     return sum;
}


double abc_basic_norm_l2(
     const double *a, /* Input vector. */
     int rows)        /* Number of elements. */
{
     int i;
     double sum = 0.0;

     for (i = 0; i < rows; i++)
          sum += ABC_SQR(a[i]);

     return sqrt(sum);
}


double abc_basic_norm_infinity(
     const double *a, /* Input vector. */
     int rows)        /* Number of elements. */
{
     int i;
     double sum = 0.0;

     for (i = 0; i < rows; i++)
          sum = ABC_MAX(sum, ABC_ABS(a[i]));

     return sum;
}

/*
**   \chapter{Band matrix functions}
*/

void abc_band_gauss_solver(
     double **a,  /* Matrix on left hand side. */
     double *b,   /* Vector on right hand side. */
     double *x,   /* Vector of unknowns. */
     int n,       /* The size. */
     int d)       /* Band number for diagonal. */
{
     abc_band_matrix_triang(a, n, d);
     abc_band_matrix_back_subst(a, b, x, n, d);
}


void abc_band_matrix_triang(
     double **a,  /* Matrix on left hand side. */
     int n,       /* The size. */
     int d)       /* Band number for diagonal. */
{
     int i, k, b0, b1, b2;
     double ad, m;

     for (k = 0; k < n; k++)
     {
          for (i = k + 1; i < ABC_MIN(k + d + 1, n); i++)
          {
               b0 = k + d - i;
               ad = a[k][d];

               if (ABC_ABS(ad) < 1.0e-35)
               {
                    fprintf(stderr, "[abc_band_matrix_triang] Warning: zero diagnoal element!\n");
                    fprintf(stderr, "(k=%d, d=%d, elem=%g)\n", k, d, ad);
                    ad = 1.0e-35;
               }

               m = a[i][b0] / ad;
               a[i][b0] = m;

               for (b1 = b0 + 1; b1 < 2 * d + 1 + k - i; b1++)
               {
                    b2 = b1 + i - k;
                    a[i][b1] = a[i][b1] - m * a[k][b2];
               }
          }
     }
}


void abc_band_matrix_back_subst(
     double **a,  /* Matrix on left hand side. */
     double *b,   /* Vector on right hand side. */
     double *x,   /* Vector of unknowns. */
     int n,       /* The size. */
     int d)       /* Band number for diagonal. */
{
     int i, j, k, b0;
     double m, sum;

     /* Modify the right hand side vector "b". */

     for (k = 0; k < n; k++)
     {
          for (i = k + 1; i < ABC_MIN(k + d + 1, n); i++)
          {
               b0 = k + d - i;
               m = a[i][b0];
               b[i] = b[i] - m * b[k];
          }
     }

     /* Back substitute */

     for (k = n - 1; k > -1; k--)
     {
          sum = 0.0;

          for (i = d + 1; i < 2 * d + 1; i++)
          {
               j = i + k - d;

               if (j < 0)
                    continue;
               else if (j >= n)
                    continue;

               sum += x[j] * a[k][i];
          }

          x[k] = (b[k] - sum) / a[k][d];
     }
}


void abc_band_matrix_mul_vector(
     double **a,  /* "A" matrix in "r = Axb". */
     double *b,   /* "b" vector in "r = Axb". */
     double *r,   /* "r" vector in "r = Axb". */
     int n,       /* The size. */
     int d)       /* Band number for diagonal. */
{
     int i, j, k;

     for (i = 0; i < n; i++)
     {
          r[i] = 0.0;

          for (k = 0; k < 2 * d + 1; k++)
          {
               j = i + k - d;

               if (0 <= j and j < n)
                    r[i] += a[i][k] * b[j];
          }
     }
}


void abc_band_matrix_mul_transp_vector(
     double **a,  /* "A" matrix in "r = Axb". */
     double *b,   /* "b" vector in "r = Axb". */
     double *r,   /* "r" vector in "r = Axb". */
     int n,       /* The size. */
     int d)       /* Band number for diagonal. */
{
     int i, j, k;

     for (j = 0; j < n; j++)
     {
          r[j] = 0.0;

          for (k = 0; k < 2 * d + 1; k++)
          {
               i = j + d - k;

               if (0 <= i and i < n)
                    r[j] += b[i] * a[i][k];
          }
     }
}


void abc_band_matrix_transpose(
     double **a,  /* "A" matrix. */
     int n,       /* The size. */
     int d)       /* Band number for diagonal. */
{
     int i, j, b1, b2;
     double value;

     for (i = 0; i < n; i++)
          for (b1 = d + 1; b1 < 2 * d + 1; b1++)
          {
               j = i + b1 - d;
               if (j < 0 or n <= j) continue;
               b2 = 2 * d - b1;

               value = a[i][b1];
               a[i][b1] = a[j][b2];
               a[j][b2] = value;
          }
}

/*
**   =============
**   Newton solver
**   =============
*/

void abc_demo_newton_solver0(
     void)
{
     int i;
     int n = 5;
     double epsilon = 1.0e-18;
     double x[10];
     const char *name[5] = {"[H+]", "[OH-]", "[HCO3-]", "[CO3--]", "[H2CO3]"};

     for (i = 0; i < 5; i++)
          x[i] = 1.0e-7;

     if (not abc_newton_solver0(n, test_func, test_fix, x, epsilon))
          printf("No convergense in Newton-solver1!\n");

     for (i = 0; i < 5; i++)
          printf("%7s = %10.4e\n", name[i], x[i]);
}


void abc_demo_newton_solver1(
     void)
{
     int i;
     double epsilon = 1.0e-18;
     double x[10];
     const char *name[5] = {"[H+]", "[OH-]", "[HCO3-]", "[CO3--]", "[H2CO3]"};
     AbcNewton1 *solver = abc_new_newton_solver1(5, test_func, test_fix);

     for (i = 0; i < 5; i++)
          x[i] = 1.0e-7;

     solver->is_verbose = TRUE;

     if (not abc_newton_solver1(solver, x, epsilon))
          printf("No convergense in Newton-solver1!\n");

     for (i = 0; i < 5; i++)
          printf("%7s = %10.4e, f(%d) = %10.4e\n", name[i], x[i], i, solver->f[i]);

     abc_delete_newton_solver1(&solver);
}


static void test_func(
     int n,
     double *x,
     double *f)
{
     double K1 = pow(10.0,  -6.3);
     double K2 = pow(10.0, -10.3);
     double Kw = pow(10.0, -14.0);
     double CT = pow(10.0,  -2.0);

     f[0] = x[0] * x[1] - Kw;
     f[1] = x[0] * x[2] - K1 * x[4];
     f[2] = x[0] * x[3] - K2 * x[2];
     f[3] = x[0] - x[1] - x[2] - 2 * x[3];
     f[4] = CT - x[2] - x[3] - x[4];

     ABC_UNUSED_PARAMETER(n);
}


static void test_fix(
     int n,
     double *x)
{
     int i;

     for (i = 0; i < n; i++)
          if (x[i] < 0.0)
               x[i] = 1.0e-9;
}


int abc_newton_solver0(
     int n,
     ABC_NEWTON_FUNC1 func,
     ABC_NEWTON_FIX1 fix,
     double *x,
     double epsilon)
{
     int ok;
     AbcNewton1 *solver = abc_new_newton_solver1(n, func, fix);
     ok = abc_newton_solver1(solver, x, epsilon);
     abc_delete_newton_solver1(&solver);
     return ok;
}


AbcNewton1 *abc_new_newton_solver1(
     int n,
     ABC_NEWTON_FUNC1 func,
     ABC_NEWTON_FIX1 fix)
{
     AbcNewton1 *solver;

     if (func == NULL)
          ABC_ERROR_EXIT("[abc_new_newton_solver1] Missing func!");

     ABC_NEW_OBJECT(solver, AbcNewton1);

     ABC_NEW_ARRAY(solver->f, double, n);
     ABC_NEW_ARRAY(solver->f1, double, n);
     ABC_NEW_ARRAY(solver->x1, double, n);
     ABC_NEW_ARRAY(solver->dx, double, n);
     ABC_NEW_ARRAY(solver->aux_dbl, double, n);
     ABC_NEW_ARRAY(solver->aux_int, int, n);
     ABC_NEW_MATRIX_2(solver->A, double, n, n);

     solver->n = n;
     solver->fix = fix;
     solver->func = func;
     solver->max_iter = 25;
     solver->is_verbose = FALSE;

     return solver;
}


void abc_delete_newton_solver1(
     AbcNewton1 **ptr)
{
     AbcNewton1 *solver;

     if (ptr == NULL) return;
     solver = *ptr;

     ABC_FREE_ARRAY(solver->f)
     ABC_FREE_ARRAY(solver->f1);
     ABC_FREE_ARRAY(solver->x1);
     ABC_FREE_ARRAY(solver->dx);
     ABC_FREE_ARRAY(solver->aux_dbl);
     ABC_FREE_ARRAY(solver->aux_int);
     ABC_FREE_MATRIX_2(solver->A);
     ABC_FREE(solver);
}


int abc_newton_solver1(
     AbcNewton1 *ns,
     double *x,
     double epsilon)
{
     int counter = 0;
     int i, j, n;
     double err = 1.0e+32;
     double dxj;

     if (ns == NULL) 
          ABC_RETURN_FALSE("[abc_newton_solver1] NULL-pointer!");

     n = ns->n;

     while (err > epsilon)
     {
          counter++;

          if (counter >= ns->max_iter)
               return FALSE;


          ns->func(n, x, ns->f);

          for (j = 0; j < n; j++)
          {
               abc_basic_copy_vector(ns->x1, x, n);
               dxj = 1.0e-6 * x[j];
               ns->x1[j] = x[j] + dxj;
               ns->func(n, ns->x1, ns->f1);
     
               for (i = 0; i < n; i++)
                    ns->A[i][j] = (ns->f1[i] - ns->f[i]) / dxj;
          }

          abc_basic_gauss_solver(ns->A, ns->f, ns->dx, ns->aux_dbl, ns->aux_int, n);
          abc_basic_mul_vector_and_scalar(ns->dx, -1.0, n);
          abc_basic_inc_vector(x, ns->dx, n);
          if (ns->fix != NULL) ns->fix(n, x);

          err = abc_basic_norm_l2(ns->f, n);

          if (ns->is_verbose)
               printf("(iteration: %d, err=%g)\n", counter, err);
     }

     return TRUE;
}

