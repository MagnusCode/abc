/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998-2011 by M. Wangen.
**
**   Info: Library for allocation of memory, which will not be reallocated
**   Date: Version 1.1, December 2011
**
**   $Id$
*/   

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/ 

#ifndef _LIB_ALLOCATE_ONCE_H_
#define _LIB_ALLOCATE_ONCE_H_

#define ABC_MAX_POINTERS 4096

typedef struct _AbcMemory_ AbcMemory;

struct _AbcMemory_ {
     int is_verbose;
     int n_array;
     int array_of_sizes[ABC_MAX_POINTERS];
     void *array_of_pointers[ABC_MAX_POINTERS];
     void *array_of_group_id[ABC_MAX_POINTERS];
};

void abc_test_allocated_once1(void);
void abc_test_allocated_once2(void);
void abc_alloc_once_init(AbcMemory *memory);
AbcMemory *abc_get_current_alloc_once(void);
void abc_set_current_alloc_once(AbcMemory *memory);
void abc_set_default_alloc_once(void);
int *abc_alloc_int_once(int number);
char *abc_alloc_char_once(int number);
char *abc_alloc_chars_once(int number);
char *abc_alloc_chars_once2(void *id, int number, char value);
int *abc_alloc_ints_once(int number);
int *abc_alloc_ints_once2(void *id, int number, int value);
float *abc_alloc_floats_once(int number);
float *abc_alloc_floats_once2(void *id, int number, float value);
double *abc_alloc_doubles_once(int number);
double *abc_alloc_doubles_once2(void *id, int number, double value);
void *abc_calloc_once(size_t n_nmemb, size_t size, void *id);
void *abc_malloc_once(size_t n_bytes, void *id);
void abc_store_allocated_pointer(void *pointer, int n_bytes, void *id);
void abc_free_allocated_pointer(void *pointer);
void abc_delete_memory_allocated_once(AbcMemory *memory);
void abc_delete_all_allocated_once2(void *id);
void abc_delete_all_allocated_once(void);
void abc_list_allocated_once(FILE *out);
int abc_get_bytes_allocated_once(void);
int abc_get_unused_index_alloc_once(void);
int abc_get_pointer_index_alloc_once(void *pointer);

#endif

