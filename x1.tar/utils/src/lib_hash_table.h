/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1993-2002 by M. Wangen.
**
**   Info: A general hash table
**   Date: Version 1.0, November 1993
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_HASH_TABLE_H_
#define _LIB_HASH_TABLE_H_

typedef struct _AbcHashTableItem_ AbcHashTableItem;
typedef struct _AbcHashTable_ AbcHashTable;

typedef void (*ABC_HASH_DELETE_FUNC)(void **buffer);
typedef void (*ABC_HASH_PRINT_FUNC)(FILE *out, void const *buffer);
typedef void (*ABC_HASH_PRINT_FUNC_ITEM)(FILE *out, AbcHashTableItem *item);

struct _AbcHashTableItem_ {
     char *name;                       /* The item name (or key). */
     void *buffer;                     /* Pointer to any object. */
     struct _AbcHashTableItem_ *next;  /* The next item in the list. */
};

struct _AbcHashTable_ {
     char *name;                       /* The table name. */
     int size;                         /* The table size. */
     AbcHashTableItem **table;         /* The table. */
     ABC_HASH_DELETE_FUNC delete_buffer_func;
};

int abc_test_hash_table(void);
AbcHashTable *abc_create_hash_table(int size, char const *table_name, ABC_HASH_DELETE_FUNC delete_buffer);
void abc_delete_hash_table(AbcHashTable **table);
int abc_get_hash_table_index(int size, char const *string);
void abc_hash_table_insert(AbcHashTable *table, char const *name, void *anything);
AbcHashTableItem *abc_get_hash_table_item(AbcHashTable *table, char const *name);
void *abc_hash_table_lookup(AbcHashTable *table, char const *name);
void abc_print_hash_table(FILE *out, AbcHashTable *table, ABC_HASH_PRINT_FUNC print_buffer);
void abc_print_hash_table_items(FILE *out, AbcHashTable *table, ABC_HASH_PRINT_FUNC_ITEM print_func);
int abc_get_number_of_items_in_hash_table(AbcHashTable *table);
AbcHashTableItem **abc_create_sorted_hash_table(AbcHashTable *table);
AbcHashTable *abc_create_string_hash_table(int size, const char *name);
void abc_set_hash_table_string_item(AbcHashTable *table, const char *key, const char *name);
void abc_print_string_hash_table(FILE *out, AbcHashTable *table);

#endif
