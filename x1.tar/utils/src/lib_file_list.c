/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1996-2015 by M. Wangen.
**
**   Info: Title: Repository for file descriptors.
**   Date: Version 1.0, February 1994
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   History:
**   Version: 1.00 Feb 1994: The first version.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <lib_macros.h>
#include <lib_file_list.h>

#define MAX_FILES_IN_LIST 64

typedef struct _AbcFileList_ AbcFileList;

struct _AbcFileList_ {
     FILE *fd;
     char mode[ABC_MAX_WORD];
     char filename[ABC_MAX_WORD];
     char comment[ABC_MAX_WORD];
};

static int is_verbose = TRUE;
static int n_files_in_list = 0;
static AbcFileList file_list[MAX_FILES_IN_LIST];


void abc_test_listed_files(
     void)
{
     FILE *fd1, *fd2, *fd3;

     fd1 = abc_open_listed_file("x1-test.txt", "Main results are written to:", "w");
     fd2 = abc_open_listed_file("x2-test.txt", "Other results are written to:", "w");
     fd3 = abc_open_listed_file("x3-test.txt", "Logged variables are written to:", "w");

     fprintf(fd1, "Main results\n");
     fprintf(fd2, "Other results\n");
     fprintf(fd3, "Logged variables\n");

     abc_show_all_listed_files();

     abc_close_one_listed_file(fd3);
     abc_show_all_listed_files();

     abc_close_all_listed_files();
     abc_show_all_listed_files();
}


static void close_listed_file_by_index(
     int i)
{
     if (file_list[i].fd == NULL) return;
     fclose(file_list[i].fd);
     file_list[i].fd = NULL;
     if (not is_verbose) return;
     printf("%s %s\n", file_list[i].comment, file_list[i].filename);
}


FILE *abc_new_listed_file(
     const char *basename,
     const char *ext,
     const char *comment)
{
     char filename[ABC_MAX_WORD];
     sprintf(filename, "%s%s", basename, ext);
     return abc_open_listed_file(filename, comment, "w");
}


FILE *abc_open_listed_file(
     const char *filename,
     const char *comment,
     const char *mode)
{
     int i = abc_get_index_free_listed_file();
     FILE *fd = fopen(filename, mode);

     if (fd == NULL)
     {
          printf("Warning: Can't open file: %s\n", filename);
          exit(1);
     }

     file_list[i].fd = fd;
     strcpy(file_list[i].mode, mode);
     strcpy(file_list[i].filename, filename);
     strcpy(file_list[i].comment, comment);

     return fd;
}


void abc_close_one_listed_file(
     FILE *fd)
{
     int i = abc_get_index_listed_file(fd);

     if (i < 0)
     {
          fclose(fd);
          printf("[abc_close_one_listed_file] Closed a non-listed file!\n");
     }

     close_listed_file_by_index(i);

     if (i == n_files_in_list - 1) 
          n_files_in_list--;
}


void abc_close_all_listed_files(
     void)
{
     int i;

     for (i = 0; i < n_files_in_list; i++)
     {
          if (file_list[i].fd == NULL) continue;
          close_listed_file_by_index(i);
     }

     n_files_in_list = 0;
}


void abc_show_all_listed_files(
     void)
{
     int i;

     for (i = 0; i < n_files_in_list; i++)
          printf("file: \"%s\", mode: \"%s\", comment: \"%s\"\n",
               file_list[i].filename, file_list[i].mode, file_list[i].comment);
}


int abc_get_index_free_listed_file(
     void)
{
     int i;

     for (i = 0; i < n_files_in_list; i++)
          if (file_list[i].fd == NULL)
               return i;

     i = n_files_in_list;
     n_files_in_list++;

     if (n_files_in_list > MAX_FILES_IN_LIST)
          ABC_ERROR_EXIT("Too many open files!");

     return i;
}


int abc_get_index_listed_file(
     FILE *fd)
{
     int i;

     for (i = 0; i < n_files_in_list; i++)
          if (file_list[i].fd == fd)
               return i;

     return -1;
}


