/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1993-2008 by M. Wangen.
**
**   Info: A library for the solution of 1D elliptic/parabolic equations
**   Date: Version 1.0, December 1993
**
**   $Id$
*/   

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   Jun 1993: First version.
**   Jan 2008: Rewritten/simplfied and overlapping nodes.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_utils.h>
#include <lib_matrix.h>
#include <lib_simple_1d.h>

#define MAX_WORD 256

static int
     demo_size = 50,
     demo_bc_comb = 0,
     demo_debugging = 0,
     demo_make_overlap = FALSE;

static int read_one_option(const char *string);
static void show_options(FILE *out);
static void set_alternative_bcs(AbcSimple1D *demo, int bc_combination);
static void set_overlapping_nodes(AbcSimple1D *demo);
static double zero_coef(AbcSimple1D *sol, double t, int i);
static void insert_bc(AbcSimple1D *sol, int boundary);
static void store_A_and_b(AbcSimple1D *sol, const char *filaname);

/*
**   ==============
**   A demo example
**   ==============
*/

#ifdef _TEST_SIMPLE_1D
int main(
     int argc,
     char **argv)
{
     abc_1d_demo_simple_1d(argc, argv);
     return 0;
}
#endif

/*
**   (1) The solution of U,t-U,xx=0 on the x-axis from 0 to 1.
**   (2) Left BC is U=0 (ABC_1D_BC_1ST_KIND) and 
**       right BC is U,x=1 (ABC_1D_BC_2ND_KIND)
**   (3) Initial condition is U=0.
*/

/* Some compilors give warnings about unused variables. */
#define UNUSED2 sol=sol; t=t;
#define UNUSED3 sol=sol; t=t; i=i;
#define UNUSED4 sol=sol; t=t; i=i; code=code;
static double acoef(AbcSimple1D *sol, double t, int i) {UNUSED3; return 1.0;}
static double lambda(AbcSimple1D *sol, double t, int i, int code) {UNUSED4; return 1.0;}
static double unit_value(AbcSimple1D *sol, double t) {UNUSED2; return 1.0;}
static double zero_value(AbcSimple1D *sol, double t) {UNUSED2; return 0.0;}


void abc_1d_demo_simple_1d(
     int argc,
     char **argv)
{
     int i;
     double t;
     double dt = 0.001;
     FILE *out;
     const char *filename = "xdemo.xy";
     AbcSimple1D *demo;

     abc_1d_read_options(argc, argv);
     demo = abc_1d_new(demo_size);
     abc_1d_set_debugging(demo, demo_debugging);
     abc_1d_set_coef_funcs(demo, acoef, lambda, NULL);
     abc_1d_set_bc(demo, ABC_1D_BOUNDARY_LEFT, ABC_1D_BC_1ST_KIND, zero_value);
     abc_1d_set_bc(demo, ABC_1D_BOUNDARY_RIGHT, ABC_1D_BC_1ST_KIND, unit_value);

     if (demo_bc_comb > 0)
          set_alternative_bcs(demo, demo_bc_comb);

     if (demo_make_overlap)
          set_overlapping_nodes(demo);

     /* Set initial condition */

     for (i = 0; i < demo->size; i++)
          demo->solution0[i] = 0.0;

     if (not abc_1d_is_ok(demo))
          ABC_ERROR_EXIT("Can't continue!");
          
     out = abc_new_file(filename, "");
     abc_1d_store_solution(demo, out);

     for (t = 0.0; t < 2.5001; t += dt)
     {
          abc_1d_do_one_time_step(demo, t, dt);
          abc_1d_store_solution(demo, out);
          dt *= 2.0;
     }

     fclose(out);
     printf("Demo solution is written to: %s\n", filename);
     abc_1d_free(&demo);
}


static void set_alternative_bcs(
     AbcSimple1D *demo,
     int bc_comb)
{
     if (bc_comb == 1)
     {
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_LEFT, ABC_1D_BC_1ST_KIND, zero_value);
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_RIGHT, ABC_1D_BC_1ST_KIND, unit_value);
     }
     else if (bc_comb  == 10)
     {
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_LEFT, ABC_1D_BC_1ST_KIND, unit_value);
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_RIGHT, ABC_1D_BC_1ST_KIND, zero_value);
     }
     else if (bc_comb  == 2)
     {
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_LEFT, ABC_1D_BC_1ST_KIND, zero_value);
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_RIGHT, ABC_1D_BC_2ND_KIND, unit_value);
     }
     else if (bc_comb  == 20)
     {
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_LEFT, ABC_1D_BC_2ND_KIND, unit_value);
          abc_1d_set_bc(demo, ABC_1D_BOUNDARY_RIGHT, ABC_1D_BC_1ST_KIND, zero_value);
     }
     else
          ABC_ERROR_EXIT("[abc_1d_demo] Unknown BC's!");
}

static void set_overlapping_nodes(
     AbcSimple1D *demo)
{
     double *xcoord = demo->xcoord;
     int im = demo->size / 2;
     int i1 = im - 2;
     int i2 = im + 2;
     int i;

     for (i = i1; i < i2; i++)
          xcoord[i] = xcoord[i1];
}

/*
**   ==================
**   The Abc-functions
**   ==================
*/

void abc_1d_read_options(
     int argc,
     char **argv)
{
     int i;
     int n_errors = 0;

     for (i = 1; i < argc; i++)
          if (not read_one_option(argv[i]))
          {
               fprintf(stderr, "Unknown option: %s\n", argv[i]);
               n_errors++;
          }

     if (n_errors > 0)
          ABC_ERROR_EXIT("Option errors! Can't continue!");
}


static int read_one_option(
     const char *string)
{
     double value;
     char option[MAX_WORD], value_part[MAX_WORD];

     abc_interpret_option(string, option, value_part, &value);

     if      (ABC_MATCH(option, "bc01")) demo_bc_comb = 1;
     else if (ABC_MATCH(option, "bc10")) demo_bc_comb = 10;
     else if (ABC_MATCH(option, "bc02")) demo_bc_comb = 2;
     else if (ABC_MATCH(option, "bc20")) demo_bc_comb = 20;
     else if (ABC_MATCH(option, "overlap")) demo_make_overlap = TRUE;
     else if (ABC_MATCH(option, "debugging")) demo_debugging = (int) value;
     else if (ABC_MATCH(option, "-h") or ABC_MATCH(option, "help"))
     {
          show_options(stdout);
          exit(1);
     }
     else return FALSE;

     return TRUE;
}


static void show_options(
     FILE *out)
{
     fprintf(out, "Demo options:\n");
     fprintf(out, "   bc01    Left=1st kind (U=0);   Right=1st kind (U=1).\n");
     fprintf(out, "   bc10    Left=1st kind (U=1);   Right=1st kind (U=0).\n");
     fprintf(out, "   bc02    Left=1st kind (U=0);   Right=2nd kind (U,x=1).\n");
     fprintf(out, "   bc20    Left=2nd kind (U,x=1); Right=1st kind (U=0).\n");
     fprintf(out, "   overlap Introduce overlapping nodes.\n");
     fprintf(out, "Other options:\n");
     fprintf(out, "   -h help Show options.\n");
     fprintf(out, "   debug_map Debug node-map.\n");
     fprintf(out, "   debug_Ab Store A-matrix and b-vector to file.\n");
     fprintf(out, "   debug_stepping Write time-step info.\n");
}


AbcSimple1D *abc_1d_new(
     int size)
{
     int i;
     double dx;
     AbcSimple1D *obj;

     if (size < 3)
          ABC_ERROR_EXIT("[abc_1d_new] Size is less than 3!");

     ABC_NEW_OBJECT(obj, AbcSimple1D);
     ABC_NEW_ARRAY(obj->map, int , size);
     ABC_NEW_ARRAY(obj->inv_map, int , size);
     ABC_NEW_ARRAY(obj->xcoord, double , size);
     ABC_NEW_ARRAY(obj->solution0, double, size);
     ABC_NEW_ARRAY(obj->solution1, double, size);
     ABC_NEW_ARRAY(obj->solution2, double, size);
     ABC_NEW_ARRAY(obj->sol_mapped, double, size);
     ABC_NEW_ARRAY(obj->b_vector, double, size);
     ABC_NEW_MATRIX_2(obj->A_matrix, double, size, 3);

     dx = 1.0 / (size - 1);

     for (i = 0; i < size; i++)
     {
          obj->xcoord[i] = i * dx;
          obj->solution0[i] = 0.0;
          obj->solution1[i] = 0.0;
          obj->solution2[i] = 0.0;
          obj->sol_mapped[i] = 0.0;
          obj->b_vector[i] = 0.0;
          obj->A_matrix[i][0] = 0.0;
          obj->A_matrix[i][1] = 1.0;
          obj->A_matrix[i][2] = 0.0;
     }

     obj->size = size;
     obj->t1 = 0.0;
     obj->dt = 0.0;
     obj->bc_left = ABC_1D_BC_UNDEFINED;
     obj->bc_right = ABC_1D_BC_UNDEFINED;
     obj->acoef = NULL;
     obj->lambda = NULL;
     obj->source = NULL;
     obj->value_left = NULL;
     obj->value_right = NULL;

     /* Extra attributes for overlapping nodes. */

     obj->has_overlapping_nodes = FALSE;
     obj->debugging = 0;
     obj->size2 = size;

     for (i = 0; i < size; i++)
     {
          obj->map[i] = i;
          obj->inv_map[i] = i;
     }

     return obj;
}


void abc_1d_free(
     AbcSimple1D **pp)
{
     AbcSimple1D *obj;

     if (pp == NULL)
          return;

     obj = *pp;

     ABC_FREE_ARRAY(obj->map);
     ABC_FREE_ARRAY(obj->inv_map);
     ABC_FREE_ARRAY(obj->xcoord);
     ABC_FREE_ARRAY(obj->solution0);
     ABC_FREE_ARRAY(obj->solution1);
     ABC_FREE_ARRAY(obj->solution2);
     ABC_FREE_ARRAY(obj->sol_mapped);
     ABC_FREE_ARRAY(obj->b_vector);
     ABC_FREE_MATRIX_2(obj->A_matrix);
     ABC_FREE(obj);

     obj = NULL;
}


int abc_1d_is_ok(
     AbcSimple1D *sol)
{
     int i, size;
     int is_OK = TRUE;

     if (sol == NULL)
          ABC_RETURN_FALSE("[abc_1d_is_ok] NULL-pointer!\n");

     if (sol->lambda == NULL)
          ABC_RETURN_FALSE("[abc_1d_is_ok] Missing lambda-function!\n");

     if ((sol->bc_left == ABC_1D_BC_UNDEFINED) or (sol->value_left == NULL))
          ABC_RETURN_FALSE("[abc_1d_is_ok] Illegal left BC!\n");

     if ((sol->bc_right == ABC_1D_BC_UNDEFINED) or (sol->value_right == NULL))
          ABC_RETURN_FALSE("[abc_1d_is_ok] Illegal right BC!\n");

     /* 
     ** Check that coords are in increasing order.
     ** Beware that overlapping nodes are OK.
     */

     size = sol->size;

     for (i = 1; i < size; i++)
          if (sol->xcoord[i-1] > sol->xcoord[i])
          {
               fprintf(stderr, "[abc_1d_is_ok] x[%d]=%g > x[%d]=%g !\n",
                    i-1, sol->xcoord[i-1], 
                    i, sol->xcoord[i]);
               is_OK = FALSE;
          }

     if (ABC_ABS(sol->xcoord[1] - sol->xcoord[0]) < 1.0e-6)
          ABC_ERROR_EXIT("[abc_1d_is_ok] The two first nodes overlap!");

     if (ABC_ABS(sol->xcoord[size - 1] - sol->xcoord[size - 2]) < 1.0e-6)
          ABC_ERROR_EXIT("[abc_1d_is_ok] The two last nodes overlap!");

     return is_OK;
}


void abc_1d_set_debugging(
     AbcSimple1D *sol,
     int code)
{
     if (sol == NULL)
          ABC_ERROR_EXIT("[abc_1d_set_debugging] NULL-pointer!");

     sol->debugging = code;
}


void abc_1d_set_coef_funcs(
     AbcSimple1D *sol,
     ABC_1D_MAKE_COEF1 acoef,
     ABC_1D_MAKE_COEF2 lambda,
     ABC_1D_MAKE_COEF1 source)
{
     if (sol == NULL)
          ABC_ERROR_EXIT("[abc_1d_set_coef_funcs] NULL-pointer!");

     sol->acoef = acoef;
     sol->lambda = lambda;
     sol->source = source;

     if (sol->lambda == NULL)
          ABC_ERROR_EXIT("[abc_1d_set_coef_funcs] lambda == NULL!");

     if (sol->acoef == NULL) 
          sol->acoef = zero_coef;
    
     if (sol->source == NULL) 
          sol->source = zero_coef;
}


static double zero_coef(
     AbcSimple1D *sol,
     double t,
     int i)
{
     UNUSED3;
     return 0.0;
}


void abc_1d_set_bc(
     AbcSimple1D *sol,
     int boundary,
     int BC,
     ABC_1D_MAKE_BC func)
{
     if (sol == NULL)
          ABC_ERROR_EXIT("[abc_1d_set_bc] NULL-pointer!");

     if (boundary == ABC_1D_BOUNDARY_LEFT)
     {
          sol->bc_left = BC;
          sol->value_left = func;
     }
     else if (boundary == ABC_1D_BOUNDARY_RIGHT)
     {
          sol->bc_right = BC;
          sol->value_right = func;
     }
     else 
          ABC_ERROR_EXIT("[abc_1d_set_bc] Illegal boundary!");
}


void abc_1d_stationary_solution(
     AbcSimple1D *sol)
{
     sol->t1 = 0.0;
     sol->dt = 1.0;
     sol->acoef = zero_coef;

     if (abc_1d_has_overlapping_nodes(sol))
          abc_1d_solve_overlapping_nodes(sol);
     else
          abc_1d_solve(sol);
}


void abc_1d_do_one_time_step(
     AbcSimple1D *sol,
     double t1,
     double dt)
{
     sol->t1 = t1;
     sol->dt = dt;

     if (abc_1d_has_overlapping_nodes(sol))
          abc_1d_solve_overlapping_nodes(sol);
     else
          abc_1d_solve(sol);
}


void abc_1d_store_solution(
     AbcSimple1D *sol,
     FILE *out)
{
     int i;
     double *xcoord = sol->xcoord;
     double *solution1 = sol->solution1;
     double *solution2 = sol->solution2;

     fprintf(out, "#( time=%g )#\n", sol->t1);
     fprintf(out, "#( xcoord:0 solution:1 analytical:2 )#\n");

     for (i = 0; i < sol->size; i++)
          fprintf(out, "%g %g %g\n", xcoord[i], solution1[i], solution2[i]);
}


void abc_1d_solve(
     AbcSimple1D *sol)
{
     int i;
     int diag = 1;
     int size = sol->size;
     double t1 = sol->t1;
     double dt = sol->dt;
     double *b = sol->b_vector;
     double *U1 = sol->solution1;
     double *U0 = sol->solution0;
     double **A = sol->A_matrix;
     double *xcoord = sol->xcoord;
     double a1, l0, l1, q1, dx0, dx1, dxm, C0, C1;

     if (sol->debugging & ABC_1D_DEBUG_TIME_STEPPING)
          printf("(doing time step) (from=%g; to=%g)\n", t1 - dt, t1);

     /* Update the previous solution. */

     for (i = 0; i < size - 1; i++)
          U0[i] = U1[i];

     /* Make equation system. */

     for (i = 1; i < size - 1; i++)
     {
          a1 = sol->acoef(sol, t1, i);
          l0 = sol->lambda(sol, t1, i, ABC_1D_MINUS_HALF);
          l1 = sol->lambda(sol, t1, i, ABC_1D_PLUS_HALF);
          q1 = sol->source(sol, t1, i);

          dx0 = xcoord[i] - xcoord[i - 1];
          dx1 = xcoord[i + 1] - xcoord[i];
          dxm = 0.5 * (dx0 + dx1);

          C0 = dt * l0 / (dxm * dx0);
          C1 = dt * l1 / (dxm * dx1);

          A[i][0] = - C0;
          A[i][1] = C0 + C1 + a1;
          A[i][2] = - C1;
          b[i] = dt * q1 + a1 * U0[i];
     }

     /* Insert BC's. */

     insert_bc(sol, ABC_1D_BOUNDARY_LEFT);
     insert_bc(sol, ABC_1D_BOUNDARY_RIGHT);

     /* Solve. */

     for (i = 0; i < size; i++)
          U0[i] = U1[i];

     if (sol->debugging & ABC_1D_DEBUG_Ab) store_A_and_b(sol, "x1.deb");
     abc_band_gauss_solver(A, b, U1, size, diag);
}


static void insert_bc(
     AbcSimple1D *sol,
     int boundary)
{
     double dx, value;
     double t = sol->t1;
     double *xcoord = sol->xcoord;
     double *b = sol->b_vector;
     double **A = sol->A_matrix;
     int size = sol->size;
     int i, type;

     if (sol->has_overlapping_nodes)
          size = sol->size2;

     if (boundary == ABC_1D_BOUNDARY_LEFT)
     {
          i = 0;
          type = sol->bc_left;
          value = sol->value_left(sol, t);
          dx = xcoord[1] - xcoord[0];
     }
     else if (boundary == ABC_1D_BOUNDARY_RIGHT)
     {
          i = size - 1;
          type = sol->bc_right;
          value = sol->value_right(sol, t);
          dx = xcoord[size - 1] - xcoord[size - 2];
     }
     else
          ABC_ERROR_EXIT("[insert_bc] Unknown boundary!");

     if (type == ABC_1D_BC_1ST_KIND)
     {
          A[i][0] = 0.0;
          A[i][1] = 1.0;
          A[i][2] = 0.0;
          b[i] = value;
     }
     else if (type == ABC_1D_BC_2ND_KIND)
     {
          if (boundary == ABC_1D_BOUNDARY_LEFT)
          {
               A[i][0] = 0.0;
               A[i][1] = -1.0;
               A[i][2] = 1.0;
               b[i] = dx * value;
          }
          else if (boundary == ABC_1D_BOUNDARY_RIGHT)
          {
               A[i][0] = -1.0;
               A[i][1] =  1.0;
               A[i][2] = 0.0;
               b[i] = dx * value;
          }
          else
               ABC_ERROR_EXIT("[insert_bc] Unknown boundary!");
     }
     else
          ABC_ERROR_EXIT("[insert_bc] Unknown BC!");
}


static void store_A_and_b(
     AbcSimple1D *sol,
     const char *filename)
{
     int i;
     int size = sol->size;
     double *b = sol->b_vector;
     double **A = sol->A_matrix;
     FILE *out = abc_new_file(filename, "");

     if (sol->has_overlapping_nodes)
          size = sol->size2;

     for (i = 0; i < size; i++)
          fprintf(out, "%g %g %g %g\n", A[i][0], A[i][1], A[i][2], b[i]);

     fclose(out);
     printf("(A-matrix and b-vector are written to: %s)\n", filename);
}

/*
**   =================
**   Overlapping nodes
**   =================
*/

int abc_1d_has_overlapping_nodes(
     AbcSimple1D *sol)
{
     int i;
     int j = 1;
     int has_overlapping_nodes = FALSE;
     int *map, *inv_map;
     double *xcoord;

     if (sol == NULL)
          ABC_ERROR_EXIT("[abc_1d_has_overlapping_nodes] NULL-pointer!");

     xcoord = sol->xcoord;
     map = sol->map;
     inv_map = sol->inv_map;

     map[0] = 0;

     for (i = 1; i < sol->size; i++)
          if (ABC_ABS(xcoord[i] - xcoord[i - 1]) < 1.0e-9)
          {
             map[i] = j - 1;
             has_overlapping_nodes = TRUE;
          }
          else
          {
             map[i] = j;
             j++;
          }

     for (i = 0; i < sol->size; i++)
          inv_map[i] = 0;
     
     for (i = 0; i < sol->size; i++)
          inv_map[map[i]] = i;

     sol->size2 = j;
     sol->has_overlapping_nodes = has_overlapping_nodes;

     if (sol->debugging & ABC_1D_DEBUG_MAP)
          abc_1d_print_map(sol, stdout);

     return has_overlapping_nodes;
}


void abc_1d_print_map(
     AbcSimple1D *sol,
     FILE *out)
{
     int i;
     int size = sol->size;
     int size2 = sol->size2;
     int has_overlap = sol->has_overlapping_nodes;
     int *map = sol->map;
     int *inv_map = sol->inv_map;
     double *xcoord = sol->xcoord;

     for (i = 0; i < sol->size; i++)
     {
          printf("map[%d]=%d; inv[%d]=%d", i, map[i], i, inv_map[i]);

	  if (i > 1 and ABC_ABS(xcoord[i] - xcoord[i-1]) < 1.0e-6) 
               fprintf(out, " (overlap)");

          if (i == size2 and has_overlap) 
               fprintf(out, " (last node in inv_map)");

          fprintf(out, "\n");
     }

     if (has_overlap)
          fprintf(out, "got %d overlapping nodes!\n", size - size2);
}


void abc_1d_solve_overlapping_nodes(
     AbcSimple1D *sol)
{
     int i, j, im, i0, ip;
     int diag = 1;
     int size = sol->size;
     int size2 = sol->map[size - 1] + 1;
     int *map = sol->map;
     int *inv_map = sol->inv_map;
     double t1 = sol->t1;
     double dt = sol->dt;
     double *b = sol->b_vector;
     double *U0 = sol->solution0;
     double *U1 = sol->solution1;
     double *UM = sol->sol_mapped;
     double **A = sol->A_matrix;
     double *xcoord = sol->xcoord;
     double a1, l0, l1, q1, dx0, dx1, dxm, C0, C1;

     if (sol->debugging & ABC_1D_DEBUG_TIME_STEPPING)
          printf("(doing time step) (t1=%g; dt=%g) (has overlapping nodes)\n", t1, dt);

     /* Update the previous solution. */

     for (i = 0; i < size - 1; i++)
          U0[i] = U1[i];

     /* Make equation system. */

     for (j = 1; j < size2 - 1; j++)
     {
          im = inv_map[j - 1];
          i0 = inv_map[j];
          ip = inv_map[j + 1];

          a1 = sol->acoef(sol, t1, i0);
          l0 = sol->lambda(sol, t1, i0, ABC_1D_MINUS_HALF);
          l1 = sol->lambda(sol, t1, i0, ABC_1D_PLUS_HALF);
          q1 = sol->source(sol, t1, i0);

          dx0 = xcoord[i0] - xcoord[im];
          dx1 = xcoord[ip] - xcoord[i0];
          dxm = 0.5 * (dx0 + dx1);

          C0 = dt * l0 / (dxm * dx0);
          C1 = dt * l1 / (dxm * dx1);

          A[j][0] = - C0;
          A[j][1] = C0 + C1 + a1;
          A[j][2] = - C1;
          b[j] = dt * q1 + a1 * U0[i0];
     }

     /* Insert BC's. */

     insert_bc(sol, ABC_1D_BOUNDARY_LEFT);
     insert_bc(sol, ABC_1D_BOUNDARY_RIGHT);

     /* Solve. */

     if (sol->debugging & ABC_1D_DEBUG_Ab) store_A_and_b(sol, "x2.deb");
     abc_band_gauss_solver(A, b, UM, size2, diag);

     for (i = 0; i < sol->size; i++)
          U1[i] = UM[map[i]];
}


