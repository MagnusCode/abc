/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1999 by M. Wangen.
**
**   Info: 2D linear tables
**   Date: Version 1.0, February 1995
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   \chapter{Introduction}
**
**   \sloppypar
**   This library, {\tt lib\_table2d.c}, provides functions for
**   easy generation of 2D tables and linear interpolation in them.
**   A table is stored in a struct named {\tt AbcTable2D}, and the value
**   corresponding to the point $(x,y)$ in the table is produced by
**   a function call to {\tt double table\_value\_2d(AbcTable2D *table,
**   double x, double y)}.
**
**   \sloppypar
**   A table can be easily read in from an ASCII-file and created
**   by use of the function {\tt create\_2d\_table\_from\_file()},
**   which reads from last file opened by the
**   {\tt lib\_input}-function {\tt begin\_input(char *file\_name)}.
**   (See the {\tt lib\_input} manual for a description of the
**   the function {\tt begin\_input}, and it's counter part
**   {\tt end\_input} which closes files.)  Standard input is read
**   in case {\tt begin\_input} is never called, just as in the
**   example below.  A table created in this way has to be given
**   a format as shown in the example below.
**
**   {\footnotesize\tt\begin{verbatim}
**        begin_2d_table
**             rows 3 cols 5
**             name "This is a demo table"
**                    0.0  1.0  2.0  3.0  4.0
**             10.0 : 1.0  2.0  4.0  8.0  9.9
**             30.0 : 1.0  2.0  4.0  8.0  9.9
**             80.0 : 1.0  2.0  4.0  8.0  9.9
**        end_2d_table
**    \end{verbatim}}
**
**   \sloppypar
**   The table is enclosed by {\tt begin\_2d\_table} and
**   {\tt end\_2d\_table}.  The first to appear inside the
**   table are the key words which specify the number of
**   rows and columns in the table, ({\tt rows} and {\tt cols}).
**   Next follows the {\tt name}-key word and the table name
**   as a string delimited by double quotes.
**   After the table name come the $x$-values, which are the
**   look-up values for each column.  As many $x$-values as
**   number of columns are needed, but they don't have to be
**   given on a single line, if two or more line breaks are
**   wanted.  The data for each row and column then follow.
**   The $y$-value begins each row and a `{\tt :}' delimits
**   the $y$-values from the table data.
**
**   It is important to note that the $x$-values corresponds to
**   columns and the $y$-values to rows.  A program to read and
**   interpolate values in the table just shown might be:
**
**   {\footnotesize\tt\begin{verbatim}
**   int main()
**   {
**        AbcTable2D *table = NULL;
**        double y = 25.0;
**        double x;
**
**        if ((table = abc_create_2d_table_from_file()) == NULL) exit(1);
**        abc_print_2d_table(stdout, table, "", "     ");
**
**        for (x = 0.0; x < 4.0; x += 0.1)
**             printf("f(%g,%g)=%g\n", x, y, abc_value_2d_table(table, x, y));
**
**        abc_delete_2d_table(&table);
**   }
**    \end{verbatim}}
**
**   If this program is compiled and given the name {\tt prog},
**   and the table above is residing on the file {\tt data.xy}, then
**   the following command will make the program read the data
**   {\tt prog < data.xy}.
**
**   \chapter{Reference manual}
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_input.h>
#include <lib_table2d.h>

#ifdef ABC_RETURN_NULL
#undef ABC_RETURN_NULL
#endif

#define ABC_RETURN_NULL(in, text) {table_error(in, text); return NULL;}

#define RETURN_RANGE_ERROR(value, comp, lim) {\
     fprintf(stderr, "[table_2d_func] Out of range!, (%g%s%g) (%s)\n",\
     value, comp, lim, table->text);\
     return 0.5 * (table->min + table->max);\
}

/* Prototypes for local functions. */

static char *save_string(char const *word);
static double *save_double_array(int n, double *array);
static double **save_double_matrix(int nx, int ny, double **matrix);
static int binary_search(int n, double *xcoord, double x);
static void table_error(AbcInput *in, char const *text);
static int is_equally_spaced_array(double *vec, int nn);

int abc_test_table2d(
     int argc, 
     char **argv)
{
     static AbcInput in;
     AbcTable2D *table;
     double x0, y0, dx, dy, x, y;
     int i;

     if ((table = abc_create_2d_table_from_file(&in)) == NULL)
     {
          printf("Unable to read the table!\n");
          exit(1);
     }

     x0 = 0.5 * (table->xmin + table->xmax);
     y0 = 0.5 * (table->ymin + table->ymax);
     dx = (table->xmax - table->xmin) / 10;
     dy = (table->ymax - table->ymin) / 10;

     for (i = 1; i < argc; i++)
          if (strcmp(argv[i], "-x0") == 0) x0 = atof(argv[++i]);
          else if (strcmp(argv[i], "-y0") == 0) y0 = atof(argv[++i]);
          else {
               printf("Legal options are:\n");
               printf("  -x0 <numb> Set the x-argument.\n");
               printf("  -y0 <numb> Set the y-argument.\n");
               exit(1);
          }

     printf("The function values (x, %g) in \"%s\"\n", y0, table->text);

     for (x = table->xmin; x <= table->xmax; x += dx)
          printf("f(%g,%g)=%g\n", x, y0, abc_value_2d_table(table, x, y0));

     printf("The function values (%g, y) in \"%s\"\n", x0, table->text);

     for (y = table->ymin; y <= table->ymax ; y += dy)
          printf("f(%g,%g)=%g\n", x0, y, abc_value_2d_table(table, x0, y));

     abc_print_2d_table(stdout, table, "", "     ");
     abc_delete_2d_table(&table);
     return 0;
}


int abc_read_2d_table(
     AbcInput *in,             /* The input stream. */
     AbcTable2D **table,          /* A pointer to the table pointer. */
     char const *block_name)   /* The block name (added to begin_ and end_). */
/*
**   This function creates a table when the contents
**   of the table are given.
*/
{
     char begin_word[ABC_MAX_WORD], end_word[ABC_MAX_WORD];

     sprintf(begin_word, "begin_%s", block_name);
     sprintf(end_word, "end_%s", block_name);
     abc_put_back_word(in, begin_word);

     if (*table != NULL)
          abc_delete_2d_table(table);

     if ((*table = abc_create_2d_table_by_file(in, begin_word, end_word)) == NULL)
     {
          fprintf(stderr, "Can't read 2d table!\n");
          return FALSE;
     }

     return TRUE;
}


AbcTable2D *abc_create_2d_table(
     char const *name,     /* Table name. */
     int nx,               /* Number of coloms. */
     int ny,               /* Number of rows. */
     double *xvec,         /* Row access values. */
     double *yvec,         /* Column access values. */
     double **data)        /* Table data matrix. */
/*
**   This function creates a table when the contents
**   of the table are given.
*/
{
     double dx = 1.0e-10 * (xvec[nx-1] - xvec[0]);
     double dy = 1.0e-10 * (yvec[ny-1] - yvec[0]);
     AbcTable2D *table;
     int i, j;

     ABC_NEW_OBJECT(table, AbcTable2D);

     table->nx = nx;
     table->ny = ny;
     table->text = save_string(name);
     table->xvec = save_double_array(nx, xvec);
     table->yvec = save_double_array(ny, yvec);
     table->data = save_double_matrix(ny, nx, data);
     table->xmin = xvec[0] + dx;
     table->ymin = yvec[0] + dy;
     table->xmax = xvec[nx-1] - dx;
     table->ymax = yvec[ny-1] - dy;
     table->min = data[0][0];
     table->max = data[0][0];
     table->dx = (xvec[nx-1] - xvec[0]) / (nx - 1);
     table->dy = (yvec[ny-1] - yvec[0]) / (ny - 1);
     table->begin_key = save_string("begin_2d_table");
     table->end_key = save_string("end_2d_table");
     table->is_equally_x_spaced = is_equally_spaced_array(xvec, nx);
     table->is_equally_y_spaced = is_equally_spaced_array(yvec, ny);

     for (j = 0; j < ny; j++)
          for (i = 0; i < nx; i++)
          {
               if (data[j][i] < table->min) table->min = data[j][i];
               if (data[j][i] > table->max) table->max = data[j][i];
          }

     return table;
}


AbcTable2D *abc_create_2d_table_from_file(
     AbcInput *in)    /* The input stream. */
/*
**   This function reads the last file opened with {\tt begin\_input},
**   a {\tt lib\_input}-function, and creates a table that holds
**   the data read in.   In case no {\tt begin\_input} is called,
**   then standard input is read.  Note that {\tt end\_input}
**   closes a file opened by {\tt begin\_input}.  See the
**   introduction for the format needed for the tables to be
**   read in by this function.
*/
{
     return abc_create_2d_table_by_file(in, "begin_2d_table", "end_2d_table");
}


AbcTable2D *abc_create_2d_table_by_file(
     AbcInput *in,                /* The input stream. */
     char const *begin_key_word,  /* The key word to begin the table. */
     char const *end_key_word)    /* The key word to end the table. */
/*
**   This function is similar to the preceeding function except
**   that it offers the user the oppertunity to select the key
**   words that should enclose the table.
*/
{
     AbcTable2D *table;
     int i, j, nx, ny;
     char name[ABC_MAX_WORD], word[ABC_MAX_WORD];
     char begin_error[ABC_MAX_WORD], end_error[ABC_MAX_WORD];
     static int size = 0;
     static double *xvec = NULL;
     static double *yvec = NULL;
     static double **data = NULL;

     sprintf(begin_error, "Expected the key word \"%s\"!", begin_key_word);
     sprintf(end_error, "Expected the key word \"%s\"!", end_key_word);

     /* Read the table definition. */

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, begin_key_word))
          ABC_RETURN_NULL(in, begin_error);

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "rows"))
          ABC_RETURN_NULL(in, "Expected the key word \"rows\"!");

     if (not abc_get_int(in, &ny))
          ABC_RETURN_NULL(in, "Couldn't read the number of table rows!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "cols"))
          ABC_RETURN_NULL(in, "Expected the key word \"cols\"!");

     if (not abc_get_int(in, &nx))
          ABC_RETURN_NULL(in, "Couldn't read the number of table columns!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "name"))
          ABC_RETURN_NULL(in, "Expected the key word \"name\"!");

     if (not abc_get_string(in, name, ABC_MAX_WORD))
          ABC_RETURN_NULL(in, "Couldn't read the name of the table!");

     if (nx * ny > size)
     {
          if (xvec) ABC_FREE(xvec);
          ABC_NEW_ARRAY(xvec, double, nx);
          if (yvec) ABC_FREE(yvec);
          ABC_NEW_ARRAY(yvec, double, ny);
          if (data) ABC_FREE(data);
          ABC_NEW_MATRIX_2(data, double, ny, nx);
          size = nx * ny;
     }

     for (i = 0; i < nx; i++)
          if (not abc_get_double(in, &xvec[i]))
               ABC_RETURN_NULL(in, "Couldn't read column access data!");

     for (j = 0; j < ny; j++)
     {
          if (not abc_get_double(in, &yvec[j]))
               ABC_RETURN_NULL(in, "Couldn't read row access data!");

          if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, ":"))
               ABC_RETURN_NULL(in, "Expected the key word \":\"!");

          for (i = 0; i < nx; i++)
               if (not abc_get_double(in, &data[j][i]))
                    ABC_RETURN_NULL(in, "Couldn't read table data!");
     }

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, end_key_word))
          ABC_RETURN_NULL(in, end_error);

     table = abc_create_2d_table(name, nx, ny, xvec, yvec, data);

     ABC_FREE(table->begin_key);
     ABC_FREE(table->end_key);
     table->begin_key = save_string(begin_key_word);
     table->end_key = save_string(end_key_word);

     return table;
}


void abc_delete_2d_table(
     AbcTable2D **table)  /* Delete the table pointed to by *table. */
/*
**   This funciton deallocates all space hold by the table pointed
**   to by {\tt *table}, and {\tt *table} becomes a {\tt NULL}-pointer.
*/
{
     AbcTable2D *tab = *table;

     if (table == NULL) return;
     if ((tab = *table) == NULL) return;

     ABC_FREE(tab->text);
     ABC_FREE(tab->data);
     ABC_FREE(tab->xvec);
     ABC_FREE(tab->yvec);
     ABC_FREE(tab);

     *table = NULL;
}


double abc_value_2d_table(
     AbcTable2D *table,  /* The table. */
     double x,        /* Column value in the table. */
     double y)        /* Row value in the table. */
/*
**   This function returns the table value corresponding
**   to {\tt x} and {\tt y} in the table pointed to by {\tt table}.
**   In case the coordinate pair, {\tt x} and {\tt y}, is outside
**   the table, an error message is issued.  A table lookup is
**   fastest if the table lookup arrays are equally spaced,
**   otherwise binary search is applied.
*/
{
     double func_value = 0.0;
     int ok = TRUE;
     int i, j;

     if (table == NULL) ABC_ERROR_EXIT("[abc_value_2d_table_general] Null pointer!");

     if (x < table->xmin) RETURN_RANGE_ERROR(x, "<", table->xmin);
     if (x > table->xmax) RETURN_RANGE_ERROR(x, ">", table->xmax);
     if (y < table->ymin) RETURN_RANGE_ERROR(y, "<", table->ymin);
     if (y > table->ymax) RETURN_RANGE_ERROR(y, ">", table->ymax);

     if (table->is_equally_x_spaced)
          i = (int) ((x - table->xvec[0]) / table->dx);
     else
          ok = ((i = binary_search(table->nx, table->xvec, x)) >= 0);

     if (table->is_equally_y_spaced)
          j = (int) ((y - table->yvec[0]) / table->dy);
     else
          ok = ((j = binary_search(table->ny, table->yvec, y)) >= 0);

     if (not ok)
     {
          fprintf(stderr, "[abc_value_2d_table] Internal error!");
          func_value = 0.5 * (table->min + table->max);
     }
     else
     {
          double wx = (x - table->xvec[i]) / (table->xvec[i+1] - table->xvec[i]);
          double wy = (y - table->yvec[j]) / (table->yvec[j+1] - table->yvec[j]);

          double x1 = (1.0 - wx) * table->data[j][i] + wx * table->data[j][i+1];
          double x2 = (1.0 - wx) * table->data[j+1][i] + wx * table->data[j+1][i+1];

          func_value = (1.0 - wy) * x1 + wy * x2;
     }

     return func_value;
}


void abc_print_2d_table(
     FILE *out,        /* The output stream. */
     AbcTable2D *table,   /* The table to be printed. */
     char const *margin1,    /* Margin for table block exterior. */
     char const *margin2)    /* Margin for table block interior. */
/*
**   Print out the table in a format compatible with format expected
**   by the function {\tt create\_2d\_table\_from\_file}.
**   The two {\tt char} arguments {\tt margin1} and {\tt margin2}
**   controls the indentation in the printed table.
*/
{
     int i, j;

     if (table == NULL)
     {
          fprintf(stderr, "[abc_print_2d_table] Called with a NULL-pointer!\n");
          return;
     }

     fprintf(out, "%s%s\n", margin1, table->begin_key);
     fprintf(out, "%srows %d cols %d\n", margin2, table->ny, table->nx);
     fprintf(out, "%sname \"%s\"\n", margin2, table->text);
     fprintf(out, "%s #%s#\n", margin2, (table->is_equally_x_spaced) ?
          "is equally x-spaced" : "is not equally x-spaced");
     fprintf(out, "%s #%s#\n", margin2, (table->is_equally_y_spaced) ?
          "is equally y-spaced" : "is not equally y-spaced");

     fprintf(out, "%s%12s", margin2, "   ");
     for (i = 0; i < table->nx; i++)
          fprintf(out, "  %10.4e", table->xvec[i]);
     fprintf(out, "\n");

     fprintf(out, "%s%12s", margin2, " #");
     for (i = 0; i < table->nx; i++)
          fprintf(out, "  %s", "----------");
     fprintf(out, " #\n");

     for (j = 0; j < table->ny; j++)
     {
          fprintf(out, "%s", margin2);
          fprintf(out, "%10.4e :", table->yvec[j]);

          for (i = 0; i < table->nx; i++)
               fprintf(out, "  %10.4e", table->data[j][i]);

          fprintf(out, "\n");
     }

     fprintf(out, "%s%s\n", margin1, table->end_key);
}


static char *save_string(
     char const *word)
{
     char *p;

     ABC_NEW_ARRAY(p, char, strlen(word) + 1);
     strcpy(p, word);
     return p;
}


static double *save_double_array(
     int n,
     double *array)
{
     int i;
     double *p;

     ABC_NEW_ARRAY(p, double, n);

     for (i = 0; i < n; i++)
          p[i] = array[i];

     return p;
}


static double **save_double_matrix(
     int nx,
     int ny,
     double **matrix)
{
     int i, j;
     double **m;

     ABC_NEW_MATRIX_2(m, double, nx, ny);

     for (i = 0; i < nx; i++)
          for (j = 0; j < ny; j++)
               m[i][j] = matrix[i][j];

     return m;
}


static int binary_search(
     int n,
     double *xcoord,
     double x)
{
     int low, high, mid;

     low = 0;
     high = n - 1;

     while (low <= high)
     {
          mid = (low + high) / 2;

          if (x < xcoord[mid])
               high = mid - 1;
          else if (x > xcoord[mid])
               low = mid + 1;
          else
               return mid;

          if (xcoord[mid] <= x and x < xcoord[mid + 1])
               return mid;
     }

     return -1;
}


static void table_error(
     AbcInput *in,
     char const *text)
{
     fprintf(stderr, "Line: %d; %s\n", abc_get_input_line_number(in), text);
     abc_skip_rest_of_line(in);
}


static int is_equally_spaced_array(
     double *vec,
     int nn)
{
     double ds = (vec[nn-1] - vec[0]) / (nn - 1);
     double de = 1.0e-6 * ds;
     int i;

     for (i = 1; i < nn; i++)
          if (ABC_ABS(vec[i] - vec[0] - i * ds) > de)
               return FALSE;

     return TRUE;
}


