/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2011 by Magnus Wangen.
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
**
**   $Id$
*/

#ifndef _LIB_GEOHIST_H_
#define _LIB_GEOHIST_H_

#include <lib_input.h>

#define ABC_LAYER_UNDEFINED        0
#define ABC_LAYER_SEDIMENTATION    1
#define ABC_LAYER_EROSION          2
#define ABC_LAYER_PAUSE            3
#define ABC_LAYER_DT_MAX           4
#define ABC_LAYER_FORMATION_NAME   5

#define MAX_GEOHIST_LAYERS   1024
#define MAX_FORM_NAMES       1024
#define MAX_LITH_NAMES       1024
#define MAX_H_NODES         16384

#define ABC_BC_BASE_CLOSED      1
#define ABC_BC_BASE_1ST_KIND    2
#define ABC_BC_BASE_2ND_KIND    3

typedef struct _AbcLayer_           AbcLayer;
typedef struct _AbcXYBoundaryHist_  AbcXYBoundaryHist;
typedef struct _AbcGeohistory_      AbcGeohistory;

typedef void (*ABC_PRINT_LAYER)(FILE *out, AbcLayer *layer);
typedef int  (*ABC_GET_VLINE_FUNC)(AbcGeohistory *hist,
     int elem_or_node, double time, double *value);

struct _AbcXYBoundaryHist_ {
      char name[ABC_MAX_WORD];
      char short_name[ABC_MAX_WORD];
      int n_times;
      int current_index;
      double time[MAX_GEOHIST_LAYERS];
      double *array[MAX_GEOHIST_LAYERS];
};

struct _AbcLayer_ {
     double t1;
     double t2;
     double dt_max;
     double *thickness;
     int type;
     int form_no;
     int *lith_no;
     int rows;
     AbcGeohistory *hist;
     ABC_PRINT_LAYER print;
};

struct _AbcGeohistory_ {
     int n_dim;
     int n_layers;
     int n_x_nodes;
     int n_y_nodes;
     int n_h_nodes;
     int n_formations;
     int n_lithologies;
     int type_base_pres_BC;
     int type_base_temp_BC;

     AbcLayer *layer[MAX_GEOHIST_LAYERS];
     double *xcoord;
     double *ycoord;
     double *total_height;

     /* 
     ** NOTE: 
     ** formation_name[0] = "no-name"; 
     ** lithology_name[0] = "erosion"; 
     */

     char *formation_name[MAX_FORM_NAMES];
     char *lithology_name[MAX_LITH_NAMES];

     double time_begin_hist;
     double time_end_hist;

     /* Temporary working variables. */

     double current_t1;
     double current_t2;
     double current_dt_max;
     double *current_thickness;
     int *current_lith_no;
     int current_formation_no;
     int current_rows;

     AbcXYBoundaryHist water_depth;
     AbcXYBoundaryHist temp_surface;
     AbcXYBoundaryHist temp_base;
     AbcXYBoundaryHist heat_flux_base;
     AbcXYBoundaryHist pres_base;
     AbcXYBoundaryHist darcy_flux_base;
};

int abc_test_geohist(int argc, char **argv);
AbcGeohistory *abc_create_geohistory_from_bas_file(const char *filename);
AbcGeohistory *abc_read_bas_geohistory(AbcInput *in);
AbcGeohistory *abc_new_geohistory(void);
void abc_delete_geohistory(AbcGeohistory **pp);
void abc_add_layer_to_geohistory(AbcGeohistory *hist, int type, ABC_PRINT_LAYER func);
AbcLayer *abc_create_layer(int type, AbcGeohistory *hist, ABC_PRINT_LAYER func);
void abc_delete_layer(AbcLayer **pp);
void abc_print_geohistory(FILE *out, AbcGeohistory *hist);
const char *abc_get_geohistory_formation_name(AbcGeohistory *hist, int i);
const char *abc_get_geohistory_lithology_name(AbcGeohistory *hist, int i);
int abc_geohist_has_base_heat_flux(AbcGeohistory *hist);
int abc_geohist_has_base_pressure(AbcGeohistory *hist);
int abc_geohist_has_base_darcy_flux(AbcGeohistory *hist);
int abc_get_elems_in_geohistory(AbcGeohistory *hist);
int abc_get_nodes_in_geohistory(AbcGeohistory *hist);
int abc_get_x_nodes_in_geohistory(AbcGeohistory *hist);
int abc_get_y_nodes_in_geohistory(AbcGeohistory *hist);
int abc_get_z_nodes_in_geohistory(AbcGeohistory *hist);
int abc_get_h_nodes_in_geohistory(AbcGeohistory *hist);
int abc_get_x_elems_in_geohistory(AbcGeohistory *hist);
int abc_get_y_elems_in_geohistory(AbcGeohistory *hist);
int abc_get_z_elems_in_geohistory(AbcGeohistory *hist);
int abc_get_h_elems_in_geohistory(AbcGeohistory *hist);
int abc_get_rows_in_geohistory(AbcGeohistory *hist);
int abc_get_node_col_from_elem_col(AbcGeohistory *hist, int elem_col);
void abc_update_water_depth(AbcGeohistory *hist, double time, double *zcoord);
void abc_fill_in_geohistory_xcoords(AbcGeohistory *hist, double *xcoord);
void abc_fill_in_geohistory_ycoords(AbcGeohistory *hist, double *ycoord);
void abc_fill_in_geohistory_zcoords(AbcGeohistory *hist, double *zcoord);
void abc_fill_in_geohistory_lith_no(AbcGeohistory *hist, int *lith_no, int *form_no);
void abc_store_geohistory_names(AbcGeohistory *hist, FILE* out);
void abc_store_geohistory_names_II(AbcGeohistory *hist, AbcOutputStreamII *stream);
int abc_get_formation_number(AbcGeohistory *hist, const char *name);
int abc_get_lithology_number(AbcGeohistory *hist, const char *name);
int get_geohist_water_depth(AbcGeohistory *hist, int vline, double time, double *value);
int get_geohist_temp_surface(AbcGeohistory *hist, int vline, double time, double *value);
int get_geohist_temp_base(AbcGeohistory *hist, int vline, double time, double *value);
int get_geohist_heat_flux_base(AbcGeohistory *hist, int vline, double time, double *value);
int get_geohist_pres_base(AbcGeohistory *hist, int vline, double time, double *value);
int get_geohist_darcy_flux_base(AbcGeohistory *hist, int vline, double time, double *value);
int abc_get_xy_boundary_value(AbcGeohistory *hist, 
     AbcXYBoundaryHist *bp, int vline, double time, double *value);
void abc_print_geohistory_xy_lith_elem_no(FILE *out, AbcGeohistory *hist, int row_no, int *lith_no);
void abc_print_geohistory_xy_lith_node_no(FILE *out, AbcGeohistory *hist, int row_no, int *lith_no);
void abc_inspect_vline(AbcGeohistory *hist, int vline);

#endif

