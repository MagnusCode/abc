/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1995-1999 by M. Wangen.
**
**   Info: A library for spline tables
**   Date: Version 1.2, October 1992
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   References:
**   The spline coefficents are make according to section 7.1 in Cheny and Kincaid:
**   Numerical mathematics and computing, Brooks/Cole Publishing Compandy, 1980.
**   Notice: This type of slines are called natural spines.
*/

/*
** Example: A sin-function as a table.
** A library can be tested by writing out the interpolations 
** of the function, the 1st and the 2nd derivaties.
**
begin_table
     name=TestTab
      0.000e+00,  0.000e+00
      2.027e-01,  2.013e-01
      4.054e-01,  3.944e-01
      6.080e-01,  5.713e-01
      8.107e-01,  7.248e-01
      1.013e+00,  8.486e-01
      1.216e+00,  9.378e-01
      1.419e+00,  9.885e-01
      1.621e+00,  9.987e-01
      1.824e+00,  9.681e-01
      2.027e+00,  8.978e-01
      2.230e+00,  7.908e-01
      2.432e+00,  6.514e-01
      2.635e+00,  4.853e-01
      2.838e+00,  2.994e-01
      3.040e+00,  1.012e-01
      3.243e+00, -1.012e-01
      3.446e+00, -2.994e-01
      3.648e+00, -4.853e-01
      3.851e+00, -6.514e-01
      4.054e+00, -7.908e-01
      4.256e+00, -8.978e-01
      4.459e+00, -9.681e-01
      4.662e+00, -9.987e-01
      4.864e+00, -9.885e-01
      5.067e+00, -9.378e-01
      5.270e+00, -8.486e-01
      5.472e+00, -7.248e-01
      5.675e+00, -5.713e-01
      5.878e+00, -3.944e-01
      6.080e+00, -2.013e-01
      6.283e+00,  0.000e+00
end_table
**
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_input.h>
#include <lib_matrix.h>
#include <lib_utils.h>
#include <lib_table.h>

#ifdef RETURN_FALSE
#undef RETURN_FALSE
#endif

#ifdef RETURN_NULL
#undef RETURN_NULL
#endif

#define RETURN_NULL(in, text) {abc_read_error(in, text); return NULL;}
#define RETURN_FALSE(in, text) {abc_read_error(in, text); return FALSE;}

static void make_spline_coef(AbcTable *table);


static int
     run_silent = FALSE;         /* True if no warnings are wanted. */

static double
     x_buffer[ABC_MAX_TABLE_SIZE],          /* Buffer for x-coords. */
     y_buffer[ABC_MAX_TABLE_SIZE];          /* Buffer for y-coords. */


int abc_test_table_lib(
     int argc, 
     char **argv)
{
     static AbcInput in;
     AbcTable *table;

     if (not abc_begin_input(&in, ""))
          ABC_ERROR_EXIT("Can't read std-in!");

     table = abc_read_and_create_table(&in);

     if (table == NULL)
          RETURN_FALSE(&in, "Can't read table!");

     abc_dump_table_values_to_file(table, "xtable2.xy", 64);
     abc_write_table(stdout, "", "     ", table);
     
     abc_delete_table(&table);
     abc_end_input(&in);

     ABC_UNUSED_PARAMETER(argc);
     ABC_UNUSED_PARAMETER(argv);

     return 0;
}


AbcTable *abc_create_table(
     char const *name,
     int size,
     double *xcoord,
     double *ycoord)
{
     AbcTable *table;

     /* Create new table. */

     ABC_NEW_OBJECT(table, AbcTable);
     table->size = size;
     table->name = abc_save_string(name);
     table->x = abc_save_double_array(xcoord, size);
     table->y = abc_save_double_array(ycoord, size);
     table->y2 = abc_save_double_array(ycoord, size);
     table->is_equidist = abc_is_equally_spaced_array(xcoord, size);

     /* Make spline functions. */

     make_spline_coef(table);

     return table;
}


AbcTable *abc_read_and_create_table(
     AbcInput *in)
{
     int n;
     char name[ABC_MAX_WORD], word[ABC_MAX_WORD];
     AbcTable *table = NULL;;

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "begin_table"))
          RETURN_NULL(in, "Expected a \"begin_table\" key word!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "name"))
          RETURN_NULL(in, "Expected a \"name\" key word!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "="))
          RETURN_NULL(in, "Expected a \"name\" key word!");

     if (not abc_get_word(in, name, ABC_MAX_WORD))
          RETURN_NULL(in, "Couldn't read the name of the table!");

     for (n = 0; TRUE; n++)
     {
          if (n >= ABC_MAX_TABLE_SIZE)
               RETURN_NULL(in, "The table is too large!");

          if (not abc_get_word(in, word, ABC_MAX_WORD))
               RETURN_NULL(in, "Expected \"end_table\"!");

          abc_put_back_word(in, word);

          if (ABC_MATCH(word, "end_table"))
               break;

          if (not abc_get_double(in, &x_buffer[n]))
               RETURN_NULL(in, "Expected x-coordinate!");

          if (not abc_get_double(in, &y_buffer[n]))
               RETURN_NULL(in, "Expected y-coordinate!");

          if ((n > 0) and (x_buffer[n-1] > x_buffer[n]))
               RETURN_NULL(in, "x-values are not in increasing order!");
     }

     if (n < 2)
          RETURN_NULL(in, "The table needs at least 2 points!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "end_table"))
          RETURN_NULL(in, "Expected key word \"end_table\"!");

     table = abc_create_table(name, n, x_buffer, y_buffer);

     return table;
}


static void make_spline_coef(
     AbcTable *table)
{
     int i, n;
     double *b_buffer, **a_matrix;

     n = table->size;

     ABC_NEW_ARRAY(b_buffer, double, n);
     ABC_NEW_MATRIX_2(a_matrix, double, n, 3);

     /* 
     ** Make equation system for 2nd derivatives. 
     ** See section 7.1 in Cheny and Kincaid:
     ** Numerical mathematics and computing, Brooks/Cole Publishing Compandy, 1980.
     */

     for (i = 1; i < n - 1; i++)
     {
          if (i == 1)
               a_matrix[i-1][0] = 0.0;
          else
               a_matrix[i-1][0] = table->x[i] - table->x[i-1];

          if (i == n - 2)
               a_matrix[i-1][2] = 0.0;
          else
               a_matrix[i-1][2] = table->x[i] - table->x[i-1];

          a_matrix[i-1][1] = 2.0 * (table->x[i+1] - table->x[i-1]);

          b_buffer[i-1] = 6.0 *
              ((table->y[i+1] - table->y[i]) / (table->x[i+1] - table->x[i])
             - (table->y[i] - table->y[i-1]) / (table->x[i] - table->x[i-1]));
     }

     /* Solve for the 2nd derivatives. */

     abc_band_gauss_solver(a_matrix, b_buffer, x_buffer, n - 2, 1);

     /* Make spline coefficients. */

     table->y2[0] = 0.0;
     table->y2[n-1] = 0.0;

     for (i = 1; i < n - 1; i++)
          table->y2[i] = x_buffer[i-1];

     ABC_FREE(b_buffer);
     ABC_FREE_MATRIX_2(a_matrix);
}


void abc_delete_table(
     AbcTable **pp)
{
     AbcTable *table = NULL;

     if (pp == NULL) return;
     table = *pp;
     if (table == NULL) return;

     ABC_FREE(table->x);
     ABC_FREE(table->y);
     ABC_FREE(table->y2);
     ABC_FREE(table->name);
     ABC_FREE(table);

     *pp = NULL;
}


double abc_get_table_linear_interpolate(
     AbcTable *table,
     double x)
{
     int n;
     double x0, x1, f0, f1, fx, w1;

     if ((n = abc_binary_search(x, table->x, table->size)) < 0)
          return abc_get_table_boundary(table, x);

     if (n >= table->size - 1)
          return table->y[table->size - 1];

     x0 = table->x[n];
     x1 = table->x[n+1];
     f0 = table->y[n];
     f1 = table->y[n+1];

     w1 = (x - x0) / (x1 - x0);
     fx = (1.0 - w1) * f0 + w1 *f1;

     return fx;
}


double abc_get_table_func(
     AbcTable *table,
     double x)
{
     int n;
     double h, x0, x1, y20, y21, f0, f1, a1, a2, a3, a4;

     if ((n = abc_binary_search(x, table->x, table->size)) < 0)
          return abc_get_table_boundary(table, x);

     if (n >= table->size - 1)
          return table->y[table->size - 1];

     x0 = table->x[n];
     x1 = table->x[n+1];
     f0 = table->y[n];
     f1 = table->y[n+1];
     y20 = table->y2[n];
     y21 = table->y2[n+1];

     h = x1 - x0;
     a1 = y20 / (6.0 * h);
     a2 = y21 / (6.0 * h);
     a3 = f1 / h - y21 * h / 6.0;
     a4 = f0 / h - y20 * h / 6.0;

     return (a1 * ABC_CUB(x1 - x) + a2 * ABC_CUB(x - x0) + a3 * (x - x0) + a4 * (x1 - x));
}


double abc_get_d_table_func(
     AbcTable *table,
     double x)
{
     int n;
     double h, x0, x1, y20, y21, f0, f1, a1, a2, a3;

     if ((n = abc_binary_search(x, table->x, table->size)) < 0)
          return abc_get_table_boundary(table, x);

     x0 = table->x[n];
     x1 = table->x[n+1];
     f0 = table->y[n];
     f1 = table->y[n+1];
     y20 = table->y2[n];
     y21 = table->y2[n+1];

     h = x1 - x0;
     a1 = - y20 / (2.0 * h);
     a2 = y21 / (2.0 * h);
     a3 = (f1 - f0) / h - h * (y21 - y20) / 6.0;

     return (a1 * ABC_SQR(x1 - x) + a2 * ABC_SQR(x - x0) + a3);
}


double abc_get_dd_table_func(
     AbcTable *table,
     double x)
{
     int n;
     double h, x0, x1, y20, y21, a1, a2;

     if ((n = abc_binary_search(x, table->x, table->size)) < 0)
          return abc_get_table_boundary(table, x);

     x0 = table->x[n];
     x1 = table->x[n+1];
     y20 = table->y2[n];
     y21 = table->y2[n+1];

     h = x1 - x0;
     a1 = y20 / h;
     a2 = y21 / h;

     return (a1 * (x1 - x) + a2 * (x - x0));
}


int abc_binary_search(
     double x,
     double *xcoord,
     int n)
{
     int low, high, mid;

     low = 0;
     high = n - 1;

     while (low <= high)
     {
          mid = (low + high) / 2;

          if (x < xcoord[mid])
               high = mid - 1;
          else if (x > xcoord[mid])
               low = mid + 1;
          else
               return mid;

          if (xcoord[mid + 1] > x and x > xcoord[mid])
               return mid;
     }

     return -1;
}


double abc_get_table_xmin(
     AbcTable *table)
{
     return table->x[0];
}


double abc_get_table_xmax(
     AbcTable *table)
{
     return table->x[table->size - 1];
}


double abc_get_table_ymin(
     AbcTable *table)
{
     return table->y[0];
}


double abc_get_table_ymax(
     AbcTable *table)
{
     return table->y[table->size - 1];
}


double abc_get_table_boundary(
     AbcTable *table,
     double x)
{
     static int counter = 0;
     static int max_counter = 100;

     double xmin = abc_get_table_xmin(table);
     double xmax = abc_get_table_xmax(table);
     double ymin = abc_get_table_ymin(table);
     double ymax = abc_get_table_ymax(table);
     double xcenter = 0.5 * (xmin + xmax);

     if (not run_silent and counter < max_counter)
     {
          fprintf(stderr, "Table: %s; ", table->name);
          fprintf(stderr, "Look up key is outside table boundary!\n");
          fprintf(stderr, "The key = %-10.3e is not between ", x);
          fprintf(stderr, "%-10.3e and %-10.3e.\n", xmin, xmax);
     }

     if (not run_silent and counter == max_counter)
     {
          fprintf(stderr, "Too many messages from table lib!\n");
          fprintf(stderr, "(more than %d messages are given)\n", max_counter);
          fprintf(stderr, "This is the last message!\n");
     }

     counter++;

     return ((x < xcenter) ? ymin : ymax);
}


void abc_write_only_table_values(
     FILE *out,
     AbcTable *table)
{
     int i;

     for (i = 0; i < table->size; i++)
          fprintf(out, "%10.3e %10.3e\n", table->x[i], table->y[i]);
}


void abc_write_table(
     FILE *out,
     char const *margin1,
     char const *margin2,
     AbcTable *table)
{
     int i;

     fprintf(out, "%sbegin_table\n", margin1);
     fprintf(out, "%sname=%s\n", margin2, table->name);

     for (i = 0; i < table->size; i++)
          fprintf(out, "%s%10.3e %10.3e\n", margin2, table->x[i], table->y[i]);

     fprintf(out, "%send_table\n", margin1);
}


void abc_dump_table_values_to_file(
     AbcTable *table,
     const char *filename,
     int size)
{
     FILE *out = abc_new_file(filename, "");
     abc_dump_table_values(table, out, size);
     fclose(out);
}


void abc_dump_table_values( 
     AbcTable *table,
     FILE *out,
     int out_size)
{    
     double x0 = abc_get_table_xmin(table);
     double x1 = abc_get_table_xmax(table);
     double dx = (x1 - x0) / (out_size - 1);
     int i; 

     fprintf(out, "#(\n");
     fprintf(out, "%12s %12s %12s %12s\n", 
          "xcoord:0", "table:1", "dtable:2", "ddtable:3");
     fprintf(out, ")#\n");
     
     for (i = 0; i < out_size; i++)
     {    
          double x = i * dx + x0;
          
          fprintf(out, "%12.5e %12.5e %12.5e %12.5e\n", x,
               abc_get_table_func(table, x),  
               abc_get_d_table_func(table, x),  
               abc_get_dd_table_func(table, x));
     }
}

