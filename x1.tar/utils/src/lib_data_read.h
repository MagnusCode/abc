/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1994-2011 by Magnus Wangen.
**
**   Info: Functions for reading results.
**   Date: Version 2.0, June 2011
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_DATA_READ_H_
#define _LIB_DATA_READ_H_

#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_input.h>
#include "lib_data_write.h"

#define ABC_RW_TYPE_INT     1
#define ABC_RW_TYPE_DOUBLE  2
#define ABC_RW_TYPE_STRING  3

#define ABC_RW_VAR_NAME    64
#define ABC_MAX_RW_VARS  1024

typedef struct {
     FILE *in;
     int max_word;
     int endian_type;
     char filename[ABC_MAX_WORD];
} AbcInputStreamII;

typedef struct {
     int grid_type;
     int n_elems;
     int n_nodes;
     int n_x_elems;
     int n_y_elems;
     int n_z_elems;
     int n_x_nodes;
     int n_y_nodes;
     int n_z_nodes;
     int n_local_nodes;
} AbcFileFemInfo;

typedef struct {
     char name[ABC_RW_VAR_NAME];
     int type;
     int size;
     int max_word;
     int index;
     double min;
     double max;
     void *array;
     char filename[ABC_MAX_WORD];
     AbcFileFemInfo fem_info;
} AbcFileVar;

typedef struct {
     int n_vars;
     AbcFileVar var[ABC_MAX_RW_VARS];
     int is_debugging;
     int is_silent;
} AbcFileContents;

/* Testing */

int abc_rw_main_contents(int argc, char **argv);
int abc_rw_main_test1(int argc, char **argv);
int abc_rw_main_test2(int argc, char **argv);
void abc_rw_print_var(AbcFileVar *var);

/* File contents. */

void abc_rw_set_debugging_on_off(AbcFileContents *cont, int on_off);
void abc_rw_init_file_contents(AbcFileContents *cont);
void abc_rw_init_var(AbcFileVar *var, int size, int type, 
     const char *varname, const char *filename);
void abc_rw_init_fem_info(AbcFileFemInfo *fem_info);
void abc_rw_delete_file_contents(AbcFileContents *cont);
void abc_rw_read_file_contents_or_exit(AbcFileContents *cont, 
     const char *filename, int i1, const char *prename);
int abc_rw_read_file_contents(AbcFileContents *cont, 
     const char *filename, int i1, const char *prename);
int abc_rw_get_number_of_vars(AbcFileContents *cont);
AbcFileVar *abc_rw_get_var_by_index(AbcFileContents *cont, int i);
AbcFileVar *abc_rw_get_var_by_name(AbcFileContents *cont, const char *name);

/* One file variable. */

void abc_rw_allocate_one_int(AbcFileVar *var, int value, 
     const char *varname, const char *filename);
void abc_rw_allocate_ints(AbcFileVar *var, int size, 
     const char *varname, const char *filename);
void abc_rw_allocate_one_double(AbcFileVar *var, double value, 
     const char *varname, const char *filename);
void abc_rw_allocate_doubles(AbcFileVar *var, int size, 
     const char *varname, const char *filename);
void abc_rw_allocate_strings(AbcFileVar *var, int size, 
     const char *varname, const char *filename);
void abc_rw_reallocate_var(AbcFileVar *var, int size, int type, 
     const char *varname, const char *filename);
int abc_rw_get_next_free_pos(AbcFileContents *cont);
void abc_rw_list_contents(AbcFileContents *cont);
int abc_rw_get_max_array_size_in_bytes(AbcFileContents *cont);
int abc_rw_get_total_storage_size_in_bytes(AbcFileContents *cont);
void abc_rw_find_storage_size_in_bytes(AbcFileContents *cont, 
     int *total_size, int *max_array_size);
int abc_rw_is_used_var(AbcFileVar *var);
const char *abc_rw_get_var_name(AbcFileVar *var);
const char *abc_rw_get_var_filename(AbcFileVar *var);
int abc_rw_get_var_size(AbcFileVar *var);
int abc_rw_get_var_type(AbcFileVar *var);
const char *abc_rw_get_var_type_name(AbcFileVar *var);
int *abc_rw_get_int_array(AbcFileVar *var);
double *abc_rw_get_double_array(AbcFileVar *var);
char *abc_rw_get_char_array(AbcFileVar *var);
int abc_rw_get_int_by_name(AbcFileContents *cont, 
     const char *name, int i, int *numb);
int abc_rw_get_double_by_name(AbcFileContents *cont, 
     const char *name, int i, double *numb);
int *abc_rw_get_int_array_by_name(AbcFileContents *cont,
     const char *name, int *size);
double *abc_rw_get_double_array_by_name(AbcFileContents *cont,
     const char *name, int *size);
char *abc_rw_get_string_array_by_name(AbcFileContents *cont,
     const char *name, int *size, int *word_size);
int abc_rw_get_int(AbcFileVar *var, int i);
double abc_rw_get_double(AbcFileVar *var, int i);
const char *abc_rw_get_string(AbcFileVar *var, int i);
void abc_rw_find_min_and_max_var(AbcFileVar *var);
double abc_rw_get_min_var(AbcFileVar *var);
double abc_rw_get_max_var(AbcFileVar *var);
double abc_rw_get_var_value(AbcFileVar *var, int i);
void abc_rw_rename_var(AbcFileVar *var, const char *new_name);
void abc_rw_update_fem_info(AbcFileVar *var, AbcFileFemInfo *fem_info);
void abc_rw_print_fem_info(AbcFileVar *var, FILE *out);
void abc_rw_copy_fem_info(AbcFileFemInfo *fem1, AbcFileFemInfo *fem2);
const char *abc_rw_get_name_of_type(int type);
int abc_rw_get_var_type_from_name(const char *typename);

/* New ascii-file format. */

int abc_rw_add_ascii_file_contents(AbcFileContents *cont, const char *filename);
int abc_rw_read_ascii_file_contents(AbcFileContents *cont, 
     const char *filename, int first_index, const char *pre_name);

/* New binary-file format. */

int abc_rw_add_binary_file_contents(AbcFileContents *cont, const char *filename);
int abc_rw_read_binary_file_contents(AbcFileContents *cont,
     const char *filename, int first_index, const char *pre_name);
int abc_rw_open_input_sII(AbcInputStreamII *stream, const char *filename);
int abc_rw_close_input_sII(AbcInputStreamII *stream);

/* Column file-format. */

int abc_rw_read_columns_file_contents(AbcFileContents *cont, 
     const char *filename, int first_index, const char *prename);

/* Column old-ascii format. */

int abc_rw_read_old_serie_file_contents(AbcFileContents *cont, 
     const char *filename, int first_index, const char *prename);
int read_int_serie(AbcInput *in, AbcFileVar *var);
int read_double_serie(AbcInput *in, AbcFileVar *var);
int read_string_serie(AbcInput *in, AbcFileVar *vars, int max_word);

/* Reading one var from console. */

void abc_rw_read_data_one_var(AbcFileContents *cont, AbcInput *in, int index, int size);
void abc_rw_read_data_one_string_var(AbcFileContents *cont, AbcInput *in, 
     int index, int max_array, int max_word);

#endif

