/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1998-2001 by M. Wangen.
**
**   Info: Functions processing spreadsheets
**   Date: Version 1.0, November 1998
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

#ifndef _LIB_SPREADSHEET_H_
#define _LIB_SPREADSHEET_H_

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "lib_macros.h"
#include "lib_input.h"
#include "lib_spreadsheet.h"

#define ABC_MAX_SPREADSHEET_COLS  64
#define ABC_MAX_SPREADSHEET_ROWS 256
#define ABC_MAX_SPREADSHEET_WORD 128

typedef struct AbcSpreadsheet {
     int cols;
     int rows;
     char field[ABC_MAX_SPREADSHEET_ROWS][ABC_MAX_SPREADSHEET_COLS][ABC_MAX_SPREADSHEET_WORD];
     char file_name[ABC_MAX_WORD];
} AbcSpreadsheet;

void abc_set_spreadsheet_verbose_mode(int on_off);
int abc_read_spreadsheet_from_file(const char *filename, AbcSpreadsheet *spreadsheet);
void abc_read_spreadsheet(AbcInput *in, AbcSpreadsheet *spreadsheet);
int abc_get_spreadsheet_cols(AbcSpreadsheet *spreadsheet);
int abc_get_spreadsheet_rows(AbcSpreadsheet *spreadsheet);
void abc_init_spreadsheet(AbcSpreadsheet *spreadsheet);
void abc_print_spreadsheet(FILE *out, AbcSpreadsheet *spreadsheet);
void abc_print_spreadsheet_col_by_name(FILE *out, AbcSpreadsheet *spreadsheet, const char *name);
int abc_get_spreadsheet_col_by_name(AbcSpreadsheet *spreadsheet, const char *name);
void abc_set_spreadsheet_field_by_row_col(AbcSpreadsheet *spreadsheet, int row, int col, const char *field);
const char *abc_get_spreadsheet_field_by_name(AbcSpreadsheet *spreadsheet, const char *name, int row);
const char *abc_get_spreadsheet_field_by_row_col(AbcSpreadsheet *spreadsheet, int row, int col);
int abc_get_spreadsheet_number_by_row_col(AbcSpreadsheet *spreadsheet, int row, int col, double *number);
int abc_add_spreadsheet_column(AbcSpreadsheet *spreadsheet);
int abc_add_spreadsheet_row(AbcSpreadsheet *spreadsheet);

#endif

