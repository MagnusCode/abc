/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 1994-2011 by Magnus Wangen.
**
**   Info: Functions for storing results.
**   Date: Version 2.0, June 2011
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   History:
**   Version: 1.00 May 1994: First version based xdr.
**   Version: 2.00 Jun 2001: Always little-endian instead of xdr.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_data_write.h>

#define ABC_TYPE_INT     1
#define ABC_TYPE_DOUBLE  2
#define ABC_TYPE_CHAR    3

#define IS_LITTLE_ENDIAN
#define ERROR_EXIT(text) {fprintf(stderr, "Error: %s\n", text); exit(1);}
#define RETURN_FALSE(text) {fprintf(stderr, "Error: %s\n", text); return FALSE;}

static int begin_writing_ascii(AbcOutputStreamII *stream, char const *filename);
static int end_writing_ascii(AbcOutputStreamII *stream);
static int write_strings_ascii(AbcOutputStreamII *stream, char const *name, char *array, int size, int max_word);
static int write_doubles_ascii(AbcOutputStreamII *stream, char const *name, double *array, int size);
static int write_ints_ascii(AbcOutputStreamII *stream, char const *name, int *array, int size);

static int begin_writing_binary(AbcOutputStreamII *stream, char const *filename);
static int end_writing_binary(AbcOutputStreamII *stream);
static int write_ints_binary(AbcOutputStreamII *stream, char const *name, int *array, int size);
static int write_doubles_binary(AbcOutputStreamII *stream, char const *name, double *array, int size);
static int write_strings_binary(AbcOutputStreamII *stream, char const *name, char *array, int size, int max_word);
static void put_int(AbcOutputStreamII *stream, int numb);
static void put_double(AbcOutputStreamII *stream, double numb);
static void put_char(AbcOutputStreamII *stream, const char *text, int max_word);
static void put_ordered_bytes(AbcOutputStreamII *stream, char *bytes, int size);

static int read_time_interval(AbcInput *in, double *from, double *to, double *step);


#define MAX_INT_ARRAY 64
#define MAX_DOUBLE_ARRAY 64
#define MAX_WORD 32
#define MAX_STRINGS 16
#define MAX_CHAR_ARRAY (MAX_STRINGS * MAX_WORD)

/*****
int main(int argc, char **argv);

int main(int argc, char **argv)
{
     return abc_test_results2(argc, argv);
}
*****/


int abc_write_test_II(
     int argc,
     char **argv)
{
     const char *format = "binary";
     const char *filename = "xres.xy";
     AbcOutputStreamII stream;
     int int_array[MAX_INT_ARRAY];
     double double_array[MAX_DOUBLE_ARRAY];
     char char_array[MAX_CHAR_ARRAY];
     int i;

     if (argc > 1) filename = argv[1];
     if (argc > 2) format = argv[2];

     /* 1) Fill some arrays with data. */

     for (i = 0; i < MAX_INT_ARRAY; i++) 
          int_array[i] = i;

     for (i = 0; i < MAX_DOUBLE_ARRAY; i++) 
          double_array[i] = (double) i;

     for (i = 0; i < MAX_STRINGS; i++)
          sprintf(&char_array[i * MAX_WORD], "string=%d", i);

     /* 2) Store the arrays. */

     if (ABC_MATCH(format, "binary"))
          abc_init_binary_stream(&stream);
     else if (ABC_MATCH(format, "ascii"))
          abc_init_ascii_stream(&stream);
     else
          ABC_ERROR_EXIT("Usage: xres [filename] [format]");

     abc_write_begin_II(&stream, filename);
     abc_write_ints_II(&stream, "some_ints", int_array, MAX_INT_ARRAY);
     abc_write_doubles_II(&stream, "some_doubles", double_array, MAX_DOUBLE_ARRAY);
     abc_write_strings_II(&stream, "some_strings", char_array, MAX_STRINGS, MAX_WORD);
     abc_write_end_II(&stream);

     return TRUE;
}


int abc_write_test_strings_II(
     int argc,
     char **argv)
{
     AbcOutputStreamII stream;
     char char_array[1024];
     int size1 = 8;
     int size2 = 8;
     int max_word1 = 4;
     int max_word2 = 32;
     int i;

     /* 1) Open the stream. */

     abc_init_binary_stream(&stream);
     abc_write_begin_II(&stream, "xres.b2");

     /* 2) Write short string array. */

     for (i = 0; i < size1; i++)
          sprintf(&char_array[i * max_word1], "s=%d", (i + 1));

     abc_write_strings_II(&stream, "short_strings", char_array, size1, max_word1);

     /* 3) Write long string array. */

     for (i = 0; i < size1; i++)
          sprintf(&char_array[i * max_word2], "long-string=%d", (i + 1));

     abc_write_strings_II(&stream, "long_strings", char_array, size2, max_word2);

     /* 4) Close stream. */

     abc_write_end_II(&stream);

     ABC_UNUSED_PARAMETER(argc);
     ABC_UNUSED_PARAMETER(argv);

     return 0;
}


void abc_write_param_as_string_II(
     AbcOutputStreamII *stream,
     const char *name,
     const char *fmt,
     double param)
{
     int max_word = 32;
     char string[ABC_MAX_WORD];

     if (fmt == NULL) fmt = "%g";
     sprintf(string, fmt, param);
     abc_write_strings_II(stream, name, string, 1, max_word);
}

/*
**   ============================
**   PART I: ASCII storage format
**   ============================
*/

void abc_init_ascii_stream(
     AbcOutputStreamII *stream)
{
     stream->out = NULL;
     stream->write_begin = begin_writing_ascii;
     stream->write_end = end_writing_ascii;
     stream->write_ints = write_ints_ascii;
     stream->write_strings = write_strings_ascii;
     stream->write_doubles = write_doubles_ascii;
     stream->counter = 0;
     stream->endian_type = ABC_UNDEFINED_ENDIAN;
     strcpy(stream->filename, "");
}


static int begin_writing_ascii(
     AbcOutputStreamII *stream,
     char const *filename)
{
     stream->out = fopen(filename, "w");

     if (stream->out == NULL)
     {
          fprintf(stderr, "Can't open file: %s!\n", filename);
          return FALSE;
     }

     strcpy(stream->filename, filename);
     fprintf(stream->out, "begin_results2\n");

     return TRUE;
}


static int end_writing_ascii(
     AbcOutputStreamII *stream)
{
     fprintf(stream->out, "end_results2\n");
     fclose(stream->out);
     printf("(%d arrays are written to ascii file %s)\n", 
          stream->counter, stream->filename);

     return TRUE;
}


static int write_ints_ascii(
     AbcOutputStreamII *stream,
     char const *name,
     int *array,
     int size)
{
     int i;
     FILE *out = stream->out;

     if (out == NULL) return FALSE;
     fprintf(out, "\n");
     fprintf(out, "int %s %d", name, size);

     for (i = 0; i < size; i++)
     {
          if (i == 0 or i % 6 == 0) fprintf(out, "\n");
          fprintf(out, " %11d", array[i]);
     }

     fprintf(out, "\n");
     stream->counter++;

     return TRUE;
}


static int write_doubles_ascii(
     AbcOutputStreamII *stream,
     char const *name,
     double *array,
     int size)
{
     int i;
     FILE *out = stream->out;

     if (out == NULL) return FALSE;
     fprintf(out, "\n");
     fprintf(out, "double %s %d", name, size);

     if (array == NULL)
     {
          for (i = 0; i < size; i++)
          {
               if (i == 0 or i % 10 == 0) fprintf(out, "\n");
               fprintf(out, "  0.0");
          }
     }
     else
     {
          for (i = 0; i < size; i++)
          {
               if (i == 0 or i % 3 == 0) fprintf(out, "\n");
               fprintf(out, "  %21.14le", array[i]);
          }
     }

     fprintf(out, "\n");
     stream->counter++;

     return TRUE;
}


static int write_strings_ascii(
     AbcOutputStreamII *stream,
     char const *name,
     char *array,
     int size,
     int max_word)
{
     FILE *out = stream->out;
     int i;

     if (out == NULL) return FALSE;

     write_ints_ascii(stream, "max_word", &max_word, 1);

     fprintf(out, "\n");
     fprintf(out, "strings %s %d\n", name, size);

     for (i = 0; i < size; i++)
          fprintf(out, "\"%s\"\n", &array[i * max_word]);

     fprintf(out, "\n");
     stream->counter++;

     return TRUE;
}

/*
**   ==============================
**   PART II: Binary storage format
**   ==============================
*/

void abc_init_binary_stream(
     AbcOutputStreamII *stream)
{
     stream->out = NULL;
     stream->write_begin = begin_writing_binary;
     stream->write_end = end_writing_binary;
     stream->write_ints = write_ints_binary;
     stream->write_strings = write_strings_binary;
     stream->write_doubles = write_doubles_binary;
     stream->counter = 0;
     stream->endian_type = abc_get_endianess();
     strcpy(stream->filename, "");
}


static int begin_writing_binary(
     AbcOutputStreamII *stream,
     char const *filename)
{
     if (not abc_is_ok_binary_sizes())
          return FALSE;

     stream->out = fopen(filename, "w");

     if (stream->out == NULL)
     {
          fprintf(stderr, "Can't open file: %s!\n", filename);
          return FALSE;
     }

     strcpy(stream->filename, filename);
     put_char(stream, ABC_STREAM_II_CODE, ABC_STREAM_II_CODE_MAX_WORD);

     return TRUE;
}


static int end_writing_binary(
     AbcOutputStreamII *stream)
{
     fclose(stream->out);
     printf("(%d arrays are written to binary file: %s) (%s)\n",
          stream->counter, stream->filename, 
          abc_get_endianess_name(stream->endian_type));

     return TRUE;
}


static int write_ints_binary(
     AbcOutputStreamII *stream,
     char const *name,
     int *array,
     int size)
{
     int i;
     FILE *out = stream->out;

     if (out == NULL) return FALSE;

     put_int(stream, ABC_TYPE_INT);
     put_char(stream, name, ABC_STREAM_II_MAX_NAME);
     put_int(stream, size);

     for (i = 0; i < size; i++)
          put_int(stream, array[i]);

     stream->counter++;

     return TRUE;
}


static int write_doubles_binary(
     AbcOutputStreamII *stream,
     char const *name,
     double *array,
     int size)
{
     int i;
     FILE *out = stream->out;

     if (out == NULL) return FALSE;

     put_int(stream, ABC_TYPE_DOUBLE);
     put_char(stream, name, ABC_STREAM_II_MAX_NAME);
     put_int(stream, size);

     for (i = 0; i < size; i++)
          put_double(stream, array[i]);

     stream->counter++;

     return TRUE;
}


static int write_strings_binary(
     AbcOutputStreamII *stream,
     char const *name,
     char *array,
     int size,
     int max_word)
{
     int i;
     FILE *out = stream->out;

     if (out == NULL) return FALSE;

     write_ints_binary(stream, "max_word", &max_word, 1);

     put_int(stream, ABC_TYPE_CHAR);
     put_char(stream, name, ABC_STREAM_II_MAX_NAME);
     put_int(stream, size);

     for (i = 0; i < size; i++)
           put_char(stream, &array[i * max_word], max_word);

     stream->counter++;

     return TRUE;
}


static void put_int(
     AbcOutputStreamII *stream,
     int numb)
{
     char *bytes4 = (char *) &numb;
     put_ordered_bytes(stream, bytes4, 4);
}


static void put_double(
     AbcOutputStreamII *stream,
     double numb)
{
     char *bytes8 = (char *) &numb;
     put_ordered_bytes(stream, bytes8, 8);
}


static void put_char(
     AbcOutputStreamII *stream,
     const char *text, 
     int max_word)
{
     int i;
     int size = strlen(text);
     int length = ABC_MIN(size, max_word);
     FILE *out = stream->out;

     for (i = 0; i < length + 1; i++)
          putc(text[i], out);

     for (i = length + 1; i < max_word; i++)
          putc(' ', out);
}


static void put_ordered_bytes(
     AbcOutputStreamII *stream,
     char *bytes,
     int size)
{
     int i;
     FILE *out = stream->out;

     if (stream->endian_type == ABC_LITTLE_ENDIAN)
          for (i = size - 1; i >= 0; i--)
               putc(bytes[i], out);
     else
          for (i = 0; i < size; i--)
               putc(bytes[i], out);
}


int abc_is_ok_binary_sizes(
    void)
{
     if (sizeof(int) != 4)
          RETURN_FALSE("sizeof(int) != 4");

     if (sizeof(char) != 1)
          RETURN_FALSE("sizeof(char) != 1");

     if (sizeof(float) != 4)
          RETURN_FALSE("sizeof(float) != 4");

     if (sizeof(double) != 8)
          RETURN_FALSE("sizeof(double) != 8");

     return TRUE;
}


int abc_get_endianess(
     void)
{
    /*
    ** Endianess is the same as byte order. 
    ** A big-endian machine stores the most-significant byte first.
    ** A little-endian machine stores the least-significant byte first. 
    */

    unsigned int tmp = 1;
    char *test = (char*) &tmp;

    if (test[0] == 1) 
         return ABC_LITTLE_ENDIAN;

    return ABC_BIG_ENDIAN;
}


const char *abc_get_endianess_name(
     int type)
{
     switch (type)
     {
          case ABC_UNDEFINED_ENDIAN:   return "undefined endian";
          case ABC_LITTLE_ENDIAN:      return "little endian";
          case ABC_BIG_ENDIAN:         return "big endian";
     }

     return "undefined endien type";
}

/*
**   ===============================
**   PART III: Making output actions
**   ===============================
*/

#ifdef RETURN_FALSE
#undef RETURN_FALSE
#endif

#define RETURN_FALSE(in, text) {\
     abc_input_error(in, text);\
     return FALSE;\
}


int abc_read_output_times(
     AbcInput *in,
     AbcActionList *list,
     int type,
     char const *begin_key_word,
     char const *end_key_word)
{
     double time, from, to, step;
     char word[ABC_MAX_WORD], error_message[ABC_MAX_WORD];

     strcpy(word, "");
     sprintf(error_message, "Expected the key word \"%s\"!", end_key_word);

     while (abc_get_word(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, begin_key_word))
          ;

     while (abc_get_field(in, word, ABC_MAX_WORD) and not ABC_MATCH(word, end_key_word))
     {
          if (ABC_MATCH(word, "from"))
          {
               if (not read_time_interval(in, &from, &to, &step))
                    RETURN_FALSE(in, "Can't read time interval!");

               for (time = from; time < (to + 0.001 * step); time += step)
                    abc_add_defined_action(list, type, time, NULL, NULL);
          }
          else
          {
               abc_put_back_word(in, word);

               if (abc_get_double(in, &time))
                    abc_add_defined_action(list, type, time, NULL, NULL);
               else
                    RETURN_FALSE(in, "Can't read output time!");
          }
     }

     if (not ABC_MATCH(word, end_key_word))
          RETURN_FALSE(in, error_message);

     return TRUE;
}


static int read_time_interval(
     AbcInput *in,
     double *from,
     double *to,
     double *step)
{
     int no;
     char word[ABC_MAX_WORD];

     /* Default is no interval at all, from > to. */

     *from = 1;
     *to = 0;
     *step = 1;

     if (not abc_get_double(in, from))
          RETURN_FALSE(in, "Can't read time from!");

     if (not abc_get_word(in, word, ABC_MAX_WORD) or not ABC_MATCH(word, "to"))
          RETURN_FALSE(in, "Expected the key word \"to\"!");

     if (not abc_get_double(in, to))
          RETURN_FALSE(in, "Can't read time to!");

     if (not abc_get_word(in, word, ABC_MAX_WORD))
          RETURN_FALSE(in, "Expected the key word \"step\" or \"steps\"!");

     if (ABC_MATCH(word, "step"))
     {
          if (not abc_get_double(in, step))
               RETURN_FALSE(in, "Can't read time step!");

          return TRUE;
     }
     else if (ABC_MATCH(word, "steps"))
     {
          if (not abc_get_int(in, &no))
               RETURN_FALSE(in, "Can't read number of time steps!");

          if (no < 1)
               RETURN_FALSE(in, "Number of time steps is less than 1!");

          *step = (*to - *from) / no;
          return TRUE;
     }
     else 
          RETURN_FALSE(in, "Expected the key word \"step\" or \"steps\"!");

     return FALSE;
}

