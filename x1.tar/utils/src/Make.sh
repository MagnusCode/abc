#!/bin/bash

if (( $# > 0 )); then ABC_PLATFORM=$1; else ABC_PLATFORM="Linux"; fi
if (( $# > 1 )); then OPTION=$2; else OPTION=""; fi

OBJ="../obj/$ABC_PLATFORM"
SRC="../../src"
DEFS=""

if [ -e MakeDefs.$ABC_PLATFORM ]; then
     DEFS="-f $SRC/MakeDefs.$ABC_PLATFORM"
else
     echo "Will try default compiler and flags"
fi 

if [ ! -e ../obj ]; then
     (cd ..; mkdir obj)
fi

if [ ! -e $OBJ ]; then
     (cd ../obj; mkdir $ABC_PLATFORM)
fi

(cd $OBJ; make -f $SRC/Makefile $DEFS $OPTION)

