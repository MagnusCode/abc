/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2000-2002 by M. Wangen.
**
**   Info: Functions processing command line arguments.
**   Date: Version 1.0, November 2000
**
**   $Id$
*/

/*
**   GNU General Public License 
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   History:
**   Version 1.0, 2000 First version
**   Version 2.0, 2009 Added buffer of args.
**   Version 2.1, 2010 argv[0] is not dummy anymore.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lib_macros.h>
#include <lib_utils.h>
#include <lib_args.h>

static int
     is_debugging = FALSE;

#define ABC_MATCH(a, b) (strcmp(a,b) == 0)

static void init_args(AbcArgs *args);
static void print_prev_arg(AbcArgs *args, FILE *out);
static void add_args(AbcArgs *args, int first, int last, char **argv);
static const char *get_next_arg(AbcArgs *args);


int abc_test_args(
     int argc, 
     char **argv)
{
     AbcArgs args;

     abc_init_args(&args);
     abc_add_args_by_string(&args, "-text before-ABC -int 123");
     abc_add_args(&args, argc, argv);
     abc_add_args_by_string(&args, "-text after-ABC -int 789");
     abc_add_args_by_string(&args, "-doublex x9x9x");
     abc_add_args_by_string(&args, "-text \"This is a sentence.\" -int 999");
     abc_add_args_by_string(&args, "-textx xxx -intx 9x9");

     abc_show_all_args(&args, stdout);

     abc_test_reading_args(&args);
     abc_test_reading_args(&args);
     abc_test_reading_args(&args);

     abc_exit_if_unused_args(&args);

     return 0;
}


void abc_test_reading_args(
     AbcArgs *args)
{
     const char *option;

     abc_begin_reading_args(args);

     while ((option = abc_get_next_arg(args)) != NULL)
     {
          if      (ABC_MATCH(option, "-text"))   printf("text=%s\n",   abc_get_carg(args));
          else if (ABC_MATCH(option, "-int"))    printf("int=%d\n",    abc_get_iarg(args));
          else if (ABC_MATCH(option, "-double")) printf("double=%g\n", abc_get_darg(args));
          else     abc_current_arg_is_unused(args);
     }
}


int abc_read_args(
     int argc,
     char **argv,
     ABC_READ_ONE_ARG read_one_arg)
{
     const char *option;
     int error_counter = 0;

     AbcArgs args;

     abc_init_args(&args);
     abc_add_args(&args, argc, argv);
     abc_begin_reading_args(&args);

     while ((option = abc_get_next_arg(&args)) != NULL)
          if (not read_one_arg(option))
          {
               fprintf(stderr, "Unknown option: %s\n", option);
               error_counter++;
          }

     if (error_counter > 0)
     {
          fprintf(stderr, "Input errors!\n");
          return FALSE;
     }

     return TRUE;
}


int abc_get_boolen_arg(
     AbcArgs *args,
     const char *wanted_name,
     int default_value)
{
     return abc_get_int_arg(args, wanted_name, 0, 1, default_value);
}


int abc_get_int_arg(
     AbcArgs *args,
     const char *wanted_name,
     int min_value,
     int max_value,
     int default_value)
{
     return abc_get_double_arg(args, wanted_name, 
          (double) min_value, (double) max_value, (double) default_value);
}


double abc_get_double_arg(
     AbcArgs *args,
     const char *wanted_name,
     double min_value,
     double max_value,
     double default_value)
{
     char name_part[ABC_MAX_WORD];
     char value_part[ABC_MAX_WORD];
     double input_value = default_value;
     const char *option;
     double value;

     abc_begin_reading_args(args);

     while ((option = abc_get_next_arg(args)) != NULL)
     {
          abc_interpret_option(option, name_part, value_part, &value);

          if (ABC_MATCH(name_part, wanted_name))
               input_value = value;
          else
               abc_current_arg_is_unused(args);
     }

     if (input_value < min_value)
     {
          fprintf(stderr, "option \"%s\" is less than min %g! ", wanted_name, min_value);
          fprintf(stderr, "(min is used)\n");
          return min_value;
     }

     if (input_value > max_value)
     {
          fprintf(stderr, "option \"%s\" is larger than max %g! ", wanted_name, max_value);
          fprintf(stderr, "(max is used)\n");
          return max_value;
     }

     return input_value;
}


void abc_get_field_arg(
     AbcArgs *args,
     const char *wanted_name,
     const char *default_field,
     char *field)
{
     char name_part[ABC_MAX_WORD];
     char value_part[ABC_MAX_WORD];
     const char *option;
     double value;

     abc_begin_reading_args(args);
     strcpy(field, default_field);

     while ((option = abc_get_next_arg(args)) != NULL)
     {
          abc_interpret_option(option, name_part, value_part, &value);

          if (ABC_MATCH(name_part, wanted_name))
               strcpy(field, value_part);
          else
               abc_current_arg_is_unused(args);
     }
}


void abc_exit_with_arg_info(
     AbcArgs *args)
{
     int no = abc_get_arg_errors(args);

     fprintf(stderr, "Can't continue!  ");
     fprintf(stderr, "(%d command line error%s)\n", no, (no > 1) ? "s" : "");

     exit(1);
}


void abc_init_args(
     AbcArgs *args)
{
     if (is_debugging)
          printf("(using version of 2.0 of LibArgs)\n");

     args->n_errors = 0;
     args->cur_arg = -1;
     args->prev_arg = -1;
     args->buf_pos = 0;
     args->argc = 0;
}


void abc_init_arg_lib0(
     AbcArgs *args,
     int argc,
     char **argv)
{
     init_args(args);
     add_args(args, 0, argc - 1, argv);
}


void abc_init_arg_lib(
     AbcArgs *args,
     int argc,
     char **argv)
{
     init_args(args);
     add_args(args, 1, argc - 1, argv);
}


void abc_add_args0(
     AbcArgs *args,
     int argc,
     char **argv)
{
     add_args(args, 0, argc - 1, argv);
}


void abc_add_args(
     AbcArgs *args,
     int argc,
     char **argv)
{
     add_args(args, 1, argc - 1, argv);
}


void abc_add_unused_args(
     AbcArgs *dest,
     AbcArgs *src)
{
     const char *option = NULL;

     abc_begin_reading_args(src);

     while ((option = abc_get_next_arg(src)) != NULL)
          abc_add_one_arg(dest, option);
}

#define IS_BLANK(ch) (ch == ' ')
#define IS_QUOTE(ch) (ch == '"')
#define IS_END(ch)   (ch == '\0')

void abc_add_args_by_string(
     AbcArgs *args,
     const char *string)
{
     int i, k;
     char text[ABC_MAX_WORD];

     i = 0;
     while (not IS_END(string[i]))
     {
          k = 0;

          while (IS_BLANK(string[i]) and not IS_END(string[i]))
               i++;

          if (IS_QUOTE(string[i]))
          {
               i++;

               while ((not IS_QUOTE(string[i])) and (not IS_END(string[i])))
                    text[k++] = string[i++];

               if (IS_QUOTE(string[i]))
                    i++;
               else
                    ABC_ERROR_EXIT("[abc_add_args_by_string] Missing \"!");
          }
          else
          {
               while (not IS_BLANK(string[i]) and not IS_END(string[i])) 
                    text[k++] = string[i++];
          }

          text[k] = '\0';
          abc_add_one_arg(args, text);
     }

     if (not IS_END(string[i]))
          ABC_ERROR_EXIT("[abc_add_args_by_string] Error!");
}


void abc_add_one_arg(
     AbcArgs *args,
     const char *text)
{
     int size = 1 + strlen(text);

     if (args->buf_pos + size >= MAX_ARGS_BUFFER)
          ABC_ERROR_EXIT("[add_args] Buffer space exceeded!");

     strcpy(&args->buffer[args->buf_pos], text);

     if (args->argc >= MAX_ARGS)
          ABC_ERROR_EXIT("[add_args] Too many args!");

     args->argv[args->argc] = &args->buffer[args->buf_pos];
     args->is_used[args->argc] = FALSE;

     if (is_debugging)
          printf("adding argv[%d]=%s (size=%d, buf_pos=%d)\n",
               args->argc, args->argv[args->argc], size-1, args->buf_pos);

     args->buf_pos += size;
     args->argc++;
}


void abc_restart_reading_args(
     AbcArgs *args)
{
     abc_begin_reading_args(args);
}


void abc_begin_reading_args(
     AbcArgs *args)
{
     args->cur_arg = -1;
     args->prev_arg = -1;
}


void abc_mark_all_args_as_unused(
     AbcArgs *args)
{
     int i;

     abc_begin_reading_args(args);

     for (i = 0; i < args->argc; i++)
          args->is_used[i] = FALSE;
}


int abc_get_arg_errors(
     AbcArgs *args)
{
     return args->n_errors;
}


void abc_inc_arg_error_counter(
     AbcArgs *args)
{
     args->n_errors++;
}


const char *abc_get_carg(
     AbcArgs *args)
{
     const char *next_arg = abc_get_next_arg(args);

     if (next_arg != NULL)
          return next_arg;

     fprintf(stderr, "Missing option!\n");
     print_prev_arg(args, stderr);
     args->n_errors++;

     return "";
}


int abc_get_iarg(
     AbcArgs *args)
{
     int numb;
     const char *next_arg = abc_get_next_arg(args);

     if (next_arg == NULL)
     {
          fprintf(stderr, "Missing option of type integer!\n");
          print_prev_arg(args, stderr);
          args->n_errors++;
          return 0;
     }

     if (sscanf(next_arg, "%d", &numb) != 1)
     {
          fprintf(stderr, "Expected \"%s\" to be an integer!\n", next_arg);
          print_prev_arg(args, stderr);
          args->n_errors++;
          return 0;
     }

     return numb;
}


float abc_get_farg(
     AbcArgs *args)
{
     float numb;
     const char *next_arg = abc_get_next_arg(args);

     if (next_arg == NULL)
     {
          fprintf(stderr, "Missing option of type number!\n");
          print_prev_arg(args, stderr);
          args->n_errors++;
          return 0.0;
     }

     if (sscanf(next_arg, "%f", &numb) != 1)
     {
          fprintf(stderr, "Expected \"%s\" to be a float!\n", next_arg);
          print_prev_arg(args, stderr);
          args->n_errors++;
          return 0.0;
     }

     return numb;
}


double abc_get_darg(
     AbcArgs *args)
{
     double numb;
     const char *next_arg = abc_get_next_arg(args);
 
     if (next_arg == NULL)
     {
          fprintf(stderr, "Missing option of type number!\n");
          print_prev_arg(args, stderr);
          args->n_errors++;
          return 0.0;
     }

     if (sscanf(next_arg, "%lf", &numb) != 1)
     {
          fprintf(stderr, "Expected \"%s\" to be a double!\n", next_arg);
          print_prev_arg(args, stderr);
          args->n_errors++;
          numb = 0.0;
     }

     return numb;
}


const char *abc_get_next_arg(
     AbcArgs *args)
{
     const char *option = NULL;

     while ((option = get_next_arg(args)) != NULL) 
          if (not args->is_used[args->cur_arg])
          {
               args->is_used[args->cur_arg] = TRUE;
               return option;
          }

     return option;
}


static const char *get_next_arg(
     AbcArgs *args)
{
     args->prev_arg = args->cur_arg;

     if (args->cur_arg < args->argc - 1)
          args->cur_arg++;
     else
          return NULL;

     return args->argv[args->cur_arg];
}


void abc_current_arg_is_unused(
     AbcArgs *args)
{
     if (args->cur_arg < 0) return;
     args->is_used[args->cur_arg] = FALSE;
}


void abc_exit_if_unused_args(
     AbcArgs *args)
{
     int n_unused_options = abc_get_unused_args(args);

     abc_show_unused_args(args, stderr);

     if (n_unused_options)
     {
          fprintf(stderr, "Found %d unused options!\n", n_unused_options);
          fprintf(stderr, "Can't continue!\n");
          exit(1);
     }
}


void abc_show_unused_args(
     AbcArgs *args,
     FILE *out)
{
     int i;

     for (i = 0; i < args->argc; i++)
          if (not args->is_used[i])
               fprintf(out, "Option \"%s\" has not been used!\n", args->argv[i]);
}


int abc_get_unused_args(
     AbcArgs *args)
{
     int i;
     int n_unused_options = 0;

     for (i = 0; i < args->argc; i++)
          if (not args->is_used[i])
               n_unused_options++;

     return n_unused_options;
}


void abc_show_all_args(
     AbcArgs *args,
     FILE *out)
{
     int i;

     for (i = 0; i < args->argc; i++)
          fprintf(out, "argv[%d]=%s (is_used=%d)\n", i, args->argv[i], args->is_used[i]);
}


void abc_make_all_args_unused(
     AbcArgs *args)
{
     int i;

     for (i = 0; i < args->argc; i++)
          args->is_used[i] = FALSE;
}

/*
**   =================
**   Private functions
**   =================
*/

static void add_args(
     AbcArgs *args,
     int first,
     int last,
     char **argv)
{
     int i;

     for (i = first; i <= last; i++)
          abc_add_one_arg(args, argv[i]);
}


static void init_args(
     AbcArgs *args)
{
     args->n_errors = 0;
     args->cur_arg = -1;
     args->prev_arg = -1;
     args->buf_pos = 0;
     args->argc = 0;
}


static void print_prev_arg(
     AbcArgs *args,
     FILE *out)
{
     int index = args->prev_arg;

     if (index < 0 || args->argc <= index)
          return;

     fprintf(out, "The previous option was \"%s\".\n", args->argv[index]);
}


