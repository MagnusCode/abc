/*
**   This program is free software under GNU General Public License.
**   (c) Copyright 2005-2011 by M. Wangen.
**
**   Info: Functions for rock properties.
**   Date: Version 1.1, October 2011
**
**   $Id$
*/

/*
**   GNU General Public License
**
**   This program is free software; you can redistribute it and/or
**   modify it under the terms of the GNU General Public License as
**   published by the Free Software Foundation; either version 2 of
**   the License, or (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**   02111-1307, USA.
*/

/*
**   A test program:
**   ===============
**   
**   #include <stdio.h>
**   #include <math.h>
**   #include <lib_rock_prop.h>
**   
**   int main(int argc, char **argv)
**   {
**        return abc_test_rock_lib(argc, argv);
**   }
*/

/*
**   An example of a rock library: 
**   =============================

begin_rock_library
     begin_table
          name=PorosityLinear
             0  0.80
          4000  0.40
          8000  0.00
     end_table

     begin_rock
          name = Sandstone1
          density           function=density_std {density0=2500, expan=2e-5}
          heat_capacity     function=heat_cap_const {C0=1000}
          porosity          function=porosity_table_of_z {table=PorosityLinear}
          heat_conductivity function=heat_cond_const {lambda=3}
          permeability      function=Gibson {k0=1e-15, exp=1, kmin=1e-23}
          Youngs_modulus    function=E {E=10e+9}
          Poisson_ratio     function=nu {nu=0.25}
          Biot_coefficient  function=Biot_coef {Biot_coef=1}
     end_rock

     begin_rock
          name = Sandstone1
          density           function=density_std {density0=2500, expan=2e-5}
          heat_capacity     function=heat_cap_const {C0=1000}
          porosity          function=linear_void_ratio_of_ps {e0=0.5, emin=0, alpha=1e-8}
          heat_conductivity function=heat_cond_const {lambda=3}
          permeability      function=Gibson {k0=1e-15, exp=1, kmin=1e-23}
          Youngs_modulus    function=E {E=10e+9}
          Poisson_ratio     function=nu {nu=0.25}
          Biot_coefficient  function=Biot_coef {Biot_coef=1}
     end_rock
  
     begin_rock
          name = Sandstone2
          density           function=density_std {density0=2500, expan=2e-5}
          heat_capacity     function=heat_cap_const {C0=1000}
          porosity          function=linear_void_ratio_of_ps {e0=0.65, emin=0, alpha=0.9e-8}
          heat_conductivity function=heat_cond_const {lambda=2.5}
          permeability      function=Gibson {k0=1e-16, exp=1, kmin=1e-23}
          Youngs_modulus    function=E {E=10e+9}
          Poisson_ratio     function=nu {nu=0.25}
          Biot_coefficient  function=Biot_coef {Biot_coef=1}
          angle_friction    function=phi {phi=35}
          cohesive_strength function=c0 {c0=100.0e+3}
     end_rock
end_rock_library

**   Some rock property functions:
**   =============================
**
     porosity          function=porosity_table_of_z {table=PorosityLinear}
     porosity          function=linear_void_ratio_of_ps {e0=0.5, emin=0, alpha=1e-8}
     porosity          function=Athy_of_ps {phi0=0.5, phi_min=0.03, alpha=1e-7}
     heat_conductivity function=heat_cond_harmonic_mean {lambda=3, c1=0, c2=0}
     heat_conductivity function=heat_cond_linear_mean {lambda=3, c1=0, c2=0}
     permeability      function=Kozeny_Carman {k0=1e-15, exp=3, C=7, kmin=1e-23}
     permeability      function=perm_exp_of_phi {k0=1e-21, c0=22}
     permeability      function=perm_exp10_of_phi {a0=5, b0=-18}
     permeability      function=perm_const {k0=1.5e-15}
     Youngs_modulus    function=E {E=10e+9}
     Youngs_modulus    constant=E {E=10e+9}
     Poisson_ratio     function=nu {nu=0.25}
     Poisson_ratio     constant=nu {nu=0.25}
     Biot_coefficient  function=Biot_coef {Biot_coef=1}
     Biot_coefficient  constant=Biot_coef {Biot_coef=1}
**
**   A |constant| is function that returns a constant.
**   A function becomes a constant when the function name
**   is equal to the parameter name. There can be only one
**   parameter, which is the constant.
*/

#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <lib_macros.h>
#include <lib_alloc.h>
#include <lib_matrix.h>
#include <lib_utils.h>
#include <lib_input.h>
#include <lib_params.h>
#include <lib_rock_prop.h>

#ifdef MAX_WORD
#undef MAX_WORD
#endif

#define LITH_EROSION 0
#define MAX_WORD ABC_MAX_ROCK_NAME
#define RETURN_FALSE(in, text) {abc_read_error(in, text); return FALSE;}
#define RETURN_FALSE2(in, text1, text2) {abc_read_error2(in, text1, text2); return FALSE;}
#define ERROR_EXIT(text) {fprintf(stderr, "Error: %s\n", text); exit(1);}

static double get_undefined(AbcRockProp *prop, AbcRockArg *arg);
static double get_prop_value(AbcRock *rock, AbcRockProp *prop, AbcRockArg *arg);
static int is_missing_prop(AbcRock *rock, int type);
static void   def_porosity_table_z(AbcRockProp *prop);
static double get_porosity_table_z(AbcRockProp *prop, AbcRockArg *arg);
static void   def_porosity_athy_z(AbcRockProp *prop);
static double get_porosity_athy_z(AbcRockProp *prop, AbcRockArg *arg);
static void   def_porosity_athy_zeta(AbcRockProp *prop);
static double get_porosity_athy_zeta(AbcRockProp *prop, AbcRockArg *arg);
static void   def_porosity_athy_ps(AbcRockProp *prop);
static double get_porosity_athy_ps(AbcRockProp *prop, AbcRockArg *arg);
static void   def_density_std(AbcRockProp *prop);
static double get_density_std(AbcRockProp *prop, AbcRockArg *arg);
static void   def_porosity_linear_void_ratio_ps(AbcRockProp *prop);
static double get_porosity_linear_void_ratio_ps(AbcRockProp *prop, AbcRockArg *arg);
static void   def_heat_cond_harmonic_mean(AbcRockProp *prop);
static double get_heat_cond_harmonic_mean(AbcRockProp *prop, AbcRockArg *arg);
static void   def_heat_cond_linear_mean(AbcRockProp *prop);
static double get_heat_cond_linear_mean(AbcRockProp *prop, AbcRockArg *arg);
static void   def_heat_cond_const(AbcRockProp *prop);
static double get_heat_cond_const(AbcRockProp *prop, AbcRockArg *arg);
static void   def_perm_Kozeny_Carman(AbcRockProp *prop);
static double get_perm_Kozeny_Carman(AbcRockProp *prop, AbcRockArg *arg);
static void   def_perm_exp_of_phi(AbcRockProp *prop);
static double get_perm_exp_of_phi(AbcRockProp *prop, AbcRockArg *arg);
static void   def_perm_exp10_of_phi(AbcRockProp *prop);
static double get_perm_exp10_of_phi(AbcRockProp *prop, AbcRockArg *arg);
static void   def_perm_const(AbcRockProp *prop);
static double get_perm_const(AbcRockProp *prop, AbcRockArg *arg);
static void   def_perm_Gibson(AbcRockProp *prop);
static double get_perm_Gibson(AbcRockProp *prop, AbcRockArg *arg);
static void   def_heat_cap_const(AbcRockProp *prop);
static double get_heat_cap_const(AbcRockProp *prop, AbcRockArg *arg);
static void   def_youngs_modulus_const(AbcRockProp *prop);
static double get_youngs_modulus_const(AbcRockProp *prop, AbcRockArg *arg);
static void   def_poisson_ratio_const(AbcRockProp *prop);
static double get_poisson_ratio_const(AbcRockProp *prop, AbcRockArg *arg);
static void   def_biot_coef_const(AbcRockProp *prop);
static double get_biot_coef_const(AbcRockProp *prop, AbcRockArg *arg);
static void   def_angle_internal_friction(AbcRockProp *prop);
static double get_angle_internal_friction(AbcRockProp *prop, AbcRockArg *arg);
static void   def_cohesive_strength(AbcRockProp *prop);
static double get_cohesive_strength(AbcRockProp *prop, AbcRockArg *arg);
static void   def_rock_strength_const(AbcRockProp *prop);
static double get_rock_strength_const(AbcRockProp *prop, AbcRockArg *arg);
static void   def_frac_lim_std(AbcRockProp *prop);
static double get_frac_lim_std(AbcRockProp *prop, AbcRockArg *arg);
static void   def_frac_fac_const(AbcRockProp *prop);
static double get_frac_fac_const(AbcRockProp *prop, AbcRockArg *arg);

static AbcListOfRockProps prop_list;
static int do_range_checking = TRUE;

/* Dirty trick to map rock properties to library tables. */
static AbcRockLib *current_lib = NULL;


int abc_test_rock_lib(
     int argc,
     char **argv)
{
     static AbcRockLib lib;
     /* 
     ** Notice that AbcRockLib is static. 
     ** Otherwise it takes to much local stack space! 
     */
     AbcRock *rock = NULL;
     AbcParams *params = abc_new_params(1024);
     char input_file[ABC_MAX_WORD];
     char name_rock[ABC_MAX_WORD];
     int show_rock_lib = FALSE;
     int P1 = 0;

     abc_def_param_group(params, "Read rock-library parameters:", P1);
     abc_def_string_param(params, name_rock, "test", "Name of test-rock", "", ABC_MAX_WORD, P1);
     abc_def_string_param(params, input_file, "input", "Input file", "xrock.bas", ABC_MAX_WORD, P1);
     abc_def_yes_no_param(params, &show_rock_lib, "show-library", "Print the library ", 0, P1);

     abc_init_rock_lib(&lib);

     if (not abc_read_params(params, &argc, argv))
          ABC_ERROR_EXIT("Can't continue!");

     if (not abc_read_rock_lib_from_file(&lib, input_file))
          ABC_ERROR_EXIT("Can't read the library!");

     if (not abc_is_ok_rock_lib(&lib))
          ABC_ERROR_EXIT("Library contains incomplete rocks!");

     if (show_rock_lib) 
          abc_show_rock_lib(stdout, &lib);

     if (not ABC_MATCH(name_rock, ""))
     {
          rock = abc_get_rock_from_lib(&lib, name_rock);

          if (rock == NULL) 
               fprintf(stderr, "No rock named: %s\n", name_rock);
          else
               abc_test_rock(stdout, rock);
     }

     abc_delete_rock_lib(&lib);
     abc_delete_params(&params);
     abc_delete_input_lib();

     return 0;
}


void abc_test_rock(
     FILE *out,
     AbcRock *rock)
{
     double dTdz = 0.035;
     double density_brine = 1000.0;
     double gravity = 10.0;
     double density_rock;
     AbcRockArg arg;

     fprintf(out, "-------------------------------------------------------------------\n");
     fprintf(out, "%7s %7s %9s %7s %7s %7s %9s %9s\n", 
          "z", "temp", "ps", "phi", "dens", "cond", "perm", "heat_cap");
     fprintf(out, "-------------------------------------------------------------------\n");

     for (arg.z_depth = 0.0; arg.z_depth < 5000.0; arg.z_depth += 250.0)
     {
          abc_init_rock_arg(&arg);

          arg.temp1 = dTdz * arg.z_depth;
          arg.heat_cond_fluid = 0.6;
          density_rock = abc_get_rock_density(rock, &arg);
          arg.ps = (density_rock - density_brine) * gravity * arg.z_depth;
          arg.phi = abc_get_rock_porosity(rock, &arg);

          printf("%7.0f %7.1f %9.1e %7.3f %7.1f %7.3f %9.1e %9.1f\n", 
               arg.z_depth, arg.temp1, arg.ps, 
               arg.phi, density_rock,
               abc_get_rock_heat_cond(rock, &arg),
               abc_get_rock_perm(rock, &arg),
               abc_get_rock_heat_cap(rock, &arg));
     }

     fprintf(out, "-------------------------------------------------------------------\n");
}

/*
**   ===========================
**   The rock property interface
**   ===========================
*/

void abc_init_rock_arg(
     AbcRockArg *arg)
{
     arg->phi = 0.0;
     arg->z_depth = 0.0;
     arg->zeta_depth = 0.0;
     arg->ps = 0.0;
     arg->pex = 0.0;
     arg->pf = 0.0;
     arg->ph = 0.0;
     arg->pb = 0.0;
     arg->temp1 = 0.0;
     arg->temp0 = 0.0;
     arg->dt = 0.0;
     arg->heat_cond_fluid = 0.0;
     /* extra info */
     arg->rock = NULL;
     arg->elem = -1;
}


void abc_print_rock_arg(
     FILE *out,
     AbcRockArg *arg)
{
     const char *name = (arg->rock == NULL) ? "" : arg->rock->name;

     fprintf(out, "-----\n");
     fprintf(out, "rock=\"%s\" and elem=%d\n", name, arg->elem);
     fprintf(out, "dt=%g [s], zeta=%g [m], z=%g [m], phi=%g [-]\n", 
          arg->dt, arg->zeta_depth, arg->z_depth, arg->phi);
     fprintf(out, "temp0=%g [C], temp1=%g [C], heat_cond_f=%g [W/mK]\n", 
          arg->temp0, arg->temp1, arg->heat_cond_fluid);
     fprintf(out, "pex=%g [Pa], ph=%g [Pa], pf=%g [Pa]\n", 
          arg->pex, arg->ph, arg->pf);
     fprintf(out, "pb=%g [Pa], ps=%g [Pa]\n", arg->pb, arg->ps);
     fprintf(out, "-----\n");
}


void abc_set_rock_lib_range_checking(
     int on_off)
{
     do_range_checking = on_off;
}


double abc_get_rock_heat_cap(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->heat_cap;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_density(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->density;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_porosity(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->porosity;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_heat_cond(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->heat_cond;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_heat_cond_x(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->heat_cond_x;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_heat_cond_y(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->heat_cond_y;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_heat_cond_z(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->heat_cond_y;
     return get_prop_value(rock, prop, arg);
}    


double abc_get_rock_perm(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->perm;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_perm_x(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->perm_x;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_perm_y(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->perm_y;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_perm_z(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->perm_z;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_youngs_modulus(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->E;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_poisson_ratio(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->nu;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_biot_coef(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->biot_coef;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_angle_friction(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->angle_fric;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_cohesive_strength(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->cohesive_str;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_strength(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->rock_strength;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_frac_lim(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->frac_lim;
     return get_prop_value(rock, prop, arg);
}


double abc_get_rock_frac_fac(
     AbcRock *rock,
     AbcRockArg *arg)
{
     AbcRockProp *prop = &rock->frac_fac;
     return get_prop_value(rock, prop, arg);
}


int abc_rock_has_perm_tensor(
     AbcRock *rock)
{
     AbcRockProp *kx = &rock->perm_x;
     AbcRockProp *ky = &rock->perm_y;
     AbcRockProp *kz = &rock->perm_z;

     if (kx->type < 0) return FALSE;
     if (ky->type < 0) return FALSE;
     if (kz->type < 0) return FALSE;

     return TRUE;
}


int abc_rock_has_heat_cond_tensor(
     AbcRock *rock)
{
     AbcRockProp *kx = &rock->heat_cond_x;
     AbcRockProp *ky = &rock->heat_cond_y;
     AbcRockProp *kz = &rock->heat_cond_z;

     if (kx->type < 0) return FALSE;
     if (ky->type < 0) return FALSE;
     if (kz->type < 0) return FALSE;

     return TRUE;
}


void abc_make_diag_perm_tensor(
     AbcRock *rock,
     AbcRockArg *arg,
     double K_diag[3])
{
     if (abc_rock_has_perm_tensor(rock))
     {
          K_diag[0] = abc_get_rock_perm_x(rock, arg);
          K_diag[1] = abc_get_rock_perm_y(rock, arg);
          K_diag[2] = abc_get_rock_perm_z(rock, arg);
     }
     else
     {
          K_diag[0] = abc_get_rock_perm(rock, arg);
          K_diag[1] = K_diag[0];
          K_diag[2] = K_diag[0];
     }
}


void abc_make_diag_heat_cond_tensor(
     AbcRock *rock,
     AbcRockArg *arg,
     double L_diag[3])
{
     if (abc_rock_has_heat_cond_tensor(rock))
     {
          L_diag[0] = abc_get_rock_heat_cond_x(rock, arg);
          L_diag[1] = abc_get_rock_heat_cond_y(rock, arg);
          L_diag[2] = abc_get_rock_heat_cond_z(rock, arg);
     }
     else
     {
          L_diag[0] = abc_get_rock_heat_cond(rock, arg);
          L_diag[1] = L_diag[0];
          L_diag[2] = L_diag[0];
     }
}


static double get_prop_value(
     AbcRock *rock,
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     if (prop == NULL)
          ABC_ERROR_EXIT("[get_prop_value] NULL-pointer!");

     if (prop->type < 0 or prop->get == NULL)
     {
          fprintf(stderr, "Error: Rock \"%s\" is missing property \"%s\"!\n",
               rock->name, prop->name);
          exit(1);
     }

     return prop->get(prop, arg);
}

/*
**   =========================
**   The rest of the interface
**   ========================= 
*/

void abc_init_rock_prop_lib(
     void)
{
     prop_list.n_props = 0;

     abc_add_rock_prop_to_lib(&prop_list, "density_std",                def_density_std);
     abc_add_rock_prop_to_lib(&prop_list, "heat_cap_const",             def_heat_cap_const);
     abc_add_rock_prop_to_lib(&prop_list, "porosity_table_of_z",        def_porosity_table_z);
     abc_add_rock_prop_to_lib(&prop_list, "Athy_of_z",                  def_porosity_athy_z);
     abc_add_rock_prop_to_lib(&prop_list, "Athy_of_zeta",               def_porosity_athy_zeta);
     abc_add_rock_prop_to_lib(&prop_list, "Athy_of_ps",                 def_porosity_athy_ps);
     abc_add_rock_prop_to_lib(&prop_list, "linear_void_ratio_of_ps",    def_porosity_linear_void_ratio_ps);
     abc_add_rock_prop_to_lib(&prop_list, "heat_cond_harmonic_mean",    def_heat_cond_harmonic_mean);
     abc_add_rock_prop_to_lib(&prop_list, "heat_cond_linear_mean",      def_heat_cond_linear_mean);
     abc_add_rock_prop_to_lib(&prop_list, "heat_cond_const",            def_heat_cond_const);
     abc_add_rock_prop_to_lib(&prop_list, "Kozeny_Carman",              def_perm_Kozeny_Carman);
     abc_add_rock_prop_to_lib(&prop_list, "perm_exp_of_phi",            def_perm_exp_of_phi);
     abc_add_rock_prop_to_lib(&prop_list, "perm_exp10_of_phi",          def_perm_exp10_of_phi);
     abc_add_rock_prop_to_lib(&prop_list, "perm_const",                 def_perm_const);
     abc_add_rock_prop_to_lib(&prop_list, "Gibson",                     def_perm_Gibson);
     abc_add_rock_prop_to_lib(&prop_list, "E",                          def_youngs_modulus_const);
     abc_add_rock_prop_to_lib(&prop_list, "nu",                         def_poisson_ratio_const);
     abc_add_rock_prop_to_lib(&prop_list, "Biot_coef",                  def_biot_coef_const);
     abc_add_rock_prop_to_lib(&prop_list, "phi",                        def_angle_internal_friction);
     abc_add_rock_prop_to_lib(&prop_list, "c0",                         def_cohesive_strength);
     abc_add_rock_prop_to_lib(&prop_list, "strength_const",             def_rock_strength_const);
     abc_add_rock_prop_to_lib(&prop_list, "frac_lim_std",               def_frac_lim_std);
     abc_add_rock_prop_to_lib(&prop_list, "frac_fac_const",             def_frac_fac_const);
}


void abc_add_rock_prop_to_lib(
     AbcListOfRockProps *list,
     const char *name,
     ABC_DEF_ROCK_PROP def_prop)
{
     int i = list->n_props;

     if (i >= ABC_MAX_ROCK_PROPS)
          ERROR_EXIT("Too many rock property definitions!");

     if (strlen(name) >= MAX_WORD)
          ERROR_EXIT("Too large name for rock property!");

     strcpy(list->prop[i].name, name);
     list->prop[i].def_prop = def_prop;
     list->n_props++;
}


void abc_init_rock_lib(
     AbcRockLib *lib)
{
     lib->n_rocks = 0;
     lib->n_tables = 0;
}


void abc_delete_rock_lib(
     AbcRockLib *lib)
{
     int i;

     for (i = 0; i < lib->n_tables; i++)
          abc_delete_table(&lib->table[i]);
}


void abc_print_rock_lib_to_file(
     AbcRockLib *lib,
     const char *filename)
{
     FILE *out = abc_new_file(filename, "");
     abc_show_rock_lib(out, lib);
     fclose(out);
     printf("(rock lib is written to: %s)\n", filename);
}


void abc_show_rock_lib(
     FILE *out,
     AbcRockLib *lib)
{
     int i;
     const char *margin1 = abc_get_margin(1);
     const char *margin2 = abc_get_margin(2);

     fprintf(out, "begin_rock_library\n");

     for (i = 0; i < lib->n_tables; i++)
          abc_write_table(out, margin1, margin2, lib->table[i]);

     for (i = 0; i < lib->n_rocks; i++)
          abc_show_rock(out, &lib->rock[i]);

     fprintf(out, "end_rock_library\n");
}


void abc_show_rock(
     FILE *out,
     AbcRock *rock)
{
     const char *margin1 = abc_get_margin(1);
     const char *margin2 = abc_get_margin(2);

     fprintf(out, "%sbegin_rock\n", margin1);
     fprintf(out, "%sname=%s\n", margin2, rock->name);
     abc_show_rock_prop(out, &rock->density);
     abc_show_rock_prop(out, &rock->heat_cap);
     abc_show_rock_prop(out, &rock->porosity);
     abc_show_rock_prop(out, &rock->heat_cond);
     abc_show_rock_prop(out, &rock->heat_cond_x);
     abc_show_rock_prop(out, &rock->heat_cond_y);
     abc_show_rock_prop(out, &rock->heat_cond_z);
     abc_show_rock_prop(out, &rock->perm);
     abc_show_rock_prop(out, &rock->perm_x);
     abc_show_rock_prop(out, &rock->perm_y);
     abc_show_rock_prop(out, &rock->perm_z);
     abc_show_rock_prop(out, &rock->E);
     abc_show_rock_prop(out, &rock->nu);
     abc_show_rock_prop(out, &rock->biot_coef);
     abc_show_rock_prop(out, &rock->angle_fric);
     abc_show_rock_prop(out, &rock->cohesive_str);
     abc_show_rock_prop(out, &rock->rock_strength);

     fprintf(out, "%send_rock\n", margin1);
}


void abc_show_rock_prop(
     FILE *out,
     AbcRockProp *prop)
{
     int i;
     const char *margin2 = abc_get_margin(2);
     const char *margin3 = abc_get_margin(3);

     if (prop->type < 0) return;

     fprintf(out, "%s%s function=%s {\n", 
          margin2, prop->name, prop->func);

     if (prop->table != NULL)
          fprintf(out, "%stable=%s\n", margin3, prop->table_name);
     else
          for (i = 0; i < prop->n_params; i++)
          {
               int ch = (i == prop->n_params - 1) ? ' ' : ',';
               abc_show_rock_param(out, &prop->param[i], ch);
          }

     fprintf(out, "%s}\n", margin2);
}


void abc_show_rock_param(
     FILE *out,
     AbcRockParam *param,
     int ch)
{
     const char *margin3 = abc_get_margin(3);

     fprintf(out, "%s%s=%g%c #(%s)#\n", 
          margin3, param->name, param->value, ch, param->unit);
}


AbcRock *abc_get_rock_from_lib(
     AbcRockLib *lib, 
     const char *name)
{
     int i;

     for (i = 0; i < lib->n_rocks; i++)
          if (ABC_MATCH(lib->rock[i].name, name))
               return &(lib->rock[i]);

     return NULL;
}


int abc_read_rock_lib_from_file(
     AbcRockLib *lib,
     const char *filename)
{
     static AbcInput in;

     if (not abc_begin_input(&in, filename))
     {
          fprintf(stderr, "Error: Can't open file: %s!\n", filename);
          exit(1);
     }

     if (not abc_read_rock_lib(&in, lib))
     {
          fprintf(stderr, "Error: Can't read rock lib from: %s!\n", filename);
          exit(1);
     }

     if (lib->n_rocks == 1)
          printf("(one rock definition is read from file: %s)\n", filename);
     else
          printf("(%d rock definitions are read from file: %s)\n", lib->n_rocks, filename);

     abc_end_input(&in);

     return TRUE;
}


int abc_read_rock_lib(
     AbcInput *in,
     AbcRockLib *lib)
{
     char word[MAX_WORD];

     current_lib = lib;

     if (not abc_skip_until_word(in, "begin_rock_library"))
          ABC_ERROR_EXIT("Can't find keyword \"begin_rock_library\"!");

     while (TRUE)
     {
          if (not abc_get_word(in, word, MAX_WORD))
               RETURN_FALSE(in, "Expected a keyword!");

          if (ABC_MATCH(word, "end_rock_library"))
              return TRUE;

          abc_put_back_word(in, word);

          if (ABC_MATCH(word, "begin_rock"))
          {
               if (not abc_read_rock_to_lib(in, lib))
                    RETURN_FALSE(in, "Can't read rock definition!");
          }
          else if (ABC_MATCH(word, "begin_table"))
          {
               if (not abc_read_table_to_lib(in, lib))
                    RETURN_FALSE(in, "Can't read table!");
          }
          else
               RETURN_FALSE(in, "Expected rock definition or table!");
     }

     return TRUE;
}


int abc_read_table_to_lib(
     AbcInput *in,
     AbcRockLib *lib)
{
     int i = lib->n_tables;

     if (i >= ABC_MAX_ROCK_TABLES)
          RETURN_FALSE(in, "Too many tables in library!");

     lib->table[i] = abc_read_and_create_table(in);

     if (lib->table[i] == NULL)
          RETURN_FALSE(in, "Can't read table!");

     lib->n_tables++;
     return TRUE;
}


int abc_read_rock_to_lib(
     AbcInput *in,
     AbcRockLib *lib)
{
     int i = lib->n_rocks;

     if (i >= ABC_MAX_ROCKS)
          RETURN_FALSE(in, "Too many rocks in library!");

     if (not abc_read_rock(in, &lib->rock[i]))
          RETURN_FALSE(in, "Can't read rock definition!");

     lib->n_rocks++;
     return TRUE;
}


int abc_read_rock(
     AbcInput *in,
     AbcRock *rock)
{
     static int is_initialized = FALSE;
     char word[MAX_WORD];
     AbcRockProp *prop;
     int type;

     abc_init_rock(rock);

     if (not abc_get_word(in, word, MAX_WORD) or not ABC_MATCH(word, "begin_rock"))
          RETURN_FALSE(in, "Expected \"begin_rock\"!");

     if (not abc_get_word(in, word, MAX_WORD) or not ABC_MATCH(word, "name"))
          RETURN_FALSE(in, "Expected keyword \"name\"!");

     if (not abc_get_word(in, word, MAX_WORD) or not ABC_MATCH(word, "="))
          RETURN_FALSE(in, "Expected equal-sign!");

     if (not abc_get_word(in, word, MAX_WORD))
          RETURN_FALSE(in, "Expected rock name!");

     if (not is_initialized)
     {
          abc_init_rock_prop_lib();
          is_initialized = TRUE;
     }

     strcpy(rock->name, word);

     while (abc_get_word(in, word, MAX_WORD))
     {
          if (ABC_MATCH(word, "end_rock"))
               return TRUE;

          type = abc_get_rock_prop_type_by_name(word);
          prop = abc_get_rock_prop_by_name(rock, word);

          if (prop == NULL)
               RETURN_FALSE2(in, "Unknown rock property!", word);

          strcpy(prop->name, word);
          prop->rock = rock;

          if (not abc_read_rock_prop(in, prop, type))
               RETURN_FALSE2(in, "Can't read rock property!", word);
     }

     RETURN_FALSE(in, "Expected \"end_rock\"!");
}


int abc_read_rock_prop(
     AbcInput *in,
     AbcRockProp *prop,
     int type)
{
     AbcRockProp p1;
     ABC_DEF_ROCK_PROP def_prop;

     if (not abc_read_rock_func(in, p1.func))
          RETURN_FALSE(in, "Expected a function!");

     if (not abc_read_rock_prop_params(in, &p1))
          RETURN_FALSE(in, "Can't read rock property parameters!");

     def_prop = abc_get_rock_prop_def_func(&prop_list, p1.func);

     if (def_prop == NULL)
          RETURN_FALSE2(in, "No rock property of this name!", p1.func);

     def_prop(prop);

     if (prop->type != type)
          RETURN_FALSE(in, "Illegal rock property type!");

     if (not abc_set_prop_param_values(prop, &p1))
          RETURN_FALSE2(in, "Can't assign rock parameters!", p1.func);

     return TRUE;
}


int abc_read_rock_func(
     AbcInput *in,
     char *name)
{
     char word[MAX_WORD];

     if (not abc_get_word(in, word, MAX_WORD) and ABC_MATCH(word, "function"))
          RETURN_FALSE(in, "Expected keyword \"function\"!");

     if (not abc_get_word(in, word, MAX_WORD) and ABC_MATCH(word, "="))
          RETURN_FALSE(in, "Expected an equal sign!");

     if (not abc_get_word(in, name, MAX_WORD))
          RETURN_FALSE(in, "Expected a function name!");

     return TRUE;
}


ABC_DEF_ROCK_PROP abc_get_rock_prop_def_func(
     AbcListOfRockProps *list,
     const char *name)
{
     int i;

     for (i = 0; i < list->n_props; i++)
          if (ABC_MATCH(list->prop[i].name, name))
               return list->prop[i].def_prop;

     return NULL;
}


int abc_read_rock_prop_type(
     AbcInput *in)
{
     char name[MAX_WORD];

     if (not abc_get_word(in, name, MAX_WORD))
          RETURN_FALSE(in, "Expected a rock property name!");

     return abc_get_rock_prop_type_by_name(name);
}


int abc_get_rock_prop_type_by_name(
     const char *name)
{
     if (ABC_MATCH(name, "porosity"))                 return ABC_POROSITY_FUNC;
     if (ABC_MATCH(name, "permeability"))             return ABC_PERM_FUNC;
     if (ABC_MATCH(name, "permeability_x"))           return ABC_PERM_FUNC;
     if (ABC_MATCH(name, "permeability_y"))           return ABC_PERM_FUNC;
     if (ABC_MATCH(name, "permeability_z"))           return ABC_PERM_FUNC;
     if (ABC_MATCH(name, "heat_conductivity"))        return ABC_HEAT_COND_FUNC;
     if (ABC_MATCH(name, "heat_conductivity_x"))      return ABC_HEAT_COND_FUNC;
     if (ABC_MATCH(name, "heat_conductivity_y"))      return ABC_HEAT_COND_FUNC;
     if (ABC_MATCH(name, "heat_conductivity_z"))      return ABC_HEAT_COND_FUNC;
     if (ABC_MATCH(name, "heat_capacity"))            return ABC_HEAT_CAP_FUNC;
     if (ABC_MATCH(name, "density"))                  return ABC_DENSITY_FUNC;
     if (ABC_MATCH(name, "Youngs_modulus"))           return ABC_E_FUNC;
     if (ABC_MATCH(name, "Poisson_ratio"))            return ABC_NU_FUNC;
     if (ABC_MATCH(name, "Biot_coefficient"))         return ABC_BIOT_COEF_FUNC;
     if (ABC_MATCH(name, "angle_friction"))           return ABC_ANGLE_INT_FRIC_FUNC;
     if (ABC_MATCH(name, "cohesive_strength"))        return ABC_COHESIVE_STRENGTH_FUNC;
     if (ABC_MATCH(name, "rock_strength"))            return ABC_ROCK_STRENGTH_FUNC;
     if (ABC_MATCH(name, "fracture_limit"))           return ABC_FRAC_LIM_FUNC;
     if (ABC_MATCH(name, "fracture_factor"))          return ABC_FRAC_FAC_FUNC;

     return -1;
}


AbcRockProp *abc_get_rock_prop_by_type(
     AbcRock *rock,
     int type)
{
     if (type == ABC_POROSITY_FUNC)            return &rock->porosity;
     if (type == ABC_PERM_FUNC)                return &rock->perm;
     if (type == ABC_PERM_X_FUNC)              return &rock->perm_x;
     if (type == ABC_PERM_Y_FUNC)              return &rock->perm_y;
     if (type == ABC_PERM_Z_FUNC)              return &rock->perm_z;
     if (type == ABC_HEAT_COND_FUNC)           return &rock->heat_cond;
     if (type == ABC_HEAT_COND_X_FUNC)         return &rock->heat_cond_x;
     if (type == ABC_HEAT_COND_Y_FUNC)         return &rock->heat_cond_y;
     if (type == ABC_HEAT_COND_Z_FUNC)         return &rock->heat_cond_z;
     if (type == ABC_HEAT_CAP_FUNC)            return &rock->heat_cap;
     if (type == ABC_DENSITY_FUNC)             return &rock->density;
     if (type == ABC_E_FUNC)                   return &rock->E;
     if (type == ABC_NU_FUNC)                  return &rock->nu;
     if (type == ABC_BIOT_COEF_FUNC)           return &rock->biot_coef;
     if (type == ABC_ANGLE_INT_FRIC_FUNC)      return &rock->angle_fric;
     if (type == ABC_COHESIVE_STRENGTH_FUNC)   return &rock->cohesive_str;
     if (type == ABC_ROCK_STRENGTH_FUNC)       return &rock->rock_strength;
     if (type == ABC_FRAC_LIM_FUNC)            return &rock->frac_lim;
     if (type == ABC_FRAC_FAC_FUNC)            return &rock->frac_fac;

     return NULL;
}


const char *abc_get_rock_prop_name_by_type(
     int type)
{
     if (type == ABC_POROSITY_FUNC)            return "porosity";
     if (type == ABC_PERM_FUNC)                return "permeability";
     if (type == ABC_PERM_X_FUNC)              return "permeability_x";
     if (type == ABC_PERM_Y_FUNC)              return "permeability_y";
     if (type == ABC_PERM_Z_FUNC)              return "permeability_z";
     if (type == ABC_HEAT_COND_FUNC)           return "heat_conductivity";
     if (type == ABC_HEAT_COND_X_FUNC)         return "heat_conductivity_x";
     if (type == ABC_HEAT_COND_Y_FUNC)         return "heat_conductivity_y";
     if (type == ABC_HEAT_COND_Z_FUNC)         return "heat_conductivity_z";
     if (type == ABC_HEAT_CAP_FUNC)            return "heat_capacity";
     if (type == ABC_DENSITY_FUNC)             return "density";
     if (type == ABC_E_FUNC)                   return "Youngs_modulus";
     if (type == ABC_NU_FUNC)                  return "Poisson_ratio";
     if (type == ABC_BIOT_COEF_FUNC)           return "Biot_coefficient";
     if (type == ABC_ANGLE_INT_FRIC_FUNC)      return "angle_friction";
     if (type == ABC_COHESIVE_STRENGTH_FUNC)   return "cohesive_strength";
     if (type == ABC_ROCK_STRENGTH_FUNC)       return "rock_strength";
     if (type == ABC_FRAC_LIM_FUNC)            return "fracture_limit";
     if (type == ABC_FRAC_FAC_FUNC)            return "fracture_factor";

     return "undefined";
}


AbcRockProp *abc_get_rock_prop_by_name(
     AbcRock *rock,
     const char *name)
{
     int type = abc_get_rock_prop_type_by_name(name);
     AbcRockProp *prop = abc_get_rock_prop_by_type(rock, type);
     return prop;
}


int abc_read_rock_prop_params(
     AbcInput *in,
     AbcRockProp *prop)
{
     int i = 0;
     char name[MAX_WORD], word[MAX_WORD];

     prop->n_params = 0;
     prop->table = NULL;
     strcpy(prop->table_name, "");

     if (not abc_get_word(in, name, MAX_WORD) or not ABC_MATCH(name, "{"))
          RETURN_FALSE(in, "Missing \'{\' !!");

     while (abc_get_word(in, name, MAX_WORD) and (not ABC_MATCH(name, "}")))
     {
          if (ABC_MATCH(name, ",") and not abc_get_word(in, name, MAX_WORD))
               RETURN_FALSE(in, "Expected a parameter name after comma!");

          if (i >= ABC_MAX_ROCK_PARAMS)
               RETURN_FALSE(in, "Too many rock parameters!");

          if (not abc_get_word(in, word, MAX_WORD) or not ABC_MATCH(word, "="))
               RETURN_FALSE(in, "Expected \'=\' !!\n");

          if (ABC_MATCH(name, "table"))
          {
               if (not abc_get_word(in, prop->table_name, MAX_WORD))
                    RETURN_FALSE(in, "Expected a table name!");

               prop->table = abc_get_rock_prop_table(current_lib, prop->table_name);

               if (prop->table == NULL)
                    RETURN_FALSE(in, "Unknown table!");
          }
          else
          {
               strcpy(prop->param[i].name, name);

               if (not abc_get_double(in, &(prop->param[i].value)))
                    RETURN_FALSE(in, "Expected a number!");
 
               prop->param[i].is_used = FALSE;
               i++;
          }
     }

     if (not ABC_MATCH(name, "}"))
          RETURN_FALSE(in, "Missing \'}\' !!");

     prop->n_params = i;
     return TRUE;
}


AbcTable *abc_get_rock_prop_table(
     AbcRockLib *lib,
     const char *name)
{
     int i;

     if (lib == NULL)
          return NULL;

     for (i = 0; i < lib->n_tables; i++)
          if (ABC_MATCH(lib->table[i]->name, name))
               return lib->table[i];

     return NULL;
}


int abc_set_prop_param_values(
     AbcRockProp *pdef,
     AbcRockProp *values)
{
     int i;
     int OK = TRUE;

     strcpy(pdef->func, values->func);
     strcpy(pdef->table_name, values->table_name);
     pdef->table = values->table;

     for (i = 0; i < pdef->n_params; i++)
     {
          const char *name = pdef->param[i].name;
          AbcRockParam *pval = abc_get_rock_prop_param(values, name);

          if (pval == NULL)
          {
               fprintf(stderr, "Error: Missing parameter: %s for: %s\n", 
                    name, pdef->name);
               return FALSE;
          }

          if (not abc_assign_rock_param_value(&pdef->param[i], pval))
          {
               fprintf(stderr, "Error: Illegal parameter: %s for: %s\n", 
                    name, pdef->name);
               return FALSE;

          }
     }

     for (i = 0; i < values->n_params; i++)
          if (not values->param[i].is_used)
          {
               fprintf(stderr, "Warning: Unused parameter: %s=%g\n", 
                    values->param[i].name, values->param[i].value);
               OK = FALSE;
          }

     return OK;
}


AbcRockParam *abc_get_rock_prop_param(
     AbcRockProp *p1,
     const char *name)
{
     int i;

     for (i = 0; i < p1->n_params; i++)
     {
          const char *name1 = p1->param[i].name;
          if (ABC_MATCH(name, name1)) return &(p1->param[i]);
     }

     return NULL;
}


int abc_assign_rock_param_value(
     AbcRockParam *param, 
     AbcRockParam *pval) 
{
     double value = pval->value;

     if (do_range_checking and (value < param->min_value))
     {
          fprintf(stderr, "Error: %s=%g is less than legal min=%g!\n", 
               param->name, value, param->min_value);
          return FALSE;
     }

     if (do_range_checking and (value > param->max_value))
     {
          fprintf(stderr, "Error: %s=%g is larger than legal max=%g!\n", 
               param->name, value, param->max_value);
          return FALSE;
     }
          
     param->value = value;
     param->is_used = TRUE;
     pval->is_used = TRUE;

     return TRUE;
}


void abc_set_rock_prop(
     AbcRockProp *prop,
     int type,
     const char *unit,
     ABC_GET_ROCK_PROP get)
{
     prop->n_params = 0;
     prop->type = type;
     prop->get = get;
     prop->print = NULL;
     strcpy(prop->unit, unit);
}


void abc_def_rock_prop_param(
     AbcRockProp *prop,
     int i,
     const char *name,
     const char *unit,
     double default_value,
     double min_value,
     double max_value)
{
     if ((i < 0) or (ABC_MAX_ROCK_PARAMS <= i))
          ERROR_EXIT("Illegal rock parameter index!");

     if (i != prop->n_params)
          ERROR_EXIT("Rock parameter indices must be in increasing order!");

     strcpy(prop->param[i].name, name);
     strcpy(prop->param[i].unit, unit);
     prop->param[i].value = 0.0;
     prop->param[i].default_value = default_value;
     prop->param[i].min_value = min_value;
     prop->param[i].max_value = max_value;
     prop->n_params++;
}


int abc_all_rocks_in_lib_have_prop(
     AbcRockLib *lib,
     int type,
     int only_needed)
{
     int i;
     int errors = 0;
     const char *prop_name = abc_get_rock_prop_name_by_type(type);

     for (i = 0; i < lib->n_rocks; i++)
     {
          AbcRock *rock = &(lib->rock[i]);

          if (only_needed and not rock->is_needed) continue;

          if (not abc_rock_has_prop_by_type(rock, type))
          {
               printf("Error: Rock \"%s\" is missing: %s!\n", rock->name, prop_name);
               errors++;
          }
     }

     if (errors > 1)
          printf("%d rocks are missing the property: %s!\n", errors, prop_name);

     if (errors > 0) 
          return FALSE;

     return TRUE;
}


int abc_is_ok_rock_lib(
     AbcRockLib *lib)
{
     int i;
     int errors = 0;

     for (i = 0; i < lib->n_rocks; i++)
          if (not abc_is_complete_rock(&lib->rock[i]))
               errors++;

     return (errors == 0);
}

#define RETURN_FALSE_PROP(prop, rock) {\
     fprintf(stderr, "Error: Missing \"%s\" for rock \"%s\"!\n", prop, rock->name);\
     return FALSE;\
}\

int abc_is_complete_rock(
     AbcRock *rock)
{
     int errors = 0;

     errors += is_missing_prop(rock, ABC_POROSITY_FUNC);
     errors += is_missing_prop(rock, ABC_PERM_FUNC);
     errors += is_missing_prop(rock, ABC_HEAT_COND_FUNC);
     errors += is_missing_prop(rock, ABC_HEAT_CAP_FUNC);
     errors += is_missing_prop(rock, ABC_DENSITY_FUNC);
     errors += is_missing_prop(rock, ABC_E_FUNC);
     errors += is_missing_prop(rock, ABC_NU_FUNC);
     errors += is_missing_prop(rock, ABC_BIOT_COEF_FUNC);

     return (errors == 0);
}


static int is_missing_prop(
     AbcRock *rock,
     int type)
{
     const char *prop_name = abc_get_rock_prop_name_by_type(type);
     if (abc_rock_has_prop_by_type(rock, type)) return FALSE;
     printf("Error: Rock \"%s\" is missing: %s!\n", rock->name, prop_name);
     return TRUE;
}


int abc_is_needed_rock(
     AbcRock *rock)
{
     return rock->is_needed;
}


int abc_rock_has_prop(
     AbcRockProp *prop)
{
     return (prop->type >= 0);
}


int abc_rock_has_prop_by_name(
     AbcRock *rock,
     const char *name)
{
     AbcRockProp *prop = abc_get_rock_prop_by_name(rock, name);
     return (prop->type >= 0);
}


int abc_rock_has_prop_by_type(
     AbcRock *rock,
     int type)
{
     AbcRockProp *prop = abc_get_rock_prop_by_type(rock, type);
     return (prop->type >= 0);
}


void abc_init_rock(
     AbcRock *rock)
{
     strcpy(rock->name, "");
     rock->is_needed = FALSE;
     abc_init_rock_prop(&rock->porosity,      "porosity");
     abc_init_rock_prop(&rock->density,       "density");
     abc_init_rock_prop(&rock->heat_cap,      "heat_capacity");
     abc_init_rock_prop(&rock->perm,          "permeability");
     abc_init_rock_prop(&rock->perm_x,        "permeability_x");
     abc_init_rock_prop(&rock->perm_y,        "permeability_y");
     abc_init_rock_prop(&rock->perm_z,        "permeability_z");
     abc_init_rock_prop(&rock->heat_cond,     "heat_conductivity");
     abc_init_rock_prop(&rock->heat_cond_x,   "heat_conductivity_x");
     abc_init_rock_prop(&rock->heat_cond_y,   "heat_conductivity_y");
     abc_init_rock_prop(&rock->heat_cond_z,   "heat_conductivity_z");
     abc_init_rock_prop(&rock->E,             "Youngs_modulus");
     abc_init_rock_prop(&rock->nu,            "Poisson_ratio");
     abc_init_rock_prop(&rock->biot_coef,     "Biot_coefficient");
     abc_init_rock_prop(&rock->angle_fric,    "angle_friction");
     abc_init_rock_prop(&rock->cohesive_str,  "cohesive_strength");
     abc_init_rock_prop(&rock->frac_lim,      "fracture_limit");
     abc_init_rock_prop(&rock->frac_fac,      "fracture_factor");
     abc_init_rock_prop(&rock->rock_strength, "rock_strength");
}


void abc_init_rock_prop(
     AbcRockProp *prop,
     const char * name)
{
     prop->type = -1;
     strcpy(prop->name, name);
     strcpy(prop->func, "???");
     strcpy(prop->unit, "???");
     strcpy(prop->table_name, "???");
     prop->n_params = 0;;
     prop->print = NULL;
     prop->get = get_undefined;
     prop->rock = NULL;
     prop->table = NULL;
}


static double get_undefined(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     fprintf(stderr, "Calling an undefined get-function!\n");
     ABC_UNUSED_PARAMETER(prop);
     ABC_UNUSED_PARAMETER(arg);
     return 0.0;
}

/*
**   ==========================
**   Density: Standard function
**   ==========================
*/

#define PARAM_DENSITY          0
#define PARAM_EXPAN            1

static void def_density_std(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_DENSITY_FUNC, "kg/m3", get_density_std);
     abc_def_rock_prop_param(prop, PARAM_DENSITY, "density0", "kg/m3", 2300.0, 0.0, 6000.0);
     abc_def_rock_prop_param(prop, PARAM_EXPAN, "expan", "-", 0.0, 0.0, 1.0e-3);
}


static double get_density_std(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double dens0 = prop->param[PARAM_DENSITY].value;
     double expan = prop->param[PARAM_EXPAN].value;
     double temp = arg->temp1;
     double dens = dens0 * (1.0 - expan * temp);
     return dens;
}

#undef PARAM_DENSITY
#undef PARAM_EXPAN

/*
**   ====================
**   Porosity: Table of z
**   ====================
*/

static void def_porosity_table_z(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_POROSITY_FUNC, "-", get_porosity_table_z);
}


static double get_porosity_table_z(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double z = arg->z_depth;
     double phi;

     if (prop->table == NULL) 
          ABC_ERROR_EXIT("[get_porosity_table_z] table==NULL!");

     phi = abc_get_table_func(prop->table, z);

     return phi;
}

/*
**   ===================
**   Porosity: Athy of z
**   ===================
*/

#define PARAM_ATHY_PHI0        0
#define PARAM_ATHY_PHI_MIN     1
#define PARAM_ATHY_ALPHA_Z     2

static void def_porosity_athy_z(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_POROSITY_FUNC, "-", get_porosity_athy_z);
     abc_def_rock_prop_param(prop, PARAM_ATHY_PHI0, "phi0", "-", 0.5, 0.001, 1.0);
     abc_def_rock_prop_param(prop, PARAM_ATHY_PHI_MIN, "phi_min", "-", 0.03, 0.001, 1.0);
     abc_def_rock_prop_param(prop, PARAM_ATHY_ALPHA_Z, "alpha", "1/m", 1.0e-3, 0.0, 1.0e+9);
}


static double get_porosity_athy_z(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double phi0 = prop->param[PARAM_ATHY_PHI0].value;
     double phi_min = prop->param[PARAM_ATHY_PHI_MIN].value;
     double alpha = prop->param[PARAM_ATHY_ALPHA_Z].value;
     double z = ABC_ABS(arg->z_depth);
     double phi = (phi0 - phi_min) * exp(- alpha * z) + phi_min;
     return phi;
}

#undef PARAM_ATHY_PHI0
#undef PARAM_ATHY_PHI_MIN
#undef PARAM_ATHY_ALPHA_Z

/*
**   ======================
**   Porosity: Athy of zeta
**   ======================
*/

#define PARAM_ATHY_PHI0        0
#define PARAM_ATHY_PHI_MIN     1
#define PARAM_ATHY_ALPHA_ZETA  2

static void def_porosity_athy_zeta(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_POROSITY_FUNC, "-", get_porosity_athy_zeta);
     abc_def_rock_prop_param(prop, PARAM_ATHY_PHI0, "phi0", "-", 0.5, 0.001, 1.0);
     abc_def_rock_prop_param(prop, PARAM_ATHY_PHI_MIN, "phi_min", "-", 0.03, 0.001, 1.0);
     abc_def_rock_prop_param(prop, PARAM_ATHY_ALPHA_ZETA, "alpha", "1/m", 1.0e-3, 0.0, 1.0e+9);
}


static double get_porosity_athy_zeta(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double phi0 = prop->param[PARAM_ATHY_PHI0].value;
     double phi_min = prop->param[PARAM_ATHY_PHI_MIN].value;
     double alpha = prop->param[PARAM_ATHY_ALPHA_ZETA].value;
     double zeta = arg->zeta_depth;
     double phi = (phi0 - phi_min) * exp(- alpha * zeta) + phi_min;
     return phi;
}

#undef PARAM_ATHY_PHI0
#undef PARAM_ATHY_PHI_MIN
#undef PARAM_ATHY_ALPHA_ZETA

/*
**   ====================
**   Porosity: Athy of ps
**   ====================
*/

#define PARAM_ATHY_PHI0        0
#define PARAM_ATHY_PHI_MIN     1
#define PARAM_ATHY_ALPHA_PS    2

static void def_porosity_athy_ps(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_POROSITY_FUNC, "-", get_porosity_athy_ps);
     abc_def_rock_prop_param(prop, PARAM_ATHY_PHI0, "phi0", "-", 0.5, 0.001, 1.0);
     abc_def_rock_prop_param(prop, PARAM_ATHY_PHI_MIN, "phi_min", "-", 0.03, 0.001, 1.0);
     abc_def_rock_prop_param(prop, PARAM_ATHY_ALPHA_PS, "alpha", "1/Pa", 1.0e-6, 0.0, 1.0e+9);
}


static double get_porosity_athy_ps(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double phi0 = prop->param[PARAM_ATHY_PHI0].value;
     double phi_min = prop->param[PARAM_ATHY_PHI_MIN].value;
     double alpha = prop->param[PARAM_ATHY_ALPHA_PS].value;
     double ps = arg->ps;
     double phi = (phi0 - phi_min) * exp(- alpha * ps) + phi_min;
     return phi;
}

#undef PARAM_ATHY_PHI0
#undef PARAM_ATHY_PHI_MIN
#undef PARAM_ATHY_ALPHA_PS

/*
**   =================================
**   Porosity: Linear void ratio of ps
**   =================================
*/

#define PARAM_LINEAR_VRATIO_E0          0
#define PARAM_LINEAR_VRATIO_EMIN        1
#define PARAM_LINEAR_VRATIO_ALPHA_PS    2

static void def_porosity_linear_void_ratio_ps(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_POROSITY_FUNC, "-", get_porosity_linear_void_ratio_ps);
     abc_def_rock_prop_param(prop, PARAM_LINEAR_VRATIO_E0, "e0", "-", 1.0, 0.001, 5.0);
     abc_def_rock_prop_param(prop, PARAM_LINEAR_VRATIO_EMIN, "emin", "-", 0.0, 0.0, 0.1);
     abc_def_rock_prop_param(prop, PARAM_LINEAR_VRATIO_ALPHA_PS, "alpha", "1/Pa", 1.0e-6, 0.0, 1.0e+9);
}


static double get_porosity_linear_void_ratio_ps(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double e0 = prop->param[PARAM_LINEAR_VRATIO_E0].value;
     double emin = prop->param[PARAM_LINEAR_VRATIO_EMIN].value;
     double alpha = prop->param[PARAM_LINEAR_VRATIO_ALPHA_PS].value;
     double ps = arg->ps;
     double e1 = e0 - alpha * ps;
     double phi;

     if (e1 < emin) e1 = emin;
     phi = e1 / (1.0 + e1);

     return phi;
}

#undef PARAM_LINEAR_VRATIO_E0
#undef PARAM_LINEAR_VRATIO_EMIN
#undef PARAM_LINEAR_VRATIO_ALPHA_PS

/*
**   ==========================================
**   heat conductivity: heat_cond_harmonic_mean
**   ==========================================
*/

#define PARAM_LAMBDA_SOLID    0
#define PARAM_LAMBDA_COEF1    1
#define PARAM_LAMBDA_COEF2    2

static void def_heat_cond_harmonic_mean(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_HEAT_COND_FUNC, "W/mK", get_heat_cond_harmonic_mean);
     abc_def_rock_prop_param(prop, PARAM_LAMBDA_SOLID, "lambda", "W/mK", 3.0, 0.001, 10.0);
     abc_def_rock_prop_param(prop, PARAM_LAMBDA_COEF1, "c1", "1/K", 0.0, 0.0, 0.5);
     abc_def_rock_prop_param(prop, PARAM_LAMBDA_COEF2, "c2", "1/K2", 0.0, 0.0, 0.05);
}

static double get_heat_cond_harmonic_mean(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double ls = prop->param[PARAM_LAMBDA_SOLID].value;
     double c1 = prop->param[PARAM_LAMBDA_COEF1].value;
     double c2 = prop->param[PARAM_LAMBDA_COEF2].value;
     double temp = arg->temp1;
     double heat_cond_fluid = arg->heat_cond_fluid;
     double heat_cond_solid = ls * (1.0 + c1 * temp + c2 * temp * temp);
     double phi = arg->phi;
     double f1 = pow(heat_cond_fluid, phi);
     double f2 = pow(heat_cond_solid, 1.0 - phi);
     double heat_cond_bulk = f1 * f2;
     return heat_cond_bulk;
}

#undef PARAM_LAMBDA_SOLID
#undef PARAM_LAMBDA_COEF1
#undef PARAM_LAMBDA_COEF2

/*
**   ========================================
**   heat conductivity: heat_cond_linear_mean
**   ========================================
*/

#define PARAM_LAMBDA_SOLID    0
#define PARAM_LAMBDA_COEF1    1
#define PARAM_LAMBDA_COEF2    2

static void def_heat_cond_linear_mean(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_HEAT_COND_FUNC, "W/mK", get_heat_cond_linear_mean);
     abc_def_rock_prop_param(prop, PARAM_LAMBDA_SOLID, "lambda", "W/mK", 3.0, 0.001, 10.0);
     abc_def_rock_prop_param(prop, PARAM_LAMBDA_COEF1, "c1", "1/K", 0.0, 0.0, 0.5);
     abc_def_rock_prop_param(prop, PARAM_LAMBDA_COEF2, "c2", "1/K2", 0.0, 0.0, 0.05);
}

static double get_heat_cond_linear_mean(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double ls = prop->param[PARAM_LAMBDA_SOLID].value;
     double c1 = prop->param[PARAM_LAMBDA_COEF1].value;
     double c2 = prop->param[PARAM_LAMBDA_COEF2].value;
     double temp = arg->temp1;
     double heat_cond_fluid = arg->heat_cond_fluid;
     double heat_cond_solid = ls * (1.0 + c1 * temp + c2 * temp * temp);
     double phi = arg->phi;
     double f1 = heat_cond_fluid * phi;
     double f2 = heat_cond_solid *(1.0 - phi);
     double heat_cond_bulk = f1 + f2;
     return heat_cond_bulk;
}

#undef PARAM_LAMBDA_SOLID
#undef PARAM_LAMBDA_COEF1
#undef PARAM_LAMBDA_COEF2

/*
**   ==================================
**   heat conductivity: heat_cond_const
**   ==================================
*/

#define PARAM_LAMBDA_SOLID    0

static void def_heat_cond_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_HEAT_COND_FUNC, "W/mK", get_heat_cond_const);
     abc_def_rock_prop_param(prop, PARAM_LAMBDA_SOLID, "lambda", "W/mK", 3.0, 0.001, 10.0);
}


static double get_heat_cond_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double ls = prop->param[PARAM_LAMBDA_SOLID].value;
     ABC_UNUSED_PARAMETER(arg);
     return ls;
}

#undef PARAM_LAMBDA_SOLID

/*
**   ===========================
**   Permeability: Kozeny_Carman
**   ===========================
*/

#define PARAM_PERM_K0    0
#define PARAM_PERM_KMIN  1
#define PARAM_PERM_C     2
#define PARAM_PERM_EXP   3

static void def_perm_Kozeny_Carman(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_PERM_FUNC, "m2", get_perm_Kozeny_Carman);
     abc_def_rock_prop_param(prop, PARAM_PERM_K0, "k0", "m2", 1.0e-15, 1.0e-25, 1.0);
     abc_def_rock_prop_param(prop, PARAM_PERM_KMIN, "kmin", "m2", 1.0e-23, 0.0, 1.0);
     abc_def_rock_prop_param(prop, PARAM_PERM_C, "C", "-", 1.0, 0.1, 100.0);
     abc_def_rock_prop_param(prop, PARAM_PERM_EXP, "exp", "-", 1.0, 1.0e-9, 12.0);
}


static double get_perm_Kozeny_Carman(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double kmin = prop->param[PARAM_PERM_KMIN].value;
     double k0 = prop->param[PARAM_PERM_K0].value;
     double C0 = prop->param[PARAM_PERM_C].value;
     double nn = prop->param[PARAM_PERM_EXP].value;
     double phi = arg->phi;
     double f1 = k0 * pow(phi, nn);
     double f2 = C0 * (1.0 - phi);
     double perm = f1 / f2;
     if (perm < kmin) perm = kmin;
     return perm;
}

#undef PARAM_PERM_K0
#undef PARAM_PERM_KMIN
#undef PARAM_PERM_C
#undef PARAM_PERM_EXP

/*
**   ==========================
**   Permeability: Exp-function
**   ==========================
*/

#define PARAM_PERM_K0    0
#define PARAM_PERM_C0    1

static void def_perm_exp_of_phi(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_PERM_FUNC, "m2", get_perm_exp_of_phi);
     abc_def_rock_prop_param(prop, PARAM_PERM_K0, "k0", "m2", 1.0e-15, 1.0e-25, 1.0);
     abc_def_rock_prop_param(prop, PARAM_PERM_C0, "c0", "-", 1.0, 0.0, 100.0);
}


static double get_perm_exp_of_phi(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double k0 = prop->param[PARAM_PERM_K0].value;
     double c0 = prop->param[PARAM_PERM_C0].value;
     double phi = arg->phi;
     double perm = k0 * exp(c0 * phi);
     return perm;
}

#undef PARAM_PERM_K0
#undef PARAM_PERM_C0

/*
**   ============================
**   Permeability: Exp10-function
**   ============================
*/

#define PARAM_PERM_A0    0
#define PARAM_PERM_B0    1

static void def_perm_exp10_of_phi(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_PERM_FUNC, "m2", get_perm_exp10_of_phi);
     abc_def_rock_prop_param(prop, PARAM_PERM_A0, "a0", "-", 1.0, 0.0, 100.0);
     abc_def_rock_prop_param(prop, PARAM_PERM_B0, "b0", "-", -15.0, -24.0, 0.0);
}


static double get_perm_exp10_of_phi(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double a0 = prop->param[PARAM_PERM_A0].value;
     double b0 = prop->param[PARAM_PERM_B0].value;
     double phi = arg->phi;
     double log_perm = a0 * phi + b0;
     double perm = exp(log(10.0) * log_perm);
     return perm;
}

#undef PARAM_PERM_A0
#undef PARAM_PERM_B0

/*
**   ===================
**   Permeability: Const
**   ===================
*/

#define PARAM_PERM_K0    0

static void def_perm_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_PERM_FUNC, "m2", get_perm_const);
     abc_def_rock_prop_param(prop, PARAM_PERM_K0, "k0", "m2", 1.0e-15, 1.0e-25, 1.0);
}


static double get_perm_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double perm = prop->param[PARAM_PERM_K0].value;
     ABC_UNUSED_PARAMETER(arg);
     return perm;
}

#undef PARAM_PERM_K0

/*
**   ====================
**   Permeability: Gibson
**   ====================
*/

#define PARAM_PERM_K0    0
#define PARAM_PERM_N0    1
#define PARAM_PERM_KMIN  2

static void def_perm_Gibson(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_PERM_FUNC, "m2", get_perm_Gibson);
     abc_def_rock_prop_param(prop, PARAM_PERM_K0, "k0", "m2", 1.0e-15, 1.0e-25, 1.0);
     abc_def_rock_prop_param(prop, PARAM_PERM_N0, "exp", "-", 0.0, 0.0, 10.0);
     abc_def_rock_prop_param(prop, PARAM_PERM_KMIN, "kmin", "m2", 1.0e-23, 0.0, 1.0);
}


static double get_perm_Gibson(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double k0 = prop->param[PARAM_PERM_K0].value;
     double n0 = prop->param[PARAM_PERM_N0].value;
     double kmin = prop->param[PARAM_PERM_KMIN].value;
     double phi = arg->phi;
     double e1 = phi / (1.0 - phi);
     double perm = k0 * (1.0 + e1) * pow(e1, n0);
     if (perm < kmin) perm = kmin;
     return perm;
}

#undef PARAM_PERM_K0
#undef PARAM_PERM_N0
#undef PARAM_PERM_KMIN

/*
**   ====================
**   Heat capacity: Const
**   ====================
*/

#define PARAM_PERM_C0    0

static void def_heat_cap_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_HEAT_CAP_FUNC, "J/kgK", get_heat_cap_const);
     abc_def_rock_prop_param(prop, PARAM_PERM_C0, "C0", "J/kgK", 1.0e+3, 1.0e+3, 100.0e+3);
}


static double get_heat_cap_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double perm = prop->param[PARAM_PERM_C0].value;
     ABC_UNUSED_PARAMETER(arg);
     return perm;
}

#undef PARAM_PERM_C0

/*
**   =====================
**   Youngs modulus: const
**   =====================
*/

#define PARAM_CONST_E    0

static void def_youngs_modulus_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_E_FUNC, "1/Pa", get_youngs_modulus_const);
     abc_def_rock_prop_param(prop, PARAM_CONST_E, "E", "1/Pa", 1.0e+9, 0.0, 1.0e+25);
}


static double get_youngs_modulus_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double E = prop->param[PARAM_CONST_E].value;
     ABC_UNUSED_PARAMETER(arg);
     return E;
}

#undef PARAM_CONST_E

/*
**   ====================
**   Possion ratio: const
**   ====================
*/

#define PARAM_CONST_NU    0

static void def_poisson_ratio_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_NU_FUNC, "-", get_poisson_ratio_const);
     abc_def_rock_prop_param(prop, PARAM_CONST_NU, "nu", "-", 0.2, 0.0, 1.0);
}


static double get_poisson_ratio_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double nu = prop->param[PARAM_CONST_NU].value;
     ABC_UNUSED_PARAMETER(arg);
     return nu;
}

#undef PARAM_CONST_NU

/*
**   =======================
**   Biot coefficient: const
**   =======================
*/

#define PARAM_CONST_BIOT_COEF    0

static void def_biot_coef_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_BIOT_COEF_FUNC, "-", get_biot_coef_const);
     abc_def_rock_prop_param(prop, PARAM_CONST_BIOT_COEF, "Biot_coef", "-", 1.0, 0.0, 2.0);
}


static double get_biot_coef_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double biot_coef = prop->param[PARAM_CONST_BIOT_COEF].value;
     ABC_UNUSED_PARAMETER(arg);
     return biot_coef;
}

#undef PARAM_CONST_BIOT_COEF

/*
**   =================================
**   Angle of internal friction: const
**   =================================
*/

#define PARAM_CONST_ANGLE    0

static void def_angle_internal_friction(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_ANGLE_INT_FRIC_FUNC, "-", get_angle_internal_friction);
     abc_def_rock_prop_param(prop, PARAM_CONST_ANGLE, "phi", "-", 30.0, 0.0, 90.0);
}


static double get_angle_internal_friction(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double biot_coef = prop->param[PARAM_CONST_ANGLE].value;
     ABC_UNUSED_PARAMETER(arg);
     return biot_coef;
}

#undef PARAM_CONST_ANGLE

/*
**   ========================
**   Cohesive strength: const
**   ========================
*/

#define PARAM_STRENGTH    0

static void def_cohesive_strength(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_COHESIVE_STRENGTH_FUNC, "-", get_cohesive_strength);
     abc_def_rock_prop_param(prop, PARAM_STRENGTH, "c0", "Pa", 0.0, 0.0, 1.0e+10);
}


static double get_cohesive_strength(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double biot_coef = prop->param[PARAM_STRENGTH].value;
     ABC_UNUSED_PARAMETER(arg);
     return biot_coef;
}

#undef PARAM_STRENGTH

/*
**   ====================
**   Rock strength: const
**   ====================
*/

#define PARAM_ROCK_STRENGTH_CONST        0

static void def_rock_strength_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_ROCK_STRENGTH_FUNC, "-", get_rock_strength_const);
     abc_def_rock_prop_param(prop, PARAM_ROCK_STRENGTH_CONST, "s0", "-", 0.0, 0.0, 1.0e+19);
}


static double get_rock_strength_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double fac = prop->param[PARAM_ROCK_STRENGTH_CONST].value;
     ABC_UNUSED_PARAMETER(arg);
     return fac;
}

#undef PARAM_ROCK_STRENGTH_CONST

/*
**   ==================================
**   Fracture fluid pressure limit: std
**   ==================================
*/

#define PARAM_FRAC_LIM_COEF         0
#define PARAM_FRAC_LIM_COHESION     1

static void def_frac_lim_std(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_FRAC_LIM_FUNC, "-", get_frac_lim_std);
     abc_def_rock_prop_param(prop, PARAM_FRAC_LIM_COEF, "sigma1_coef", "-", 0.7, 0.0, 1000.0);
     abc_def_rock_prop_param(prop, PARAM_FRAC_LIM_COHESION,  "cohesion", "Pa", 0.0, 0.0, 1.0e+9);
}


static double get_frac_lim_std(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double sigma1_coef = prop->param[PARAM_FRAC_LIM_COEF].value;
     double cohesion = prop->param[PARAM_FRAC_LIM_COHESION].value;
     double pf_lim = (sigma1_coef * arg->pb) + cohesion;
     double pe_lim = pf_lim - arg->ph;

     return pe_lim;
}

#undef PARAM_FRAC_LIM_COEF
#undef PARAM_FRAC_LIM_COHESION

/*
**   ======================
**   Fracture factor: const
**   ======================
*/

#define PARAM_FRAC_FAC_CONST        0

static void def_frac_fac_const(
     AbcRockProp *prop)
{
     abc_set_rock_prop(prop, ABC_FRAC_FAC_FUNC, "-", get_frac_fac_const);
     abc_def_rock_prop_param(prop, PARAM_FRAC_FAC_CONST, "factor", "-", 1.0, 0.0, 1.0e+19);
}


static double get_frac_fac_const(
     AbcRockProp *prop,
     AbcRockArg *arg)
{
     double fac = prop->param[PARAM_FRAC_FAC_CONST].value;
     ABC_UNUSED_PARAMETER(arg);
     return fac;
}

#undef PARAM_FRAC_FAC_CONST

